@echo off
set PATH=..\Install;C:\Program Files\PostgreSQL\8.3\bin;%PATH%
%1
if errorlevel 1 goto VCReportError
goto VCEnd
:VCReportError
exit 1
:VCEnd
