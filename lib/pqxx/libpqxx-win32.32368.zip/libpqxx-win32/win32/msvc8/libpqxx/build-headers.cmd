@echo off
xcopy /i /d /y %1..\..\config\sample-headers\compiler\VisualC++.NET-2003\*.* pqxx
xcopy /d /y %1..\..\config\sample-headers\libpq\8.1\*.* pqxx
xcopy /d /y %1..\..\include\pqxx pqxx
