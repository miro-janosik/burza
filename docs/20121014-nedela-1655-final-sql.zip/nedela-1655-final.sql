--
-- PostgreSQL database dump
--

-- Started on 2012-10-14 16:57:11 CEST

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 140 (class 1259 OID 16418)
-- Dependencies: 1785 3
-- Name: item_category; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE item_category (
    "ID" integer DEFAULT (-1) NOT NULL,
    "LETTER" character(1),
    "NAME" text,
    "FEE_PER_ITEM" double precision
);


ALTER TABLE public.item_category OWNER TO postgres;

--
-- TOC entry 1819 (class 0 OID 0)
-- Dependencies: 140
-- Name: TABLE item_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE item_category IS 'Item categories.';


--
-- TOC entry 141 (class 1259 OID 16427)
-- Dependencies: 1786 1787 1788 1789 1790 1791 1792 3
-- Name: items; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE items (
    "ITEM_ID" integer DEFAULT (-1) NOT NULL,
    "NAME" text,
    "SELLER_ID" integer DEFAULT (-1) NOT NULL,
    "PRICE" double precision DEFAULT 0.0 NOT NULL,
    "CHANGING" boolean DEFAULT false NOT NULL,
    "CHANGED_BY" text,
    "ITEM_CATEGORY_ID" integer DEFAULT (-1),
    "NUMBER" integer,
    "STATUS" integer DEFAULT 0 NOT NULL,
    "MODIFIED" timestamp with time zone DEFAULT '2000-01-01 01:02:03'::timestamp without time zone NOT NULL
);


ALTER TABLE public.items OWNER TO postgres;

--
-- TOC entry 1821 (class 0 OID 0)
-- Dependencies: 141
-- Name: TABLE items; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE items IS 'List of all items of all sellers.';


--
-- TOC entry 142 (class 1259 OID 16442)
-- Dependencies: 1793 1794 1795 1796 1797 1798 3
-- Name: seller_category; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE seller_category (
    "ID" integer DEFAULT (-1) NOT NULL,
    "LETTER" character(1),
    "NAME" text,
    "FEE" double precision DEFAULT 0,
    "FEE_SOLD_PERC" double precision DEFAULT 0,
    "FEE_SOLD_ITEM" double precision DEFAULT 0,
    "FEE_ITEM" double precision DEFAULT 0,
    "FEE_ITEM_PERC" double precision DEFAULT 0
);


ALTER TABLE public.seller_category OWNER TO postgres;

--
-- TOC entry 1823 (class 0 OID 0)
-- Dependencies: 142
-- Name: TABLE seller_category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE seller_category IS 'Seller categories.';


--
-- TOC entry 1824 (class 0 OID 0)
-- Dependencies: 142
-- Name: COLUMN seller_category."FEE"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN seller_category."FEE" IS 'Fee is {value}.';


--
-- TOC entry 1825 (class 0 OID 0)
-- Dependencies: 142
-- Name: COLUMN seller_category."FEE_SOLD_PERC"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN seller_category."FEE_SOLD_PERC" IS 'Fee is {value}% of the price of all sold items.';


--
-- TOC entry 1826 (class 0 OID 0)
-- Dependencies: 142
-- Name: COLUMN seller_category."FEE_SOLD_ITEM"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN seller_category."FEE_SOLD_ITEM" IS 'Fee is {value} for every sold item.';


--
-- TOC entry 1827 (class 0 OID 0)
-- Dependencies: 142
-- Name: COLUMN seller_category."FEE_ITEM"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN seller_category."FEE_ITEM" IS 'Fee is {value} for every item.';


--
-- TOC entry 1828 (class 0 OID 0)
-- Dependencies: 142
-- Name: COLUMN seller_category."FEE_ITEM_PERC"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN seller_category."FEE_ITEM_PERC" IS 'Fee is {value}% of price for every item.';


--
-- TOC entry 143 (class 1259 OID 16456)
-- Dependencies: 1799 1800 1801 1802 3
-- Name: sellers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sellers (
    "SELLER_ID" integer NOT NULL,
    "SHORT_CODE" text,
    "NAME" text,
    "COMMENT" text,
    "CHANGING" boolean DEFAULT false NOT NULL,
    "CHANGED_BY" text,
    "SELLER_CATEGORY_ID" integer DEFAULT (-1),
    "MODIFIED" timestamp with time zone DEFAULT '2000-01-01 01:02:03'::timestamp without time zone NOT NULL,
    "STATUS" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.sellers OWNER TO postgres;

--
-- TOC entry 1830 (class 0 OID 0)
-- Dependencies: 143
-- Name: TABLE sellers; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE sellers IS 'List of sellers.';


--
-- TOC entry 1811 (class 0 OID 16418)
-- Dependencies: 140
-- Data for Name: item_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY item_category ("ID", "LETTER", "NAME", "FEE_PER_ITEM") FROM stdin;
\.


--
-- TOC entry 1812 (class 0 OID 16427)
-- Dependencies: 141
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY items ("ITEM_ID", "NAME", "SELLER_ID", "PRICE", "CHANGING", "CHANGED_BY", "ITEM_CATEGORY_ID", "NUMBER", "STATUS", "MODIFIED") FROM stdin;
56	fialové rukavice	2	1	f	-	0	5	1	2012-10-13 12:47:27+02
57	tričko dlhý rukáv kakhi	2	1	f	-	0	6	1	2012-10-13 12:47:27+02
58	pančušky 3ks 	2	1.5	f	-	0	7	1	2012-10-13 12:47:27+02
59	ružové rukavice	2	1	f	-	0	8	1	2012-10-13 12:47:27+02
5	ružová mikina next	1	1	f	-	0	4	2	2012-10-13 15:45:41+02
70	dupačky biele myškai	2	1	f	-	0	19	2	2012-10-13 16:02:17+02
23	ružová prúžkovaná čiapka s medvedíkmi	1	1	f	-	0	22	2	2012-10-13 17:47:00+02
63	fialové pyžamo	2	1.5	f	-	0	12	1	2012-10-13 12:47:27+02
64	menžestrová sukńa	2	1	f	-	0	13	1	2012-10-13 12:47:27+02
65	ružové tepláky	2	0.5	f	-	0	14	1	2012-10-13 12:47:27+02
66	ružové tepláky	2	0.5	f	-	0	15	1	2012-10-13 12:47:27+02
67	pančušky 3ks 	2	1	f	-	0	16	1	2012-10-13 12:47:27+02
68	ružové pyžamo flanelové	2	1	f	-	0	17	2	2012-10-13 19:19:16+02
69	ružové papučky roháčan 24	2	1	f	-	0	18	1	2012-10-13 12:47:27+02
2	nohavice 2ks, hnedé a retro č. 92	1	2	f	-	0	1	2	2012-10-13 16:20:44+02
71	dupačky biele  	2	1	f	-	0	20	1	2012-10-13 12:47:27+02
73	dupačky žlté	2	1	f	-	0	22	1	2012-10-13 12:47:27+02
74	dupačky biele	2	1	f	-	0	23	1	2012-10-13 12:47:27+02
75	body 2ks farebné 	2	1	f	-	0	24	1	2012-10-13 12:47:27+02
76	oranžové pásikové štucne	2	1	f	-	0	25	1	2012-10-13 12:47:27+02
49	fialová háčkovaná čiapka s mašličkou	1	1.5	f	-	0	48	2	2012-10-13 18:07:21+02
77	čiapka ružová	2	1	f	-	0	26	2	2012-10-13 17:47:00+02
54	staroružová háčkovaná čiapka	2	1.5	f	-	0	3	2	2012-10-14 11:31:31+02
80	fialové legíny prúžkované	2	1	f	-	0	29	1	2012-10-13 12:47:27+02
81	farebné pyžamové nohavice	2	1	f	-	0	30	1	2012-10-13 12:47:27+02
82	červené tričko dlhý rukáv	2	1	f	-	0	31	1	2012-10-13 12:47:27+02
83	prúžkovaný svetrík	2	1	f	-	0	32	1	2012-10-13 12:47:27+02
84	kukla merino vlna	2	3	f	-	0	33	1	2012-10-13 12:47:27+02
85	nepremokava podlozka zelena medvedici	2	1	f	-	0	34	1	2012-10-13 12:47:27+02
86	nepremokava podlozka zlta medvedici	2	1	f	-	0	35	1	2012-10-13 12:47:27+02
38	2ks tričká dlhý rukáv, béžové, fialové	1	2	f	-	0	37	2	2012-10-13 15:33:00+02
45	vianočný overal a čiapka prúžkovaný	1	2	f	-	0	44	2	2012-10-13 16:25:44+02
3	oranžová čiapka	1	0.5	f	-	0	2	1	2012-10-12 21:57:26+02
31	šedý rolák 	1	1	f	-	0	30	2	2012-10-13 19:04:25+02
21	ružové legíny	1	1	f	-	0	20	2	2012-10-13 15:46:42+02
6	starorúžový rolákový sveter č. 224	1	2	f	-	0	5	1	2012-10-12 22:51:12+02
53	tmavomodrá háčkovaná čiapika	2	1.5	f	-	0	2	1	2012-10-13 12:47:27+02
10	teplé šaty kvetinové 	1	0.5	f	-	0	9	1	2012-10-12 22:50:11+02
7	menžestrové nohavice béžovč č. 80	1	1	f	-	0	6	1	2012-10-12 22:49:45+02
43	čiapka ružová 	1	1	f	-	0	42	2	2012-10-13 18:53:01+02
11	tričko dlhý rukáv s dievčatkom a kvetmi	1	1	f	-	0	10	1	2012-10-12 21:57:37+02
62	body 2ks farebné 	2	1	f	-	0	11	2	2012-10-13 16:46:23+02
12	ružová mikina s kapucou 30m	1	1	f	-	0	11	2	2012-10-13 16:34:29+02
14	štrikovaný modro bieli sveter	1	1	f	-	0	13	1	2012-10-12 21:57:37+02
15	rifle	1	1	f	-	0	14	1	2012-10-12 21:57:37+02
16	rifle	1	1	f	-	0	15	1	2012-10-12 21:57:37+02
17	rifle	1	1	f	-	0	16	1	2012-10-12 21:57:37+02
18	ružový overal č. 62-68	1	3	f	-	0	17	1	2012-10-12 21:57:37+02
78	čiapka fialová prúžkovaná	2	1	f	-	0	27	2	2012-10-13 17:47:00+02
20	nohavice prúžkované 	1	1	f	-	0	19	1	2012-10-12 21:57:37+02
61	body 2ks farebné 	2	1	f	-	0	10	2	2012-10-13 15:56:01+02
22	tričko biele  dlhý rukáv 9-12m	1	1	f	-	0	21	1	2012-10-12 21:57:37+02
19	bele capačky teplé 	1	0.5	f	-	0	18	2	2012-10-13 17:47:00+02
24	pyžamo fialové	1	1.5	f	-	0	23	1	2012-10-12 21:57:37+02
25	rúžovo biele nohavice 	1	1	f	-	0	24	1	2012-10-12 21:57:37+02
26	ružová mikina č. 62	1	1	f	-	0	25	1	2012-10-12 21:57:37+02
27	body žlté a fialové 12-18m	1	1	f	-	0	26	1	2012-10-12 21:57:37+02
4	ružová bunda s bodkami 3 až 6 m	1	3	f	-	0	3	2	2012-10-13 18:57:46+02
13	rifľová sukňa  2-3 r	1	1	f	-	0	12	2	2012-10-13 16:30:23+02
30	béžové tepláky 	1	1	f	-	0	29	1	2012-10-12 21:57:37+02
79	modré tepláky	2	1	f	-	0	28	2	2012-10-14 10:36:19+02
33	rifle	1	2	f	-	0	32	1	2012-10-12 21:57:37+02
48	pyžamo ružové 	1	2	f	-	0	47	2	2012-10-13 18:20:14+02
35	pyžamé ružové s baletkami	1	1	f	-	0	34	1	2012-10-12 21:57:37+02
36	ružová mikina 12-18m	1	0.5	f	-	0	35	1	2012-10-12 21:57:37+02
37	pančuchy 3ks	1	1.5	f	-	0	36	1	2012-10-12 21:57:37+02
60	body 2ks farebné 	2	1	f	-	0	9	2	2012-10-13 15:40:33+02
39	pyžamo ružové a bordové 0-3m	1	1	f	-	0	38	1	2012-10-12 21:57:38+02
40	ružové papučky roháčan č. 23	1	1	f	-	0	39	1	2012-10-12 21:57:38+02
41	tielka 2ks	1	1	f	-	0	40	1	2012-10-12 21:57:38+02
42	ružové tepláky	1	1	f	-	0	41	1	2012-10-12 21:57:38+02
28	pyžamo žlté s kvetinkami  6-9m	1	1	f	-	0	27	2	2012-10-13 18:55:46+02
44	vianočný overal a čiapka prúžkovaný	1	2	f	-	0	43	1	2012-10-12 21:57:38+02
29	pyžamo ružové a modré 2ks 0-3m	1	2	f	-	0	28	2	2012-10-13 16:25:44+02
46	hnedé topánky kožené  č. 22	1	1	f	-	0	45	1	2012-10-12 22:03:09+02
47	vianočný overal a čiapka so sladkosťami	1	2	f	-	0	46	1	2012-10-12 22:03:08+02
9	červené tričko s mačičkami 2 - 3 r	1	1	f	-	0	8	2	2012-10-13 18:49:05+02
34	miky pyýžamo	1	2	f	-	0	33	2	2012-10-13 18:19:20+02
50	rifle	1	1	f	-	0	49	1	2012-10-12 21:57:38+02
51	červené legíny s hviezdičkami	1	1	f	-	0	50	1	2012-10-12 21:57:38+02
107	fialové rifle na traky veľ. 1 - 2 roky	3	3	f	-	0	6	1	2012-10-13 11:36:49+02
89	H&M deka hello kity	2	3	f	-	0	38	1	2012-10-13 12:47:27+02
90	ikea zelena deka	2	2	f	-	0	39	1	2012-10-13 12:47:27+02
94	modre tricko	2	1	f	-	0	43	1	2012-10-13 12:47:27+02
91	pancusky 2ks zelene a biele	2	1	f	-	0	40	1	2012-10-13 12:47:27+02
148	biele dupačky s ružovými pásmi a koníkom zn. Detex, veľ. 68	3	2	f	-	0	47	2	2012-10-14 10:36:19+02
95	pancusky fialove 1ks	2	0.5	f	-	0	44	1	2012-10-13 12:47:27+02
140	biele body s dlhým rukávom a myškami zn. CDRL veľ. 68	3	2	f	-	0	39	2	2012-10-13 18:53:01+02
97	nohavicky, tielko	2	1	f	-	0	46	1	2012-10-13 12:47:27+02
98	papucky rohacan c 25	2	1	f	-	0	47	1	2012-10-13 12:47:27+02
99	sveter sedy	2	1	f	-	0	48	1	2012-10-13 12:47:27+02
100	teplakova suprava oranzova c.92	2	3	f	-	0	49	1	2012-10-13 12:47:27+02
101	rohacan ruzove papucky c. 24	2	1	f	-	0	50	1	2012-10-13 12:47:27+02
93	pancusky 2ks hnede, fialove	2	1	f	-	0	42	1	2012-10-13 12:47:27+02
55	oranžová háčkovaná čipka s fialovými kvetmi 	2	3	f	-	0	4	1	2012-10-13 12:47:27+02
72	dupačky s muchotrávkovým domčekom	2	1	f	-	0	21	1	2012-10-13 12:47:27+02
130	červenobiele tepláčiky s bodkami zn. Flexi	3	2	f	-	0	29	2	2012-10-13 15:40:33+02
88	deka medvedikova patchwork	2	3	f	-	0	37	1	2012-10-13 12:47:27+02
102	ružová guličková bunda zn. NEXT, veľ. 9 - 12 M	3	8	f	-	0	1	1	2012-10-13 11:36:39+02
103	cyklaménová prechodná bunda s kapucňou zn. Okay, veľ. 74	3	5	f	-	0	2	1	2012-10-13 11:36:41+02
104	biela flísová mikinka s motýlikmi na zips zn. Cherokee, veľ. 3 - 6 M	3	4	f	-	0	3	1	2012-10-13 11:36:43+02
105	cyklaménová mikinka na zips zn. Hai Di, veľ. 9 - 12 M	3	4	f	-	0	4	1	2012-10-13 11:36:44+02
106	bieloružová dlhá mikina s kapucou zn. Okay, veľ. 80	3	4	f	-	0	5	1	2012-10-13 11:36:46+02
108	fialová šuštiaková bunda zn. Napoleone, veľ. 12 - 18 M	3	3	f	-	0	7	1	2012-10-13 11:36:51+02
109	modré hrubé rifle na traky podš. červenou látkou zn. Mackays, veľ. 74	3	4	f	-	0	8	1	2012-10-13 11:36:57+02
110	ružové menžestrové nohavice veľ. 68	3	2	f	-	0	9	1	2012-10-13 11:36:59+02
150	žlté body s dlhým rukávom zn. Tinko, veľ. 74	3	2	f	-	0	49	2	2012-10-13 18:03:40+02
112	ružový pletený svetrík na gombíčky zn. Disney, veľ. 3 - 6 M	3	4	f	-	0	11	1	2012-10-13 11:37:04+02
113	ružové polodupačky 0 - 3 M	3	4	f	-	0	12	1	2012-10-13 11:37:06+02
92	pancusky 2ks oranzove, zelene	2	1	f	-	0	41	2	2012-10-14 10:34:50+02
115	ružové pásikové dupačky s mackom 	3	4	f	-	0	14	1	2012-10-13 11:37:13+02
116	ružové pásikové dupačky s domčekom	3	3.5	f	-	0	15	1	2012-10-13 11:37:15+02
117	riflové kraťasky s hviezdičkami zn. Bhs Baby, veľ. 80	3	4	f	-	0	16	1	2012-10-13 11:37:17+02
118	ružové tepláčiky veľ. 62	3	3	f	-	0	17	1	2012-10-13 11:37:18+02
119	červené tepláky	3	1	f	-	0	18	1	2012-10-13 11:37:22+02
120	riflová bunda s ružovou kožušinkou na límci zn. George, veľ. 9 - 12 M	3	5	f	-	0	19	1	2012-10-13 11:37:24+02
121	modré dupačky	3	2	f	-	0	20	1	2012-10-13 11:37:43+02
122	modré tepláčiky VK, veľ. 74	3	1.5	f	-	0	21	1	2012-10-13 11:37:45+02
123	zelené body veľ. 62	3	2	f	-	0	22	1	2012-10-13 11:37:48+02
124	ružovobiele dupačky zn. Domaja	3	2.5	f	-	0	23	1	2012-10-13 11:37:51+02
125	modré tričko s dlhým rukávom zn. Loana, veľ. 68	3	1	f	-	0	24	1	2012-10-13 11:37:54+02
126	biele legínky s jahôdkami zn. Okay, veľ. 74	3	2	f	-	0	25	1	2012-10-13 11:37:57+02
127	oranžový overal na spanie zn. new baby, veľ. 56	3	3.5	f	-	0	26	1	2012-10-13 11:37:59+02
128	oranžové body s kvetinkami zn. F&F, veľ. 3 - 6 M	3	3	f	-	0	27	1	2012-10-13 11:38:03+02
129	biele body s ružovými guličkami zn. F&F, veľ. 3 - 6 M	3	2	f	-	0	28	1	2012-10-13 11:38:14+02
111	hnedé sametové polodupačky zn. Mini, veľ. 68	3	4	f	-	0	10	2	2012-10-13 17:03:24+02
131	bledoružové body zn. Next, veľ. 3 - 6 M	3	2	f	-	0	30	1	2012-10-13 11:38:18+02
132	žltý pletený svetrík	3	1.5	f	-	0	31	1	2012-10-13 11:38:26+02
133	bledoružový overal na spanie zn. Petit Bateru, veľ. 54	3	2.5	f	-	0	32	1	2012-10-13 11:38:29+02
134	bledoružové body s dlhým rukávom zn. Cherokee, veľ. 56	3	2	f	-	0	33	1	2012-10-13 11:38:31+02
135	biele body s dlhým rukávom zn. F&F, veľ. 0 - 3 M	3	2	f	-	0	34	1	2012-10-13 11:38:32+02
114	rifle s ružovými volánikmi a opaskom zn. Loana, veľ. 86	3	3	f	-	0	13	2	2012-10-13 18:55:46+02
137	biele body s dlhým rukávom zn. F&F, veľ. 0 - 3 M	3	2	f	-	0	36	1	2012-10-13 11:38:36+02
138	biele body s dlhým rukávom zn. F&F, veľ. 3 - 6 M	3	2	f	-	0	37	1	2012-10-13 11:38:38+02
139	biele body s dlhým rukávom zn. F&F, veľ. 9 - 12 M	3	2	f	-	0	38	1	2012-10-13 11:38:39+02
136	biele body s dlhým rukávom zn. F&F, veľ. 0 - 3 M	3	2	f	-	0	35	2	2012-10-13 18:53:01+02
141	bledoružový overal na spanie zn. New baby, veľ. 56	3	3	f	-	0	40	1	2012-10-13 11:38:43+02
142	bledoružový overal na spanie zn. New baby, veľ. 56	3	3	f	-	0	41	1	2012-10-13 11:38:47+02
143	bledoružový overal na spanie zn. New baby, veľ. 56	3	3	f	-	0	42	1	2012-10-13 11:38:51+02
144	ružové prekladacie bodynko s cvočkami, veľ. 56	3	2	f	-	0	43	1	2012-10-13 11:38:55+02
145	ružové body s dlhým rukávom zn. M, veľ. 6 - 9 M	3	2	f	-	0	44	1	2012-10-13 11:38:57+02
146	červenobiele pásikové body s dlhým rukávom zn. Disney, veľ. 9 - 12 M	3	2	f	-	0	45	1	2012-10-13 11:38:58+02
147	flísová béžová súprava - mikinka a nohavice zn. H&M, veľ. 62	3	4	f	-	0	46	1	2012-10-13 11:39:00+02
149	biele body so zeleným lemovaním veľ. 56	3	2	f	-	0	48	1	2012-10-13 11:39:18+02
96	tricko cervene dlh. Rukav c.110	2	1	f	-	0	45	2	2012-10-13 18:35:20+02
151	bledoružové body Moja mama je najlepšia zn. Tinko, veľ. 68	3	3	f	-	0	50	1	2012-10-13 11:39:22+02
52	pásikové farebné teplátky 	2	1.5	f	-	0	1	1	2012-10-13 12:47:27+02
87	deka medvedikova patchwork	2	3	f	-	0	36	1	2012-10-13 12:47:27+02
211	modré rifle , farebný opasok, Cherokee, veľ.2-3r	4	3.5	f	-	0	10	1	2012-10-13 11:59:52+02
207	vyšívané rifle, motýlik,vrecká, opasok fialový, veľ.122	4	2.5	f	-	0	6	1	2012-10-13 11:59:57+02
213	hnedé menžestráky Cherokee JAY CHEKKY, veľ.2-3 r	4	3.5	f	-	0	12	1	2012-10-13 12:00:08+02
212	modré menžestráky POWER, chlapčenské, veľ.20	4	2.1000000000000001	f	-	0	11	1	2012-10-13 12:00:11+02
204	dievčenské rifle, naboku kvietky, veľ.5	4	2.5	f	-	0	3	1	2012-10-13 12:00:15+02
205	dievčenské rifle - vpredu vačok a červené srdiečko, mauli	4	1.3	f	-	0	4	1	2012-10-13 12:00:18+02
206	dievčenské rifle vyšívané ružové kvietky, veľ.2-3 r	4	2.2000000000000002	f	-	0	5	1	2012-10-13 12:00:22+02
208	zelené menžestráky na traky, veľ.24	4	3.5	f	-	0	7	1	2012-10-13 12:00:26+02
209	žlté menžestráky na traky, veľ.92	4	1.5	f	-	0	8	1	2012-10-13 12:00:30+02
210	modré menžestráky na traky, veľ.1 rok	4	1.3999999999999999	f	-	0	9	1	2012-10-13 12:00:38+02
202	rifle LITTLE rock DOPODOPO č.98	4	4	f	-	0	1	1	2012-10-13 12:00:44+02
203	rifle cherokee s opaskom,žltý gombík, veľ. 4-5 r	4	3	f	-	0	2	1	2012-10-13 12:00:48+02
219	modré flaušové nohavice, LTA, dole výšivka, veľ.110	4	3	f	-	0	18	1	2012-10-13 12:00:57+02
220	červené flaušové nohavice, LTA, veľ.104	4	1.3	f	-	0	19	1	2012-10-13 12:01:00+02
216	zelené flaušové nohavice s mašličkou, veľ 1 r	4	1.1000000000000001	f	-	0	15	1	2012-10-13 12:03:06+02
215	hnedé dievčenské menžestráky, veľ.98	4	2.2000000000000002	f	-	0	14	1	2012-10-13 12:03:09+02
223	modrý sametový kabátik, veľ.74	4	1.2	f	-	0	22	1	2012-10-13 12:03:16+02
224	biely župan, s kapucňou, 6-12 mes	4	1	f	-	0	23	1	2012-10-13 12:03:19+02
218	červené twist nohavice LTA, veľ 134	4	4	f	-	0	17	1	2012-10-13 12:03:27+02
217	hnedé flaušové nohavice, veľ 2-3 r	4	1	f	-	0	16	2	2012-10-13 16:44:40+02
222	žlté flaušové nohavice, FROG, veľ.110	4	1.8	f	-	0	21	2	2012-10-13 16:44:40+02
221	ružové flaušové nohavice, LTA, veľ.116	4	1.3	f	-	0	20	2	2012-10-13 16:44:40+02
214	hnedé menžestráky Dopodopo, veľ.98	4	3.5	f	-	0	13	2	2012-10-13 18:01:27+02
288	čierne tehotenské rifle, Mamas & Papas, maternity, veľ. 8R	6	11	f	-	0	1	1	2012-10-13 09:39:08+02
256	Diev.topánky,na suchý zips,modro-bežové,na podpätku,AGAXY,veľ.35	5	7	f	-	0	5	1	2012-10-13 11:53:44+02
253	Dievč.topánky s vyvýš. podrážkou,f.šnúrky,na zips,GRACELAND,v.36	5	9	f	-	0	2	1	2012-10-13 11:53:48+02
252	Čižmy šedé dievčenské,s vyvýšenou podrážkou,šnurovacie,veľ.35	5	8	f	-	0	1	1	2012-10-13 11:53:52+02
257	Botasky biele NIKE,na šnurovanie,ružová "fajka",veľ.37,5	5	8	f	-	0	6	1	2012-10-13 11:53:56+02
255	Diev.topánky,okolo nohy sú vybíjané,na zips,GRACELAND,veľ.36	5	10	f	-	0	4	1	2012-10-13 11:54:02+02
259	Zimná diev.bunda,medenno čierna,kapuca,opasok,HAPPY DAYS,v.12	5	5	f	-	0	8	1	2012-10-13 11:54:12+02
260	Zimná chlap.bunda,šedá s kapucou,biely nápis,CRASHONE,v.146/152	5	10	f	-	0	9	1	2012-10-13 11:54:17+02
261	Detská riflová kabelka,s aplikáciami,ružové "uši",WINX	5	5	f	-	0	10	1	2012-10-13 11:54:22+02
262	Šedá tepláková súprava,mikina cez hlavu,LUCKY LAX,veľ.122	5	4	f	-	0	11	1	2012-10-13 11:54:29+02
263	Biela šušťová bunda,tenká,s kapucou,lemovaná čiernym úpletom,v.10	5	7	f	-	0	12	1	2012-10-13 11:54:32+02
264	Fialová nepremokavá bunda,lesklá,KENVELO GIRLS,veľ.152	5	10	f	-	0	13	1	2012-10-13 11:54:36+02
265	Oranžovo-zelená tepláková súprava,nápis BESTER,veľ.8	5	4	f	-	0	14	1	2012-10-13 11:54:45+02
266	Oranžovo-biela tepláková súprava,s kapucou,veľ.10	5	4	f	-	0	15	1	2012-10-13 11:54:47+02
267	Ružová mikina s kapucou,na zips,s vreckami,CHEROKEE,veľ.8-9	5	4	f	-	0	16	1	2012-10-13 11:54:49+02
268	Tmavo fialová mikina s kapucou,na zips,CHEROKEE,veľ.12-13	5	4	f	-	0	17	1	2012-10-13 11:54:55+02
269	Šedá mikina,kapuca,na predu potlač s flitrami,CRASHONE,v.146/152	5	7	f	-	0	18	1	2012-10-13 11:54:59+02
244	modro biele tričko, sova vpredu, veľ. 8-9 r	4	3	f	-	0	43	2	2012-10-13 19:27:00+02
251	šuštiaková súprava NIKE , modro bielo oranžová, veľ. 122	4	12	f	-	0	50	2	2012-10-13 17:56:04+02
271	Hnedo biely svetrík,kapuca,na predu gombíček,C A,veľ.134/140	5	7	f	-	0	20	1	2012-10-13 11:55:35+02
272	Ružový sveter na zips,so stojačikom,CHEROKEE,veľ.8-9	5	3	f	-	0	21	1	2012-10-13 11:55:37+02
273	Čierne sametové tepláky,vzadu na vrecku smrtka,GEORGE,veľ.140	5	4	f	-	0	22	1	2012-10-13 11:55:42+02
274	Modré tepláky,na boku ružové pásy,veľ.140	5	2	f	-	0	23	1	2012-10-13 11:55:46+02
250	rifle Dopodopo Detroit veľ. 116	4	2.2000000000000002	f	-	0	49	2	2012-10-13 15:26:40+02
276	Červené šušťové tepláky s bielym štepovaním,veľ.134	5	4	f	-	0	25	1	2012-10-13 11:55:56+02
277	Riflová sukňa,naboku modrý motýľ,veľ.10	5	3	f	-	0	26	1	2012-10-13 11:56:00+02
278	Rifle dievč.,rozšírené,dolu patent,vyšší pás,veľ.152	5	6	f	-	0	27	1	2012-10-13 11:56:22+02
279	Rifle chlapč.,vyšívané fialovým,DOPODOPO,veľ.116	5	6	f	-	0	28	1	2012-10-13 11:56:26+02
280	Rifle chlapč.,na nohe červený škorpion,DOPODOPO,veľ.110	5	5	f	-	0	29	1	2012-10-13 11:56:32+02
281	Rifle chpapč.,v páse gumička,CHEROKEE,veľ.2-3	5	3	f	-	0	30	1	2012-10-13 11:56:36+02
282	Červená mikina na zips,na predu nápis BASK CLUB,veľ.134	5	3	f	-	0	31	1	2012-10-13 11:56:41+02
270	Šedá mikina s kapucou,Spiderman,na zips,NEXT,veľ.110	5	4	f	-	0	19	2	2012-10-13 16:50:32+02
284	Tričko dl.rukáv,tyrkysové,na predu potlač,DOPODOPO,veľ.122	5	3	f	-	0	33	1	2012-10-13 11:56:48+02
285	Tričko dl.rukáv,čiernej farby,HANNAH MONTANA,veľ.146/152	5	5	f	-	0	34	1	2012-10-13 11:56:51+02
286	Ružové tričko dl.rukáv,na predu potlač,WENICE,veľ.146	5	2	f	-	0	35	1	2012-10-13 11:56:54+02
287	Dievč.košela dl.rukáv,fialovej farby,CRASHONE,veľ.146/152	5	7	f	-	0	36	1	2012-10-13 11:56:58+02
237	Cherokee ružové tričko Lovely, veľ. 8-9 r	4	1.8	f	-	0	36	1	2012-10-13 12:01:20+02
258	Detská kabelka HANNAH MONTANA s peňaženkou+malá návliečka	5	8	f	-	0	7	2	2012-10-13 18:14:06+02
232	Basket Boy, modré tričko, kapucňa, veľ.98	4	0.5	f	-	0	31	1	2012-10-13 12:02:07+02
235	Dopodopo Detroit modro šedé pásikavé tričko	4	1	f	-	0	34	1	2012-10-13 12:01:28+02
234	zelené tričko , vpredu loďka, veľ.122	4	1.5	f	-	0	33	1	2012-10-13 12:01:31+02
233	tyrkysové tričko, vpredu havko, veľ.122	4	1.5	f	-	0	32	1	2012-10-13 12:01:34+02
283	Červená flísová vesta na zips,so stojačikom,ITEMS,veľ.7-8	5	3	f	-	0	32	2	2012-10-13 16:44:41+02
230	zelené tričko Happy girl, kapucňa, veľ.122	4	0.80000000000000004	f	-	0	29	2	2012-10-13 19:32:16+02
275	Tričko dl.rukáv,šedé,na predu dinosaurus,DOPODOPO,veľ.122	5	3	f	-	0	24	2	2012-10-13 15:26:40+02
241	hnedo ružové tričko crash One veľ.140	4	1	f	-	0	40	1	2012-10-13 12:01:56+02
248	Cherokee svetrík ružový, na zips, veľ. 8-9 r	4	1	f	-	0	47	2	2012-10-13 16:06:44+02
245	Here hnedo oranžové tričko, veľ. 146-152	4	2.2000000000000002	f	-	0	44	2	2012-10-13 16:44:41+02
238	Hello Kitty ružové tričko, veľ.152	4	1.8	f	-	0	37	2	2012-10-13 16:44:41+02
240	oranžové pásikavé tričko, LTA veľ.116	4	1	f	-	0	39	2	2012-10-13 19:32:16+02
229	Kenvelo tričko 01, veľ.4-5 r	4	2	f	-	0	28	1	2012-10-13 12:02:18+02
228	modré tričko GRACE,veľ.18 mes	4	1	f	-	0	27	1	2012-10-13 12:02:20+02
227	R-sports tričko, chlapčenské, LTA veľ.92	4	1.5	f	-	0	26	1	2012-10-13 12:02:21+02
226	biely kabátik na zips, BABY WORED, veľ.98	4	1.2	f	-	0	25	1	2012-10-13 12:02:24+02
225	červený kabátik, na gombíky, SINO, veľ.6 mes	4	0.5	f	-	0	24	1	2012-10-13 12:02:26+02
249	Kenvelo sveter, ružový, na zips, kapucňa, veľ.8-9 r	4	2.5	f	-	0	48	1	2012-10-13 12:02:35+02
231	červeno šedé pásikavé tričko, kapucňa,opička, veľ.4-5 r	4	2.2000000000000002	f	-	0	30	2	2012-10-13 16:34:29+02
247	fialovo šedý sveter, pásikavý, kapucňa, veľ.128	4	2	f	-	0	46	1	2012-10-13 12:02:47+02
239	Miss cherokee bieloružové tričko veľ. 8 - 9	4	1.8	f	-	0	38	2	2012-10-13 15:33:34+02
236	H&M tričko, červené, pásikavé, mačka vpredu, veľ 7-8 r	4	3.2000000000000002	f	-	0	35	2	2012-10-13 18:10:52+02
246	Cherokee šedé rifle, veľ. 9-10 r	4	3	f	-	0	45	1	2012-10-13 12:04:24+02
243	Miss Cherokee ružové tričko, havko, veľ. 8-9 r	4	1.2	f	-	0	42	2	2012-10-13 15:19:34+02
291	svetlo-modrá čiapka, šál	7	0.59999999999999998	f	-	0	2	1	2012-10-13 08:45:17+02
296	modrá čiapka	7	0.29999999999999999	f	-	0	7	2	2012-10-13 16:15:47+02
302	oranžový pulóver, čierný rukáv, autá 18-24m	7	1	f	-	0	13	2	2012-10-13 17:53:55+02
294	svetlo-modrý čiapka     	7	0.5	f	-	0	5	1	2012-10-13 08:45:42+02
295	hnedá čiapka	7	0.29999999999999999	f	-	0	6	1	2012-10-13 08:45:46+02
303	modrý pulóver Macko Pooh, 24m	7	1.5	f	-	0	14	2	2012-10-13 16:52:37+02
297	bledý, štrikovaný svetrík 6-9m	7	2.5	f	-	0	8	1	2012-10-13 08:45:57+02
311	sveter modrý Early days 18-24m	7	2.5	f	-	0	22	2	2012-10-13 17:09:37+02
299	šedý pulóver, vláčik 9-12m	7	0.5	f	-	0	10	1	2012-10-13 08:46:07+02
319	tmavo-modrý bunda s koženkovou kapucou 18-23m	7	1.5	f	-	0	30	2	2012-10-13 15:33:34+02
301	zelený pulóver, auto 9-12m	7	0.29999999999999999	f	-	0	12	1	2012-10-13 08:46:14+02
337	hnedý, pásikový svetrík 18-24m	7	1.5	f	-	0	48	2	2012-10-13 18:01:27+02
352	Ružové tričko s nápisom Fashion, Super Girl veľ.116	8	1.5	f	-	0	13	2	2012-10-13 16:57:10+02
304	červeno-čierný pulóver 18m	7	1.5	f	-	0	15	1	2012-10-13 08:46:28+02
332	gumáčiky 21	7	2	f	-	0	43	2	2012-10-13 17:36:18+02
305	béžový sveter NEXT 6-9m	7	1	f	-	0	16	2	2012-10-13 17:34:49+02
307	štrikovaný sveter, bledý, farebný 2-3 roky	7	3	f	-	0	18	1	2012-10-13 08:46:41+02
331	čierné koženné topánky 22	7	1.5	f	-	0	42	2	2012-10-13 17:49:24+02
317	šedá buda s kapucou 9-12m	7	2.5	f	-	0	28	2	2012-10-14 10:43:23+02
310	sveter šedý Early days 18-24m 	7	2.5	f	-	0	21	1	2012-10-13 08:47:17+02
346	Modrý kabátik so psíkom DUNNES,veľ. 0-3mes	8	1	f	-	0	7	2	2012-10-13 17:20:12+02
326	papučky kravička 20-21	7	1	f	-	0	37	2	2012-10-13 17:31:15+02
315	zelená bunda 3-6m	7	2.5	f	-	0	26	1	2012-10-13 08:47:48+02
320	oteplovačky farebné 12-18m	7	4	f	-	0	31	2	2012-10-13 18:14:41+02
357	Ružové tričko s vílou a jednorožcom early days, veľ.18-23 mes.	8	1	f	-	0	18	2	2012-10-14 11:08:27+02
318	zelený kabát 12-18m	7	4	f	-	0	29	1	2012-10-13 08:48:01+02
292	pásiková barania čiapka	7	0.5	f	-	0	3	2	2012-10-13 15:44:00+02
358	Šedé menšestráky s kvietkami Cherokee, veľ.18-24 mes.	8	2	f	-	0	19	2	2012-10-13 18:49:05+02
321	oteplovačky šedé 3-6m	7	3	f	-	0	32	1	2012-10-13 08:48:41+02
293	tmavo-modrá čiapka	7	0.5	f	-	0	4	2	2012-10-13 17:50:43+02
323	béžová bunda 12-18m 	7	5	f	-	0	34	1	2012-10-13 08:48:58+02
324	riflová bunda 12-18	7	5	f	-	0	35	1	2012-10-13 08:49:01+02
322	oteplovačky modré, opica 18-24m	7	5	f	-	0	33	2	2012-10-13 17:49:24+02
306	zelený sveter 6-12m	7	0.80000000000000004	f	-	0	17	2	2012-10-13 17:34:49+02
327	čierné koženné čižmy 26	7	5	f	-	0	38	1	2012-10-13 08:49:33+02
309	2x tepláky (šedé a čierné) 6-12m	7	1	f	-	0	20	2	2012-10-14 10:25:05+02
329	hnedé topánky 21	7	1	f	-	0	40	1	2012-10-13 08:49:44+02
330	koženné topánky, čierné 18-19	7	1	f	-	0	41	1	2012-10-13 08:49:55+02
325	kabát, čierný 12-18m	7	6	f	-	0	36	2	2012-10-13 17:49:24+02
334	kovbojské čižmy 25	7	1.5	f	-	0	45	1	2012-10-13 08:50:03+02
308	šedá tepláková súprava 12-18m	7	1	f	-	0	19	2	2012-10-13 17:47:48+02
316	modrý bunda NEXT 6-9m	7	2.5	f	-	0	27	2	2012-10-13 18:11:12+02
336	modrý, pásikový svetrik 18-24m	7	1.5	f	-	0	47	2	2012-10-13 18:01:27+02
333	snehule, béžové 23	7	1.5	f	-	0	44	2	2012-10-13 18:04:43+02
340	Tenisky ružové AIR veľ.26	8	2	f	-	0	1	1	2012-10-13 09:33:04+02
341	Tenisky biele Nike veľ. 26,5	8	8	f	-	0	2	1	2012-10-13 09:33:07+02
342	Bielo-ružové tenisky veľ.27	8	2	f	-	0	3	1	2012-10-13 09:33:10+02
343	Tenisky Toplay veľ.28	8	2	f	-	0	4	1	2012-10-13 09:33:13+02
344	Čierne čižmy s flitrami veľ. 24	8	2	f	-	0	5	1	2012-10-13 09:33:15+02
345	Tyrkysová vesta a mikina a nohavice veľ. 3-6 mes.	8	4	f	-	0	6	1	2012-10-13 09:33:18+02
314	hnedé nohavice na tráky, pulóver 18-24m	7	5	f	-	0	25	2	2012-10-13 17:24:17+02
347	Mod. čiapka+body+čiapka+polodupky+body Mothercare,veľ. 0-3 mes.	8	2	f	-	0	8	1	2012-10-13 09:33:31+02
348	Nohavice na traky s kvietkom veľ. 68	8	2	f	-	0	9	1	2012-10-13 09:34:00+02
350	Zelená zimná súpravička Baby Club, veľ.3-6mes.	8	2	f	-	0	11	1	2012-10-13 09:34:13+02
349	Šedé nohavice na traky early days veľ. 6-12mes	8	3	f	-	0	10	1	2012-10-13 09:34:17+02
351	Červená bunda veľ. 92	8	2	f	-	0	12	1	2012-10-13 09:34:22+02
298	bielo-hnedý pulóver 18-23m	7	0.59999999999999998	f	-	0	9	2	2012-10-13 17:01:33+02
353	Oranžové tričko Kids Club veľ.116, 4-5 rokov	8	1.5	f	-	0	14	1	2012-10-13 09:34:29+02
354	Ružové tričko s kvietkom Tigerlily veľ.7rokov	8	1	f	-	0	15	1	2012-10-13 09:34:31+02
355	Ružové tričko HAIDI veľ.36mes	8	1	f	-	0	16	1	2012-10-13 09:34:33+02
356	Ružové tričko s roláčikom BENETTON 	8	1	f	-	0	17	1	2012-10-13 09:34:35+02
312	3x body, nohavice 9-18m	7	1.5	f	-	0	23	2	2012-10-14 12:03:53+02
360	Set ruž.tričko Cherokee+bord.tričko s motýľmi+ ruž.tričko s dievčaťom	8	1.5	f	-	0	21	2	2012-10-13 19:32:16+02
359	Ružové nohavice Next, veľ. 12-18 mes.	8	2	f	-	0	20	1	2012-10-13 09:34:45+02
328	hnedé koženné topánky 19	7	1	f	-	0	39	2	2012-10-14 10:20:49+02
361	Ružová súpravička macko(dupačky, čiapka, podbradník), veľ. 9-12 mes.	8	2	f	-	0	22	1	2012-10-13 09:34:55+02
362	Ruž.pančuchy so srnkou lupilu+fial.pančuchy s motýľmi a kvietkami	8	1	f	-	0	23	1	2012-10-13 09:35:07+02
363	Červ.pasikavé pančuchy+ružové pančuchy St.Bernard, veľ.12-18.mes	8	0.80000000000000004	f	-	0	24	1	2012-10-13 09:35:13+02
364	Modré pančuchy so psíkmi+modré pančuchy s vláčikom a obláčikmi	8	0.5	f	-	0	25	1	2012-10-13 09:35:18+02
365	Modrý spací vak early days, veľ. 0-6 mes.	8	4	f	-	0	26	1	2012-10-13 09:35:28+02
300	šedý pulóver, opica 12-18m	7	0.80000000000000004	f	-	0	11	2	2012-10-13 15:17:55+02
390	zimne topanky ruzove	9	5.7999999999999998	f	-	0	1	1	2012-10-13 08:56:31+02
393	olivovo zelene prechodne topanky 	9	5.7999999999999998	f	-	0	4	1	2012-10-13 08:56:36+02
394	sede zimne snehulky	9	5.2999999999999998	f	-	0	5	1	2012-10-13 08:56:41+02
417	ruzovy svetrik - tunika	9	3.5	f	-	0	28	2	2012-10-13 19:19:16+02
380	Biele dupačky s mackom Mothercare, veľ.0-3 mes.	8	1	f	-	0	41	2	2012-10-13 16:02:17+02
397	cizmy next cierne, velkost 35	9	6.5	f	-	0	8	1	2012-10-13 08:56:59+02
396	bezove prechodne topanky na snurku	9	3.8999999999999999	f	-	0	7	1	2012-10-13 08:57:05+02
398	karo sukna HM	9	3	f	-	0	9	1	2012-10-13 08:57:13+02
399	olivovo zelene sukna	9	3	f	-	0	10	1	2012-10-13 08:57:17+02
400	teplakove zelene saty next, 92	9	3.2999999999999998	f	-	0	11	1	2012-10-13 08:57:23+02
401	bezove mencestrakove saty	9	4	f	-	0	12	1	2012-10-13 08:57:27+02
402	riflove saty Next, 98	9	4	f	-	0	13	1	2012-10-13 08:57:32+02
403	riflove saty, 98	9	4.2999999999999998	f	-	0	14	1	2012-10-13 08:57:39+02
404	riflove saty, 122	9	3.7000000000000002	f	-	0	15	1	2012-10-13 08:57:43+02
405	rifle george 92	9	3	f	-	0	16	1	2012-10-13 08:57:47+02
406	GAP ruzove nohavice hrubsie	9	3.7999999999999998	f	-	0	17	1	2012-10-13 08:57:53+02
407	rifle 128	9	3.2999999999999998	f	-	0	18	1	2012-10-13 08:57:58+02
408	ruzove mencestraky	9	2.5	f	-	0	19	1	2012-10-13 08:58:03+02
409	ruzove teplaciky	9	2.5	f	-	0	20	1	2012-10-13 08:58:07+02
411	flees teplaky bezove	9	2.7999999999999998	f	-	0	22	1	2012-10-13 08:58:19+02
412	hnede leskle nohavice - slušné	9	4	f	-	0	23	1	2012-10-13 08:58:24+02
413	mencestraky ruzove tmave	9	3.3999999999999999	f	-	0	24	1	2012-10-13 08:58:29+02
414	riflova kosielka	9	3.7999999999999998	f	-	0	25	1	2012-10-13 08:58:34+02
415	flees cervena mikina	9	4.2000000000000002	f	-	0	26	1	2012-10-13 08:58:39+02
416	staroruzova mikina	9	2.8999999999999999	f	-	0	27	1	2012-10-13 08:58:44+02
423	cierna bunda lacoste	9	4.7999999999999998	f	-	0	34	2	2012-10-14 10:20:01+02
418	flees ruzove pončo	9	3.8999999999999999	f	-	0	29	1	2012-10-13 08:58:56+02
419	pasikova mikinA ruzova	9	3.8999999999999999	f	-	0	30	1	2012-10-13 08:59:01+02
420	hneda flees mikina	9	4.5	f	-	0	31	1	2012-10-13 08:59:12+02
421	bledo ruzova bunda	9	5.7999999999999998	f	-	0	32	1	2012-10-13 08:59:18+02
422	olivovo zelena bunda	9	4.9000000000000004	f	-	0	33	1	2012-10-13 08:59:26+02
427	flees sal pasikovy	9	3	f	-	0	38	2	2012-10-14 11:00:00+02
381	Zelené dupačky so sloníkom Baby elegance, veľ.0-3 mes	8	1	f	-	0	42	2	2012-10-13 16:25:44+02
395	prechodne topanky malicke na snurku	9	4	f	-	0	6	2	2012-10-13 19:19:16+02
426	blede zateplene pancuchy	9	1.7	f	-	0	37	1	2012-10-13 08:59:53+02
386	Červená mikina so srdiečkami Artena, veľ.116	8	1.5	f	-	0	47	2	2012-10-14 11:09:27+02
428	bledo modra ciapka adidas	9	3.5	f	-	0	39	1	2012-10-13 09:00:02+02
429	hneda ciapka s brmbolcom plus rukavice	9	4.5	f	-	0	40	1	2012-10-13 09:00:09+02
430	tmavomodre tricko	9	1.5	f	-	0	41	1	2012-10-13 09:00:14+02
432	ruzove tricko s opicou	9	1	f	-	0	43	1	2012-10-13 09:00:22+02
433	hneda tunika	9	3	f	-	0	44	1	2012-10-13 09:00:26+02
376	Ružové pyžamo Peppa Pig, veľ.4-5 rokov	8	2.5	f	-	0	37	2	2012-10-13 16:34:29+02
388	Ružová mikina s mačkou girl2girl,veľ.4-5 rokov	8	1	f	-	0	49	2	2012-10-13 15:20:36+02
436	kabatik- prsiplast	10	9.9000000000000004	f	-	0	2	1	2012-10-13 09:02:44+02
443	cervena bunda, 110	10	5	f	-	0	9	2	2012-10-14 14:56:18+02
438	kozusok	10	7.5	f	-	0	4	1	2012-10-13 09:02:58+02
439	tmavomodra vesta	10	2.7999999999999998	f	-	0	5	1	2012-10-13 09:03:06+02
440	modra bleda vesta	10	3	f	-	0	6	1	2012-10-13 09:03:12+02
377	Ružová mikina s kapucňou, early days, veľ. 18-23 mes	8	1.5	f	-	0	38	2	2012-10-13 17:05:32+02
392	prechodne topanky na skrtku, 27	9	6.7000000000000002	f	-	0	3	2	2012-10-13 15:26:50+02
444	bledo sede rifle, 140	10	5	f	-	0	10	1	2012-10-13 09:03:39+02
437	hnedy mencestrovy kabatik	10	8	f	-	0	3	2	2012-10-14 11:29:14+02
366	Biele body a červené šaty St. Bernard, veľ. 9-12 mes.	8	2	f	-	0	27	1	2012-10-13 09:35:31+02
367	Ružové tričko so srdiečkom United Colours of Benneton	8	0.80000000000000004	f	-	0	28	1	2012-10-13 09:35:42+02
368	3x tričko-biele kvietkované;ružové kvietkované;bieles princeznou...	8	2	f	-	0	29	1	2012-10-13 09:35:52+02
369	Hnedé tričko Pretty Next, veľ. 9-12 mes.	8	1	f	-	0	30	1	2012-10-13 09:35:56+02
370	Zelené nohavice na traky Mothercare, veľ, 3-6 mes.	8	1.5	f	-	0	31	1	2012-10-13 09:36:00+02
371	Červené tepláky s ružovo-bielym pruhom Roller Girl, veľ. 9-12	8	1	f	-	0	32	2	2012-10-13 18:57:46+02
373	Ružové tepláky Next, veľ.9-12.mes	8	0.80000000000000004	f	-	0	34	1	2012-10-13 09:36:36+02
372	Rifle s kvietkami girl2girl, veľ. 2-3 roky	8	2	f	-	0	33	1	2012-10-13 09:36:21+02
374	Ružová bunda s kožušinovou kapucňou Adams Kids, veľ.2-3 roky	8	4	f	-	0	35	1	2012-10-13 09:36:38+02
441	seda bunda SAM, 146	10	10	f	-	0	7	2	2012-10-13 16:57:51+02
382	Hnedý svetrík Premaman, veľ.3 roky	8	2	f	-	0	43	2	2012-10-13 17:29:26+02
378	Ružová bunda s kvetmi a vreckom na rukáve Adams Kids, veľ.18-24 m	8	3	f	-	0	39	1	2012-10-13 09:36:48+02
379	Set 4x tričko-ružové, pásikavé, ružové s nápisom, biele so zvieratkami	8	2	f	-	0	40	1	2012-10-13 09:36:54+02
384	Ružové pančuchy s pásikmi a mačkou na zadku,veľ. 92-98	8	0.5	f	-	0	45	2	2012-10-13 16:20:44+02
434	pasikove tricko dl.rukav, lindex	9	4.2999999999999998	f	-	0	45	2	2012-10-13 16:32:00+02
425	ruzove pasik. Pancuchy	9	1	f	-	0	36	2	2012-10-13 18:24:20+02
383	Červené tričko s nápisom Always in your dreams, Girl2girl, veľ.4-5 rok	8	1	f	-	0	44	1	2012-10-13 09:37:10+02
424	ciklamenove pancuchy	9	1.5	f	-	0	35	2	2012-10-13 16:20:44+02
435	prsiplast ruzovy podsity	10	9.9000000000000004	f	-	0	1	2	2012-10-13 14:52:41+02
375	Ružový overal Swetie Marks and Spencer, veľ.0-3 mes.	8	3	f	-	0	36	2	2012-10-14 11:17:02+02
442	modra bunda next, 110	10	5	f	-	0	8	2	2012-10-13 15:26:50+02
387	Ružová flísová súpravička LUSA S.R.O., veľ.L	8	3	f	-	0	48	1	2012-10-13 09:37:33+02
385	2xbiele polodupačky mothercare, veľ 3-6 mes.	8	1	f	-	0	46	2	2012-10-13 14:51:09+02
511	ciklamenova chlpatka next	12	7.5	f	-	0	2	1	2012-10-13 08:53:06+02
512	fialova chlpatka so salom	12	6.7000000000000002	f	-	0	3	1	2012-10-13 08:53:09+02
513	malicka ruz. Chlpatka	12	4	f	-	0	4	1	2012-10-13 08:53:12+02
514	ruzova chlpatka 98	12	6	f	-	0	5	1	2012-10-13 08:53:15+02
515	ciklamenovy kozustek	12	8	f	-	0	6	1	2012-10-13 08:53:19+02
516	pasikovy zupan	12	6.5	f	-	0	7	1	2012-10-13 08:53:23+02
445	hnede mencestraky next, 104	10	3.8999999999999999	f	-	0	11	2	2012-10-14 10:20:01+02
465	ruzova mikina disney	10	3	f	-	0	31	2	2012-10-13 17:24:39+02
519	vesticka-bunda seda	12	3.5	f	-	0	10	1	2012-10-13 08:53:39+02
520	bezova menc. Bunda	12	3.2999999999999998	f	-	0	11	1	2012-10-13 08:53:56+02
463	ruzovy svetrik	10	3	f	-	0	29	2	2012-10-13 16:48:23+02
497	Flísová mikinka, fialová s krátkym zipsíkom, veľ 86/92	11	5	f	-	0	13	2	2012-10-14 12:50:36+02
523	cervena mikina	12	2	f	-	0	14	1	2012-10-13 08:54:31+02
524	ruzovy sveter gombiky	12	2.8999999999999999	f	-	0	15	1	2012-10-13 08:54:48+02
522	cerveny sveter	12	3	f	-	0	13	2	2012-10-14 10:53:50+02
446	ruzove mencestraky, 104	10	3.2999999999999998	f	-	0	12	1	2012-10-13 09:03:49+02
454	oranzove tricko	10	2.2999999999999998	f	-	0	20	2	2012-10-13 15:26:40+02
448	hnede mencestraky, 110	10	3.2999999999999998	f	-	0	14	1	2012-10-13 09:04:01+02
449	modre mencestraky	10	2.8999999999999999	f	-	0	15	1	2012-10-13 09:04:05+02
450	ruzova vesta - bolerko	10	3.7999999999999998	f	-	0	16	1	2012-10-13 09:04:13+02
452	pruhovany modry rolak tenky	10	1	f	-	0	18	1	2012-10-13 09:04:20+02
499	Teplá vestička, biela s motýlikom, fialová podšívka, veľ. 18 mes.	11	4	f	-	0	15	2	2012-10-13 15:44:08+02
453	sede tricko bench	10	2	f	-	0	19	2	2012-10-13 15:26:50+02
521	pasikovy sveter	12	3.7999999999999998	f	-	0	12	2	2012-10-13 16:30:23+02
459	ruzove strikovane saty next	10	4	f	-	0	25	2	2012-10-14 10:10:21+02
487	Čižmičky, semišové, hnedé s výšivkou, veľ.21	11	9	f	-	0	3	2	2012-10-13 18:49:05+02
458	ruzovy rolak	10	3	f	-	0	24	1	2012-10-13 09:04:45+02
517	bezova vesticka kozusinkova	12	5	f	-	0	8	2	2012-10-14 10:20:01+02
460	modry svetrik na gombik	10	3.8999999999999999	f	-	0	26	1	2012-10-13 09:04:57+02
461	staroruzovy V svetrik	10	3.8999999999999999	f	-	0	27	1	2012-10-13 09:05:07+02
462	strikovane saty	10	3	f	-	0	28	1	2012-10-13 09:05:12+02
473	riflove saty ADAMS	10	4.5	f	-	0	39	2	2012-10-13 16:49:36+02
464	bledoruzovy svetrik	10	3	f	-	0	30	1	2012-10-13 09:05:25+02
494	Oteplováky svetlomodré s hnedou a bielou, na lavej noh. Nápis , veľ.86	11	8	f	-	0	10	2	2012-10-13 17:30:15+02
495	Fialová pletená tunička, veľ.86	11	4	f	-	0	11	2	2012-10-13 18:12:37+02
467	mikina Next 98	10	2.8999999999999999	f	-	0	33	1	2012-10-13 09:05:39+02
468	cerveny svetrik next	10	5	f	-	0	34	1	2012-10-13 09:05:43+02
469	staroruzove menc. Saty	10	5	f	-	0	35	1	2012-10-13 09:05:51+02
470	olivovo zelene saty	10	4.9000000000000004	f	-	0	36	1	2012-10-13 09:05:57+02
471	riflove saty 98	10	4.5999999999999996	f	-	0	37	1	2012-10-13 09:06:02+02
498	Ružový kabátik zn. Topolino, výšivky, veľ. 98	11	12	f	-	0	14	2	2012-10-13 16:57:10+02
474	fialove mencestr. Saty	10	4.5	f	-	0	40	1	2012-10-13 09:06:21+02
477	cierno seda pasik. Ciapka	10	1	f	-	0	43	1	2012-10-13 09:06:39+02
466	ruzova mikina next 92	10	3.5	f	-	0	32	2	2012-10-13 18:03:40+02
475	bezova baranicova ciapka	10	3	f	-	0	41	1	2012-10-13 09:06:50+02
478	seda flees ciapka	10	1.8	f	-	0	44	1	2012-10-13 09:06:55+02
479	opicova ciapka	10	3.8999999999999999	f	-	0	45	1	2012-10-13 09:07:00+02
455	modre tricko dl. Rukav	10	2.2000000000000002	f	-	0	21	2	2012-10-13 16:20:19+02
481	fialova ciapka s motylom	10	3.7999999999999998	f	-	0	47	1	2012-10-13 09:07:14+02
476	modra vzorova ciapka	10	2.5	f	-	0	42	2	2012-10-13 18:01:27+02
483	ciapka olivovo zelena	10	2.7000000000000002	f	-	0	49	1	2012-10-13 09:07:24+02
491	Modro červený overal zimný, vpredu výšivka, veľ. 98/104	11	7	f	-	0	7	1	2012-10-13 10:28:41+02
518	prechodna bunda zara 104	12	4	f	-	0	9	2	2012-10-13 17:18:28+02
493	Modrá bundička, podšitá sieťovinou, veľ. 140	11	6	f	-	0	9	1	2012-10-13 10:29:24+02
496	Ružový overalík, pyžamko s pinguinom, veľ. 6-9 mes.	11	4	f	-	0	12	1	2012-10-13 10:29:32+02
501	Modrá bundička, srdiečkové gombíky, veľ. 6 mes.	11	3	f	-	0	17	1	2012-10-13 10:29:41+02
503	Červená zimná bundička, kvietky, kapucka s uškami, H&M, veľ. 74	11	6	f	-	0	19	1	2012-10-13 10:29:49+02
504	Sivá zimná bundička, C&A, veľ. 68	11	8	f	-	0	20	1	2012-10-13 10:29:58+02
490	Červené oteplováky, veľ. 98/104	11	8	f	-	0	6	1	2012-10-13 10:30:08+02
482	bezova ciapka silt	10	3	f	-	0	48	2	2012-10-13 17:49:24+02
457	biele tricko dl. Rukav	10	1.8	f	-	0	23	2	2012-10-13 18:24:20+02
492	Bundička staroružová farba, vpredu výšivka včielky,veľ. 12-18 mes	11	3	f	-	0	8	1	2012-10-13 10:30:33+02
506	Zateplené červené nohavice, veľ. 9-12	11	4	f	-	0	22	1	2012-10-13 10:30:45+02
507	Zeleno - tyrkysové nohavice, veľ. 1-1 1/2 roka	11	4	f	-	0	23	1	2012-10-13 10:30:50+02
505	Nike šušiakové nohavice, svelá ružová s tmavšou ružovou, veľ. 18-24m.	11	6	f	-	0	21	1	2012-10-13 10:30:57+02
508	Svetlo ružové zateplené  nohavice, C&A	11	6	f	-	0	24	1	2012-10-13 10:31:03+02
509	Hnedé zateplené nohavice s kvietkami, veľ, 18 mes.	11	6	f	-	0	25	1	2012-10-13 10:31:10+02
500	Šuštiaková súpravka zn. Nike, ružovo-biela, veľ. XS	11	14.9	f	-	0	16	2	2012-10-14 13:06:53+02
480	ruzova melirovana ciapka	10	2.6000000000000001	f	-	0	46	2	2012-10-13 16:06:44+02
456	sedy natelnik	10	0.59999999999999998	f	-	0	22	2	2012-10-14 09:21:26+02
502	Svetlo bledomodra bundička, jesenná, veľ. 92	11	6	f	-	0	18	1	2012-10-13 10:31:56+02
488	Topánočky ružovo - fialové na 2 suché zipsy, kvieky, veľ. 21	11	8	f	-	0	4	1	2012-10-13 10:32:06+02
489	Čižmičky, ružové so srdiečkami, veľ.22	11	11	f	-	0	5	1	2012-10-13 10:32:09+02
447	ruzove mencestraky next, 110	10	3	f	-	0	13	2	2012-10-13 15:07:45+02
526	bolerko ruzove strikovane	12	2.2000000000000002	f	-	0	17	1	2012-10-13 08:55:01+02
569	papučky BOB BUILDER na lepenie č.21	13	1.5	f	-	0	10	2	2012-10-14 11:28:57+02
552	rifle podsite	12	3.8999999999999999	f	-	0	43	2	2012-10-13 17:54:20+02
599	Junior – sveter modro bielo hnedý veľ.3 r.	13	2	f	-	0	40	2	2012-10-14 09:21:26+02
584	modro biela čiapka FIDO, 2 bombrlce, kožušina, č.49	13	3	f	-	0	25	2	2012-10-13 15:23:25+02
528	modra mikina	12	2.5	f	-	0	19	2	2012-10-13 17:49:24+02
529	cervene tricko hm	12	1.6000000000000001	f	-	0	20	2	2012-10-13 18:35:20+02
533	biele tricko 	12	1.3999999999999999	f	-	0	24	1	2012-10-13 08:55:44+02
534	bolerko	12	1.5	f	-	0	25	1	2012-10-13 08:55:47+02
535	lososove tricko hrubsie	12	0.59999999999999998	f	-	0	26	1	2012-10-13 08:55:48+02
527	seda mikina	12	2.5	f	-	0	18	2	2012-10-14 11:16:20+02
537	modry svetrik	12	3	f	-	0	28	1	2012-10-13 08:55:58+02
531	fialove tricko	12	2	f	-	0	22	2	2012-10-13 17:31:15+02
539	biele tricko george	12	1.6000000000000001	f	-	0	30	2	2012-10-13 17:29:26+02
541	ruzova sukna HM 104	12	2.8999999999999999	f	-	0	32	1	2012-10-13 08:56:12+02
542	riflova sukna esprit	12	3	f	-	0	33	1	2012-10-13 08:56:17+02
543	ruzova menc. Sukna	12	2.5	f	-	0	34	1	2012-10-13 08:56:20+02
544	karo sukna na traky	12	3.2999999999999998	f	-	0	35	1	2012-10-13 08:56:22+02
545	riflova sukna 128	12	3	f	-	0	36	1	2012-10-13 08:56:24+02
546	cervene menc. Saty next	12	4	f	-	0	37	1	2012-10-13 08:56:27+02
547	fialove menc. Saty	12	3	f	-	0	38	1	2012-10-13 08:56:30+02
548	riflove saty	12	4	f	-	0	39	1	2012-10-13 08:56:33+02
577	ružová bunda na zips, kapucňa, veľ.8-9 r	13	10	f	-	0	18	2	2012-10-13 17:17:11+02
550	rifle next 98	12	2.7999999999999998	f	-	0	41	1	2012-10-13 08:56:37+02
551	rifle sede	12	3.8999999999999999	f	-	0	42	1	2012-10-13 08:56:39+02
554	lacoste sustiaky podsite	12	5	f	-	0	45	2	2012-10-13 17:55:08+02
549	bezove mencestr. Saty	12	4	f	-	0	40	2	2012-10-13 17:13:47+02
532	ruzovo biele tricko	12	1.5	f	-	0	23	2	2012-10-13 18:04:43+02
555	hnede mencestraky	12	3	f	-	0	46	1	2012-10-13 08:56:52+02
557	rifle next 110	12	3.7999999999999998	f	-	0	48	1	2012-10-13 08:56:58+02
553	teplaky nike	12	4.2999999999999998	f	-	0	44	2	2012-10-13 15:44:00+02
559	modre zimne snehule velkost 28	12	8	f	-	0	50	1	2012-10-13 08:57:09+02
602	modro biely sveter HONDA veľ.110	13	3	f	-	0	43	1	2012-10-13 12:05:32+02
574	modrý overal na zips veľ.92	13	5	f	-	0	15	2	2012-10-14 11:00:00+02
600	biely svetrík, srdiečkové gombíky, veľ.12 mes.	13	1.5	f	-	0	41	1	2012-10-13 12:06:08+02
601	Kenveko sveter hnedo modrý 1989 číslo,, veľ.4-5r, na zips	13	4	f	-	0	42	1	2012-10-13 12:06:10+02
594	modrý pasikavý sveter na zips, kapucňa, veľ.3-4 r	13	2	f	-	0	35	1	2012-10-13 12:06:17+02
595	NEXT fialový sveter, vpredu srdiečka	13	2	f	-	0	36	1	2012-10-13 12:06:21+02
597	ružový sveter, pásikavý, srdiečkový, kapucňa, veľ.7-9 r	13	4	f	-	0	38	1	2012-10-13 12:06:26+02
598	JUST PLAY sveter pásikavý, modro bielo zelený č.8	13	3	f	-	0	39	1	2012-10-13 12:06:30+02
596	červená súprava na zips, žltý, nohavice a tričko Teddy Bear	13	5	f	-	0	37	1	2012-10-13 12:07:47+02
592	Tehlová súprava, nohavice a tričko, havková, LTA, veľ.110	13	8	f	-	0	33	1	2012-10-13 12:08:22+02
583	modrá čiapka FANCY KIDS, na viazanie, bombrlec	13	2	f	-	0	24	1	2012-10-13 12:08:31+02
558	ruzove snehule velkost 25	12	7.7999999999999998	f	-	0	49	2	2012-10-13 15:42:31+02
585	modrá čiapka BEAR, lapky, kožušina + šál	13	10	f	-	0	26	1	2012-10-13 12:08:38+02
589	ružový a modrý klobúčik pre dievča, na šnúrky	13	4	f	-	0	30	1	2012-10-13 12:09:23+02
573	overal biely, vpredu ružový tučniak, veľ. 3-6 mes.	13	4	f	-	0	14	1	2012-10-13 12:20:19+02
590	modrý župan veľ 5-6 r.	13	3	f	-	0	31	1	2012-10-13 12:09:34+02
593	DH hnedá súprava, nohavice a tričko, na zips, kapucňa, veľ.36 mes.	13	4	f	-	0	34	1	2012-10-13 12:10:14+02
591	súprava Timbukto, červeno hnedá, veľ. 9-12 mes.SPORTS	13	5	f	-	0	32	1	2012-10-13 12:10:54+02
570	zeleno oranžová budnička, na zips, veľ.80	13	4	f	-	0	11	1	2012-10-13 12:11:55+02
571	modrá bundička na zips JUST PLAY č.3	13	2	f	-	0	12	1	2012-10-13 12:11:58+02
572	overal zajačik modro-biely veľ.18 mes.	13	5	f	-	0	13	1	2012-10-13 12:12:00+02
575	hnedo modrá bunda na zips Cherooke, veľ 5-6 r	13	8.5	f	-	0	16	1	2012-10-13 12:12:03+02
576	lyžiarska červeno modrá zimná bunda na zips, PAPULINO, veľ.104-110	13	12	f	-	0	17	1	2012-10-13 12:12:07+02
587	modro oranžová čiapka, s uškami + rukavice	13	3	f	-	0	28	1	2012-10-13 12:12:24+02
561	Spiderman zimné topánky č.30	13	11	f	-	0	2	1	2012-10-13 12:12:59+02
566	Oranžovo-hnedé topánky na lepenie, zimné, č.28	13	4	f	-	0	7	1	2012-10-13 12:13:22+02
563	čierno zelené zimné poltopánky, kožušina č.24	13	8	f	-	0	4	1	2012-10-13 12:13:37+02
540	mikina pasikova 	12	3	f	-	0	31	2	2012-10-13 17:21:05+02
567	poltopánky hnedé, na lepenie, jesenné, č. 30	13	3	f	-	0	8	1	2012-10-13 12:13:48+02
560	zimné čižmy, ružové, strapcové č.34	13	9	f	-	0	1	1	2012-10-13 12:13:53+02
568	ružovo šedé poltopánky na lepenie, jesenné č.30	13	3	f	-	0	9	1	2012-10-13 12:14:03+02
562	šedé čižmičky na zips, bordové srdiečko, č.26	13	9	f	-	0	3	1	2012-10-13 12:14:09+02
564	hnedo čierne kotníkové topánky, zimné, na lepenie, č.28	13	6	f	-	0	5	1	2012-10-13 12:14:16+02
536	ruzovy svetrik	12	1	f	-	0	27	2	2012-10-14 11:12:01+02
565	šedo modré topánky, zimné, na lepenie č.20 	13	6	f	-	0	6	2	2012-10-13 17:19:07+02
582	bordová bunda Kenvelo, veľ. 8-9 r	13	8	f	-	0	23	1	2012-10-13 12:17:29+02
586	modro oranžová čiapka, vrtulník + šál	13	6	f	-	0	27	1	2012-10-13 12:18:53+02
530	kvietkovana tunika	12	2.2999999999999998	f	-	0	21	2	2012-10-13 14:52:41+02
625	tričko s dl.rukávom,zelené s dievčaťom,vel.14	14	1	f	-	0	16	1	2012-10-13 19:07:39+02
657	tepláky,prúškaté,place,vel.12m	14	1.5	f	-	0	48	2	2012-10-13 17:24:17+02
654	nohavice modré,menžester,vel80,napis ABC /nové/	14	6.5	f	-	0	45	2	2012-10-13 17:24:17+02
655	tepláky,modré,truly,6m	14	1.5	f	-	0	46	1	2012-10-13 10:53:00+02
653	teplaky+bunda s kapuc.,modrý samet,lodka s namornikom,9-12m	14	3	f	-	0	44	2	2012-10-13 17:53:55+02
612	overal na spanie,,hnedo-biely	14	5	f	-	0	3	2	2012-10-13 17:54:58+02
615	bunda s kapucou ružová+šedá vložka, scorpion, 8-9r	14	15	f	-	0	6	2	2012-10-13 16:57:51+02
652	teplaky modré,cherokee,0-3m	14	1.6000000000000001	f	-	0	43	1	2012-10-13 10:53:26+02
650	tričko s dl.rukávom,samet,biele so zajkami,vel.3-6m	14	1.5	f	-	0	41	1	2012-10-13 10:53:49+02
649	trigovica s dl.rukávom,hnedá s autíčkami,vel 3-6m	14	1.5	f	-	0	40	1	2012-10-13 10:53:53+02
648	tričko s dl.rukávom,modro-hnedý pásik,so psíkom,3-6m,marks spense	14	1.8	f	-	0	39	1	2012-10-13 10:53:59+02
647	tričko s dl.rukávom,adams kind,hnedé s nápisom making a mess,6-12m	14	0.5	f	-	0	38	1	2012-10-13 10:54:06+02
646	dupačky,zelene,frog,vel.6-9m	14	2	f	-	0	37	1	2012-10-13 10:54:10+02
645	tričko s dl.rukávom na 3 gombíky,modré,place, vel.12m	14	1.5	f	-	0	36	1	2012-10-13 10:54:13+02
644	body s dl.rukávom,autíčka,vel. 6-9m	14	1	f	-	0	35	1	2012-10-13 10:54:16+02
643	body s dl.rukávom,bielo-modré hviezdičky,vel.6-9m	14	1	f	-	0	34	1	2012-10-13 10:54:20+02
658	nohavice+tričko s dl.rukavom,ohm&emmy,hnedo-zelene,s autom,9-12m	14	6.5	f	-	0	49	2	2012-10-13 17:17:11+02
641	body s dl.rukávom,bielo-modré pásiky,vel.6-9m	14	0.5	f	-	0	32	1	2012-10-13 10:54:26+02
640	body s dl.rukávom,pásikavé,hello sunshine,vel. 6-9m	14	0.5	f	-	0	31	1	2012-10-13 10:54:32+02
639	body s dl.rukávom,prúškaté,vel 6-9m	14	0.80000000000000004	f	-	0	30	1	2012-10-13 10:54:35+02
638	nohavice zateplené,cherokee,modré,vel. 12-18m	14	4.5	f	-	0	29	1	2012-10-13 10:54:46+02
637	trigovica zelená s kapucou,vel.12m	14	2	f	-	0	28	1	2012-10-13 10:54:57+02
636	trigovica lonsdale,modrá s kapucou,3-6m	14	2.5	f	-	0	27	1	2012-10-13 10:55:01+02
634	trigovica next,modrá s kapuckou,vel 0-3m	14	2	f	-	0	25	1	2012-10-13 10:55:06+02
635	trigovica,raccoon,červená,vel. 9-12. s kapucou	14	1	f	-	0	26	1	2012-10-13 10:55:10+02
633	kombinéza,modrá so sloníkom,cherokee,0-3m	14	4	f	-	0	24	1	2012-10-13 10:55:17+02
631	pyžamo,modré s mackom, vel. 6-9m, samet	14	1.5	f	-	0	22	1	2012-10-13 10:55:41+02
630	pyžamo,modré so sloníkmi,tajpex,vel.68	14	2	f	-	0	21	1	2012-10-13 10:55:44+02
632	pyžamo,modré so zajkom,samet,vel. 3-6m	14	1.5	f	-	0	23	2	2012-10-14 12:58:25+02
628	tričko s dl.rukávom,modé,bodkované,vel. 8r	14	1.5	f	-	0	19	1	2012-10-13 10:55:51+02
624	nohavice sametové,modré s ružový nápisom,vel. 146/tepláky/	14	2	f	-	0	15	2	2012-10-13 19:09:27+02
626	tričko s dl.rukávom,čierne s ružovo-fial.víla,vel.10/12,cherokéé	14	2.5	f	-	0	17	1	2012-10-13 10:56:07+02
656	tepláky,zeleno-modrý prúžok, vel.12m,mexx	14	1.8	f	-	0	47	2	2012-10-13 16:43:26+02
614	bunda s kapucou,čierno-ruzová,george,7-8r	14	6.5	f	-	0	5	1	2012-10-13 19:14:52+02
623	tričko s dl.rukávom+kapuca,modré pásiky, 134/140	14	3	f	-	0	14	1	2012-10-13 10:56:38+02
622	tričko s dl.rukávom,fialové,so stojáčikom,vel.146	14	2	f	-	0	13	1	2012-10-13 10:56:41+02
613	tricko s dl.rukavom so stojáčikom,ruzove,8-9r.	14	2	f	-	0	4	2	2012-10-13 16:06:44+02
620	rifle čierne,cherokee, 8-9r	14	3.5	f	-	0	11	1	2012-10-13 10:56:49+02
619	rifle modré,146/152	14	3	f	-	0	10	1	2012-10-13 10:56:55+02
617	tričko s dl.rukavom,červene,angel devil,8-9r	14	2	f	-	0	8	1	2012-10-13 10:57:08+02
621	tričko s dl.rukávom,ružová-eifelová veža, vel.146	14	2.5	f	-	0	12	2	2012-10-13 15:52:30+02
642	body s dl.rukávom,šedo-čierny pásik,opica,vel.74/80	14	1.2	f	-	0	33	2	2012-10-13 17:07:06+02
616	tričko s dl.rukavom,červene,kvetinky,yes by kinds,8-9r	14	2	f	-	0	7	2	2012-10-13 15:31:16+02
627	tričko s dl.rukávom,ružové,bodkované,vel. 8r	14	1.5	f	-	0	18	2	2012-10-13 19:09:27+02
659	súprava kojen./čapička,košiel,kabatik,dupačky/4ks	14	6	f	-	0	50	2	2012-10-13 18:40:10+02
611	overal na spanie,cherokee,hnedo-biely macko	14	5	f	-	0	2	1	2012-10-13 10:57:56+02
629	tričko s dl.rukávom,čierno-biele pásiky,vel. 146/152	14	2	f	-	0	20	2	2012-10-14 10:43:23+02
666	Červený flísový kabátik s nápisom Teddy,v. 92	15	2	f	-	0	7	1	2012-10-13 11:46:09+02
661	Ružový svetrík, v.74, zn. Coccobello, nádherný	15	4	f	-	0	2	1	2012-10-13 11:46:15+02
662	Ružová flísová čiapka v predu s hnedým mackom, v. 3-12 mes,zn. Items	15	1	f	-	0	3	1	2012-10-13 11:46:18+02
663	Ružová čiapočka v predu s aplikáciou dievčatka,zn. Rockino	15	2	f	-	0	4	1	2012-10-13 11:46:35+02
664	Modré riflové nohavice s aplikáciami, manžetami, veľ. 92	15	1	f	-	0	5	1	2012-10-13 11:46:36+02
665	Červený kompletík čiapočka + šál zo strapcami 	15	2	f	-	0	6	1	2012-10-13 11:46:43+02
667	Žltá súpravička menžestrová nohavice + vesta, na cca 1 rok	15	1.2	f	-	0	8	1	2012-10-13 11:46:56+02
660	Ružová bunda s kapucňou a šálik biely,v. 74-80,zn. Lupilu.	15	5	f	-	0	1	2	2012-10-13 19:19:16+02
669	Modré flísové nohavice s ružovým lemom,v. 18 mes	15	1	f	-	0	10	1	2012-10-13 11:47:07+02
603	oranžovo hnedý sveter STREET, veľ. 104	13	3	f	-	0	44	1	2012-10-13 12:05:36+02
604	zeleno hnedý sveter FROG, veľ. 110 – 116	13	1.5	f	-	0	45	1	2012-10-13 12:05:40+02
605	červený svetrík na gombíky Cgiboogi veľ.104	13	1.2	f	-	0	46	1	2012-10-13 12:05:50+02
606	ružové tričko, čierne gombíky, veľ.80	13	1.2	f	-	0	47	1	2012-10-13 12:05:53+02
607	hnedý svetrík, vpredu červené srdiečko, zips	13	1.3	f	-	0	48	1	2012-10-13 12:05:55+02
608	šaty ružové, flaušové, veľ.4 r.	13	2	f	-	0	49	1	2012-10-13 12:05:57+02
609	šaty žlté, flaušové, veľ.116	13	2.5	f	-	0	50	1	2012-10-13 12:05:59+02
1099	trigovica smotanova s lienkami	26	2	f	-	0	10	1	2012-10-13 12:29:06+02
740	Tmavomodrá flísová čiapka + šál pre dievča, 2 ks	17	3	f	-	0	1	1	2012-10-13 09:42:23+02
741	Červená vestička GAP, 12-18 mesiacov	17	1.5	f	-	0	2	1	2012-10-13 09:42:23+02
743	Tmavošedé tričko s dl. Rukávom Cherokee, veľ. 86	17	0.5	f	-	0	4	1	2012-10-13 09:42:23+02
719	sedy pulovrik zn DAMINI	16	1	f	-	0	30	2	2012-10-14 11:09:55+02
673	Zelené hrubé nohavice na zimu,v.74	15	1.2	f	-	0	14	1	2012-10-13 11:47:14+02
670	Bielo – ružová mikina v predu s myškou, kapucňa,v.74	15	1	f	-	0	11	1	2012-10-13 11:47:17+02
671	Ružová tunika s modrými rukávmi a srdiečkami, v. 6-9 mes., zn. Tiny ted	15	2	f	-	0	12	1	2012-10-13 11:47:26+02
729	modry pulovrik vpredu cislo 58	16	1	f	-	0	40	2	2012-10-14 14:05:56+02
720	modra mikina v predu obrazok macka v. 98	16	2	f	-	0	31	2	2012-10-13 18:10:52+02
676	Bledo modré tepláčiky,zn. Reebok, v.68	15	1.5	f	-	0	17	1	2012-10-13 11:47:46+02
677	Ružové flísové nohavice + ponožky,v.62	15	1	f	-	0	18	1	2012-10-13 11:47:52+02
678	Bielo- ružová čiapka v predu s aplikáciou kvetu, poľská výroba	15	1.5	f	-	0	19	1	2012-10-13 11:47:58+02
691	strikovana ciapka s brmbolcami	16	1	f	-	0	2	2	2012-10-13 16:57:51+02
683	Čierne menžestráky,v.98-104, na nohavici nápis Fifa Club	15	1.5	f	-	0	24	1	2012-10-13 11:48:13+02
679	Biele dupačky s motívom dievčatka.v.74	15	0.5	f	-	0	20	1	2012-10-13 11:48:16+02
680	Fialkové tričko zo stojačikom, motív Hello Kitty, zn. Lusa,v. 12m	15	0.69999999999999996	f	-	0	21	1	2012-10-13 11:48:19+02
681	Bielo-ružová súprava, nohavice+vesta+mikina,v.cca 74-80.	15	1.2	f	-	0	22	1	2012-10-13 11:48:24+02
685	Ružové tričko s dl. rukávom,zn. F&F,v.12-18 mes.,nápis Little tweetie	15	2	f	-	0	26	1	2012-10-13 11:48:33+02
684	Zimná menžestráková bunda, bledo modrá na zips,v.cca 98-104	15	1.5	f	-	0	25	1	2012-10-13 11:48:38+02
686	žltý svetrík na stužku, veľkosť cca 80-86	15	2	f	-	0	27	1	2012-10-13 11:48:49+02
1100	trigovica seda	26	0.29999999999999999	f	-	0	11	1	2012-10-13 12:29:17+02
717	tmavozeleny sveter na zips v. 2/3 r. 	16	2.5	f	-	0	28	2	2012-10-13 17:40:26+02
725	zelenohneda siltacka Bob 	16	0.5	f	-	0	36	1	2012-10-13 12:35:42+02
726	zltohneda siltacka Bob	16	1	f	-	0	37	1	2012-10-13 12:35:45+02
728	modre pancusky v 9m.	16	0.80000000000000004	f	-	0	39	1	2012-10-13 12:35:49+02
727	tmavomodre pancusky	16	1	f	-	0	38	1	2012-10-13 12:35:52+02
682	2 ks pančucháče v. 74-80	15	0.5	f	-	0	23	2	2012-10-13 16:50:52+02
731	bordovy pulovrik pasikavy	16	1	f	-	0	42	1	2012-10-13 12:36:13+02
730	cierny pulovrik vpredu c. 2	16	1	f	-	0	41	1	2012-10-13 12:36:17+02
734	rifle v. 68 s oranzovym patentom	16	2	f	-	0	45	1	2012-10-13 12:36:30+02
735	rifle v.74 s ruzovym lemom na boku	16	2	f	-	0	46	1	2012-10-13 12:36:33+02
736	sede nohavice zateplene v.3m.	16	2	f	-	0	47	1	2012-10-13 12:36:36+02
737	zlte leginy v.3/6 m.	16	0.69999999999999996	f	-	0	48	1	2012-10-13 12:36:40+02
710	sedo/zelene zimne topanky na suchy zips v. 27	16	5	f	-	0	21	2	2012-10-13 16:34:29+02
739	riflove nohavice v.3/6 m.	16	2	f	-	0	50	1	2012-10-13 12:36:45+02
723	tmavomodra bunda zn. H&M v. 3/4 r.	16	2	f	-	0	34	1	2012-10-13 12:37:06+02
713	biele lakovky v. 35	16	2	f	-	0	24	2	2012-10-14 09:44:16+02
721	seda ciapka 	16	1	f	-	0	32	1	2012-10-13 12:37:27+02
697	zeleno/ruzova trigovica v.140	16	1.5	f	-	0	8	2	2012-10-13 18:31:57+02
705	fialkova vesta v. 6/7 r.	16	3	f	-	0	16	2	2012-10-14 11:10:35+02
718	bledomodra pletena vesta v. 3 r.	16	2	f	-	0	29	1	2012-10-13 12:37:39+02
675	Fialová tunika s kapucňou,efekt 2 v 1,v. 80, zn. C&A	15	3	f	-	0	16	2	2012-10-13 18:07:21+02
724	modrozelenobiela budna s kapucnou v. 2/3 r.	16	1	f	-	0	35	2	2012-10-13 17:30:27+02
715	riflova bunda v. 4/5 r.	16	2	f	-	0	26	1	2012-10-13 12:37:50+02
714	ruzove platene cvicky na suchy zips 	16	0.5	f	-	0	25	1	2012-10-13 12:37:56+02
701	bordovo/fialove saty	16	2	f	-	0	12	2	2012-10-14 10:38:24+02
672	Ružová mikina s kapucňou, podšitá, na gombíky,v.3-6 mes., zn. Tiny Ted	15	2	f	-	0	13	2	2012-10-14 10:48:25+02
732	cervenocierny pulovrik vpredu Snoopy v aute	16	1	f	-	0	43	2	2012-10-13 16:50:17+02
711	cierne zimne topanky na suchy zips v. 26	16	5	f	-	0	22	2	2012-10-14 09:44:16+02
712	jesene topanky sedo/zelene na suchy zips v. 25	16	2	f	-	0	23	1	2012-10-13 12:38:55+02
674	Tmavo ružové polodupačky,zn. Richelieu,v.-74-80	15	1	f	-	0	15	2	2012-10-14 13:10:21+02
704	cerveno/modra trigovica na zips 	16	1	f	-	0	15	1	2012-10-13 12:39:52+02
703	oranzova trigovica v. 104	16	1	f	-	0	14	1	2012-10-13 12:39:54+02
702	cervena trigovica v. 110/116	16	1	f	-	0	13	1	2012-10-13 12:39:56+02
709	hnede zimne topanky v. 24	16	5	f	-	0	20	2	2012-10-14 10:45:13+02
706	bezova bunda s kapucov v. 150/155 cm	16	3	f	-	0	17	1	2012-10-13 12:40:07+02
708	tmavozelena bunda nepremokava v. S	16	3	f	-	0	19	1	2012-10-13 12:40:13+02
707	bleducko modra bunda znacka OLYMPUS v. XS	16	3	f	-	0	18	1	2012-10-13 12:40:16+02
699	sedo/modri strikovany svetrik s kapucov	16	2	f	-	0	10	1	2012-10-13 12:40:29+02
700	biely pulovrik v predu motyliky a kvety	16	2	f	-	0	11	1	2012-10-13 12:40:30+02
698	cierna trigovica v predu ruzovy napis	16	1.5	f	-	0	9	1	2012-10-13 12:40:41+02
722	tmavomodra nepremokava bunda s kapucou v. 98/104	16	4	f	-	0	33	2	2012-10-14 09:44:16+02
696	ruzova trigovica v. 134	16	1.5	f	-	0	7	1	2012-10-13 12:40:45+02
690	siltovka HANNAH MONTANA 	16	1	f	-	0	1	1	2012-10-13 12:40:58+02
716	bledomodrohnedy pleteny sveter zn. H&M v. 3/4 r.	16	3	f	-	0	27	2	2012-10-13 17:06:36+02
694	cerveno/cierna ciapka	16	1	f	-	0	5	1	2012-10-13 12:41:08+02
693	cierno/seda ciapka	16	1	f	-	0	4	1	2012-10-13 12:41:11+02
695	cierno/biela ciapka	16	1	f	-	0	6	1	2012-10-13 12:41:16+02
692	hackovana fialkova ciapka	16	3	f	-	0	3	1	2012-10-13 12:41:20+02
738	ruzove gate flausove 	16	2	f	-	0	49	2	2012-10-13 16:25:44+02
801	bielý dievčenský kabatik, vel. 62,	18	3	f	-	0	12	1	2012-10-13 08:13:49+02
765	Bledozelené tričko s dl.r., kvetinová nažehľovacia aplikácia, veľ. 110	17	1.5	f	-	0	26	2	2012-10-13 17:45:45+02
794	zimná kombinéza, F&F šedý podšite kožušinkou, vel. 68 	18	8	f	-	0	5	1	2012-10-13 08:14:06+02
795	teplé dupačky, biele v predu malý macko, vel.68	18	3	f	-	0	6	1	2012-10-13 08:14:16+02
796	teplé dupačky, biele v predu malý macko, vel.56	18	3	f	-	0	7	1	2012-10-13 08:14:24+02
791	zimný vak, bielý s farebnými trojuholníkmi, vel. 0-4	18	4	f	-	0	2	1	2012-10-13 08:14:50+02
790	zimná kombinéza tmavo modrá,z vnútra podšite káro,v predu malý macko, vel. 3-6 mes.	18	4	f	-	0	1	1	2012-10-13 08:17:05+02
797	rifle na traky, BABY WORLD nápis, zn.  ITEMS, vel. 74	18	2.5	f	-	0	8	1	2012-10-13 08:17:30+02
793	zimná čiapka, RACER, vel. 9-12, obvod hlavy 49cm.	18	1.5	f	-	0	4	1	2012-10-13 08:18:16+02
774	Červená mikina na zips s kapucňou, Coandin	17	1.5	f	-	0	35	2	2012-10-13 19:06:08+02
800	čierný svetrík, H&M, vel. 68	18	3	f	-	0	11	1	2012-10-13 08:19:22+02
804	oranžová károvana košela,F&F, vel. 62	18	2	f	-	0	15	1	2012-10-13 08:19:39+02
803	bielé teplé tričko, vel. 62	18	1.5	f	-	0	14	1	2012-10-13 08:20:37+02
744	Šedá vrúbkovaná mikinka na gombíčky, dole nášivka Friends	17	1	f	-	0	5	1	2012-10-13 09:42:23+02
745	Štrikovaný svetrík, modrá + melírovaná, bordové gombíčky	17	1	f	-	0	6	1	2012-10-13 09:42:23+02
746	Červeno-biela kockovaná košieľka, veľ. 100	17	1	f	-	0	7	1	2012-10-13 09:42:23+02
747	Bielo-modrý prúžkovaný župan s vyšitou myškou, veľ. cca 2-3 roky	17	1.5	f	-	0	8	1	2012-10-13 09:42:23+02
748	Biele tričko, dl.r., motív psíkov a modré lemovane, Cherokee, veľ. 62	17	1	f	-	0	9	1	2012-10-13 09:42:23+02
749	Marhuľovo-zelený overal bez dupiek s macíkom a nápisom Volare	17	1	f	-	0	10	1	2012-10-13 09:42:23+02
768	Prúžkované tričko hnedo-ružovo-oranžovo-tyrkisové, veľ. 116	17	1	f	-	0	29	2	2012-10-13 16:50:17+02
751	Fialová tunika s rozstrihnutými rukávmi a zvlneným okrajom, F&F, veľ. 122	17	2	f	-	0	12	1	2012-10-13 09:42:23+02
752	Ružová krepovaná tunika s výšivkou, veľ. 116, Items	17	2	f	-	0	13	1	2012-10-13 09:42:23+02
753	Ružový sveter (fialovo-zelené rukávy) s drevenými gombíkmi a vyšitou myškou	17	1	f	-	0	14	1	2012-10-13 09:42:23+02
754	Biela mikina s modro-striebornou výšivkou kvietkov, veľ. 116/126	17	1	f	-	0	15	1	2012-10-13 09:42:23+02
755	Disney fialová mikina s Minnie, veľ. 128	17	1	f	-	0	16	1	2012-10-13 09:42:24+02
756	Zelené tričko s ruž. vsadkami a výšivkou, Wenice kids, 134	17	1	f	-	0	17	1	2012-10-13 09:42:24+02
758	Hnedobéžová vrúbkovaná šiltovka maličká	17	0.5	f	-	0	19	1	2012-10-13 09:42:24+02
759	Bordový štrikovaný sveter so stojatým golierom a V-éčkovým výstrihom, veľ. cca 4-5 rokov	17	1	f	-	0	20	1	2012-10-13 09:42:24+02
760	Marhuľový štrikovaný pulóver s nopkami a dierkami, veľ. cca 6 rokov	17	1	f	-	0	21	1	2012-10-13 09:42:24+02
761	Ružová flísová čiapka so strapcami	17	1	f	-	0	22	1	2012-10-13 09:42:24+02
762	Bledomodré nohavice Early days, veľ. 62	17	2	f	-	0	23	1	2012-10-13 09:42:24+02
763	Ružový prúžkovaný sveter-rolák, veľ. 3	17	2	f	-	0	24	1	2012-10-13 09:42:24+02
764	Biele a žlté vrúbkované tričká,d.r., aplikácia psíka, zajka, 2 ks	17	1	f	-	0	25	1	2012-10-13 09:42:24+02
766	Fialové prúžkované tričko s d.r., CDF, veľ. 10	17	1.5	f	-	0	27	2	2012-10-13 18:11:14+02
805	bielo-modrá pásikavá trigovička C&A, vel. 62, z vnútra malý mackovia	18	2.5	f	-	0	16	2	2012-10-13 18:40:10+02
767	Tmavomodrý polorolák so semišovými aplikáciami Love a leopardím vzorom na rukávoch	17	1.5	f	-	0	28	1	2012-10-13 09:42:24+02
799	modrá prechodná bundička, vel. 68, 	18	2	f	-	0	10	2	2012-10-13 17:10:51+02
769	Tmavozelená flísová mikina s krémovými rukávmi a výšivkou, veľ. 122	17	1.5	f	-	0	30	1	2012-10-13 09:42:24+02
770	Zateplené olivové kordové nohavice, s ozdobnými šnúrkami a nitmi, veľ. 8	17	2.5	f	-	0	31	1	2012-10-13 09:42:24+02
771	Riflové nohavice na traky s farebnými gombíkmi a vyšitým psíkom , veľ. 104	17	1	f	-	0	32	1	2012-10-13 09:42:24+02
772	Zateplené rifle na traky so striebornými gombíkmi, veľ. 86	17	1	f	-	0	33	1	2012-10-13 09:42:24+02
773	Červená chlpatá mikina s vyšitými hviezdami, zips na pleci 	17	1.5	f	-	0	34	1	2012-10-13 09:42:24+02
757	Ružové prúžkované tričko s gombíčkami, d.r., Next, veľ. 134	17	1	f	-	0	18	2	2012-10-14 12:16:42+02
775	Olivové elastické nohavice, vrecká na zips, veľ. 8	17	2	f	-	0	36	1	2012-10-13 09:42:24+02
776	Ružové plátenné nohavice s výšivkou kvetov, Cherokee, veľ. 110	17	2	f	-	0	37	1	2012-10-13 09:42:24+02
777	Zimná hnedá menčestrová bundička s kapucňou, Baby Club, veľ. 86	17	5	f	-	0	38	1	2012-10-13 09:42:24+02
778	Tmavozelené úzke nohavice s vyšitými kvetmi na spodu, veľ. 8	17	2	f	-	0	39	1	2012-10-13 09:42:24+02
779	Biela "kuchárska" košeľa v čínskom štýle s vyšitými oranžovými čín. znakmi, veľ. 5/6	17	1	f	-	0	40	1	2012-10-13 09:42:24+02
780	Fialové menčestrové nohavice s pozdĺžnym prešívaním, Kikstar, v.116	17	2	f	-	0	41	1	2012-10-13 09:42:25+02
781	Ružový zimný overal tenký, veľ. 128	17	3	f	-	0	42	1	2012-10-13 09:42:25+02
782	Hnedá dievč. Zimná bunda s kožušinou na golieri, veľké gombíky	17	2	f	-	0	43	1	2012-10-13 09:42:25+02
750	Béžový overal s macíkom a húskami, zapínanie na chrbátiku, veľ. 80	17	1	f	-	0	11	2	2012-10-13 16:02:17+02
784	Fialková blúzka, jednofarebná, spodná okraj do oblúka, veľ. 122	17	1.5	f	-	0	45	1	2012-10-13 09:42:25+02
785	Lososová mikina Cherokee, nápis Lovely girls, veľ. 128	17	1.5	f	-	0	46	1	2012-10-13 09:42:25+02
786	Modrý pletený sveter s bielym vzorom zajačikov	17	1.5	f	-	0	47	1	2012-10-13 09:42:25+02
787	Rifle s aplikáciou motýlikov, veľ. 10	17	1	f	-	0	48	1	2012-10-13 09:42:25+02
788	Rifle s obrovským gombíkom, Crash one, veľ. 134	17	4	f	-	0	49	1	2012-10-13 09:42:25+02
783	Ružová zimná bunda s kapucňou, veľ. 170	17	3	f	-	0	44	2	2012-10-13 15:01:38+02
822	biele tepláčiky s modrými pásikmi, C&A,  vel. 62	18	3	f	-	0	33	1	2012-10-13 08:14:34+02
825	dupačky oranžové pásikavé, (mačička) vel. 56	18	2	f	-	0	36	1	2012-10-13 08:15:00+02
824	dupačky zelené pásikave, (TOBY) vel. 56	18	2	f	-	0	35	1	2012-10-13 08:15:05+02
806	5 ks krátkých bodičiek (3 biele s  myškami,  zelené pásikave,modré pásikavé a hnede pásikavé)vel.56-62	18	4	f	-	0	17	1	2012-10-13 08:15:23+02
828	disney suprava rifle na traky s mackom Pú, plus pásikove farebné tričko vel. 56-62	18	4	f	-	0	39	1	2012-10-13 08:16:34+02
808	krátka modrá pásiková  košela F&F, vel. 56	18	0.5	f	-	0	19	1	2012-10-13 08:16:20+02
827	topanočky everlast, 19 	18	8	f	-	0	38	1	2012-10-13 08:16:38+02
829	topanočky, lion 17	18	5	f	-	0	40	1	2012-10-13 08:16:43+02
823	capačky ,kaky farba so suchými zipsami	18	2.5	f	-	0	34	1	2012-10-13 08:16:50+02
826	2 ks, košele oranžová  a modra kockovaná,  3-6	18	3	f	-	0	37	1	2012-10-13 08:17:17+02
819	rifle disney, vel, 62	18	3	f	-	0	30	1	2012-10-13 08:18:22+02
820	rifle na gmičku (farebný pás) 62	18	2.5	f	-	0	31	1	2012-10-13 08:18:26+02
817	pyžamko šedé s pásikami, Mini-Gi, vel. 62 na zips, 	18	2	f	-	0	28	1	2012-10-13 08:18:34+02
811	3 ks dlhé body ( fialové C&A,modré, s koníkmi C&A,) vel. 56-62	18	2	f	-	0	22	1	2012-10-13 08:18:43+02
816	pyžamko (modré a biele so psíkmi) vel. 62	18	4	f	-	0	27	1	2012-10-13 08:18:52+02
840	rúžový rolák, vel. 15 m.	19	0.29999999999999999	f	-	0	11	2	2012-10-13 19:12:22+02
821	menšestrové nohavice H&M , 68, 	18	3	f	-	0	32	1	2012-10-13 08:19:45+02
814	3 ks košielky biele (s modrým limcom,žltým limcom, s krajkou)vel. 62-68	18	2	f	-	0	25	1	2012-10-13 08:20:27+02
815	3 ks BEAR POLAR (2x dlhá biele a modré body, 1x krátke biele tričko) vel. 3-6	18	4	f	-	0	26	1	2012-10-13 08:20:10+02
812	dlhé body, biele s mackom na predu,( marci) vel. 62	18	1.5	f	-	0	23	1	2012-10-13 08:20:46+02
810	dlhé body, biele (macko a zajko na predu) vel. 68, 	18	1.5	f	-	0	21	1	2012-10-13 08:20:54+02
809	dlhé body,pásikavé (žlto-modro-biele) C&A, vel. 56	18	1	f	-	0	20	1	2012-10-13 08:21:01+02
813	dlhé body, modré s vláčikom vel. 68,	18	1.5	f	-	0	24	1	2012-10-13 08:21:08+02
839	rúžove tepláky, teplé, vel. 4.r	19	1	f	-	0	10	1	2012-10-13 08:22:58+02
841	dupačky rúžove ,s mackami,  vel. 56	19	1	f	-	0	12	1	2012-10-13 08:23:11+02
842	biele dupačky, laona, vel. 80	19	0.5	f	-	0	13	1	2012-10-13 08:23:14+02
843	modré dupačky, s bielimi krajkami, vel. 68	19	0.5	f	-	0	14	1	2012-10-13 08:23:22+02
831	rúžová trigovica s kapucnou, vel. 3 r.	19	2	f	-	0	2	2	2012-10-13 18:04:43+02
845	chlap. Svetrík vel. L	19	0.5	f	-	0	16	1	2012-10-13 08:23:32+02
846	dievč, tričko s dlhým rukávom, s kvetinkami , vel. 115	19	0.40000000000000002	f	-	0	17	1	2012-10-13 08:23:36+02
847	modrá vestičky, s koníkom, vel. 68	19	0.40000000000000002	f	-	0	18	1	2012-10-13 08:23:41+02
848	ružové dupačky,na gombiky, vel. 62	19	0.5	f	-	0	19	1	2012-10-13 08:23:47+02
849	bordové nohavice, s kvetinkami, vel. 74	19	0.5	f	-	0	20	1	2012-10-13 08:23:56+02
850	rúžove tričko milk,milk,milk....vel. 6-9	19	0.40000000000000002	f	-	0	21	1	2012-10-13 08:24:08+02
851	teplé nohavice oranžové , vrel. 62	19	0.5	f	-	0	22	1	2012-10-13 08:24:14+02
852	ružové tepláky, vel. 4 r.	19	0.40000000000000002	f	-	0	23	1	2012-10-13 08:24:19+02
853	cervené tepláky, vel. 3 r	19	0.59999999999999998	f	-	0	24	1	2012-10-13 08:24:25+02
856	béžová vesta s kuriatko, ver. 68	19	0.40000000000000002	f	-	0	27	1	2012-10-13 08:24:37+02
857	rúžove dupačky, so zajacmi na gombíky, vel. 62	19	0.59999999999999998	f	-	0	28	1	2012-10-13 08:24:41+02
858	žlto modra suprava, vel. 104, s kvetinkami	19	1.5	f	-	0	29	1	2012-10-13 08:24:47+02
862	černené tričko, s lienkou, pasikave, vel.n 2-3	19	0.59999999999999998	f	-	0	33	2	2012-10-13 16:55:58+02
860	rúžove dupačky s mackom, teplejšie, vel. 68	19	0.59999999999999998	f	-	0	31	1	2012-10-13 08:24:57+02
861	3 ks, tepláky, modré,rúžové, šedé,	19	1	f	-	0	32	1	2012-10-13 08:25:05+02
863	teplačiky žlté so srdiečkami,  74	19	0.69999999999999996	f	-	0	34	1	2012-10-13 08:25:13+02
864	Zimná kvetinková bunda bielo-modrá, zn. Next, vel. 98	20	12	f	-	0	1	2	2012-10-13 17:18:28+02
838	rúžovo modrá trigovica na zips, vel. 4 r, 	19	1	f	-	0	9	1	2012-10-13 08:25:27+02
818	3 ks pyžamka,(zvieratkové,farmarské,botkové) vel. 62-68	18	4	f	-	0	29	2	2012-10-13 18:53:01+02
836	zelený teplý rolak, vel. 2r	19	1.6000000000000001	f	-	0	7	1	2012-10-13 08:25:44+02
835	die.rolák rúžový,vel.15 m., street kids	19	2.5	f	-	0	6	1	2012-10-13 08:25:50+02
834	broskynova trigovica s kapucnou,, na zips, vel. 3r	19	2	f	-	0	5	1	2012-10-13 08:25:56+02
833	dievč. Tepláky, šedo rúžové, vel. 86	19	1	f	-	0	4	1	2012-10-13 08:26:03+02
832	červené tepláky č. 54 league sports, vel. 9-12,	19	1	f	-	0	3	1	2012-10-13 08:26:15+02
830	rúžová detska súprava (3ks) vel.4 r.	19	5	f	-	0	1	2	2012-10-13 18:23:22+02
837	červená teplákova suprava, vel. 98, s kvetinkami	19	2.6000000000000001	f	-	0	8	2	2012-10-13 18:23:22+02
865	Zimná kombinéza bledoružová, na zipse vyšívaná s kamienkami, zn. Tup Tup, vel. 68	20	12	f	-	0	2	1	2012-10-13 10:18:05+02
844	rúžová tepla trigovica s kožušinkou, vel. 62	19	3	f	-	0	15	2	2012-10-13 18:03:40+02
866	Chlpatá zimná kombinéza fialovo-ružová, zn. Sanetta, vel. 68	20	16	f	-	0	3	1	2012-10-13 10:18:39+02
867	Tmavofialová bundička s rukavicami, zn. Next, vel. 98	20	8	f	-	0	4	1	2012-10-13 10:19:06+02
868	Fialkový kožúštek, zn. Next, vel. 98	20	8	f	-	0	5	1	2012-10-13 10:20:07+02
873	Fialové menčestrové šaty so srdiečkovým body, zn. F&F, vel. 86	20	5	f	-	0	10	1	2012-10-13 10:25:04+02
872	Ružová semišová súprava - vestička a nohavice, zn. Lassie, 80	20	5	f	-	0	9	1	2012-10-13 10:25:16+02
871	Pletené šaty smotanovej farby, zn. F&F, vel. 86	20	5	f	-	0	8	1	2012-10-13 10:25:29+02
870	Červené pletené šaty Minie, bodkované pančušky, zn. Disney, vel. 80	20	7	f	-	0	7	1	2012-10-13 10:25:39+02
869	Ružový pletený svetrík, čiapočka, 2x topánočky	20	9	f	-	0	6	1	2012-10-13 10:25:47+02
859	bordove tepláky, vel.. 3.r , s tučnakom na spodu	19	1	f	-	0	30	2	2012-10-13 15:45:41+02
908	Detská ľadvinka v tvare korytnačky	21	1	f	-	0	2	1	2012-10-13 09:43:43+02
909	Pletená hnedo-modro-béžová vestička	21	1	f	-	0	3	1	2012-10-13 09:43:43+02
911	Tmavošedá lesklá mikina s krátkym zipsom, Kids company, veľ. 116	21	1	f	-	0	5	1	2012-10-13 09:43:43+02
912	Ružová flísová mikina s potlačou balet. Cvičiek, Oshkosh, veľ. 6	21	2	f	-	0	6	1	2012-10-13 09:43:43+02
913	Oranžovo-zelené pončo s kapsičkou, veľ. 6	21	2.5	f	-	0	7	1	2012-10-13 09:43:43+02
925	Látkový panáčik spiaci-bdejúci, veľký (cca 60 cm)	21	1	f	-	0	19	2	2012-10-13 16:44:41+02
915	Plisovaná tehotenská blúzka, károvaná zeleno-hnedá	21	3	f	-	0	9	1	2012-10-13 09:43:43+02
916	Staroružový vlnený tehotenský sveter s V-éčkovým výstrihom	21	4	f	-	0	10	1	2012-10-13 09:43:43+02
917	Zelený tehotenský vrúbkovaný sveter na zapínanie	21	5	f	-	0	11	1	2012-10-13 09:43:43+02
918	Tmavomodré pačuchy s tyrkysovými a ružovými prúžkami, veľ. 6/8	21	1	f	-	0	12	1	2012-10-13 09:43:43+02
919	Tmavohnedé tehotenské kordové nohavice	21	2	f	-	0	13	1	2012-10-13 09:43:43+02
920	Pastelová šiltovka s 3D zajačikom	21	1	f	-	0	14	1	2012-10-13 09:43:43+02
921	Tyrkysová čiapka s tromi bielymi brmbolcami, Sportex	21	1	f	-	0	15	1	2012-10-13 09:43:43+02
922	Tyrkysovo-žlto-šedá baretka	21	0.5	f	-	0	16	1	2012-10-13 09:43:43+02
923	Tmavomodré pololakovky s vyšitými kvietkami, Bama, veľ. 30	21	1.5	f	-	0	17	1	2012-10-13 09:43:43+02
924	Červená dievčenská zimná bunda s kvietkovanou podšívkou	21	1	f	-	0	18	1	2012-10-13 09:43:43+02
899	Bledoružový overal s mačičkou, zn. Lupilu, vel. 74/80	20	1.5	f	-	0	36	2	2012-10-13 17:47:00+02
926	Pletená modro-zelená sukňa, Aqua, veľ. 128	21	1.5	f	-	0	20	1	2012-10-13 09:43:43+02
927	Kordová kvetovaná sukňa so striebornou prackou	21	2.5	f	-	0	21	1	2012-10-13 09:43:43+02
928	Bordová károvaná sukňa	21	2	f	-	0	22	1	2012-10-13 09:43:43+02
929	Hnedé prechodné čižmy so štucňami, veľ. 34	21	1.5	f	-	0	23	1	2012-10-13 09:43:44+02
930	Biele kotníkové "číňany" s károm, veľ. 34	21	1.5	f	-	0	24	1	2012-10-13 09:43:44+02
895	Súprava - 2x body s dlhým rukávom tmavoružové a biele s farebnými srdiečkami, vel. 92	20	2.5	f	-	0	32	2	2012-10-13 15:56:01+02
932	Červené semišové čižmy, veľ. 33	21	1	f	-	0	26	1	2012-10-13 09:43:44+02
905	Bledomodrá kvetinková bundička, zn. F&F, vel. 86	20	5	f	-	0	42	2	2012-10-13 18:49:05+02
934	Hnedé kožené čižmy s prackou, veľ. 13 1/2	21	2	f	-	0	28	1	2012-10-13 09:43:44+02
893	Ružový overal s dlhým rukávom a myšičkou, zn. Early Days, vel. 68	20	1.5	f	-	0	30	2	2012-10-14 10:36:19+02
914	Bordová bunda s chlpatými okrajmi, veľ. cca 7 rokov	21	1	f	-	0	8	2	2012-10-13 16:44:40+02
903	Bledoružové tričko s myšičkou - dlhý rukáv, zn. F&F, vel. 86	20	1.5	f	-	0	40	1	2012-10-13 10:20:41+02
898	Bledozelené body s vyšitou žabkou	20	1	f	-	0	35	1	2012-10-13 10:20:51+02
897	Súprava - 3x biele body s dlhým rukávom potlač macko, kvietky a zajačik, vel. 68	20	3	f	-	0	34	1	2012-10-13 10:21:00+02
935	pieskové menžestrové šaty na traky, gombíky kvietky, vpredu našité hviezdičky a kvetinka, NAPERO, 86	22	1.1000000000000001	f	-	0	1	2	2012-10-13 18:03:40+02
901	Biela čapica na uväzovanie nápis Baby, vel. 62	20	2.5	f	-	0	38	1	2012-10-13 10:21:16+02
900	Bledoružová čapica z outlastu, vel. 68	20	3	f	-	0	37	1	2012-10-13 10:21:20+02
902	Štrikovaný oranžový svetrík, vel. 68	20	2.5	f	-	0	39	1	2012-10-13 10:21:35+02
904	Červená semišová bundička s lienkou, ve. 86	20	5	f	-	0	41	1	2012-10-13 10:21:46+02
894	Sivé froté šaty bez rukávov, zn. Vroom&Dreesmann	20	1	f	-	0	31	1	2012-10-13 10:22:01+02
892	Súprava - 2x body s dlhým rukávom s bodkami a so zajačikmi - ružové, zn. F&F, vel. 74	20	2	f	-	0	29	1	2012-10-13 10:22:10+02
874	Fialová semišová tunika - šaty, zn. H&M, vel. 86	20	4	f	-	0	11	2	2012-10-14 12:50:36+02
888	Súprava - 2x tričko s dlhým rukávom Hello Kitty, zn. Sanrio, vel. 86	20	5	f	-	0	25	1	2012-10-13 10:22:32+02
881	Súpravy pyžamiek - 2x tričko, 2x nohavice, bledomodré so sloníkom, zn. F&F, vel. 62	20	3	f	-	0	18	1	2012-10-13 10:22:50+02
896	Bledomodré rifle s ružovou kvetinkou, vel. 68	20	2	f	-	0	33	1	2012-10-13 10:22:59+02
889	Semišový pásikavý ružový overal s myškami a čiapka, zn. Pidilidi, vel. 68	20	5	f	-	0	26	1	2012-10-13 10:23:06+02
890	Semišový bledoružový overal so zajačikom, zn. F&F, vel. 62	20	4	f	-	0	27	1	2012-10-13 10:23:13+02
886	Fialové tričko s dlhým rukávom - nápis KISS, zn. Mexx, vel. 92	20	6	f	-	0	23	1	2012-10-13 10:23:21+02
876	Bordová semišová vestička, zn. Bhs Baby, vel. 80	20	2	f	-	0	13	1	2012-10-13 10:23:29+02
880	Biela súprava - nohavice na traky a tričko, nápis 3107, zn. Dirkje, vel. 62	20	8	f	-	0	17	1	2012-10-13 10:23:42+02
882	Bledožltá suprava - dupačky, košieľka, čiapočka, vyšitý mackovia, vel. 62	20	4	f	-	0	19	1	2012-10-13 10:23:49+02
883	Biela košieľka - vyšitá kvetinka, zn. Coccodrillo, vel. 62	20	2	f	-	0	20	1	2012-10-13 10:23:57+02
891	Súprava pyžamiek - 2x tričko a 2x nohavice biele s hviezdičkami a ružové, zn. F&F, vel. 74	20	3	f	-	0	28	1	2012-10-13 10:24:09+02
885	Sivé semišové tepláčky, zn. Okay, vel. 56	20	2	f	-	0	22	1	2012-10-13 10:24:18+02
877	Semišové tepláčky - koralová oranžová, zn. Tup Tup, vel. 62	20	4	f	-	0	14	1	2012-10-13 10:24:24+02
884	Bledomodré body z outlastu, zn. Little Angel, vel. 62	20	3	f	-	0	21	1	2012-10-13 10:24:31+02
878	Menčestrové bledoružové nohavice s mašličkou, zn. Coccodrillo, vel. 56	20	4	f	-	0	15	1	2012-10-13 10:24:37+02
879	Fialové menčestrové šaty, zn. F&F, vel. 86	20	4	f	-	0	16	1	2012-10-13 10:24:42+02
875	Fialová semišová tunika - šaty s výšivkou, vel. 68	20	3	f	-	0	12	1	2012-10-13 10:24:53+02
933	Hnedé zimné topánky, veľ. 33	21	1	f	-	0	27	2	2012-10-13 18:11:14+02
1101	vesta biela	26	1	f	-	0	12	1	2012-10-13 12:29:19+02
931	Hnedé čižmy, lakovaný spodok, šuštiakový vrch, nášivka Aspen, veľ. 34	21	3	f	-	0	25	2	2012-10-13 14:48:29+02
954	hnedé menžestráky chlapč. GEORGE, 86	22	2	f	-	0	20	1	2012-10-13 10:29:02+02
963	modre tricko dlhy rukav s bielymi zirafami, cheerooke, 104.	22	1.3	f	-	0	29	1	2012-10-13 10:28:43+02
953	tmavomodrá mikina so stojačikom na zips, na L. rukáve červeno biele 48, H&M, 86	22	1	f	-	0	19	1	2012-10-13 10:29:04+02
962	zelenkavokrémová tepláková súprava-zelené tepláky s oranžovým prešitím, bunda zelenkavá na zips s krémovou kapucou a krémovými pásmi na rukávoch, vpredu krémový nápis YS,92	22	6	f	-	0	28	1	2012-10-13 10:29:09+02
968	modré teplé chlapč.podkolienky s s bielymi a bledomodrými kosoštvorcami, ,27-30	22	0.80000000000000004	f	-	0	34	2	2012-10-14 10:03:00+02
960	hnedobielokrémová pásiková šašovská čiapka na zaväzovanie, DATEX, cca86	22	2	f	-	0	26	1	2012-10-13 10:29:20+02
959	tmavošedá úpletová čiapka s bielym lemom a bielou snehovou vločkou vyšitou, cca122	22	1.8	f	-	0	25	1	2012-10-13 10:29:23+02
952	tmavomodré oteplovačky, vnútri flis, vpredu zajko a don oti, vel.62	22	2	f	-	0	18	1	2012-10-13 10:29:37+02
951	tmavomodročerveno krémový pásikový pulover žinilkový,nápis junior j, , zn.gomeb, vel.86	22	1.6000000000000001	f	-	0	17	1	2012-10-13 10:29:41+02
950	červená fliska so zipsom pri krku, modrá kapuca, vpredu v strede modré pásy, BAY,12/18	22	1.8	f	-	0	16	1	2012-10-13 10:29:44+02
980	tmavomodré teplé tepláky, s 2 bielymi pásmi na bokoch a bielou šnúrkou, dole na nohách gumičky, GEORGE,6-7r.	22	2	f	-	0	46	2	2012-10-13 17:07:06+02
949	bledoružový  svetrík s kapucou, 3 kolíčky na zapínanie, ADAMS, 86	22	2.5	f	-	0	15	2	2012-10-13 17:06:36+02
947	ružovobiela pásiková mikina s kapucou, vpredu dievčatko a nápis lazy town, cca 92	22	2.5	f	-	0	13	1	2012-10-13 10:30:06+02
946	pulover horčicovej farby, tmavomodré patenty,nápis FAMOUS, zn.NELYS,vel.12 mes.	22	1.7	f	-	0	12	1	2012-10-13 10:30:09+02
957	modré tenšie tepláky chlapčenské, matercare, 86	22	1.5	f	-	0	23	1	2012-10-13 10:30:27+02
956	šedomodré teplé tepláky , dole s patentami, Petit Bateau, 86	22	1.8	f	-	0	22	1	2012-10-13 10:30:29+02
941	sviežozelené tričko s dlhým, Palomino, 92	22	1.5	f	-	0	7	2	2012-10-13 15:44:00+02
948	cyklaménová súprava-zimná mekučká chlpatá čiapka ušianka+rukavice bezprstové-ten istý materiál, F&F,12-24m.	22	2.5	f	-	0	14	2	2012-10-13 16:54:15+02
940	tmavomodrá mikina flisová,vpredu 3 farebné autíčka, NEXT, vel. 3-6 mes.	22	1	f	-	0	6	1	2012-10-13 10:31:02+02
939	krémové pončo s hnedými srdiečkami a hviezdičkami v strednom páse, Marks Spencer,cca 80-86	22	3.6000000000000001	f	-	0	5	1	2012-10-13 10:31:09+02
938	tmavomodré teplejšie dievč.tepláky, po bokoch dole oranžovočercené mašličky, vpredu 2 vrecká, CARTERS, 24m.	22	2	f	-	0	4	1	2012-10-13 10:31:19+02
977	červené bavlnené tričko s dlhým rukávom, vianočný motív-tučniak s mikulášskou čiapkou, nápis let it snow, F&F, 86	22	1.8	f	-	0	43	2	2012-10-13 17:19:07+02
936	fialkovobiela pásiková žinilková háčkovaná čiapka-ušianka,na l.strane bodro biely kvet, cca 80-86, rukavice palčiaky fialovobiele	22	4.5	f	-	0	2	1	2012-10-13 10:31:39+02
965	tmavomodré chlapč.pančuchy so šedomodrými pásikmi a v spodnej časti nápisy 123, ,LUPILU,110-116	22	1.1000000000000001	f	-	0	31	2	2012-10-13 15:30:01+02
944	krémová menž. Prech.bunda,biely kožuš.limček a patenty okolo ruk,marks spenc,12-18m.	22	5	f	-	0	10	1	2012-10-13 10:34:37+02
943	ružový úpletový rolák, na l.strane patentu 2 gombíky, cherokee	22	2	f	-	0	9	1	2012-10-13 10:34:57+02
976	3ks tričiek-1šedé s dlhým rukávom,1 červené s krátkym -nápis Minesota a auto vpredu, 1 čierne so žltými a červenými pásikmi, F&F, 122	22	4	f	-	0	42	1	2012-10-13 10:35:26+02
983	2ks pyžamiek overalov- bledoružové a ružové , F&F,80	22	2.5	f	-	0	49	1	2012-10-13 10:35:42+02
974	cyklaménovobiele kožušinkové capačky do kočára na suchý zips,cherokee,12-18m.	22	2.7999999999999998	f	-	0	40	1	2012-10-13 10:36:44+02
975	oranžovoružové flisové rukavičky pre najmenších, vel.cca68-74	22	1	f	-	0	41	1	2012-10-13 10:36:49+02
969	riflové šaty bez rukávovs jedným volánom, oranžovým vtáčikom vpredu, vzadu na 3 gombíky, St.Bernard, 74	22	3.2999999999999998	f	-	0	35	2	2012-10-14 10:29:01+02
972	3ks body s dlhým rukávom-1sviežozelené s 1 včielkou vpredu,1 biele s včielkami po celom, 1 biele so žltými,červenými, zelenkavými kruhmi, F&F, 92	22	3.2999999999999998	f	-	0	38	1	2012-10-13 10:37:01+02
984	tmavomodrý roláčik bavlnený, 2 gombíky na pleci, 68	22	1	f	-	0	50	1	2012-10-13 10:37:14+02
981	cyklaménové tričko s ružovými našitými 3 kvietkami, CRAZY, 80	22	1	f	-	0	47	2	2012-10-13 18:20:14+02
961	biely bavlnený svetrík na 4 kvietkové gombíky, ružový lem okolo rukávov, dole akolo krku a pozdlž zapínania, na l.strane dole ružovofialový kvietok vyšitý, GEORGE,86	22	1.8	f	-	0	27	2	2012-10-13 19:19:16+02
937	šedé dievč.menžestráky,H&M, 86	22	3	f	-	0	3	2	2012-10-13 17:10:04+02
979	ružová bavlnená zdvojená čiapka s tmavoružovými, bielymi a zelenámi kvietkami , nápis crazy girl,,cca 86	22	2	f	-	0	45	1	2012-10-13 10:38:03+02
978	rifle na traky , vpredu vrecká aj vzadu, vpredu hore klokan a červený nápis SPORT,80-86	22	2	f	-	0	44	1	2012-10-13 10:38:06+02
982	ružový šuštiakový overal s kapucou s uškami s otvorom do autosedačky,rozopínanie vpredu 2 zipsami, LUPILU, vel.86/92	22	3	f	-	0	48	2	2012-10-13 18:07:21+02
973	hrubé ružové pančuchy s bielofialovoružovozelenými pásmi, LUPILU,74/80	22	1	f	-	0	39	1	2012-10-13 10:38:18+02
971	fialová bavlnená zdvojená šiltovka s so striebornými kamienkovým nápisom I srdiečko music,ROCKINO,50	22	4	f	-	0	37	1	2012-10-13 10:38:24+02
970	tmavomodrý sveter na zips s bielym lemom okolo krku,rukávov,vačkov a páse, MANA,vel.4	22	2.5	f	-	0	36	1	2012-10-13 10:38:30+02
966	bledoružové menžestrové šaty bez rukávov, vzadu zips, po bokoch 2 vrecká, giggles,18-23m.	22	2	f	-	0	32	2	2012-10-14 11:04:46+02
945	tmavohnedá mikina na zips s kapucou, v strede velká bieloružová kvetina, vnútro kapuce bledoružová, H&M, 86	22	3	f	-	0	11	2	2012-10-14 13:10:21+02
955	ružová teplá čiapka,vonkajšok chlpatá so zajkom vpredu, vnútro flis, na zaväzovanie, REPAL, 1	22	2	f	-	0	21	2	2012-10-13 15:34:56+02
942	fialové zimné čižmičky na 2 lepky, DEI-TEX, 20	22	6	f	-	0	8	2	2012-10-13 15:11:38+02
992	tmavomodré tričko s bordovým nápisom Hockey, zn. Gymboree, vel.3 roky	23	1.8	f	-	0	8	1	2012-10-13 10:17:46+02
1028	tmavohnedé menžestráky, George, 122	23	3	f	-	0	44	2	2012-10-13 18:39:59+02
990	šedá kockovaná zimná úpletová čiapka(zvojená)miniboys1982, 98-128	23	3.6000000000000001	f	-	0	6	1	2012-10-13 10:18:13+02
991	bledomodrý samatový overal s kapucou, mierne zateplený, na P strane ježko,lynnat,3/6m	23	4.2999999999999998	f	-	0	7	1	2012-10-13 10:18:16+02
1010	tmavomodrý flisový zateplený kabát s kapucou ,na zips a šlupky, vnútro modrá kockovaná látka, NEXT, 86, tmavomodré flisové rukavice s uškami,GAP 86	23	4.5	f	-	0	26	1	2012-10-13 10:18:40+02
993	súprava-krémovobledomodrá mikina s 3 somárikmi a nápis, bledomodré tepláčiky so somárikom, idylbaby, 6-9 mes.	23	3	f	-	0	9	1	2012-10-13 10:18:50+02
994	škoricová úpletová (zvojená)čiapka s hnedým lemom a zajkom vpredu, cherokee,12-24m.	23	2.2000000000000002	f	-	0	10	1	2012-10-13 10:18:55+02
995	zelená fliska, pri krku šikmý zips,vpredu bledomodrý obrys strašidla,H&M,116	23	3.5	f	-	0	11	1	2012-10-13 10:18:59+02
1027	modrá bavlnená čiapka s uškami a na zapínanie okolo krku na suchý zips, vnútorná látka biiela, GAP, 6-12mes.	23	1	f	-	0	43	2	2012-10-14 11:28:57+02
997	tmavohnedé tričko do V, na L strane prešitý obdlžnik NEXT, vel.86	23	1.5	f	-	0	13	1	2012-10-13 10:19:11+02
998	biely chlapč.pulover,oranž.pásy na rukávoch, zelený lem okolo krku a spodku,vpredu nápis oranž.zelený DANGER, liso jeans, 116/122	23	3.7999999999999998	f	-	0	14	1	2012-10-13 10:19:19+02
999	bledozelenkavá štrikovaná čiapka so vzorom do v a krémovými pásikmi do V, vpredu špis vapnutý gombíkom,	23	1	f	-	0	15	1	2012-10-13 10:19:21+02
1019	čierne hrubšie tepláky s bielymi pásmi po bokoch, cherokee, 98cm	23	2	f	-	0	35	2	2012-10-13 17:21:05+02
1001	ružové ponožkocapačky s bielymi srdiečkami a mačičkou čiernobielou,,cca 9-12mes.	23	1	f	-	0	17	1	2012-10-13 10:19:27+02
1003	tmavomodrý sveter na zips, biely lem okolo krku, rukávov a dole, MANA, cca 122	23	2	f	-	0	19	1	2012-10-13 10:19:31+02
1021	fialové menžestráky slim, vpredu 2 vrecká, na jednom zajko, Beneton,cca 86	23	2	f	-	0	37	2	2012-10-13 19:09:27+02
1005	tmavomodrá zimná úpletová čiapka s bielymi vert.pásmi a zelenými horiz.pásmi,vnútri flis,reserved,M	23	3.7000000000000002	f	-	0	21	1	2012-10-13 10:19:34+02
988	bledomodáflisová mikina na zips s tmavomodrými rukávmi,nápis SPORTS(cactus clone), vel.18/23m.	23	3.6000000000000001	f	-	0	4	2	2012-10-13 16:52:37+02
1007	úpletová modrokrémovozeleno pásiková jesenná čiapka, vel. 3-4 roky	23	1.1000000000000001	f	-	0	23	1	2012-10-13 10:19:46+02
996	tmavomodré tričko so šedými rukávmi, červenobiely nápis vpredu a 54, YES KIDS, vel.4	23	1.5	f	-	0	12	2	2012-10-14 11:06:18+02
1009	dlhé pyžamo-tmavomodré nohavice, modré tričko, vpreduobrázok futbalistov,nápis STRIKER, Tesco,5-6 rokov	23	2.2000000000000002	f	-	0	25	1	2012-10-13 10:20:02+02
987	pieskové menžestráky, cherokee, 98	23	4	f	-	0	3	2	2012-10-13 18:25:49+02
1012	šedá flisová mikina na gombíky, vpredu na l. strane macko,mon ours polare,23mes.	23	1.5	f	-	0	28	1	2012-10-13 10:20:33+02
1034	bledomodro biela pásiková mikina s kapucou, H&M,98	23	1.5	f	-	0	50	2	2012-10-13 17:59:36+02
1013	tmavohnedá mikina na tyrkysový zips, so stojačikom, tyrkysovobieložlté pásiky okolo krku, rukávoch a dole na patente, KAXS, 122/128	23	1.5	f	-	0	29	2	2012-10-13 17:30:27+02
1015	modríé chlapčenské rifle so škoricovým prešívaním a pokrčeným vzhľadom, m, 86cm	23	4	f	-	0	31	1	2012-10-13 10:20:42+02
1102	svetercerveno-modro-sedy so zipsom	26	2	f	-	0	13	2	2012-10-13 16:37:00+02
1017	krémová hrubá baranica na šnúrku okolo krku, vrch acryl,macko vpredu, vnútro kožušina,aliap,38-41cm	23	3	f	-	0	33	1	2012-10-13 10:20:49+02
1018	flisová mikina so stojačikom na zips, na l strane obrázok mickey,vrchná čast tmavomodrá,spodok krémový s tmavomodrým a bordovým pruhom, disney, 98	23	2	f	-	0	34	1	2012-10-13 10:20:53+02
1014	tmavošedé riflové nohavice, DENIM, 2-3 roky	23	1.6000000000000001	f	-	0	30	2	2012-10-13 17:28:01+02
1020	oranžová mikina so stojačikom, pri krku zips, na l.strane mickey, donaldson,4	23	2	f	-	0	36	1	2012-10-13 10:21:30+02
1008	šedé bavlnené pyžamo s modrými pásmi na rukávoch aj bokoch nohavíc, , na tričku vpredu dole motorka, B,122/128	23	1.7	f	-	0	24	2	2012-10-14 10:03:00+02
1022	tmavomodré menžestráky, NEXT, 116	23	4	f	-	0	38	1	2012-10-13 10:21:37+02
1023	krémové zateplené nohavice, na kolenách akoby záplaty, tiny ted, newborn	23	1.5	f	-	0	39	1	2012-10-13 10:21:40+02
1024	krémová úpletová vestička do v, vpredu snehuliačik, name it newborn, 62	23	1.5	f	-	0	40	1	2012-10-13 10:21:43+02
1025	zimná krémová súprava, vnútro červená podšívkovina-bunda s kapucou,zateplené nohavice, ITEMS, 18mes.	23	6	f	-	0	41	1	2012-10-13 10:22:14+02
1026	tmavošedá kockovaná šiltovka , DOPODOPO, na šilte nápisy detroit, obvod 53cm	23	3.5	f	-	0	42	1	2012-10-13 10:22:21+02
1004	tyrkysové tričko s dlhým rukávom, nápisy saint louis..., DOPO DOPO Boys,122	23	1	f	-	0	20	2	2012-10-13 18:59:37+02
1029	čierne hrubšie tepláky s bielymi pásmi po bokoch, cherokee, 86cm	23	1.5	f	-	0	45	1	2012-10-13 10:22:27+02
1030	modré rifle, červené štepovanie na vačkoch vzadu, little by little,98	23	2.5	f	-	0	46	1	2012-10-13 10:22:35+02
1031	bledomodré tričko s dlhým rukávom, 2 modré pásiky na rukávoch, na l.strane vpredu zelený monster,cherokee, 104	23	1	f	-	0	47	1	2012-10-13 10:22:36+02
1032	zelené bavlnené tričko  s dlhým rukávom, vpredu 6 robotov, cherokee, 98	23	1.5	f	-	0	48	1	2012-10-13 10:22:41+02
1033	tmavomodré bavlnené tričko s límčekom a na 3 gombíky, biele nápisy na rukáve a vpredu 26	23	2	f	-	0	49	1	2012-10-13 10:22:41+02
1011	krémový teplý pulover slímčekom a pri krku na zips, NAVIGATOR,98	23	3.5	f	-	0	27	2	2012-10-13 18:01:27+02
1006	šedá nátelník s dlhým rukávom, sviežo zelené nípisy vpredu, reserved,116	23	1	f	-	0	22	2	2012-10-13 16:45:05+02
989	hnede zimne topanky velkost 22	23	4	f	-	0	5	1	2012-10-13 10:24:15+02
1000	žltooranžové tričko s čiernym nápisom vzadu socker 8, cherokee, 18-24m	23	1	f	-	0	16	2	2012-10-13 17:19:07+02
1002	sedy z vnutra flisovy sufak baby land	23	16	f	-	0	18	1	2012-10-13 10:26:53+02
1016	tmavohnedá úpletová vesta do v, TU, 98cm	23	2.5	f	-	0	32	2	2012-10-13 16:32:00+02
1047	Modro-žltá lyž. bunda zn.LOOP, veľ.S	25	10	f	-	0	2	1	2012-10-13 08:36:58+02
1048	hnedá zimná bunda s kožušinkou na kapuci, zn.LOFT, veľ.:M	25	15	f	-	0	3	1	2012-10-13 08:37:04+02
1049	tehotenské tričko čierne s bielymi vzormi, Ambitionfly, veľ.: L	25	5	f	-	0	4	1	2012-10-13 08:37:17+02
1051	zelená tepl.súprava s kvietkami, zn.BAO.BAO, veľ.4	25	8	f	-	0	6	1	2012-10-13 08:37:41+02
1052	diev. Body s obr. baleríny, zn. Y-STAR Baby, veľ.74/80	25	1	f	-	0	7	1	2012-10-13 08:37:47+02
1054	mäkkučká tyrkys.súprava zn.CAMPUS, vrch s kvietkami, veľ.:74	25	5	f	-	0	9	1	2012-10-13 08:38:00+02
1053	body s dlhým rukávom s medvedíkmi, zn.H&M	25	0.5	f	-	0	8	1	2012-10-13 08:37:58+02
1055	žlté dupačky s obr.macka, UNITED COLORS OF BENETTON, veľ.:74	25	3	f	-	0	10	1	2012-10-13 08:38:06+02
1056	dojč.béžové nohavice s vreckami so zipsom, zn.LOGG, veľ.: 80	25	3	f	-	0	11	1	2012-10-13 08:38:10+02
1057	dojč.bledomodré nohavice, zn.MEXX KIDS GIRLS, veľ.: 92	25	3	f	-	0	12	1	2012-10-13 08:38:13+02
1058	diev.zatepl.ruž. nohavice s modrým károm, DOPODOPO MINI, veľ.92	25	5	f	-	0	13	1	2012-10-13 08:38:18+02
1059	dojč.biele pančušky so vzormi - na krst, veľ.:2	25	3	f	-	0	14	1	2012-10-13 08:38:25+02
1093	kombineza ruzovo-biela	26	3.5	f	-	0	4	2	2012-10-13 18:14:07+02
1060	červ. kombinéza s bielymi vločkami a kožušinkou, H&M Baby, veľ.:86	25	9	f	-	0	15	2	2012-10-13 18:04:43+02
1063	ruž.dvojvrst. mikinka s chlpat.rukávmi a kapuckou, zn.SCRAMBLED Girls	25	5	f	-	0	18	1	2012-10-13 08:39:14+02
1062	červené nohavice, dolu na bokoch so zipsami, zn.LOGG, veľ.:92	25	2	f	-	0	17	1	2012-10-13 08:39:10+02
1064	dievč. tielko s jabĺčkami, s krajkou	25	0.5	f	-	0	19	1	2012-10-13 08:39:21+02
1065	tepláčky, bielo-modré pásiky, zn.DING DONG, veľ.: 74	25	1	f	-	0	20	1	2012-10-13 08:39:28+02
1066	ruž. Tričko so slimáčikmi, zn. Babychic, veľ.:86	25	1	f	-	0	21	1	2012-10-13 08:39:32+02
1067	čierne tričko so striebor. Vzormi, zn.ZARA KIDS, veľ.:98	25	3	f	-	0	22	1	2012-10-13 08:39:34+02
1068	fialové rukavičky so sklápateľnými prstami, flauš	25	3	f	-	0	23	1	2012-10-13 08:39:44+02
1069	ružové body - tielko s fial.mašličkou, zn.F&F, veľ.: 68      NOVÉ	25	3	f	-	0	24	1	2012-10-13 08:39:46+02
1071	dojč.tmavomod. mikinka s biel.kvietkami,mašlič. a gombíkmi, veľ.6-9m.	25	2	f	-	0	26	1	2012-10-13 08:39:59+02
1070	dojč.tmavomodrý mäkkučký kabátik s biel.srdiečkami a limčekom	25	3	f	-	0	25	1	2012-10-13 08:40:01+02
1072	ruž.šaty s dlhým rukávom, zn.Adams, veľ.:86	25	2	f	-	0	27	1	2012-10-13 08:40:03+02
1075	ruž.nohavice s bielymi bodkami, zn.Cherokee, veľ.:3-4roky	25	5	f	-	0	30	1	2012-10-13 08:40:26+02
1074	tmavohnedé tričko s dlh.rukávom, zn.H&M	25	3	f	-	0	29	1	2012-10-13 08:40:07+02
1073	červeno-fial. Mikinka s 2 sovami, zn.Smile, veľ.:68	25	1	f	-	0	28	1	2012-10-13 08:40:21+02
1077	fialový roláčik so strieb. Aplikáciou, veľ.:128	25	6	f	-	0	32	1	2012-10-13 08:40:35+02
1078	jesenné topánočky ruž.-modré šnurovacie, zn.TOMAR, veľ.:23	25	13	f	-	0	33	1	2012-10-13 08:40:39+02
1079	rifľová suknička s hnedým opaskom, zn.Old Navy, veľ.:5	25	8	f	-	0	34	1	2012-10-13 08:40:43+02
1080	biele tričko s krát.rukávom s krajkovou aplikáciou	25	2	f	-	0	35	1	2012-10-13 08:40:46+02
1081	zelené tričko s dlhým rukávom s leskl.manžetami,zn.Claps, veľ.:S	25	4	f	-	0	36	1	2012-10-13 08:40:56+02
1082	čierne tričko s krátkym rukávom s červ.aplikáciou zn.DIESEL,veľ:XS	25	5	f	-	0	37	1	2012-10-13 08:41:01+02
1084	biela predĺžená bundička, zn. KEYO	25	10	f	-	0	39	1	2012-10-13 08:41:22+02
1083	čierny vlnený úzky rolák s fialovými pruhmi, krátky rukáv, veľ.:cca S	25	2	f	-	0	38	1	2012-10-13 08:41:12+02
1086	žltá flaušová mikina zn. EXI Sport, veľ.: S	25	13	f	-	0	41	1	2012-10-13 08:41:53+02
1085	Tricko kratky rukav s pasikmi a kvetinkou ESPRIT	25	2	f	-	0	40	1	2012-10-13 08:41:46+02
1087	tmavošedé nohavice s bielymi pásikmi, zn.AMISU, veľ.: S	25	5	f	-	0	42	1	2012-10-13 08:41:57+02
1088	čierné manchestrové nohavice s ruž. pásikmi, veľ.: S	25	5	f	-	0	43	1	2012-10-13 08:42:00+02
1089	červeno-bielo-čier.športová krát.bundička, zn.DOLCE&GABBANA,veľ:S	25	15	f	-	0	44	1	2012-10-13 08:42:03+02
1036	Žlté tričko zn. Coccodrillo, pre chlapca, dlhý rukáv, v. 80	24	2	f	-	0	2	1	2012-10-13 10:55:51+02
1037	Biele tričko s bordovým nápisom, pre chlapca, dlhý rukáv, v. 82	24	1	f	-	0	3	1	2012-10-13 10:55:57+02
1041	Hnedá vesta Cherokee, podšitá bledomodrým flísom, pre chlapca, v. 80 	24	5	f	-	0	7	2	2012-10-14 10:53:50+02
1038	Zimná zelená kombinéza s čiernymi lemami, pre chlapca, v. 86	24	14	f	-	0	4	1	2012-10-13 10:56:34+02
1042	Hnedý pulóver na zips, farebné pásiky, pre chlapca, v. 74/80	24	2.5	f	-	0	8	1	2012-10-13 10:56:43+02
1040	Zimná béžovo-modrá vetrovka s kapucňou, pre chlapca, vzadu obr., v. 86	24	8	f	-	0	6	2	2012-10-14 11:28:57+02
1090	modra bunda cherokee	26	5	f	-	0	1	2	2012-10-14 13:23:51+02
1043	Modro-béžový šál s drobnou výšivkou, pre chlapca, veľ. 3 - 5 r.	24	2.5	f	-	0	9	1	2012-10-13 10:57:07+02
1039	Zimná béžová kombinéza s obrázkom vpredu, 2 zipsy, + rukavice, unisex, v. 80	24	10	f	-	0	5	2	2012-10-13 19:06:26+02
1045	Jesenná vetrovka, tmavo zelená, kapucňa podšitá oranžovým flísom, v. 74	24	5	f	-	0	11	1	2012-10-13 10:57:18+02
1091	ruzova chlpata trigovica next	26	1.5	f	-	0	2	1	2012-10-13 12:28:36+02
1044	Modrý šál, jedna strana štrikovaná, druhá flís, veľ. 18 mes.	24	2	f	-	0	10	2	2012-10-13 18:22:27+02
1061	zateplené kaki nohavice, zn.Kiki&Koko, veľ.: 110	25	3	f	-	0	16	2	2012-10-13 17:53:55+02
1094	kabat ruzovy	26	2	f	-	0	5	1	2012-10-13 12:28:53+02
1092	kombineza sedo-bordova	26	3.5	f	-	0	3	2	2012-10-13 16:29:42+02
1097	vesta oranzova	26	1	f	-	0	8	1	2012-10-13 12:29:02+02
1096	sveter chlapcensky cerveno-smotanovy	26	1	f	-	0	7	1	2012-10-13 12:29:11+02
1098	rolakovy sveter cerveny	26	1.5	f	-	0	9	1	2012-10-13 12:29:14+02
1095	sveter pasikovy	26	1	f	-	0	6	2	2012-10-13 15:59:01+02
1141	Ružová zimná bundička s kapucňou a výšivkou 0-3 mes.	27	3.5	f	-	0	2	1	2012-10-13 09:35:37+02
1142	Červená flaušová bundička s mačičkami 3-6 mes.	27	3.5	f	-	0	3	1	2012-10-13 09:35:43+02
1109	tricko ruzove so psikmi	26	0.5	f	-	0	20	2	2012-10-14 12:16:42+02
1144	Ružová jogingová súprava 3-6 mes.	27	4	f	-	0	5	1	2012-10-13 09:36:01+02
1134	trigovica modra leskla	26	1.5	f	-	0	45	2	2012-10-14 11:06:18+02
1146	Rifle dievčenské prešité ružovou niťou 68veľ.	27	2.5	f	-	0	7	1	2012-10-13 09:36:12+02
1147	Červené tepláčiky s hviezdičkami 0-3 mes.	27	1.5	f	-	0	8	1	2012-10-13 09:36:21+02
1148	Ružové tepláčiky s mackom POOh 3-6mes. 68veľ.	27	1.5	f	-	0	9	1	2012-10-13 09:36:27+02
1149	Ružové tepláčiky s kvetinkovým lemom 3-6mes.68 veľ.	27	1.5	f	-	0	10	1	2012-10-13 09:36:32+02
1150	Ružovo-biele tepláčiky zatvorené s výšivkou 3-6 mes.	27	1.5	f	-	0	11	1	2012-10-13 09:36:36+02
1151	Ružové zateplené tepláčiky s kvetinkami 3-6 mes.	27	1	f	-	0	12	1	2012-10-13 09:36:44+02
1152	Červené tepláčiky s kvetinkami na traky 68veľ.	27	2	f	-	0	13	1	2012-10-13 09:36:50+02
1153	Žlté tepláčiky s uzavretou pätou 68veľ.	27	1.5	f	-	0	14	1	2012-10-13 09:36:55+02
1154	Žltý overal flaoušový so žirafou na zips 3-6 mes	27	2.5	f	-	0	15	1	2012-10-13 09:37:01+02
1155	Overal na spanie bielo ružový na cvoky 74veľ.	27	1.8	f	-	0	16	1	2012-10-13 09:37:06+02
1156	Overal na spanie so šedo bielymi pásikmi 74 veľ.	27	1.8	f	-	0	17	1	2012-10-13 09:37:10+02
1157	Overal na spanie ružový s pásikmi a zajačikom 74 vel.	27	2.2000000000000002	f	-	0	18	1	2012-10-13 09:37:14+02
1158	Overal na spanie žltý s pásikmi a čapicou 74 veľ.	27	2.2000000000000002	f	-	0	19	1	2012-10-13 09:37:20+02
1159	Overal na spanie biely flaušový s macíkom 50 veľ.	27	2	f	-	0	20	1	2012-10-13 09:37:26+02
1160	Overal na spanie žltý na cvoky 50 veľ.	27	0.5	f	-	0	21	1	2012-10-13 09:37:30+02
1161	Overal na spanie ružový s nažehlovačkou DADY 74 veľ.	27	2.5	f	-	0	22	1	2012-10-13 09:37:36+02
1127	cierne teplaky next	26	3	f	-	0	38	2	2012-10-13 17:09:37+02
1163	Ružové šatôčky s vyšívanými kvetinkami 0-3mes.	27	1.5	f	-	0	24	1	2012-10-13 09:37:55+02
1131	zateplene ruzove nohavice cherokee	26	1.2	f	-	0	42	2	2012-10-13 19:06:09+02
1165	Ružová bundička so srdiečkom vyšívaným 50 veľ.	27	1.2	f	-	0	26	1	2012-10-13 09:38:06+02
1166	Ružová bundička s vyšívaným mackom na gombíky 68 veľ.	27	1.5	f	-	0	27	1	2012-10-13 09:38:24+02
1168	Tričko dlhý rukáv s ružovými macíkmi 74 veľ. 	27	1.2	f	-	0	29	1	2012-10-13 09:38:30+02
1169	Tričko dlhý rukáv biele s vyšívanou mačičkou 74 veľ.	27	1	f	-	0	30	1	2012-10-13 09:38:35+02
1170	Tričko dlhý rukáv biele so zeleno červenými vzormi 62 veľ.	27	1.2	f	-	0	31	1	2012-10-13 09:38:40+02
1171	Tričko dlhý rukáv biele next s mackom 62 veľ.	27	1	f	-	0	32	1	2012-10-13 09:38:45+02
1172	Tričko dlhý rukáv zelené s mačičkou fialovo zelenou 62.veľ.	27	1.2	f	-	0	33	1	2012-10-13 09:38:49+02
1173	Tričko dlhý rukáv fialové s kvetinkami na leme 62 veľ.	27	1.2	f	-	0	34	1	2012-10-13 09:38:55+02
1174	Tričko dlhý rukáv fialové bodky 68 veľ.	27	1.2	f	-	0	35	1	2012-10-13 09:38:59+02
1175	Tričko dlhý rukáv fialové  Hello Kitty mačička 68 veľ.	27	1.2	f	-	0	36	1	2012-10-13 09:39:03+02
1103	bordova trigovica	26	0.5	f	-	0	14	1	2012-10-13 12:29:22+02
1119	tricko pasikove  hnedo- modro-smotanove	26	1.5	f	-	0	30	2	2012-10-14 11:06:18+02
1137	capica cierno-fialova	26	0.80000000000000004	f	-	0	48	1	2012-10-13 12:32:42+02
1123	snehule cierne chlap. c.28	26	3.5	f	-	0	34	1	2012-10-13 12:26:55+02
1104	sveter melirovy cierno-biely	26	2	f	-	0	15	1	2012-10-13 12:29:29+02
1105	sveter ruzovy so zipsom	26	0.80000000000000004	f	-	0	16	1	2012-10-13 12:29:32+02
1106	trigovica modra s opicou	26	0.80000000000000004	f	-	0	17	1	2012-10-13 12:29:34+02
1107	tricko oranzove s domcekom	26	0.5	f	-	0	18	1	2012-10-13 12:29:37+02
1164	Ružovo čierny top s bolerkom 92 veľ.	27	3	f	-	0	25	2	2012-10-13 18:55:46+02
1139	pancuchy pasikove	26	0.80000000000000004	f	-	0	50	2	2012-10-13 15:31:16+02
1112	trigovica cerveno-biela s hadom	26	1	f	-	0	23	2	2012-10-13 15:07:45+02
1126	zateplene rifle	26	1.5	f	-	0	37	2	2012-10-13 15:20:36+02
1116	tricko pasikove cerveno-cierne	26	1	f	-	0	27	2	2012-10-13 19:32:16+02
1138	capica modra popisana	26	2	f	-	0	49	2	2012-10-13 18:01:27+02
1121	tricko bielo-ruzove s kvetom cherokee	26	1.2	f	-	0	32	2	2012-10-13 15:31:16+02
1145	Ružové menčestrové nohavice s výšivkou 3-6 mes.	27	2.5	f	-	0	6	2	2012-10-14 10:48:25+02
1115	tricko s kvetmi	26	0.80000000000000004	f	-	0	26	2	2012-10-13 15:29:14+02
1110	tricko s postavickou cherokee	26	1	f	-	0	21	2	2012-10-13 15:31:16+02
1143	Tepláková súprava červeno čierna LONSDALE 3-6 mes.	27	4	f	-	0	4	2	2012-10-14 11:26:41+02
1118	tricko pasikove s postavickou	26	1.5	f	-	0	29	2	2012-10-13 15:31:16+02
1162	Súprava body a tepláčiky zatvorené s macíkmi 74 veľ.	27	2.5	f	-	0	23	2	2012-10-13 17:03:24+02
1124	sako fialove s kvetom	26	3	f	-	0	35	1	2012-10-13 12:31:19+02
1125	zelena bunda red orange	26	3	f	-	0	36	1	2012-10-13 12:31:23+02
1117	tricko zelene	26	1	f	-	0	28	2	2012-10-13 15:29:14+02
1114	kosela kockova bielo-cervena	26	0.80000000000000004	f	-	0	25	2	2012-10-13 17:30:27+02
1128	ruzove teplaky cherokee	26	2	f	-	0	39	1	2012-10-13 12:31:34+02
1129	teplaky modro-hnede	26	1	f	-	0	40	1	2012-10-13 12:31:37+02
1130	zelene zateplene nohavice next	26	3	f	-	0	41	1	2012-10-13 12:31:40+02
1113	rolak modry -doba ladova	26	1	f	-	0	24	2	2012-10-13 19:10:34+02
1132	nohavice cierne	26	3	f	-	0	43	1	2012-10-13 12:31:46+02
1133	sveter modry chlapcensky	26	3.2000000000000002	f	-	0	44	1	2012-10-13 12:31:50+02
1135	satova sukna flausova modra	26	1	f	-	0	46	1	2012-10-13 12:32:31+02
1122	kosela chlapcenska biela-pasikova	26	2	f	-	0	33	2	2012-10-13 16:37:00+02
1108	kosela ruzova kockova kenvelo	26	1.5	f	-	0	19	2	2012-10-13 18:31:20+02
1136	satova sukna smotan.-zelena + biela bluza	26	3.2999999999999998	f	-	0	47	2	2012-10-13 15:52:30+02
1111	tricko modre chlapcenske	26	1	f	-	0	22	2	2012-10-13 15:07:45+02
1177	Ružové dupačky na cvoky s kvetinkami a myškou veľ.68	27	1.5	f	-	0	38	1	2012-10-13 09:39:13+02
1178	Ružové dupačky na cvoky so psíkom veľ.68	27	1.5	f	-	0	39	1	2012-10-13 09:39:18+02
1179	Body biele dlhý rukáv s nakreslenou mašličkou ružovou veľ.56	27	1	f	-	0	40	1	2012-10-13 09:39:24+02
1180	Body biele dlhý rukáv s ružovými kvetinkami veľ.62	27	1	f	-	0	41	1	2012-10-13 09:39:27+02
1182	Body dlhý rukáv ružovo zelené prúžky veľ.56	27	1	f	-	0	43	1	2012-10-13 09:39:45+02
1181	Body žlté dlhý rukáv s nažehlovačkou motýlik,biely lem 18 mes.	27	1	f	-	0	42	2	2012-10-14 10:07:54+02
1210	Ružová súprava,na mikine macko s dáždnikom,gate bez vzoru	28	3.5	f	-	0	21	2	2012-10-13 17:30:27+02
1234	Zelená čiapka s červeným lemom, biele snúrky	28	1	f	-	0	45	2	2012-10-13 16:39:57+02
1187	Papučky červené so psíkmi na suchý zips	27	2	f	-	0	48	1	2012-10-13 09:40:11+02
1189	Papučky bielo zelené so žabkami 	27	2	f	-	0	50	1	2012-10-13 09:40:15+02
1186	Papučky žlto ružové s macíkmi	27	2	f	-	0	47	1	2012-10-13 09:40:22+02
1188	Papučky ružové s myškami	27	2.5	f	-	0	49	1	2012-10-13 09:40:28+02
1224	Ružová mikina zn.Cherokee,vpredu farebný nápis s motýlikom,veľ.2r	28	2.5	f	-	0	35	1	2012-10-13 11:20:44+02
1208	Ružová súprava,mikina obrázok s nápisom,tepláky na boku pásik	28	2.5	f	-	0	19	1	2012-10-13 11:20:52+02
1197	Ružovo-šedá zimná bunda s kapucňou,na zips,zn.Figi,veľ.86	28	8.5	f	-	0	8	1	2012-10-13 11:20:57+02
1198	Zelená vesta zn.Sandic,na zips, vzadu nápis	28	4	f	-	0	9	1	2012-10-13 11:21:03+02
1226	Ružovo-bordový pletený pulover,vpredu našitá kvetinka s gombíkom	28	2	f	-	0	37	1	2012-10-13 11:21:16+02
1231	Ružové bavlnené pančuchy zn.Tatrasvit, veľ.90	28	2	f	-	0	42	1	2012-10-13 11:21:22+02
1228	Svetlo-ružové pančuchy, veľ.90	28	1	f	-	0	39	1	2012-10-13 11:21:28+02
1229	Biele bavlnené pančuchy	28	1	f	-	0	40	1	2012-10-13 11:21:37+02
1222	Farebná fleesová vesta,vpredu vrecká,zelené gombíky	28	1.5	f	-	0	33	1	2012-10-13 11:21:40+02
1220	Modrá mikina, vpredu macko s havkom, veľ.104	28	2	f	-	0	31	1	2012-10-13 11:21:44+02
1219	Ružová mikina, vpredu vyšitá kravička	28	2	f	-	0	30	1	2012-10-13 11:21:48+02
1195	Hnedé zimné topánky, so šnúrkami, čierna podrážka, obrázok, veľ.22	28	3	f	-	0	6	2	2012-10-13 16:57:10+02
1238	Čierna čiapka s červenými pásikmi	28	1	f	-	0	49	1	2012-10-13 11:21:56+02
1232	Čierna predlžená čiapka,zelený nápis,čierne gombíky,zn.Loana,veľ.48	28	2	f	-	0	43	1	2012-10-13 11:22:08+02
1235	Modrá fleesová čiapka na uviazanie modré vrkôčiky,vpredu kvetinky	28	2	f	-	0	46	1	2012-10-13 11:22:11+02
1233	Hnedo-šedá čiapka s červeným pásom	28	2	f	-	0	44	1	2012-10-13 11:22:16+02
1185	Čapice 3ks /červená s nášivkou,ružová s mašličkou,ružová/	27	2	f	-	0	46	2	2012-10-13 15:40:33+02
1237	Modrá čiapka s bielym lemom a bielym brmbolcom na uviazanie	28	1	f	-	0	48	1	2012-10-13 11:22:27+02
1236	Žltá čiapka na uviazanie,vpredu žltý motýlik+žltý šál	28	2	f	-	0	47	1	2012-10-13 11:22:33+02
1202	Zelená bunda skapucňou,vpredu ružový slon,na zips,veľ.74/80	28	3	f	-	0	13	1	2012-10-13 11:22:41+02
1183	Body biele dlhý rukáv so šedými bodkami veľ 62	27	1	f	-	0	44	2	2012-10-13 18:53:01+02
1196	Modré menžestrové papuče,zn.Rak,veľ.38,5	28	4	f	-	0	7	2	2012-10-13 18:46:04+02
1223	Modrý pletený pulover,vpredu s hnedým havkom	28	3	f	-	0	34	1	2012-10-13 11:23:02+02
1227	Hnedý pletený pulover,vpredu mickey mouse,na spodu zelené kotvy	28	2	f	-	0	38	1	2012-10-13 11:23:06+02
1212	Modro-žltá súprava,na mikine domček,na gatiach modrý patent,veľ.86	28	4.5	f	-	0	23	1	2012-10-13 11:23:12+02
1199	Ružový zateplený overal s kapucňou,vpredu biely macko,cvoky,veľ.74	28	6	f	-	0	10	2	2012-10-13 18:20:14+02
1211	Žltá menžestrová súprava,na veste zajko a vtáčik,na gatiach zajko	28	3.5	f	-	0	22	1	2012-10-13 11:23:32+02
1203	Modro-hnedý pletený pulover, vpredu tiger s havkom	28	4.5	f	-	0	14	1	2012-10-13 11:23:36+02
1207	Biely pletený pulover,hore tri biele gombíky so sloníkmi	28	2.5	f	-	0	18	1	2012-10-13 11:23:40+02
1209	Modrý pletený sveter s guličkami,biely patent,modré gombíky	28	2.5	f	-	0	20	1	2012-10-13 11:23:45+02
1218	Pásikavá mikina zn.Tinko,bordový,zelený a hnedý pásik	28	2	f	-	0	29	1	2012-10-13 11:23:51+02
1221	Ružové pásikavé tričko s dlhým rukávom zn.Lady Ann, veľ.92	28	3	f	-	0	32	1	2012-10-13 11:23:58+02
1215	Šedé tepláky s vreckami,na bokoch čierny lem,veľ.98	28	2	f	-	0	26	1	2012-10-13 11:24:02+02
1214	Modré rifle,vzadu vrecká, v páse do gumy,veľ.12-18m	28	2	f	-	0	25	1	2012-10-13 11:24:05+02
1216	Ružové menžestráky zn.Cherokee,vrecká v tvare srdiečka,veľ.12-18m	28	3	f	-	0	27	1	2012-10-13 11:24:09+02
1213	Ružové menžestráky zn.Lassie,do gumy,na spodu kvetinka	28	4.5	f	-	0	24	1	2012-10-13 11:24:14+02
1205	Ružová fleesová súprava,na svetríku macko a balónik,gate bez vzoru	28	4.5	f	-	0	16	1	2012-10-13 11:24:21+02
1204	Béžovo-zelený sveter, na rukávoch oranžový pásik	28	4.5	f	-	0	15	1	2012-10-13 11:24:55+02
1217	Modré rifle s vreckami, vzadu biela nášivka, v páse do gumy	28	3	f	-	0	28	1	2012-10-13 11:24:59+02
1206	Modro-žltá súprava,na mikine hnedý macko,tepláky s vreckami	28	3.5	f	-	0	17	1	2012-10-13 11:25:03+02
1200	Tyrkysová zateplená bunda s kapucňou,všade mickey mouse,veľ.80	28	4	f	-	0	11	1	2012-10-13 11:25:10+02
1201	Čierne oteplováky,vpredu 2 snehuliaci,na traky,zn.saxoni,veľ.86	28	4.5	f	-	0	12	2	2012-10-13 18:50:04+02
1192	Čierne lesklé topánky na suchý zips, veľ.21	28	2	f	-	0	3	1	2012-10-13 11:25:40+02
1193	Hnedé topánky,suchý zips,béžová podrážka,oranžový kraj,veľ.20	28	4.5	f	-	0	4	1	2012-10-13 11:25:51+02
1184	Body ružové dlhý rukáv nápis Minymo veľ.62	27	1	f	-	0	45	2	2012-10-13 17:30:27+02
1190	Bielo-ružové botasky na suchý zips, zn.wink, veľ.25	28	6	f	-	0	1	1	2012-10-13 11:26:04+02
1191	Bordové topánky,modré oblúky,hnedá podrážka,zn.Peddy,veľ.25	28	4.5	f	-	0	2	1	2012-10-13 11:26:17+02
1230	2 páry froté pásikavé ponožky, 1 pár modrý, 1 pár ružový	28	1	f	-	0	41	2	2012-10-13 15:31:16+02
1267	zeleny sveter veľ.12mes.	30	2	f	-	0	1	1	2012-10-13 08:42:02+02
1297	body so psíkmi-dlhý rukáv  veľ.2-3roky	30	1	f	-	0	31	2	2012-10-13 18:31:20+02
1268	zeleny sveter veľ.9-12mes.	30	2	f	-	0	2	1	2012-10-13 08:42:09+02
1269	čierny sveter veľ.9-12mes.	30	2	f	-	0	3	1	2012-10-13 08:42:13+02
1272	červeno-šedý sveter veľ.2-3 roky	30	2	f	-	0	6	2	2012-10-13 15:29:14+02
1271	bledomodrý sveter s kapucňou veľ.0-3mes.	30	2	f	-	0	5	1	2012-10-13 08:42:31+02
1293	hnedá zmná bunda+oteplovačky veĺ.104	30	10	f	-	0	27	2	2012-10-13 15:44:00+02
1294	riflová bunda veĺ.1rok	30	1	f	-	0	28	1	2012-10-13 08:42:44+02
1295	béžovo modrá flauš.bunda veľ.6-9mes.	30	1	f	-	0	29	1	2012-10-13 08:42:53+02
1273	hnedé menč.nohavice veĽ.9-12mes.	30	2	f	-	0	7	1	2012-10-13 08:43:05+02
1306	zelený rolák veľ.80	30	1	f	-	0	40	2	2012-10-13 16:45:27+02
1275	zateplené rifle veľ.12-18mes.	30	2	f	-	0	9	1	2012-10-13 08:43:12+02
1276	čierne rifle veľ.1-1,5 rok	30	2	f	-	0	10	1	2012-10-13 08:43:22+02
1278	rifle na traky veľ.86	30	3	f	-	0	12	1	2012-10-13 08:43:28+02
1308	modrá čiapka s brmbolcom	30	1	f	-	0	42	2	2012-10-14 11:28:40+02
1280	tmavošedé menč.nohavice na traky veľ.80	30	2	f	-	0	14	1	2012-10-13 08:43:40+02
1281	modré menč.nohavice veľ.9-12mes.	30	2	f	-	0	15	1	2012-10-13 08:43:50+02
1282	hnedé menč.nohavice veĽ.9-12mes.	30	2	f	-	0	16	1	2012-10-13 08:43:53+02
1245	mikina sivá s červeným nápisom , veľ. 128	29	2	f	-	0	6	2	2012-10-13 17:55:08+02
1284	tmavomodré nohavice veĺ.6-9mes.	30	1	f	-	0	18	1	2012-10-13 08:44:00+02
1244	mikina tmavo-modrá s kapucou, jemné kocky sivé, veľ.128	29	2	f	-	0	5	2	2012-10-14 09:23:58+02
1286	bledomodré nohavice na traky veľ.6-9mes.	30	1	f	-	0	20	1	2012-10-13 08:44:14+02
1291	bledomodrá zimná bunda veľ.9-12me.	30	3	f	-	0	25	1	2012-10-13 08:44:20+02
1299	biele body so psíkom	30	1	f	-	0	33	2	2012-10-13 17:08:51+02
1288	hnedá flaušová bunda s kapucňou veĺ.6-9mes.	30	2	f	-	0	22	1	2012-10-13 08:44:27+02
1289	pásiková flauš.bunda veľ.74	30	1	f	-	0	23	1	2012-10-13 08:44:30+02
1290	žlto-šedá zateplená vesta veľ.9-12mes.	30	2	f	-	0	24	1	2012-10-13 08:44:34+02
1250	červené chlapčenské pyžamo s čiernym nápisom, veľ. 140	29	2	f	-	0	11	2	2012-10-13 16:20:19+02
1296	šedá zateplená bunda veľ.90	30	2	f	-	0	30	1	2012-10-13 08:45:20+02
1285	oranžové flaušové nohavice veĺ.80	30	1	f	-	0	19	2	2012-10-13 19:02:11+02
1309	modro žltá čiapka+rukavice	30	1	f	-	0	43	2	2012-10-13 17:10:51+02
1247	modro-sivé pyžamo s nápisom, veľ. 140	29	2	f	-	0	8	2	2012-10-13 14:59:36+02
1300	modré tričko so psíkom	30	1	f	-	0	34	1	2012-10-13 08:46:12+02
1301	modré pásikavé pyžamo	30	1	f	-	0	35	1	2012-10-13 08:46:17+02
1302	zelený kabátik +nohvice veľ.80	30	2	f	-	0	36	1	2012-10-13 08:46:24+02
1303	modrý kabátik+nohavice veĺ.6-12mes	30	3	f	-	0	37	1	2012-10-13 08:46:37+02
1287	hnedá flaušová bunda veĺ.98	30	2	f	-	0	21	2	2012-10-13 16:52:37+02
1305	biely overal veľ.0-3mes.	30	1	f	-	0	39	1	2012-10-13 08:46:46+02
1274	zateplené rifle veľ.6-9mes.	30	2	f	-	0	8	2	2012-10-13 16:36:03+02
1277	rifle na traky veľ.3-6mes.	30	2	f	-	0	11	2	2012-10-14 11:26:41+02
1264	čierny dievčenský sveter, veľ.S	29	1.5	f	-	0	25	2	2012-10-14 13:51:08+02
1256	tunika čokoládovo hnedá so zlatým nápisom, vhodná pre tehotné, veľ. M	29	1.5	f	-	0	17	2	2012-10-13 17:10:51+02
1310	zelená čiapka+šál	30	1	f	-	0	44	1	2012-10-13 08:47:39+02
1311	hnedá pásiková čiapka	30	1	f	-	0	45	1	2012-10-13 08:47:43+02
1312	modrá čiapka	30	1	f	-	0	46	1	2012-10-13 08:47:46+02
1240	ružová pelerína, zn. S.Oliver  veľ. 128	29	2	f	-	0	1	1	2012-10-13 08:51:48+02
1307	modrá čiapka s bágrom	30	1	f	-	0	41	2	2012-10-14 11:06:45+02
1242	modrá šuštiaková bunda, bez nápisov - čistá,  veľ. 128	29	3	f	-	0	3	1	2012-10-13 08:52:20+02
1270	tmavomodrý sveter s kapucňou veľ12-24mes.	30	2	f	-	0	4	2	2012-10-13 15:28:42+02
1241	ružová pelerína, veľ. 128	29	2	f	-	0	2	2	2012-10-14 10:20:01+02
1262	dievčenské pyžamo, hnedé, nohavice pásikové, veľ.152	29	1.5	f	-	0	23	2	2012-10-13 18:14:07+02
1246	biela bunda - plášťová, žltá značka, veľ. M 	29	3	f	-	0	7	1	2012-10-13 08:52:56+02
1263	teplé flanelové posteľné obliečky, motív - futbal	29	4	f	-	0	24	2	2012-10-13 15:11:23+02
1249	dlhý čierny sveter, veľké gombíky, veľ. S	29	4	f	-	0	10	1	2012-10-13 08:53:14+02
1248	prešívané čierne jesenné sako, veľ. S	29	4	f	-	0	9	1	2012-10-13 08:53:27+02
1304	mackove body veľ.68	30	1	f	-	0	38	2	2012-10-13 16:25:44+02
1252	dievčenské rifle, slabučko modré, veľ. 8-9 rokov	29	2	f	-	0	13	1	2012-10-13 08:54:58+02
1283	hnedé kárované nohavice veľ.92	30	1	f	-	0	17	2	2012-10-13 17:34:49+02
1257	tričko dlhý rukáv - tigrované, veľ. M	29	1.5	f	-	0	18	1	2012-10-13 08:58:27+02
1258	tunika modrá, tmavomodré kruhy s gumičkou pre tehotné, veľ. univerzál	29	2	f	-	0	19	1	2012-10-13 08:58:38+02
1259	tričko krátky rukáv, tyrkysová farba, vhodné pre tehotné veľ. Univerzál	29	2	f	-	0	20	1	2012-10-13 08:58:45+02
1260	hnedé dlhé nohavice, tmavší prúžok, vzadu príklopky, veľ.36	29	3	f	-	0	21	1	2012-10-13 08:58:53+02
1261	čierne dlké nohavice, zn.Wizards, veľ. 38	29	2	f	-	0	22	1	2012-10-13 08:59:01+02
1255	pletená tunika s rolákom, farba tyrkysová, veľ. 176	29	3	f	-	0	16	1	2012-10-13 08:59:16+02
1253	dievčenské sako, zn. Vero Moda, sivo-ružové +kocky, veľ.38	29	2	f	-	0	14	1	2012-10-13 08:59:39+02
1266	červený tenký rolák, veľ.S	29	2	f	-	0	27	1	2012-10-13 09:00:06+02
1265	fialový dievčenský rolák, veľké pletené osmičky	29	2	f	-	0	26	1	2012-10-13 09:00:12+02
1243	červená šuštiaková bunda, vzadu biely nápis,  veľ. 128	29	3	f	-	0	4	2	2012-10-13 15:20:36+02
1239	Zelená bunda s kapucňou,vpredu ružový slon,na zips, veľ.74/80	28	4	f	-	0	50	1	2012-10-13 11:24:50+02
1298	pásikové body	30	1	f	-	0	32	2	2012-10-13 14:34:31+02
1327	Fialová tunika s motýlmi, veľ. 92	31	2.5	f	-	0	11	2	2012-10-13 19:04:25+02
1316	modré rifle veĺ.12-18mes.	30	2	f	-	0	50	1	2012-10-13 08:48:05+02
1317	Krémová flaušová mikina s motýľom, veľ.92	31	2	f	-	0	1	1	2012-10-13 09:03:33+02
1318	Šedá šatová sukňa na traky, veľ. 86	31	3	f	-	0	2	1	2012-10-13 09:03:41+02
1319	Ružové tričko, dlhý rukáv, veľ. 86	31	2	f	-	0	3	1	2012-10-13 09:03:50+02
1320	Biele tričko so šmolkom, dlhý rukáv, veľ. 86	31	2	f	-	0	4	1	2012-10-13 09:03:57+02
1321	Dievčenské rifle, veľ. 86	31	3	f	-	0	5	1	2012-10-13 09:04:05+02
1384	chlapčenský hnedý pulovrík 3-6M	32	2.5	f	-	0	18	2	2012-10-13 18:28:03+02
1342	Tepláky fialové, veľ. 86	31	1.5	f	-	0	26	2	2012-10-14 12:12:11+02
1324	Riflová sukňa s vyšitým kvetom, veľ. 1-2roky	31	3	f	-	0	8	1	2012-10-13 09:07:12+02
1326	Riflová sukňa s volánikmi,veľ.1-2 roky	31	3	f	-	0	10	1	2012-10-13 09:07:19+02
1323	Podšité rifle, veľ. 92	31	1	f	-	0	7	2	2012-10-13 19:10:34+02
1328	Ružový rolák s veveričkou, veľ. 86	31	2	f	-	0	12	1	2012-10-13 09:07:29+02
1382	fialový dievšenský kabátik s kapucňou, 3-6M	32	4	f	-	0	16	2	2012-10-13 17:30:27+02
1343	Zamatový ružovo-šedý overal, veľ.74-80	31	2	f	-	0	27	1	2012-10-13 09:07:50+02
1344	Pásikové modro-zeleno-biele body, veľ. 2-3 roky	31	1.5	f	-	0	28	1	2012-10-13 09:07:57+02
1345	Šedý rolík , veľ.110/116	31	2	f	-	0	29	1	2012-10-13 09:08:06+02
1346	Pásikové bielo-modré body, veľ.12-15 mes.	31	1.5	f	-	0	30	1	2012-10-13 09:08:09+02
1347	Riflová šatová sukňa na traky, veľ.5 rokov	31	2.5	f	-	0	31	1	2012-10-13 09:08:19+02
1348	Rifle s vyšitými motýlmi, veľ. 4-5 rokov	31	3	f	-	0	32	1	2012-10-13 09:08:26+02
1349	Súprava riflové šaty+tričko+pančuchy bodkové, veľ.1,5-2,5 roky	31	6.5	f	-	0	33	1	2012-10-13 09:08:40+02
1350	Rifle , veľ. 104-110	31	2.5	f	-	0	34	1	2012-10-13 09:09:00+02
1351	Riflová bunda, veľ. 104-110	31	3	f	-	0	35	1	2012-10-13 09:09:03+02
1375	zimný chlapčenský overal s rukavicami a kapucňou, bledomodrový, 3-6M	32	7	f	-	0	9	2	2012-10-13 17:03:24+02
1353	Bledomodrá mikina hrubšia, veľ. 116	31	2	f	-	0	37	1	2012-10-13 09:09:28+02
1354	Červená mikina s kapucňou a zipsom, veľ. 4-5 rokov	31	2	f	-	0	38	1	2012-10-13 09:09:32+02
1337	Béžové kordové nohavice, veľ.98	31	2	f	-	0	21	2	2012-10-14 12:49:03+02
1331	Biele tričko s Minnie, veľ. 92-98	31	2	f	-	0	15	1	2012-10-13 09:09:57+02
1332	Kvetinkové tričko Next, veľ.2-3 roky	31	2	f	-	0	16	1	2012-10-13 09:10:02+02
1333	Kvetinkové tričko Cherokee, veľ. 6-9 mes.	31	1.5	f	-	0	17	1	2012-10-13 09:10:19+02
1340	Fialkové zateplené šuštiaky, veľ. 92	31	1	f	-	0	24	2	2012-10-13 18:18:10+02
1335	Ružový rolák so žirafami, veľ.92	31	1.5	f	-	0	19	1	2012-10-13 09:10:29+02
1330	Ružovo-farebná zimná čiapka, veľ. 1 rok	31	2	f	-	0	14	2	2012-10-14 11:04:46+02
1338	Bodkované pyžamo, veľ.86	31	2.5	f	-	0	22	2	2012-10-14 13:10:21+02
1339	Ružové menčestráky, veľ.80	31	2	f	-	0	23	1	2012-10-13 09:12:11+02
1315	zelene body s obrázkom veľ.18-24mes.	30	1	f	-	0	49	2	2012-10-13 18:35:20+02
1341	Flaušový guličkový overal, veľ. 0-3 mes.	31	2	f	-	0	25	1	2012-10-13 09:12:27+02
1356	Čierny kabátik, 3 veľké gombíky, veľ.5-6 rokov	31	2	f	-	0	40	2	2012-10-14 13:55:18+02
1357	Bledomodrá vesta s loďkou, veľ.3-6 mes.	31	1.5	f	-	0	41	1	2012-10-13 09:13:07+02
1358	Tmavomodrá pásiková vesta, veľ. 0-3 mes.	31	1.5	f	-	0	42	1	2012-10-13 09:13:10+02
1359	Béžová trigovica s kapucňou na zips, s havkom, veľ. Newborn	31	1.5	f	-	0	43	1	2012-10-13 09:13:15+02
1360	Gepardí svetrík, bielo-čierny, veľ. 3-6 mes. 	31	1.5	f	-	0	44	1	2012-10-13 09:13:18+02
1361	Maskáčový overal, veľ. 9-12 mes.	31	1.5	f	-	0	45	1	2012-10-13 09:13:43+02
1362	Hnedý svetrík na gombíky, veľ. 0-3 mes.	31	1	f	-	0	46	1	2012-10-13 09:13:52+02
1363	Čierna vesta, veľ. 4-5 rokov	31	1.5	f	-	0	47	1	2012-10-13 09:13:54+02
1364	Súprava khaki zelený roláčik+čierne bodkové šaty, veľ. 1 rok	31	3	f	-	0	48	1	2012-10-13 09:14:07+02
1365	Červená mikina so stojačikom na zips, veľ. 134	31	2	f	-	0	49	1	2012-10-13 09:14:09+02
1366	Súprava marhuľová chlpatka+bledé flaušové nohavice,veľ.80	31	6	f	-	0	50	1	2012-10-13 09:14:14+02
1336	Zelený rolík so žirafami, veľ. 92	31	1.5	f	-	0	20	2	2012-10-13 19:04:25+02
1322	Zimná ružová čiapka so šiltom, veľ.1-2roky	31	2	f	-	0	6	2	2012-10-13 18:20:14+02
1383	ružový kabátik skapucňou, 3-6M	32	4	f	-	0	17	1	2012-10-13 09:59:21+02
1377	bielo-hnedý kravičkový overal na spanie, 3-6M	32	4	f	-	0	11	1	2012-10-13 09:59:28+02
1376	bledomodrý chlapčenský overal na spanie s rukavicami, flisový, 6-9M	32	4	f	-	0	10	1	2012-10-13 09:59:30+02
1329	Ružová zimná bunda S. Oliver, veľ. 92-98	31	5	f	-	0	13	2	2012-10-13 17:20:12+02
1334	Body motýlikové farebné, veľ. 2-3 roky	31	1.5	f	-	0	18	2	2012-10-13 18:15:07+02
1373	spací vak biely 0-6M	32	5	f	-	0	7	1	2012-10-13 09:59:52+02
1370	perinka tvar obdĺžnik s flisovou vložkou	32	4	f	-	0	4	1	2012-10-13 10:00:15+02
1369	perinka tvar obdĺžnik s flisovou vložkou	32	4	f	-	0	3	1	2012-10-13 10:00:19+02
1371	krstová perinka na zips, satén s čipkou	32	4	f	-	0	5	1	2012-10-13 10:00:23+02
1352	Sveter 2v1, sivo-biely, 2 gombíky, veľ. 98	31	1	f	-	0	36	2	2012-10-13 16:11:13+02
1374	zimný dievčenský overal s rukavicami a kapucňou, fialový, 0-3M	32	7	f	-	0	8	2	2012-10-13 17:30:27+02
1430	3 ks tielok, biele s ružovým olemovaným, čisto biele, pásikové	34	1	f	-	0	40	2	2012-10-13 17:45:45+02
1390	vianočný overal s čiapkou, zelený, 3-6M	32	3	f	-	0	24	1	2012-10-13 10:00:40+02
1389	bledomodrý overal na spanie tigrík, 6-9M	32	2	f	-	0	23	1	2012-10-13 10:00:49+02
1386	tmavomodré dupačky so psíkom veľ. 62	32	1.5	f	-	0	20	2	2012-10-13 17:17:11+02
1388	červený overal na spanie veľ. 74, značka BHS	32	2	f	-	0	22	1	2012-10-13 10:01:01+02
1438	biele tričko s veľkou mačičkou ,nápis"It´s my lovely", č.128	35	2.5	f	-	0	6	2	2012-10-13 18:55:17+02
1393	4 ks nohaviečiek	34	0.80000000000000004	f	-	0	3	1	2012-10-13 11:45:45+02
1392	Modrá flysová vesta na zips	34	1	f	-	0	2	1	2012-10-13 11:45:41+02
1395	Fialová vestička, značka C&A, veľk. 134/140	34	1	f	-	0	5	1	2012-10-13 11:46:03+02
1396	modrá riflová sukňa s dvoma vačkami na predu i zadu, veľ. 132	34	3	f	-	0	6	1	2012-10-13 11:46:07+02
1397	modrá menžestrová sukňa  s dvoma vačkami na predu i zadu	34	5	f	-	0	7	1	2012-10-13 11:46:11+02
1398	Hnedá menžestrová sukňa s tenkou šnúrkou veľ. 98	34	3	f	-	0	8	1	2012-10-13 11:46:14+02
1399	2 ks nohavičiek 1 ks modré, 1 ks fialové	34	0.10000000000000001	f	-	0	9	1	2012-10-13 11:46:17+02
1400	Ružové body na tancovanie s krátkym rukávom ,veľ. 110/116	34	1	f	-	0	10	1	2012-10-13 11:46:22+02
1401	Červená mikina, veľ. 110	34	1	f	-	0	11	1	2012-10-13 11:46:25+02
1402	Šedá vesta bolerko, značka C&A, veľ. 134	34	0.80000000000000004	f	-	0	12	1	2012-10-13 11:46:35+02
1403	3 ks nohavičiek čisto bielych	34	1.5	f	-	0	13	1	2012-10-13 11:46:47+02
1404	Modrá mikina na predu s obrázkom, veľ na 4 roky	34	1	f	-	0	14	1	2012-10-13 11:46:52+02
1405	Modré kárované pyžamo s dvoma vačkami na jednom je myška	34	2	f	-	0	15	1	2012-10-13 11:46:55+02
1406	modrobiela károvaná košeľa, zapínanie na gombíky, 1 vačok, veľ. 146	34	5	f	-	0	16	1	2012-10-13 11:46:59+02
1407	Biely pletenný sveter s kapucňou na uviazanie so šnúrkami	34	2	f	-	0	17	1	2012-10-13 11:47:02+02
1408	modré rifle s dvoma vačkami, značka Espirt, s hviezdičkami, veľ. 122	34	5.5	f	-	0	18	1	2012-10-13 11:47:05+02
1409	Čierne lakované topánky pre dievčatko, malinké, veľ. 1	34	3	f	-	0	19	1	2012-10-13 11:47:09+02
1410	Tmavohnedé topánky, značka DAVE, veľ. 30	34	2	f	-	0	20	1	2012-10-13 11:47:12+02
1411	Biele cvičky, veľ. 31	34	1	f	-	0	21	1	2012-10-13 11:47:16+02
1412	Modré cvičky veľ. 34	34	2	f	-	0	22	1	2012-10-13 11:47:21+02
1449	hnedá menžestrová bunda s kapucňou,logo koníka vpredu,DOPO.č110	35	7	f	-	0	17	2	2012-10-13 15:58:24+02
1414	Chlapčenské tričko s riflovým golierom, značka L.O.G.G., veľ. 80	34	0.5	f	-	0	24	1	2012-10-13 11:47:31+02
1415	Riflová bunda, vzadu obrázok, zapínanie na gombíky, značka ROSE	34	3	f	-	0	25	1	2012-10-13 11:47:39+02
1416	Rifle, na predu i zadu 2 vačky, značka Esprit, veľ. 122	34	5.5	f	-	0	26	1	2012-10-13 11:47:46+02
1417	Ružová mikina, na predu nápis Esprit a kvetina, veľ. 128/134, na zips, 	34	4	f	-	0	27	1	2012-10-13 11:47:51+02
1418	Rifle, na predu 2 vačky, značka Cathay moda	34	5.5	f	-	0	28	1	2012-10-13 11:47:55+02
1419	Biely rolák veľkosť 98	34	2.5	f	-	0	29	1	2012-10-13 11:47:59+02
1420	Jemnoružový rolák na rukáve ornament, značka Esprit, veľ. 128	34	2.5	f	-	0	30	1	2012-10-13 11:48:03+02
1421	Biely sveter, na predu 3 srdiečkové gombíky, značka H&M, veľ.122/128	34	10	f	-	0	31	1	2012-10-13 11:48:10+02
1422	Červený rolák, na spodnom okraji nápis black dog to love	34	3.2999999999999998	f	-	0	32	1	2012-10-13 11:48:14+02
1423	Ružový rolák, značka Esprit, veľ. 116/122	34	3.5	f	-	0	33	1	2012-10-13 11:48:18+02
1424	Červený rolák, značka C&A, veľ. 122	34	4	f	-	0	34	1	2012-10-13 11:48:22+02
1425	3 ks nohavičiek, 	34	1	f	-	0	35	1	2012-10-13 11:48:26+02
1427	Čierne topánky na suchý zips, lakované, veľ. 28	34	5	f	-	0	37	1	2012-10-13 11:48:37+02
1429	Modré topánočky na zips s kvetinkou, veľ. 18	34	1	f	-	0	39	1	2012-10-13 11:48:58+02
1428	Čierne čižmy na zips, na boku kvetinka	34	1	f	-	0	38	1	2012-10-13 11:49:07+02
1431	Biela košielka s krajkou okolo krku, veľ. 68	34	0.80000000000000004	f	-	0	41	1	2012-10-13 11:49:13+02
1391	Ružové pančuchy, 	34	0.10000000000000001	f	-	0	1	2	2012-10-13 18:07:58+02
1432	Tenisky geox,,, veľ. 30	34	5	f	-	0	42	1	2012-10-13 11:49:22+02
1434	lyžiarska súprava ETIREL ružová bunda+šedé oteplovačky, č.116	35	35	f	-	0	2	1	2012-10-13 12:23:37+02
1433	biele sačko TERRANOVA, strieborné gombíky, lemovaný límček č.110	35	9	f	-	0	1	1	2012-10-13 12:23:41+02
1387	tmavomodrý overal na spanie, 6-9M	32	2	f	-	0	21	2	2012-10-13 17:01:44+02
1445	fialové"leopardie" vysoké tenisky, ružové šnúrky, č.27	35	6	f	-	0	13	1	2012-10-13 12:24:36+02
1444	tmavomodré papučky s prackou, ružové motýliky a podrážka, č.28	35	2	f	-	0	12	1	2012-10-13 12:24:38+02
1442	tmavosivé CROCSy s bledoružovým lemom, tmavý kamienok, č.10	35	5	f	-	0	10	1	2012-10-13 12:24:43+02
1443	biele plátenné tenisky na 2 pracky, FREE, č.27	35	2.5	f	-	0	11	1	2012-10-13 12:24:44+02
1441	ružové CROCSy s prackou a žltým kamienkom, č.9          NOVÉ	35	19	f	-	0	9	1	2012-10-13 12:24:48+02
1446	zlaté vysoké čižmy BENETTON preštepované, červené vnútro, č.28	35	10	f	-	0	14	2	2012-10-13 16:21:45+02
1413	Tepláky s dvoma vačkami na predu na zips, veľ. 140, značka C&A	34	0.80000000000000004	f	-	0	23	1	2012-10-13 19:25:40+02
1439	biely rolák pleteninový TERRANOVA, zlaté logo TRN vpredu, 104-110	35	5	f	-	0	7	1	2012-10-13 12:25:08+02
1440	bledoružový rolák pleteninový ZARA, č.118	35	4	f	-	0	8	1	2012-10-13 12:25:15+02
1437	bledofialové tenké rifle OKAIDI, 7r.	35	5	f	-	0	5	1	2012-10-13 12:25:19+02
1448	baletné cvičky Hello Kitty bledoružové, HM, č.26-27	35	2	f	-	0	16	2	2012-10-14 12:01:37+02
1435	čierne tenké tepláky č.128, naspodu nápis STAR + flitre         NOVÉ	35	3	f	-	0	3	2	2012-10-13 16:15:47+02
1450	ružová vesta šuštiaková, kožušinová kapucňa, GIRL2GIRL č.110	35	2.5	f	-	0	18	2	2012-10-13 16:08:53+02
1447	sivé papučky "slippers" s hlavou sloníka ELIOTA                   NOVÉ	35	2	f	-	0	15	1	2012-10-13 12:28:26+02
1436	rifle s modrými mašličkami vpredu, GIRLfashion č.6	35	3	f	-	0	4	2	2012-10-13 19:27:00+02
1464	pletené tmavofialové šaty HM,navrchu vzor "ruže",vsadená šnúrka,2-4r.	35	6	f	-	0	32	2	2012-10-13 17:25:33+02
1502	krémové bodynko s macikom s oranžovými ušami, Baby club značka, veľkosť 74	38	1.1000000000000001	f	-	0	9	1	2012-10-13 08:17:32+02
1492	Čierne zimné topánky, vysoké na 2 suché zipsy, zn.Dei-tex, veľ.23	37	5	f	-	0	2	2	2012-10-13 18:14:41+02
1499	hráškovo zelené polodupačky otvorené s vreckami, veľkosť 6 - 9m, značka Cherokee	38	1.1000000000000001	f	-	0	6	1	2012-10-13 08:17:45+02
1498	hráškovo zelené polodupačky uzavreté, na ľavej nohe ružový, oranžový a biely kvietok, veľkosť 6 - 9 m, značka Cherokee	38	1.1000000000000001	f	-	0	5	1	2012-10-13 08:17:58+02
1504	tehotenská tyrkysová tunika s dlhým rukávom s výstrihom do V a tmavomodrým pásikom s guličkami, značka Joe Browns, veľkosť 14 UJ	38	3	f	-	0	11	1	2012-10-13 08:18:08+02
1505	tehotenská biela tunika s ciernymi kvietkami, 3/4 rukávznačka store twenty one, veľkosť 14	38	3	f	-	0	12	1	2012-10-13 08:18:14+02
1506	tehotenská oranžová tunika s bordovými kvietmi, 3/4 rukáv, značka next, veľkosť  14	38	3	f	-	0	13	1	2012-10-13 08:18:22+02
1471	čierne tenké tepláky č.104, naspodu nápis Americas Chicas 1982	35	0.20000000000000001	f	-	0	39	2	2012-10-13 15:11:38+02
1508	tehotenská hráškovo zelená tunika s dlhým rukávom prekrížená na prsiach	38	3	f	-	0	15	1	2012-10-13 08:18:31+02
1509	tehotenská staroružová tunika s krátkym rukávom pod prsiami na zaväzovanie a na gombičky	38	3	f	-	0	16	1	2012-10-13 08:18:38+02
1473	ružovo-biela čiapky bavlnená,vpredu strieborný motýlik,  č.50	35	2	f	-	0	41	2	2012-10-13 19:11:27+02
1483	ružová súprava pre bábo /čiapka,šál,rukavičky/	36	3	f	-	0	2	1	2012-10-13 11:03:56+02
1486	ružová mikinka s kapuckou	36	1.3	f	-	0	5	1	2012-10-13 11:04:01+02
1469	tmavofialové šatyso srdiečkam DOPO., dlhý rukáv, rolák, č.116	35	2	f	-	0	37	2	2012-10-13 16:15:47+02
1487	tehotenské rifle modré veľ.42	36	15	f	-	0	6	1	2012-10-13 11:04:23+02
1488	tehotenská tunika fialovo-ružová vzor drobné kvietky veľ.40/42	36	8	f	-	0	7	1	2012-10-13 11:04:33+02
1489	tehotenská tunika krátky rukáv zeleno-tyrkysová vzorovaná veľ. 40	36	5	f	-	0	8	1	2012-10-13 11:04:43+02
1490	tehotenská tunika čierno-biela, vzor kvety veľ.40	36	7	f	-	0	9	1	2012-10-13 11:04:54+02
1485	ružový župan pre bábätko	36	2	f	-	0	4	1	2012-10-13 11:05:05+02
1461	tmavomodré tepláky na šnúrku LOGG, vpredu ružové číslo "78", č.104 	35	2.5	f	-	0	29	2	2012-10-13 18:24:20+02
1491	Modré kožené chlapčenské topánky zn.Protetika, 2 suché zipsy, veľ. 22	37	6	f	-	0	1	2	2012-10-14 11:23:44+02
1507	tehotenská fialová tunika nariasená na prsiach smerom nadol, dlhý rukáv, značka Stradivarius, veľkosť M	38	3	f	-	0	14	2	2012-10-13 14:59:36+02
1463	šedý tenký kardigan GIRL2GIRL, nazberané rukávy,sivé gombíky,č.110	35	4	f	-	0	31	1	2012-10-13 12:25:49+02
1453	fialový pulóver pásikavý,nazberaný véčkový výstrih, opasok so sponou	35	3	f	-	0	21	1	2012-10-13 12:26:03+02
1455	ružovo fialová pásiková mikina Cherokee, vpredu vrecká, 3-4 r.	35	2.5	f	-	0	23	2	2012-10-13 16:20:43+02
1468	ružový rolák bavlnený LUPILU, č.98/104	35	2	f	-	0	36	1	2012-10-13 12:26:11+02
1465	pásikové fialové tričko, vzadu na gombík , MATALAN, 3-4 r.	35	2	f	-	0	33	1	2012-10-13 12:26:16+02
1467	fialové tričko so strieb.motýľom, pásikové rukávy, Cherokee 3-4 r.	35	1.5	f	-	0	35	2	2012-10-13 16:49:36+02
1458	sivo-fialová mikina s kapucňou, nápis FREE GIRLS+dievčatko, 98/104	35	3	f	-	0	26	2	2012-10-13 16:55:58+02
1496	ružovkavá trigovička s vreckami vpredu na nich nápis "cute", vyšívané kvietky vpredu, veľkosť 6 - 9m	38	2	f	-	0	3	2	2012-10-13 17:30:27+02
1456	sametová čierna mikina MATALAN, na vreckách flitre, 4-5 r.   NOVÁ	35	3	f	-	0	24	1	2012-10-13 12:26:33+02
1466	biele tričko s fareb.srdiečkami LUPILU, č.98/104	35	1	f	-	0	34	2	2012-10-13 16:49:36+02
1482	ružovo-biela čiapka pre bábo	36	1.3999999999999999	f	-	0	1	2	2012-10-13 16:00:42+02
1493	Chlapčenský, tmavošedý kabát s kapucňou, ozdobné kostené \ngombíky, podšité kožušinou, veľ. 18-24 mes.	37	9	f	-	0	3	2	2012-10-13 14:55:37+02
1484	ružová zavinovačka Emitex	36	9	f	-	0	3	2	2012-10-13 18:40:33+02
1470	dlhá kaki sukňa s opaskom, vrecká, vyšité kvietky na boku, č.122	35	2	f	-	0	38	2	2012-10-14 14:07:37+02
1460	tmavofialová šatová sukňa, bavlnená,na 1 vrecku ružové kvietky, 3-4r.	35	3	f	-	0	28	2	2012-10-13 16:20:44+02
1454	huňatý bledoružový svetrík s kapucňou LADYBIRD, 4-5 r.	35	2.5	f	-	0	22	1	2012-10-13 12:28:09+02
1459	trblietavý biely pulóvrik HM, hore na 2 gombíky, 3-4r.	35	3	f	-	0	27	2	2012-10-14 13:03:02+02
1475	ružový pršiplášť s motýlikmi, s vreckami, Cherokee 18-24 mes.	35	3.5	f	-	0	43	2	2012-10-13 17:06:36+02
1462	rifle s károvaným opaskom, č.86/92, na zadných vreckách" draci"	35	1.5	f	-	0	30	2	2012-10-13 15:46:42+02
1472	pletená biela čiapka s brmbolcom, na uväzovanie, na boku bábika	35	1	f	-	0	40	1	2012-10-13 12:29:12+02
1480	riflové topánky PROTETIKA   č.26	35	2.2000000000000002	f	-	0	48	2	2012-10-14 09:44:16+02
1478	tenisky chlapčenské ADIDAS č.27	35	7	f	-	0	46	1	2012-10-13 12:29:21+02
1481	bledomodrá flisová súprava - čiapka + rukavice   9-12 mes.	35	2.2000000000000002	f	-	0	49	1	2012-10-13 12:29:29+02
1479	bundička bielobelasá s kapucňou, na gombíky     6-9 mes.	35	2.2000000000000002	f	-	0	47	1	2012-10-13 12:29:34+02
1477	čižmy chlapčenské hnedočervené s gumičkou č.26	35	2.5	f	-	0	45	2	2012-10-14 09:44:16+02
1452	ružové šuštiaky NIKE, naboku pásiky, č.104-110	35	5	f	-	0	20	2	2012-10-14 11:09:27+02
1451	tmavofialové oteplovačky na traky DOPO., veľ.110	35	6	f	-	0	19	2	2012-10-13 16:58:47+02
1457	sametové čierne tepláky na gumu MATALAN, 4-5 r.               NOVÉ	35	2	f	-	0	25	2	2012-10-13 14:52:41+02
1547	Modrá podšitá nepremokavá bundička s kapucou, Voltereta, veľ. 80-86	40	7	f	-	0	7	2	2012-10-13 18:28:03+02
1545	Súprava HaM (menčestráky + pásikavé tričko) ružová, veľ. 80	40	8	f	-	0	5	1	2012-10-13 08:21:44+02
1546	Tepláková súprava bavlnená, Tulec Trend krémovo-oranžová, veľ. 86	40	7	f	-	0	6	1	2012-10-13 08:21:48+02
1550	Zelená klokanková mikina s kapucou a aplikáciou, HaM, veľ. 98-104	40	3.5	f	-	0	10	1	2012-10-13 08:21:53+02
1555	Biela mikina so srdiečkami, kapuca, krátky rukáv, Cherokee, veľ. 98	40	2	f	-	0	15	2	2012-10-13 17:06:36+02
1556	Žltá chlpatá bundička s kvetmi na zips, veľ. 80	40	2	f	-	0	16	2	2012-10-13 18:38:14+02
1543	Fialový set, vyšívané menčestráky + vyšívaný kabátik, Next, veľ, 92	40	10	f	-	0	3	2	2012-10-13 16:48:23+02
1565	Červené kordové šaty s krátkym rukávom, výšivky, 2 vrecká, Lindex, veľ. 98	40	7	f	-	0	26	1	2012-10-13 08:22:19+02
1563	Ružové úpletové šaty bez rukávov, motív slona, Lindex, veľ. 86	40	5	f	-	0	23	1	2012-10-13 08:22:28+02
1528	tepláky tm.modré,bočné vrecká, TU, veľ.6r.	39	2	f	-	0	19	2	2012-10-13 16:24:03+02
1559	Biele flanelové overalové pyžamko s modrými kvietkami, veľ. 92	40	2.5	f	-	0	19	1	2012-10-13 08:22:52+02
1560	Ružové overalové pyžamko so srdiečkami, HaM, veľ. 98-104	40	2	f	-	0	20	1	2012-10-13 08:22:45+02
1551	Krémový bavlnený svetrík krátky rukáv, Next, veľ. 104	40	3.5	f	-	0	11	1	2012-10-13 08:22:58+02
1558	Žlté overalové pyžamko s aplikáciou, CaA, veľ. 80	40	2	f	-	0	18	1	2012-10-13 08:23:04+02
1562	Čierne úpletové šaty bez rukávov s 2 vreckami, Zara, veľ. 98	40	6	f	-	0	22	1	2012-10-13 08:23:15+02
1552	Šedo-ružový svetrík na zapínanie (škótsky vzor), HaM, veľ. 80	40	2.5	f	-	0	12	2	2012-10-13 16:54:15+02
1544	Súprava CaA (menčestráky + košieľka + svetrík) ružovo-krémová, veľ. 74	40	11	f	-	0	4	1	2012-10-13 08:23:33+02
1517	trigovica šedá, červené a modré pásy na hrudi,PUMA	39	2	f	-	0	8	2	2012-10-13 16:06:44+02
1523	nohavice oranžové kárované, čierne kolená, v páse do gumy,opasok,NEVEREST,veľ.140	39	3	f	-	0	14	2	2012-10-13 18:55:46+02
1536	bunda tm.hnedá,na zips,na rukávoch bledý pás -G.L.8.5., na vrecku vyšitý kruh,veľ.134	39	4	f	-	0	27	2	2012-10-13 17:26:55+02
1535	bunda šedo čierna,káro,s kapucou,vnútrišedý flauš,CHEROKEE,veľ.10/11r.	39	7	f	-	0	26	2	2012-10-14 10:57:36+02
1566	Ružové tepláky so šedým pásikom, Cherokee, veľ. 98	40	3	f	-	0	27	1	2012-10-13 08:25:52+02
1549	Hnedá teplá vesta na zips s kožušinovou kapucou, veľ. 92	40	7	f	-	0	9	1	2012-10-13 08:27:14+02
1510	trigovica khaky zelená-WENICE,vpredu dve nášivky,veľ.122	39	2	f	-	0	1	1	2012-10-13 09:09:20+02
1511	trigovica oranžová, biele a šedé nápisy, HOT OIL,veľ.134	39	2	f	-	0	2	1	2012-10-13 09:09:23+02
1557	Tmavomodrý svetrík s kvetovou aplikáciou, Zara, veľ. 86	40	4	f	-	0	17	2	2012-10-13 15:55:14+02
1513	trigovica zelená na zips, s kapucou,vpredu vrecká, veľ.10/11r.	39	2	f	-	0	4	1	2012-10-13 09:09:31+02
1515	trigovica khaky zelená,bledé a tmavé pásiky, zips, golier-polokošeľa,RED APPLE	39	2	f	-	0	6	1	2012-10-13 09:09:40+02
1516	trigovica modrá, flaušová, polov. Zips,TESCO,veľ.134	39	3	f	-	0	7	1	2012-10-13 09:09:44+02
1522	nohavice šedé oteplené,v páse do gumy,našité vrecká, malé zipsy,FASHION 8	39	5	f	-	0	13	2	2012-10-13 16:17:37+02
1512	trigovica šedo-červená pásiková s kapucou,vpredu nápis WENICE,veľ.140	39	2	f	-	0	3	2	2012-10-13 14:59:36+02
1519	pulover bordový,šedé rukávy, vpredu č.28, veľ.128                                                         3,- 	39	3	f	-	0	10	1	2012-10-13 09:09:55+02
1520	nohavice hnedé, v páse patent,šnúrky,na bokoch prešívané vrecká,F&F,veľ.9/10r.	39	3	f	-	0	11	1	2012-10-13 09:10:04+02
1564	Fialové pletené šaty s krátkym rukávom Hello Kitty, HaM, veľ. 80	40	6	f	-	0	24	2	2012-10-13 16:20:44+02
1521	rifle modré, žlté prešívanie,na ľavom vrecku BRASIL, IKO 18	39	3	f	-	0	12	2	2012-10-13 16:20:19+02
1554	Šedo-ružová kocková mikina s kapucou, Kenvelo, veľ. 98-108	40	4	f	-	0	14	2	2012-10-14 10:40:27+02
1525	nohavice bledo hnedé, oteplené,prešívané vrecká,YUE HUI,veľ.134	39	5	f	-	0	16	2	2012-10-14 10:57:37+02
1526	nohavice šedé, maskáčový vzor,v páse do gumy,vrecká so zipsom,BOUNY BABY 8	39	3	f	-	0	17	2	2012-10-14 11:04:46+02
1561	Námornícke úpletové šaty s dlhým rukávom, rolák, Zara, veľ. 104	40	1.5	f	-	0	21	2	2012-10-14 13:55:18+02
1527	rifle tm.šedé, v páse guma, CHEROKEE,veľ.8/9r.	39	3	f	-	0	18	1	2012-10-13 09:10:31+02
1553	Hnedý svetrík s farebnými srdiečkami, HaM, veľ. 98-104	40	3	f	-	0	13	2	2012-10-13 16:30:23+02
1529	tepláky bledo modré, naboku biely a žltý pás,bočné vrecká,veľ.134	39	2	f	-	0	20	1	2012-10-13 09:10:39+02
1530	tepláky šedé, naboku biely a modrý pás, bočné vrecká, veľ.140	39	2	f	-	0	21	1	2012-10-13 09:10:42+02
1531	bunda šedá,jesenná,s kapucou,na zips a cvoky,modré prešívanie,YES KIDS 8                5,-	39	5	f	-	0	22	1	2012-10-13 09:10:46+02
1532	bunda tm.modrá,s kapucou, na zips, vnútri červený flauš,vzadu nápis XMAO, 120/60       5,-	39	5	f	-	0	23	1	2012-10-13 09:10:52+02
1533	bunda tm.modrá,s kapucou,na zips,vnútro bl.modré,vpredu auto HOTWHEELS,veľ.8/9r.   	39	7	f	-	0	24	1	2012-10-13 09:10:56+02
1534	bunda žltá,na zips,na rukávoch biely a čierny pás,vrecká na zips,vpredu TOOWOOMBA	39	4	f	-	0	25	1	2012-10-13 09:11:03+02
1524	nohavice tm.modré oteplené,v páse zelená guma,našité vrecká,F&F,veľ.9/10r.	39	5	f	-	0	15	2	2012-10-14 10:57:37+02
1548	Ružová úpletová bundička krátky rukáv s kapucou, Kiki Koko, veľ, 92	40	3	f	-	0	8	2	2012-10-13 17:31:15+02
1537	kombinéza zimná,šedo-žltá,na rukávoch lesklý pás,opasok, vrecká na zips,veľ.10r.	39	6	f	-	0	28	1	2012-10-13 09:11:19+02
1538	otepľovačky čierne,na vreckách s červeným,vpredu na zips, traky,č.9	39	4	f	-	0	29	1	2012-10-13 09:11:26+02
1539	súprava -košeľa šedobiela pásiková,vesta čierna,kravata šedá,veľ.7/8r.	39	6	f	-	0	30	1	2012-10-13 09:11:31+02
1540	oblečenie na krst-overal,čiapka, papučky,rukavičky,biele s výšivkou,veľ.3/6mes.	39	10	f	-	0	31	1	2012-10-13 09:11:41+02
1518	trigovica bledo-šedá, s kapucou,vpredu vrecká,nášivka AUTÁ,F&F,veľ.10/11r.	39	2	f	-	0	9	2	2012-10-13 14:59:36+02
1596	tmavomodré čizmičky 26	41	7	f	-	0	7	2	2012-10-14 11:12:01+02
1570	Čierne jazdecké elasťáky, Zara, veľ. 98	40	4	f	-	0	31	1	2012-10-13 08:24:07+02
1569	Tmavošedé elasťáky dole s ozdobami, Monsoon, veľ. 98	40	4	f	-	0	30	1	2012-10-13 08:24:37+02
1602	roláčik prúžkový bielo-zeleno-ružovo-červený	41	2	f	-	0	13	2	2012-10-13 17:18:28+02
1568	Bledoružové tepláky na šnúrku HaM, veľ. 86	40	2	f	-	0	29	1	2012-10-13 08:25:56+02
1572	Hnedé kordové podšité nohavice s opaskom, CaA, veľ. 80	40	5	f	-	0	33	2	2012-10-13 16:21:45+02
1588	Ružovo-biele pásikavé tričko s dlhým rukávom, s aplikáciou, CaA, veľ. 92	40	1.5	f	-	0	49	1	2012-10-13 08:26:07+02
1587	Oranžové tričko s dlhým rukávom, s aplikáciou, Mothercare, veľ. 98	40	1.5	f	-	0	48	1	2012-10-13 08:26:14+02
1592	červená čapička  Littlest Pet Shop	41	1.5	f	-	0	3	2	2012-10-13 17:41:02+02
1586	Ružovo-biele tričko s dlhým rukávom, motív čerešní, veľ. 86	40	1.5	f	-	0	47	2	2012-10-13 17:36:30+02
1607	ružový sveter Cherokee na zips	41	1.5	f	-	0	18	2	2012-10-13 18:50:04+02
1579	Súprava 2 tričká (fialové a šedé s fialovými bodkami), HaM, veľ. 98-104	40	3	f	-	0	40	2	2012-10-13 16:20:44+02
1576	Krémové športové nohavice s úpletmi, 6 vreciek, Zara, veľ. 98	40	5	f	-	0	37	2	2012-10-13 18:15:07+02
1626	teply svetrik s kapucou,sedy,podsity kozusinou,12mes,vpredu vrecka	42	4.5	f	-	0	4	2	2012-10-13 16:36:03+02
1612	šedý roláčik 	41	1.5	f	-	0	23	2	2012-10-13 16:49:36+02
1574	Krémové bavlnené nohavice s aplikáciami, vrecká, všitý opasok, veľ. 98	40	5	f	-	0	35	1	2012-10-13 08:26:50+02
1575	Džínsy do gumy so šnúrkou, ružové prešívanie, Reflex, veľ. 92	40	6.5	f	-	0	36	1	2012-10-13 08:26:53+02
1567	Hnedo-oranžové trakové tepláky, 2 vrecká, Japitex, veľ. 80	40	4	f	-	0	28	1	2012-10-13 08:27:03+02
1582	2 ks bavlnená smotanová elastická plachta do postieľky, Ikea 	40	6	f	-	0	43	1	2012-10-13 08:27:35+02
1594	zelená bundička s vyšívanými kvietkami 	41	3	f	-	0	5	2	2012-10-13 18:15:07+02
1577	Džínsy podšité úpletom do gumy s mašľou, Zara, veľ. 86	40	6	f	-	0	38	1	2012-10-13 08:27:46+02
1590	fialová čapička so šiltom 	41	2	f	-	0	1	1	2012-10-13 09:46:56+02
1591	biela chlpatka	41	5	f	-	0	2	1	2012-10-13 09:47:01+02
1630	biele rifle,little star,pri vrecku napis Safari,80/9-12mes	42	1.8	f	-	0	8	2	2012-10-13 17:41:44+02
1578	Body 4 ks CaA, veľ. 86 (2x) a 92 (2x)	40	4	f	-	0	39	2	2012-10-13 17:17:11+02
1580	Ružové tričko s dlhým rukávom jednofarebné, HaM, veľ. 86	40	1.5	f	-	0	41	2	2012-10-13 18:49:05+02
1595	riflová bundička Impidinpi 98/104	41	2	f	-	0	6	1	2012-10-13 09:47:37+02
1625	tepla mikina na zips,cervena,"small boys"74/9mes,bielo-cerveno-cierne patenty	42	7.2999999999999998	f	-	0	3	2	2012-10-14 12:03:52+02
1597	bledomodré vysoké tenisky 29	41	3	f	-	0	8	1	2012-10-13 09:48:01+02
1598	strieborné tenisky Naturino 26	41	3	f	-	0	9	1	2012-10-13 09:48:13+02
1599	ružová čapička so šiltom s kvietkami 	41	1	f	-	0	10	1	2012-10-13 09:48:25+02
1600	tmavomodré rifličky Miss e-vie 6-7	41	1.5	f	-	0	11	1	2012-10-13 09:48:27+02
1601	rifličky Next 92	41	3	f	-	0	12	1	2012-10-13 09:48:32+02
1585	Zelené tričko s 3/4 rukávom s aplikáciou, Cherokee, veľ. 104	40	1.5	f	-	0	46	2	2012-10-13 17:18:29+02
1603	šedé nohavice Despetits	41	2	f	-	0	14	1	2012-10-13 09:48:40+02
1604	zelené nohavice George	41	2	f	-	0	15	1	2012-10-13 09:48:49+02
1606	zelené nohavice Cherokee	41	3	f	-	0	17	1	2012-10-13 09:48:58+02
1605	ružové nohavice George	41	2	f	-	0	16	1	2012-10-13 09:49:00+02
1623	zimný kabatik,bledo modry s kapucou,vpredu dva zvieratka vysite,6-9mes	42	5	f	-	0	1	2	2012-10-14 10:25:05+02
1609	zelený roláčik Lilly Love	41	2	f	-	0	20	1	2012-10-13 09:49:54+02
1581	Červené tričko s dlhým rukávom Hello Kitty, HaM, veľ. 86	40	1.5	f	-	0	42	2	2012-10-13 16:08:53+02
1611	riflové šatôčky Dopodopo 104	41	3	f	-	0	22	1	2012-10-13 09:50:01+02
1593	červená zimná bundička s macíkom 	41	3	f	-	0	4	2	2012-10-13 16:55:58+02
1584	Tyrkysové šaty s dlhým rukávom, motív hrocha, Lindex, veľ. 98	40	4	f	-	0	45	2	2012-10-13 17:55:08+02
1614	riflová suknička H@M	41	2	f	-	0	25	1	2012-10-13 09:50:14+02
1615	ružová čapička s macíkom vpredu s rukavičkami	41	1.5	f	-	0	26	1	2012-10-13 09:50:18+02
1616	bielo-ružová súprava veľkosť 80	41	2	f	-	0	27	1	2012-10-13 09:50:24+02
1617	bielo-ružové bodíčko Benniny vzadu na zapínanie	41	3	f	-	0	28	1	2012-10-13 09:50:32+02
1618	fialové trička s koníkom vpredu 62/68	41	2	f	-	0	29	1	2012-10-13 09:50:40+02
1619	fialové manchestrové nohavice Benetton 74	41	2.5	f	-	0	30	1	2012-10-13 09:50:46+02
1620	ružová mikinka so stojačikom Early days	41	2.5	f	-	0	31	1	2012-10-13 09:50:49+02
1621	komplet - mikinka biela a nohavičky kárované oranžovo-zelené	41	4.5	f	-	0	32	1	2012-10-13 09:50:54+02
1610	roláčik prúžkový bledomodro-fialovo-biely	41	2	f	-	0	21	2	2012-10-13 15:43:35+02
1573	Hnedéé 3/4 plátenné nohavice s kvetmi, HaM, veľ. 92	40	4	f	-	0	34	2	2012-10-14 10:40:27+02
1624	zimna vesta,cervena,na bokoch maskacova aplikacia,s kapucou	42	2.7999999999999998	f	-	0	2	1	2012-10-13 09:54:30+02
1583	Ružové šaty s dlhým rukávom, motív hrocha, Lindex, veľ. 92	40	4	f	-	0	44	2	2012-10-13 16:36:45+02
1627	zimna kombineza,cerveno cierna,baby club,86,	42	8.9000000000000004	f	-	0	5	2	2012-10-13 17:51:43+02
1628	tmavomodre menzestrove nohavice,tinko,vel.80	42	1.8999999999999999	f	-	0	6	1	2012-10-13 09:55:46+02
1629	suprava -nohavice na traky hnede podsite+trickio bezovo hnede s dlhým rukav.,cherokee,12-18mes	42	4.7000000000000002	f	-	0	7	1	2012-10-13 09:55:53+02
1613	ružovo-fialová pásiková čapička Barbie	41	1	f	-	0	24	2	2012-10-13 17:44:18+02
1631	tmavomodra teplakova supr.s oranzov.aplikaciami,na zips,vpredu kostra,vel.80	42	3.2999999999999998	f	-	0	9	1	2012-10-13 09:56:21+02
1632	teplakova suprava,tmavo sede teplaky,mikina bledo seda s tyrkisovym,vpredu auto,okay 74	42	2.7999999999999998	f	-	0	10	1	2012-10-13 09:57:06+02
1633	tricko s dlhym rukav.bledo sede,biely rukav,napis im cuter than my daddy,80	42	1	f	-	0	11	1	2012-10-13 09:57:19+02
1622	fialkovo - ružové topánočky 19	41	7	f	-	0	33	2	2012-10-13 15:11:38+02
1675	hnedo škoricová trigovica,v predu s nápisom, 82cm, Venice	43	2	f	-	0	10	2	2012-10-13 18:31:57+02
1635	polorolak,hnedy s oranzovo hnedo behove pruzky, 86	42	2.2999999999999998	f	-	0	13	1	2012-10-13 09:57:27+02
1698	Umelohm. Loďka so zvieratkami 	43	10	f	-	0	33	2	2012-10-13 15:48:43+02
1637	tricko s dlhym rukav.bledo modre,biely rukav,vpredu opica, 80	42	1.5	f	-	0	15	1	2012-10-13 09:57:38+02
1638	adidas mikina na zips,tmavo modra s tyrkis.,80	42	3.8999999999999999	f	-	0	16	1	2012-10-13 09:58:02+02
1639	rifle tmavo modre,HaM,104	42	1.8999999999999999	f	-	0	17	1	2012-10-13 09:58:08+02
1640	sede teplaky,vpredu dve auta cars, 80	42	2.7999999999999998	f	-	0	18	1	2012-10-13 09:58:25+02
1657	oranzove tricko s dlhym rukavom ,vpredu lev simba, vel.12-18 mes	42	1.6000000000000001	f	-	0	35	2	2012-10-13 17:10:51+02
1642	teply svetrik,pasiky bezovo modre cervene,na cvoky,74	42	1.7	f	-	0	20	1	2012-10-13 09:58:32+02
1643	sametovy bledo modry pulovrik,74	42	0.90000000000000002	f	-	0	21	1	2012-10-13 09:58:34+02
1644	tmavo modre teplaky,vpredu vlacik,modro biele patenty,74	42	3.6000000000000001	f	-	0	22	1	2012-10-13 09:58:39+02
1646	tmavo modre rifle,strieborne sitie,kapsacove,vel.4	42	4.2999999999999998	f	-	0	24	1	2012-10-13 09:58:45+02
1647	sametovy overal bledo modry,vpredu macko,zeleno bielo hnede pasiky,92	42	2.1000000000000001	f	-	0	25	1	2012-10-13 09:58:49+02
1650	sametova suprava,mikina na cvoky+teplaky,vpredu na mikine havko,62/68	42	2.2000000000000002	f	-	0	28	2	2012-10-13 17:00:09+02
1641	mikina mickey mouse vysity vpredu,tmavo modre a sede pasy,s kapucou,12-18mes	42	4.7999999999999998	f	-	0	19	2	2012-10-13 17:09:37+02
1665	natelnik s dlhym rukav.,biely, vel 74	42	1	f	-	0	43	2	2012-10-13 17:56:04+02
1652	bledo modre menzestrove nohavice na traky,vpredu auticka3/6 mes	42	2	f	-	0	30	1	2012-10-13 09:59:29+02
1653	bledo ruzove teplaky,vpredu traja mackovia,92	42	1.2	f	-	0	31	1	2012-10-13 09:59:32+02
1655	bledo zelene body,vpredu zirafa,vel 80	42	0.90000000000000002	f	-	0	33	2	2012-10-13 17:12:25+02
1651	podsite nohavice,pasiky hnedo modro zlte,okay 68	42	1.8	f	-	0	29	2	2012-10-13 17:24:17+02
1654	bavlneny overal-pyzamko,tyrkisove,vpredu pes pluto,9-12mes	42	2.2999999999999998	f	-	0	32	2	2012-10-13 17:12:25+02
1656	biele tricko s dlhym rukavom, vpredu tiger z macka poo,12-18 mes	42	1.3	f	-	0	34	2	2012-10-13 17:12:25+02
1659	tricko s dlhym rukav.,pasik bledo modro -tmavo modro-zeleny,6-9mes	42	0.69999999999999996	f	-	0	37	1	2012-10-13 10:00:12+02
1660	body s dlhym rukav.,tmavo modra s bledo modrou,vpredu macko,tinko 80	42	0.80000000000000004	f	-	0	38	1	2012-10-13 10:00:15+02
1661	biele body,napis "adamko ma 1 rôcik",ve.92	42	1	f	-	0	39	1	2012-10-13 10:00:17+02
1662	body s dlhym rukav.,tyrkisova s bielou,vpredu acrobat,74	42	1.6000000000000001	f	-	0	40	1	2012-10-13 10:00:20+02
1663	body s dlhym rukav.,tyrkisove,vpredy lysiak, vel 68	42	0.90000000000000002	f	-	0	41	1	2012-10-13 10:00:35+02
1664	body s dlhym rukav.,bledo modra s bielou,vpredu macko,80	42	0.5	f	-	0	42	1	2012-10-13 10:00:37+02
1634	cierne nohavice na traky,s cervenym presitym,ozdobne cvoky,podsite,24m	42	2.7999999999999998	f	-	0	12	2	2012-10-13 18:04:39+02
1681	dalmatínovský kožuch s klobúkom tak na 6 rokov	43	7	f	-	0	16	1	2012-10-13 11:01:31+02
1691	malý modrý notebook hračkársky v krabici	43	12	f	-	0	26	2	2012-10-13 19:11:09+02
1674	zelené samätové šaty s kvetinkami,Melograno,	43	4	f	-	0	9	1	2012-10-13 11:02:08+02
1672	červeno modrá šušťačka  s bielymi pásmi-nike,success, vč.116	43	3	f	-	0	7	1	2012-10-13 11:02:37+02
1673	modro zeleno oranžová trigovica zo zajačikom a nápisom v predu	43	2	f	-	0	8	1	2012-10-13 11:02:43+02
1687	čierne topánky adidas, asi 28 veľkosť	43	2	f	-	0	22	2	2012-10-14 10:09:32+02
1677	bledoškoricové nohavice,Kids kenvelo na 8 rokov, s vačkami	43	5	f	-	0	12	1	2012-10-13 11:02:52+02
1678	červená trigovica s ligotavými kvetinami,litle dream angel, S-asi 6-7r.	43	2	f	-	0	13	1	2012-10-13 11:03:00+02
1693	Hnedé semišové tenisky s modrou komb., PUMA, v.	43	8	f	-	0	28	2	2012-10-13 15:26:50+02
1680	oranžovo-tmavomodrý sveter s nápisom v predu L.O.G.G. 1-1,5 roka	43	3	f	-	0	15	1	2012-10-13 11:03:15+02
1682	modré šušťakové nohavice-oteplovačky na zips a traky	43	3	f	-	0	17	1	2012-10-13 11:03:22+02
1684	červená sukňa v predu s vačkami ,4-5rokov,mothercare	43	3	f	-	0	19	1	2012-10-13 11:03:30+02
1683	tričko s dlhým rukávom so zvieratkami v predu, KIKI KOKO,v104	43	3	f	-	0	18	1	2012-10-13 11:03:34+02
1688	smotanové tričko s dlh. Rukávom, HOT OIL, 128	43	2	f	-	0	23	1	2012-10-13 11:03:39+02
1685	tmavá riflová sukňa Mango jeans ,v.34	43	4	f	-	0	20	1	2012-10-13 11:03:48+02
1679	bledo modro hnedný sveter, s lietadlom, na boku zips,H+M,3-4r	43	5	f	-	0	14	2	2012-10-13 15:22:20+02
1690	čierny kostým smrtky, 3-4 roky	43	5	f	-	0	25	1	2012-10-13 11:04:02+02
1696	tričko s dlhým rukávom  s nápismi a  62,	43	2	f	-	0	31	1	2012-10-13 11:04:12+02
1692	trávičkovo zelené a kvietkové tričko s dlh. Rukávom, VENICE,v122	43	2	f	-	0	27	1	2012-10-13 11:04:18+02
1671	Šuštiaková sprava modro-bielo-červená PUMA,v.110	43	8	f	-	0	6	1	2012-10-13 11:04:28+02
1670	Farebný modrý overal, vzadu lyžiar a nápisAir... V. 116, 	43	4	f	-	0	5	1	2012-10-13 11:06:06+02
1669	kúpacie pončo spiderman	43	3	f	-	0	4	1	2012-10-13 11:06:15+02
1668	hnedá, vnútri modrá vesta Cherokke, 13-14 rokov	43	6	f	-	0	3	1	2012-10-13 11:06:21+02
1658	tmavo modre tricko s dlhym rukavom,vpredu zeleno biele lietadlo,6-9mes	42	0.80000000000000004	f	-	0	36	2	2012-10-14 12:58:26+02
1666	Hnedá ražná bunda s kapucou HAIDI  8/126	43	7	f	-	0	1	1	2012-10-13 11:06:33+02
1695	hovoriaci koník ružový-hračka	43	12	f	-	0	30	1	2012-10-13 11:09:12+02
1636	sametove teplaky,tmavo modre,zeleno sede patenty,86	42	2.8999999999999999	f	-	0	14	2	2012-10-13 15:44:00+02
1667	Hrubé podšité nohavice NEXT do hrubej gumy 3-4 roky	43	3	f	-	0	2	2	2012-10-14 12:16:42+02
1694	hnedé topánky semiš,vysoké,preštepované	43	5	f	-	0	29	1	2012-10-13 11:09:54+02
1649	suprava dupacky a kabatikom bledo modre,vpredu vysite bonbari,62,	42	1.8999999999999999	f	-	0	27	2	2012-10-13 16:38:46+02
1676	oranžové tričko s dlh. Rukávom TOUR58-nápis v predu,	43	2	f	-	0	11	2	2012-10-14 09:48:06+02
1697	Dance PAD-tanečný koberec s CD	43	10	f	-	0	32	1	2012-10-13 11:12:12+02
1686	modro žlto biele pásikavé tričko s dlh. Rukávom  Children´s	43	1.5	f	-	0	21	2	2012-10-13 15:15:37+02
1714	prechodna upletova ciapka modra s oranz.bielym pasikom,so snurkami,6 mes	44	1.8	f	-	0	4	2	2012-10-13 18:22:27+02
1735	zimne kotnikove topanky na suchy zisp, modro oranzove s kozusinkou, protetika, 21	44	6.5	f	-	0	25	2	2012-10-13 18:36:12+02
1715	bavlnena  bezova ciapka so snurkami,po bokoch bezovo hnedy pasik,6 mes	44	1	f	-	0	5	1	2012-10-13 10:03:40+02
1716	cervena bavlnena ciapka s dvoma uskami,so snurkami,po bokoch bielo cerveny pasik, 6 mes	44	0.5	f	-	0	6	1	2012-10-13 10:03:43+02
1723	tmavo modre rukavicky na snurke,	44	1.3	f	-	0	13	2	2012-10-13 17:17:43+02
1699	hračka-guličky na kovov. Konštrukcii na prevliekanie	43	2	f	-	0	34	2	2012-10-13 16:36:03+02
1719	upletova biela ciapka so snurkami 	44	1.1000000000000001	f	-	0	9	1	2012-10-13 10:05:18+02
1720	bavlnena ciapka,bielo zelena s uskami,so snurkami	44	0.29999999999999999	f	-	0	10	1	2012-10-13 10:05:21+02
1739	Body dlhy rukav ruzovo biele pasikave vpredu zajko s opicou	45	1	f	-	0	2	2	2012-10-13 17:30:27+02
1722	biele chlpatkove rukavicky	44	0.80000000000000004	f	-	0	12	1	2012-10-13 10:05:48+02
1721	biele rukavicky so snurkou,napis BABY	44	1.1000000000000001	f	-	0	11	2	2012-10-13 17:30:15+02
1726	latkovo kozusinkove cizmicky,bordovo biele s kozusinkou	44	6.0999999999999996	f	-	0	16	1	2012-10-13 10:05:56+02
1724	chlpatkove rukavicky cierno biele so snurkou	44	1.3	f	-	0	14	1	2012-10-13 10:06:00+02
1727	bledo modre pancusky na zadku havko,tyrkisovo hnedy pasik	44	0.90000000000000002	f	-	0	17	1	2012-10-13 10:06:47+02
1728	biele bavlnene pancuchy,tatrasvit,100	44	0.59999999999999998	f	-	0	18	1	2012-10-13 10:06:49+02
1729	modre bavlnene pancuchy tatrasvit, 80	44	0.40000000000000002	f	-	0	19	1	2012-10-13 10:06:53+02
1730	hnede bavlnene pancuchy tatrasvit 70	44	0.5	f	-	0	20	1	2012-10-13 10:06:55+02
1731	biele bavlnene pancuchy,tatrasvit,70	44	0.69999999999999996	f	-	0	21	1	2012-10-13 10:06:58+02
1732	modre bavlnene pancuchy tatrasvit, 70	44	0.69999999999999996	f	-	0	22	1	2012-10-13 10:07:01+02
1733	bledo hnede bavlnene pancuchy, tatrasvit,70	44	0.40000000000000002	f	-	0	23	1	2012-10-13 10:07:05+02
1734	biele bavlnene pancuchy tatrasvit,70	44	0.5	f	-	0	24	1	2012-10-13 10:07:07+02
1725	strikovane papucky,bielo modre	44	1.3	f	-	0	15	1	2012-10-13 10:07:19+02
1710	čiernošedé koručule na ľad, v 28, S15	43	13	f	-	0	45	2	2012-10-13 18:42:27+02
1736	tenisky na suchy zisp,zeleno zlte,adidas pasky zlte,22	44	4.5	f	-	0	26	2	2012-10-14 12:59:13+02
1737	zimne kotnikove topanky na suchy zisp,modro strieborne,zateplene,22	44	3.8999999999999999	f	-	0	27	2	2012-10-14 10:43:23+02
1738	Dve pyzamka na cvoky jedno ruzovo biele gulickove druhe kvietkove	45	3	f	-	0	1	1	2012-10-13 10:43:17+02
1749	Body 2x, jedny biele s napisom a druhe ruzove s kvetinkami cherokee	45	2.1000000000000001	f	-	0	12	2	2012-10-13 17:30:27+02
1740	Tricko dlhy rukav zelene vpredu opicka, na 2 gombicky 	45	1.8999999999999999	f	-	0	3	1	2012-10-13 10:43:46+02
1741	Overal bledo ruzovy vpredu napis aj s obrazkami prasiatko ... 	45	2	f	-	0	4	1	2012-10-13 10:43:51+02
1742	Tricko modro biele na 2 cvoky vpredu napis na 3-6mes.	45	2	f	-	0	5	1	2012-10-13 10:43:57+02
1743	Nohavice bledo ruzove s vackami na 2-4mes.	45	2	f	-	0	6	1	2012-10-13 10:44:03+02
1744	Tricko sede v predu pavucik, rukavy pasikave 	45	1.5	f	-	0	7	1	2012-10-13 10:44:08+02
1745	Body biele dlhy rukav s limcekom na 2 gombicky a nasite kvety 	45	2	f	-	0	8	1	2012-10-13 10:44:14+02
1746	Bledo ruzove teplaky vpredu snurky 	45	1	f	-	0	9	1	2012-10-13 10:44:18+02
1747	Body dlhy rukav ruzove s napisom v predu 3-6mes.	45	2	f	-	0	10	1	2012-10-13 10:44:23+02
1748	Vesticka fialova v predu psik s napisom 74/80vel.	45	2.7999999999999998	f	-	0	11	1	2012-10-13 10:44:27+02
1752	Ruzovo biely pasikavy svetrik s kapuckou 62/68 vpredu nasity macko.	45	4	f	-	0	15	2	2012-10-13 18:03:40+02
1750	Ruzova mikina na gombiky vpredu nasite prasiatko, s vackami	45	1.8999999999999999	f	-	0	13	1	2012-10-13 10:44:40+02
1751	Mikina s kapucou ruzova vzsite kvietky+ tricko biele s kvetinkou 3-6m	45	3	f	-	0	14	1	2012-10-13 10:44:48+02
1713	bledo modra flisova ciapka s uskami,so snurkami,6mes	44	2.2999999999999998	f	-	0	3	2	2012-10-13 18:04:39+02
1753	Riflicky next s kvietkami aj s opaskom 6-9mes.	45	5	f	-	0	16	1	2012-10-13 10:45:04+02
1754	Ciapocka pasikava so siltom, modro hneda na 2-6mes.	45	1.5	f	-	0	17	1	2012-10-13 10:45:12+02
1755	Riflicky na 0-3mes.  Vpredu nakreslene tri priserky	45	2	f	-	0	18	1	2012-10-13 10:45:20+02
1756	Tricko ruzove, nakresleny tweety, na 12/18mes.	45	2.8999999999999999	f	-	0	19	1	2012-10-13 10:45:24+02
1757	Tricko ruzove,tweety nakresleny na 6mes, polka rukava pasikaveho	45	3	f	-	0	20	1	2012-10-13 10:45:29+02
1758	Dupacky Domaja zeleno biele v predu husenica a hrib	45	2	f	-	0	21	1	2012-10-13 10:45:33+02
1759	Dupacky bledo oranzove v predu zirafa	45	2.5	f	-	0	22	1	2012-10-13 10:45:44+02
1760	Body pasikave bielo hnede na cvoky dlhy rukav na 2-4m. 	45	2	f	-	0	23	1	2012-10-13 10:45:48+02
1762	Tri pyzamka 1cisto modre,2 pasikave,3kockove. V modrom bielom.	45	5.4000000000000004	f	-	0	25	1	2012-10-13 10:46:10+02
1763	Svetrik s kratkym rukavom ruzovy na jeden gombicek 	45	4.5	f	-	0	26	1	2012-10-13 10:46:24+02
1764	Prechodna bunda reserved na 6-9m. Cierna, pasiky na patentoch 	45	6.9000000000000004	f	-	0	27	1	2012-10-13 10:46:32+02
1700	červená trigovica Fashion 99 6r.	43	1.5	f	-	0	35	1	2012-10-13 11:04:08+02
1707	kúpací plášť s postavičkami a hviezdami,modrý lem BUE L	43	2	f	-	0	42	1	2012-10-13 11:06:46+02
1709	červené tričko s dlhým rukávom v predu s nápisom,Cherokee,asi 122	43	2	f	-	0	44	1	2012-10-13 11:06:52+02
1708	Košeľa károvaná hnedomodrá LOGG v.92 	43	2	f	-	0	43	1	2012-10-13 11:07:00+02
1706	šutiaková bunda červeno modrá,vpredu nálep.original quality,Fashion...	43	6	f	-	0	41	1	2012-10-13 11:07:15+02
1702	maskáčové topánky , spodok gumový Spors and spors	43	5	f	-	0	37	1	2012-10-13 11:07:43+02
1701	plyš. Hračka tiger z Mcka POOU	43	4	f	-	0	36	1	2012-10-13 11:08:04+02
1703	šrek bábätko plyš. Hračka	43	12	f	-	0	38	1	2012-10-13 11:09:00+02
1704	šrek tatko zvukový	43	6	f	-	0	39	1	2012-10-13 11:09:05+02
2236	menžestráky zn. HM, veľ.98	58	5	f	-	0	8	2	2012-10-14 09:21:26+02
1717	tepla biela ciapka hunata,vnutri podsita bavlna,vpredu havko,so snurkami,45cm	44	3.6000000000000001	f	-	0	7	2	2012-10-13 17:00:09+02
1705	2 knižky pre maličké deti 	43	2	f	-	0	40	1	2012-10-13 11:10:43+02
1718	modra bavlnena ciapka so snurkami	44	0.90000000000000002	f	-	0	8	2	2012-10-13 16:25:44+02
1766	Svetrik modry pasikavy cherokee vpredu psik na 6-9mes	45	4.5	f	-	0	29	1	2012-10-13 10:46:43+02
1818	Teplá kožušinková vestička,na 1 drevený gombík	46	3.5	f	-	0	31	2	2012-10-13 18:38:14+02
1768	Nohavice zelenkave s vackami s opaskom vzadu napis L.baby 	45	6	f	-	0	31	1	2012-10-13 10:46:57+02
1786	Nohavice cherokee zelene s vackami presite farebnymi nitami 2-3roky	45	5	f	-	0	49	2	2012-10-13 18:26:49+02
1792	Bledoružový kožuštek,brúsená koža,kapucňa s uškami	46	5	f	-	0	5	2	2012-10-13 17:03:24+02
1827	Fialová kordová tunika s ružovými bodkami, 2 vrecká na bokoch	46	3.5	f	-	0	40	2	2012-10-13 17:29:26+02
1772	Nohavice zelenkave s vreckami pas na gumu a snurky cherokee	45	2.1000000000000001	f	-	0	35	1	2012-10-13 10:47:35+02
1803	Tmavomodré slim rifle,vzadu na vreckách flitre	46	5.5	f	-	0	16	2	2012-10-14 10:12:09+02
1776	Chlpatka zelenkava na zips s kapucou s vackami nasita kabelka napis	45	6.5	f	-	0	39	1	2012-10-13 10:48:48+02
1774	Svetrik s kapucou na zips pruhy modre zelene hnede	45	5.2000000000000002	f	-	0	37	1	2012-10-13 10:48:37+02
1777	Svetrik biely na gombiky s limcekom v predu nasite kvietky a motyl	45	5.2000000000000002	f	-	0	40	1	2012-10-13 10:48:56+02
1778	Ruzova mikina na zips s kapucou vel.1,5-2roky s vackami a s kvetmi	45	4	f	-	0	41	1	2012-10-13 10:49:01+02
1779	Mikina ruzova vpredu cislo 9+napis	45	2.1000000000000001	f	-	0	42	1	2012-10-13 10:49:05+02
1819	Šedé pletené šaty,okrúhly výstrih, vrkočový vzor	46	6.5	f	-	0	32	2	2012-10-13 16:20:44+02
1781	Rifle Hello Kitty s opaskom aj s vackami vzadu Hello Kitty	45	7.5	f	-	0	44	1	2012-10-13 10:49:18+02
1782	Ciapocka modra siltik pasikavy uska tiez v predu psik prechodna	45	2	f	-	0	45	1	2012-10-13 10:49:28+02
1784	Pyzamko ruzove s mackom pu a prasiatkom+napis 	45	1.8	f	-	0	47	1	2012-10-13 10:49:32+02
1767	Bunda zimna cherokee modro hneda so psikmi a s opicami na 6-9m.	45	4.7999999999999998	f	-	0	30	2	2012-10-13 18:28:03+02
2823	Oteplovaky  tmavomodré	72	4	f	-	0	11	2	2012-10-13 15:15:37+02
1787	Topanocky bielo hnede na 2suchozipse velkost 19	45	6.7000000000000002	f	-	0	50	1	2012-10-13 10:50:26+02
1783	Botasky Nike ruzova fajka vel.22,5	45	7.2000000000000002	f	-	0	46	1	2012-10-13 10:50:35+02
1799	Šedé slim rifle Next, vzadu guma	46	6	f	-	0	12	2	2012-10-13 15:34:57+02
1788	Ružový ružičkový kožuštek, podšitý ružovým saténom	46	8.5	f	-	0	1	1	2012-10-13 11:56:37+02
1789	Riflový kabátik so stojačikom,v páse zúžený	46	8	f	-	0	2	1	2012-10-13 11:56:40+02
1790	Šedá tepláková mikina s kapucou, na zips	46	4.4000000000000004	f	-	0	3	1	2012-10-13 11:56:44+02
1770	Rifle na gumu s vackami a na zadnych na vacku vlocky	45	4.7999999999999998	f	-	0	33	2	2012-10-13 16:36:44+02
1771	Menzestraky zelene s vackami na snurku zn.Cherokee naite kvety	45	5	f	-	0	34	2	2012-10-13 17:18:28+02
1793	Tmavomodrá menžestrová bunda Next,s kapucou	46	3.7999999999999998	f	-	0	6	1	2012-10-13 11:57:07+02
1794	Ružová kordová bundička, podšitá flísom, kapucňa s kožušinkou	46	5	f	-	0	7	1	2012-10-13 11:57:12+02
1795	Ružová tepláková mikina, okrúhly výstrih, vpredu aplikácie	46	2.2999999999999998	f	-	0	8	1	2012-10-13 11:57:19+02
1796	Bledomodré rifle, vzadu guma, regul.pás,na členku preštepované	46	5.5	f	-	0	9	1	2012-10-13 11:57:23+02
1797	Šedá mäkká mikina s kapucou,ružový zips, dole patent	46	3.2999999999999998	f	-	0	10	1	2012-10-13 11:57:28+02
1798	Hnedé menžestrové podšité nohavice, na ľavej nohe výšivka	46	6	f	-	0	11	1	2012-10-13 11:57:33+02
1780	Zimna ciapka s rukavicami modro hneda s pasikami znacka HaM	45	5	f	-	0	43	2	2012-10-13 16:20:43+02
1800	Tmavohnedé menžestrové nohavice HM,na kolenách srdiečka	46	6	f	-	0	13	1	2012-10-13 11:57:44+02
1801	Tmavomodré slim rifle,na vreckách cvoky	46	5	f	-	0	14	1	2012-10-13 11:57:49+02
1802	Šedé slim rifle Next, vzadu guma, regul.pás	46	5.5	f	-	0	15	1	2012-10-13 11:57:53+02
1804	Béžové nohavice,široká guma v páse+ružová šnúrka	46	4.2999999999999998	f	-	0	17	2	2012-10-14 11:09:27+02
1805	Béžová mikinka s kapucou,podšitá flísom	46	3	f	-	0	18	1	2012-10-13 11:58:14+02
1806	Ružová flísová mikina s kapucou,podšitá hviezd.látkou	46	4	f	-	0	19	1	2012-10-13 11:58:18+02
1807	Bledoružová flísová mikina s kapucou,klokanie vrecko	46	3	f	-	0	20	1	2012-10-13 11:58:22+02
1809	Pásikavá bordovoružová flísová mikina, okrúhly výstrih,písmeno M	46	3.2999999999999998	f	-	0	22	1	2012-10-13 11:58:30+02
1810	Hnedá flísová mikina s kapucou,vpredu našité aplikácie	46	3	f	-	0	23	1	2012-10-13 11:58:33+02
1811	Ružovočervená mikina so stojačikom, vpredu 2 vrecká	46	5.5	f	-	0	24	1	2012-10-13 11:58:46+02
1812	Biela kvetovaná mikina s bodkami,s kapucou, okolo zipsu krajka	46	3	f	-	0	25	1	2012-10-13 11:58:51+02
1813	Fialová zamatová mikina s kapucou na zips, vyšité srdiečko	46	3.5	f	-	0	26	1	2012-10-13 11:58:54+02
1814	Šedý pásikavý predĺžený svetrík s kapucou, v páse šnúrka	46	5	f	-	0	27	1	2012-10-13 11:58:57+02
1815	Červené bolerko na 2 gombíky,okolo krku a naspodu volániky	46	5.5	f	-	0	28	1	2012-10-13 11:59:01+02
1816	Biely svetrík,červený lem,mašličkový dierkovaný úplet	46	5.5	f	-	0	29	1	2012-10-13 11:59:06+02
1817	Bieločervené pásikavé úpletové šaty,námornícky štýl	46	6	f	-	0	30	1	2012-10-13 11:59:08+02
1825	Ružové nohavice, regul.pás, vzadu guma, ozdobný gombík	46	2.6000000000000001	f	-	0	38	2	2012-10-13 18:38:14+02
1823	Hnedé kárované podšité šaty,vpredu mašlička,vyšité kvety	46	5.7000000000000002	f	-	0	36	2	2012-10-13 16:30:23+02
1769	Tricko cervene na 2 gombiky v predu snehuliak	45	2.7000000000000002	f	-	0	32	2	2012-10-13 18:20:14+02
1821	Čierna menžestrová vesta, na 3 gombíky, s fazónkou	46	5	f	-	0	34	1	2012-10-13 11:59:23+02
1822	Čiernočervené kockované šaty,4 červené gombíčky	46	5.2999999999999998	f	-	0	35	1	2012-10-13 11:59:27+02
1791	Ružová teplá bunda s kapucou,na rukáve a kapucni kožušinka	46	6	f	-	0	4	2	2012-10-13 16:34:29+02
1824	Ružová tepláková srdiečková mikina, s kapucou, na zips	46	3.5	f	-	0	37	1	2012-10-13 11:59:36+02
1773	Tricko vzadu na gombik v predu nasite kvety, motyle	45	2.1000000000000001	f	-	0	36	2	2012-10-13 19:19:16+02
1826	Modré rifle, s farebným opaskom, našité záplaty	46	2	f	-	0	39	1	2012-10-13 11:59:44+02
1785	Zimna bunda zelena s vackami,kapuca,vnutro ruzove,nasite kvety 2-3r.	45	10	f	-	0	48	2	2012-10-13 17:31:15+02
1820	Tmavšie kaki šaty Zara,podšité bodkovanou látkou	46	5.2000000000000002	f	-	0	33	2	2012-10-13 18:15:07+02
1885	bunda tmav.modra huňatá,Minoty, vel.:18-24mes.	48	2.5	f	-	0	17	2	2012-10-13 17:49:24+02
1871	topanky tmav.hnede, suchy zips, Bambuliny, vel. 24	48	5	f	-	0	3	1	2012-10-13 09:04:55+02
1833	Tenká ružová bundička, s kapucou, podšitá kvetinkovou látkou	46	3.5	f	-	0	46	2	2012-10-14 10:48:25+02
1873	čiapka+rukavice, modra kravicka, vel. 1 - 2 r.	48	3	f	-	0	5	1	2012-10-13 09:05:16+02
1874	čiapka modra norsky vzor s brnbolcom 1-2 r.	48	1.5	f	-	0	6	1	2012-10-13 09:05:19+02
1875	čiapka čierno-šeda Cherokee 3-5 r.	48	1	f	-	0	7	1	2012-10-13 09:05:21+02
1836	Ružové vyššie zateplené športové čižmičky, na šnurovanie	46	7	f	-	0	49	2	2012-10-13 18:25:05+02
1838	Tmavomodré tepláky po bokoch pásiky, veľ.98, nápis candy girl	47	5.5	f	-	0	1	2	2012-10-13 16:57:10+02
1878	ponožky modro-bielo-oranžové 3ks, (macko, pružok,biele),vel.80-86	48	1	f	-	0	10	1	2012-10-13 09:05:34+02
1859	Bielosmotanové tričko s dlhým rukávom na predu obrázok. Veľ. 86	47	4	f	-	0	22	2	2012-10-14 09:21:26+02
1880	žlta flisova bunda na gombiky, vláčik, vel.24mes.	48	1.5	f	-	0	12	1	2012-10-13 09:05:40+02
1860	Oranžovomodré tričko s dlhým rukávom na predu obrázok, veľ. 86	47	4	f	-	0	23	2	2012-10-14 11:09:27+02
1882	bled. zelena bunda s kapucou, friends vysity, vel.92	48	2	f	-	0	14	1	2012-10-13 09:05:48+02
1883	zeleny svetrík, biely patent, Hip-Hop, vel. 80-86	48	2	f	-	0	15	1	2012-10-13 09:05:51+02
1828	Modrohnedá flísová mikina, so stojačikom, na zips	46	4.5	f	-	0	41	2	2012-10-13 18:06:11+02
1870	topanky hnedo-bezove,snurovanie, JELA TEX, vel.22   	48	5	f	-	0	2	2	2012-10-13 17:49:24+02
1887	komplet flisovy(noh.+mikina)bezovo-bled.zelene, OHMNEM, vel.86	48	3	f	-	0	19	1	2012-10-13 09:06:07+02
1888	bunda s kapucou, bleda kava, kamulino, vel.18 mes.	48	2.5	f	-	0	20	1	2012-10-13 09:06:14+02
1889	župan s kapucou, bled kava, lem onandzovy, dogs adventure, vel.92	48	3	f	-	0	21	1	2012-10-13 09:06:18+02
1834	Hnedé Richter zateplené športové čižmičky,2 suché zipsy,fialové kvety	46	11	f	-	0	47	2	2012-10-13 17:31:15+02
1891	teplaky hnede na traky,aligator , Frog, vel.86-92 	48	1.5	f	-	0	23	1	2012-10-13 09:06:28+02
1830	Čierny pletený rolák,2 vrecká, šedoružový žakárový vzor	46	6.5	f	-	0	43	2	2012-10-13 17:01:33+02
1839	Pásiková mikina s kapucňou na predu vačok, pásiky	47	9.5	f	-	0	2	1	2012-10-13 11:40:51+02
1841	2 ks tepláčkov babuluno, veľ. 62/68	47	7.5	f	-	0	4	1	2012-10-13 11:40:57+02
1842	Kojenecká košeľa ružová na predu s mačičkami, 	47	3.5	f	-	0	5	1	2012-10-13 11:41:03+02
1843	Modrá čiapka so šiltom na uviazanie	47	5	f	-	0	6	1	2012-10-13 11:41:07+02
1844	Biela kojenecká podprsenka veľ. 85/D	47	2	f	-	0	7	1	2012-10-13 11:41:12+02
1845	Červené tepláky po bokoch pásiky, veľ. 92, nápis candy girl	47	5.5	f	-	0	8	1	2012-10-13 11:41:15+02
1846	Ružové tepláky na spodu patent, 2 vačky,na boku malý obr, veľ.116	47	5.5	f	-	0	9	1	2012-10-13 11:41:19+02
1847	Fialové tepláky na spodu patent, 2 vačky na boku malý obr. Veľ. 110	47	5.5	f	-	0	10	1	2012-10-13 11:41:22+02
1848	Biela kojenecká podprsenka veľ. 90/D	47	1.5	f	-	0	11	1	2012-10-13 11:41:25+02
1850	Menžestrová ružová sukňa na spodu volánik so srnčekom, veľ. 110	47	3.5	f	-	0	13	1	2012-10-13 11:41:30+02
1840	Šedé plátenné tenisky na uviazanie i zips, veľ. 21	47	5	f	-	0	3	1	2012-10-13 11:41:38+02
1852	Ponožky Hello Kitty aj ako capačky	47	3	f	-	0	15	1	2012-10-13 11:41:42+02
1853	Hráškovozelná zimná bunda Macko Pooh so šálom, veľ. 18m, nová	47	20	f	-	0	16	1	2012-10-13 11:41:46+02
1855	Modrá vesta Mickey, veľ. 122	47	9	f	-	0	18	1	2012-10-13 11:41:54+02
1849	Biele cvičky, veľ. 29	47	2	f	-	0	12	1	2012-10-13 11:42:00+02
1851	Ružové papučky capačky na uviazanie 	47	1.5	f	-	0	14	1	2012-10-13 11:42:04+02
1854	Zimné fialové čižmy na uviazanie na boku 3 hvizdičky, veľ. 22	47	10	f	-	0	17	1	2012-10-13 11:42:09+02
1856	Zelené pásikové tričko s dlhým rukávom na predu obrázok, veľ. 80	47	4	f	-	0	19	1	2012-10-13 11:42:14+02
1857	Modré pásikové tričko na predu s obrázkom tirák, veľ. 80	47	4	f	-	0	20	1	2012-10-13 11:42:18+02
1858	Ponožky Spiderman, veľ. 23-26	47	1.2	f	-	0	21	1	2012-10-13 11:42:22+02
1872	čiapka+rukavice, zelena zabka, vel. 1 - 3 r.	48	3	f	-	0	4	2	2012-10-14 09:21:26+02
1861	Fialová mikina s kapucňou s nápisom star popular, veľ. 104	47	8	f	-	0	24	1	2012-10-13 11:42:46+02
1879	rolák tm.modry,opica stars, vel.80-86	48	1	f	-	0	11	2	2012-10-14 09:21:26+02
1864	Bieloružové pásikové tričko s 2 gombíkmi, veľ. 52	47	3.7999999999999998	f	-	0	27	1	2012-10-13 11:43:41+02
1865	Fialová pásikavá čiapka so šiltom veľ. 51-52, značka rada	47	6	f	-	0	28	1	2012-10-13 11:43:54+02
1866	Žlté dupačky so žirafou, veľ. 74	47	5.5	f	-	0	29	1	2012-10-13 11:43:58+02
1867	Modrá kojenecká súprava na predu autičko, dupačky + kabátik, veľ. 62	47	7	f	-	0	30	1	2012-10-13 11:44:03+02
1868	Kabátik na gombíky s kapucňou, značka CHERROKE, 2 vačky	47	2.7999999999999998	f	-	0	31	1	2012-10-13 11:44:09+02
1876	pančušky 2ks, zelene (myska,pružok), biele (hrošíkove) vel.86-92	48	1.5	f	-	0	8	2	2012-10-13 18:15:07+02
1829	Kaki sukňa,vzadu guma,pútka, vyšité kvety	46	4	f	-	0	42	1	2012-10-13 11:59:56+02
1890	overal na spanie 2ks, bled.zeleny,pružok hnedy,Disney, vel.12-18mes.	48	3	f	-	0	22	2	2012-10-13 17:08:51+02
1831	Ružovobiela tenká pásikavá mikina s kapucou, 3 srdiečkové gombíky	46	4	f	-	0	44	1	2012-10-13 12:00:11+02
1832	Modrobiela flísová pásikavá mikina s kapucou, vpredu našitý zajko	46	4.5	f	-	0	45	1	2012-10-13 12:00:16+02
1881	bled.modra bunda šuštiak.,rukav latkovy,ALLY sport, vel.92	48	2	f	-	0	13	2	2012-10-14 11:00:00+02
1886	kabatik hnedy s kapucou, power kids, vel.92-98 2-3 roky	48	6	f	-	0	18	2	2012-10-13 17:40:33+02
1862	Bordová mikina s kapucňou na spodu i rukávoch patent, veľ. 104	47	7.5	f	-	0	25	2	2012-10-13 18:38:14+02
1837	Čierne vyššie čižmy, z vnút. strany zips, 2 ozdobné pracky	46	9	f	-	0	50	1	2012-10-13 12:01:16+02
1877	pančušky krem.blede s lietadielkom vel.80-86	48	0.69999999999999996	f	-	0	9	2	2012-10-13 16:03:35+02
1929	Pyzamo hnede s oveckou velk.128	50	2	f	-	0	13	2	2012-10-13 19:27:00+02
1920	Pruzkove fialove tricko velk.122-128	50	2	f	-	0	4	2	2012-10-13 15:17:55+02
1895	rifle modre, basketboy, vel.86	48	2	f	-	0	27	1	2012-10-13 09:06:36+02
1896	nohavice menžestrove,hnede podsite, na kolene nasivky1,2,3, vel.128;	48	3	f	-	0	28	1	2012-10-13 09:06:38+02
1897	overal flisovy bled.kava+ čiapka, vysity 2 zajkovia, vel. 6mes.	48	3	f	-	0	29	1	2012-10-13 09:06:51+02
1898	overal s kapucou+ciapka+sal, bled.kava, vel. 9 mes. 	48	7	f	-	0	30	1	2012-10-13 09:06:53+02
1900	bunda s kapucou, flisova šedá, modre vrecka, DIVISION, vel.86 	48	1.5	f	-	0	32	1	2012-10-13 09:07:05+02
1946	trigovica zelená - našivka topánka	51	2	f	-	0	1	1	2012-10-13 09:14:43+02
1956	vesta bledomodrá	51	2	f	-	0	11	1	2012-10-13 09:14:49+02
1947	menžestrové nohavice slabo modré	51	1.5	f	-	0	2	1	2012-10-13 09:14:55+02
1948	menžestrové nohavice hnedé	51	1.5	f	-	0	3	1	2012-10-13 09:14:59+02
1958	bunda fialová s našivkou G	51	1	f	-	0	13	1	2012-10-13 09:15:03+02
1937	Modry rolak s oranzovym na pleci velk.128	50	2	f	-	0	21	2	2012-10-14 11:06:18+02
1962	rifle modré	51	2.5	f	-	0	17	1	2012-10-13 09:15:11+02
1963	rifle na traky modré	51	3	f	-	0	18	1	2012-10-13 09:15:17+02
1964	tepláky tmavo zelené	51	0.5	f	-	0	19	1	2012-10-13 09:15:21+02
1949	košela - hnedý pásik	51	1	f	-	0	4	1	2012-10-13 09:15:31+02
1951	menžesrové nohavice na traky - hnedé	51	2	f	-	0	6	1	2012-10-13 09:15:34+02
1952	punčochové nohavice šedé	51	1.5	f	-	0	7	1	2012-10-13 09:15:39+02
1953	nohavice slabo modré vzorka	51	1.5	f	-	0	8	1	2012-10-13 09:15:46+02
1944	Prechodne topanky cierno hnedo bezove velk.35	50	4	f	-	0	28	2	2012-10-13 18:23:18+02
1955	tepláky šedé - na boku červený pásik	51	1.5	f	-	0	10	1	2012-10-13 09:15:54+02
1957	bunda z nohavicami modrá	51	3	f	-	0	12	1	2012-10-13 09:16:25+02
1934	Seda zimna bundicka velk.134	50	7	f	-	0	18	2	2012-10-13 18:31:21+02
1965	punčochové nohavice zelenohnede 	51	0.5	f	-	0	20	1	2012-10-13 09:16:35+02
1959	Šušťáková bunda oranžová	51	2	f	-	0	14	1	2012-10-13 09:17:15+02
1961	tepláky modré	51	0.5	f	-	0	16	1	2012-10-13 09:17:20+02
1903	Chlap. Zimná bunda hnedo-zelená, károvaná,zn.GEORGE, v. 6-9m	49	5	f	-	0	3	1	2012-10-13 09:24:31+02
1904	Chlap.Zimná bunda tmavo modrá s traktorom, CHEROKEE, v. 3-6m	49	3	f	-	0	4	1	2012-10-13 09:24:33+02
1905	Chlap.Zimná bunda bledo modrá, CHEROKEE v. 0-3m	49	3	f	-	0	5	1	2012-10-13 09:24:39+02
1906	Chlap.Flysová zateplená  súprava, šedo -modrá , v. 68	49	5	f	-	0	6	1	2012-10-13 09:24:42+02
1907	Chlap.Sveter biely s modrým pružkom v. 56	49	2	f	-	0	7	1	2012-10-13 09:24:48+02
1908	Chlap.Tepláková súprava šedo- modrá so psíkom na teplákoch	49	4	f	-	0	8	1	2012-10-13 09:24:51+02
1909	Chlap.tepláky na traky modro-šedé so zajkom, HAPPY, v.68	49	3	f	-	0	9	1	2012-10-13 09:24:59+02
1910	Chalp.tepláky tavo modré F&F v. 6-9m	49	1	f	-	0	10	1	2012-10-13 09:25:03+02
1911	Chlap.rifle čierne NEXT v. 6-9m	49	2	f	-	0	11	1	2012-10-13 09:25:07+02
1912	Chlap.menžestrové nohavice modré, HAPPY	49	1	f	-	0	12	1	2012-10-13 09:25:12+02
1915	Zateplené nohavice tmavo šedé, vrecká štepované červeným, Cherokee	49	3	f	-	0	15	1	2012-10-13 09:25:16+02
1916	Chlap.tepláková súprava modro-bielo-zelená, YATSI, v. 0-3m	49	2	f	-	0	16	1	2012-10-13 09:25:20+02
1913	Chlap. Čiapka modrá s hrochom	49	1.5	f	-	0	13	1	2012-10-13 09:25:27+02
1914	Chlap.čiapka hnedá prúžková so psíkom, PUPILL	49	1.5	f	-	0	14	1	2012-10-13 09:25:29+02
1935	Modra zumna bunda velk.128	50	2	f	-	0	19	1	2012-10-13 11:40:23+02
1940	Cierne teplaky so zelenym velk.140	50	2	f	-	0	24	2	2012-10-13 15:07:45+02
1936	Cervena trigovica velk.146	50	2	f	-	0	20	2	2012-10-13 15:13:06+02
1893	teplaky modre, cerveno-biela nasivka, Wence, vel. 86	48	1	f	-	0	25	2	2012-10-13 18:36:12+02
1938	Hneda polokosela s bledym rukavom velk.134	50	2.5	f	-	0	22	1	2012-10-13 11:40:53+02
1932	Pancuchy filove karo,ruzove motylik,hnede kitty,cervene velk.128	50	3.8999999999999999	f	-	0	16	2	2012-10-14 11:59:29+02
1894	teplaky tmav.sede, dva biele pruzky,cherokee, vel. 18-24mes.	48	1	f	-	0	26	2	2012-10-13 15:15:37+02
1950	nohavice tmavo zelené	51	2	f	-	0	5	2	2012-10-13 18:25:49+02
1942	Zimne topanky hnedo cierne velk.34	50	6	f	-	0	26	1	2012-10-13 11:41:15+02
1943	Zimne topanky tmavo modre velk.34	50	3	f	-	0	27	1	2012-10-13 11:41:18+02
1941	Sede teplaky s cervenym pasikom velk.140	50	2	f	-	0	25	2	2012-10-13 15:07:45+02
1922	Teplaky ruzove s macickou velk.134	50	3	f	-	0	6	2	2012-10-13 18:14:07+02
1917	Mikina hneda s kapucnou a kozusinkou.Vpredu vysivana velk.122-128	50	6	f	-	0	1	2	2012-10-13 17:09:37+02
1928	Leginy lienkove velk.128	50	2	f	-	0	12	2	2012-10-13 15:28:42+02
1921	Bezova trigovica velk.134	50	3.5	f	-	0	5	1	2012-10-13 11:42:19+02
1954	čiapka bledomodrá	51	1.5	f	-	0	9	2	2012-10-13 18:14:07+02
1930	Pyzamo bezove pirati s karibiku velk.128	50	2	f	-	0	14	2	2012-10-14 09:37:16+02
1924	Teplaky fialove vel.134	50	3	f	-	0	8	1	2012-10-13 11:42:36+02
1960	punčochové nohavice modré	51	1	f	-	0	15	2	2012-10-14 11:00:00+02
1918	Sty modre s vysivkou upletove velk.122-128	50	5	f	-	0	2	2	2012-10-14 13:55:41+02
1927	Adidas ciapka bledo ruzova velk.128	50	2	f	-	0	11	2	2012-10-13 15:49:21+02
1923	Teplaky staro ruzove velk.134	50	2.5	f	-	0	7	2	2012-10-13 19:27:00+02
1931	Pancuchy sede,fialove, bledo fialove,sede s pruzkom velk.128	50	3.5	f	-	0	15	2	2012-10-14 10:09:32+02
1925	Ruzove podsite nohavice velk.134	50	5	f	-	0	9	2	2012-10-14 10:38:24+02
1926	Fialova ciapka hello kitty s rukavicami velk.122-128	50	5.7999999999999998	f	-	0	10	2	2012-10-14 12:15:24+02
1933	 Hnedy kozustek velk128	50	5	f	-	0	17	1	2012-10-13 11:44:33+02
1939	Modra mikina velk.140	50	3	f	-	0	23	2	2012-10-13 18:33:44+02
1919	Saty cervene s kittynou velk.122-128	50	5	f	-	0	3	2	2012-10-13 16:06:44+02
1945	Cierne polropanky velk.36	50	5	f	-	0	29	2	2012-10-13 14:46:08+02
2026	bunda Beneton čierna zimná city soul napis na chrbte vel 122/128chlap	53	15	f	-	0	1	0	2012-10-11 20:59:21+02
2027	vesta zimna bordo s kapucnou zara vel 122 vnutri hnedá podšivka	53	6	f	-	0	2	0	2012-10-11 20:59:21+02
2028	nohavice lyžiarske nord blanc čierne  na traky 122/128 chlapčeneske	53	11	f	-	0	3	0	2012-10-11 20:59:21+02
2029	nohavice lyžiarske šedé bez trakov 122	53	2	f	-	0	4	0	2012-10-11 20:59:21+02
2030	rifle chlapč.tmavo modre oz.DGNS DENIM vel12/13rokov	53	3	f	-	0	5	0	2012-10-11 20:59:21+02
2031	trigovica šeda chlapč. New york červene nápisy vel.9-10rokov	53	2	f	-	0	6	0	2012-10-11 20:59:21+02
2032	umbro mikina tmav.modra s kapucňou vel146 chlapč.	53	4	f	-	0	7	0	2012-10-11 20:59:21+02
2033	reporter mikina tm.hnedá+modre.napis s kapucnou vel.128	53	2.2000000000000002	f	-	0	8	0	2012-10-11 20:59:21+02
2012	Čiapka dievč.,žltá,vpredu kačiatko,na zaväzovanie	52	0.5	f	-	0	28	2	2012-10-13 18:50:04+02
2021	Pančuchy 4ks v balení (hnedé,biele,fialové,ružové)veľ.18-24mes.	52	2	f	-	0	37	1	2012-10-14 09:39:48+02
1974	košela ako tričko s dlhým rukávom hnedé	51	1.5	f	-	0	29	2	2012-10-13 17:10:51+02
1999	Nohavice na traky chlapč.,zelené,vpredu vačok s opičkou	52	2	f	-	0	15	2	2012-10-13 17:54:20+02
1972	sveter štrikovaný modrý	51	1	f	-	0	27	1	2012-10-13 09:15:26+02
2009	Body s dlhým rukávom dievč.,ružové,vpredu myška,veľ.12-18mes.,FaF	52	1	f	-	0	25	2	2012-10-13 18:31:20+02
1975	košela modrá pásiková	51	1	f	-	0	30	1	2012-10-13 09:16:06+02
1976	košela svetlá - pásiky ćerveny zelený hnedý	51	1	f	-	0	31	1	2012-10-13 09:16:09+02
2018	Rukavičky bledomodré	52	0.5	f	-	0	34	2	2012-10-13 17:17:43+02
1971	rifle modré na gumičku	51	1.5	f	-	0	26	1	2012-10-13 09:16:39+02
1977	menžestrové nohavice slabo modré	51	1.5	f	-	0	32	1	2012-10-13 09:16:45+02
1978	bledohnedé nohavice 	51	2	f	-	0	33	1	2012-10-13 09:16:50+02
2013	Čiapka dievč.,ružovo-tyrkysová pásiková,na zaväzov.,veľ.46/48,LINDEX	52	1	f	-	0	29	2	2012-10-13 15:11:38+02
1969	košela modrá pásiková	51	1	f	-	0	24	1	2012-10-13 09:17:04+02
1970	trigovica modrá s kapucou 	51	1.5	f	-	0	25	1	2012-10-13 09:17:09+02
1966	menžestrové nohavice tmavošedé	51	2.5	f	-	0	21	1	2012-10-13 09:17:24+02
1996	Bunda dievč.,rifľová s kapucou na zips,patenty na rukáv.,veľ.12-18mes.	52	3	f	-	0	12	1	2012-10-13 11:26:17+02
1997	Vesta dievč.,bledoružová s kapucou na zips,vpredu snehuliaci	52	2.5	f	-	0	13	1	2012-10-13 11:26:21+02
2000	Nohavice na traky chlapč.,bledomodré,veľ.80,CaA	52	1.5	f	-	0	16	1	2012-10-13 11:26:27+02
1973	tričko s dlhým rukávom červené - vzor 03	51	1.5	f	-	0	28	2	2012-10-13 18:01:27+02
1998	Vestička biela s kapucou na zips,flisová	52	1	f	-	0	14	1	2012-10-13 11:26:34+02
2020	Pančuchy 4ks v balení (ružové,fialové,biele,červené)veľ.18-24mes.	52	2	f	-	0	36	2	2012-10-13 14:46:07+02
2003	Rifle dievč.,veľ.12-18mes.,NEXT	52	1.8	f	-	0	19	1	2012-10-13 11:27:08+02
2015	Čiapka chlapč.,tm.zeleno-hnedá,navrchu brmbolec	52	0.5	f	-	0	31	2	2012-10-13 16:36:03+02
2010	Čiapka dievč.,fialová,veľ.0-3mes.,vpredu sova,CHEROKEE	52	0.5	f	-	0	26	2	2012-10-13 19:11:27+02
1991	Triga dievč.,bledoružová,s kapucou na zips,veľ.12-18mes.,ADIDAS	52	2	f	-	0	7	2	2012-10-14 12:50:36+02
1980	žlté rogery č.26	51	2.5	f	-	0	35	2	2012-10-13 17:07:06+02
2004	Zateplené dievč. Nohavice,hnedé,veľ.86,OKAY	52	2	f	-	0	20	2	2012-10-13 14:46:07+02
1992	Triga dievč.,fialová,veľ.18-24mes.	52	1.5	f	-	0	8	1	2012-10-13 11:27:41+02
1990	Triga dievč.,tyrkysová,vpredu zajko,s kapucou,na zips,veľ.18-24mes.	52	2	f	-	0	6	1	2012-10-13 11:27:53+02
2022	Pyžamo dievč.,bielo-vínovočervené,vpredu MINIE,veľ.86/92, DISNEY	52	2	f	-	0	38	2	2012-10-13 16:08:53+02
2024	Tenisky jesenné dievč.,ružové na šnorovanie,veľ.24,FaF	52	2.5	f	-	0	40	1	2012-10-13 11:28:05+02
2017	Čiapka+rukavice,chlapč.,modro.zelené	52	1	f	-	0	33	2	2012-10-13 15:44:00+02
2002	Rifle dievč.,vpredu lístky,veľ.18-24mes.,CHEROKEE	52	2	f	-	0	18	2	2012-10-13 16:08:53+02
1993	Triga dievč.,ružová,na zips,veľ.86,LINDEX	52	2	f	-	0	9	2	2012-10-13 14:46:07+02
1983	čižmy bielo čierne	51	1	f	-	0	38	2	2012-10-13 18:42:27+02
1987	Bunda chlapč.,tm.šedá na gombíky s kapucou,veľ.92,CaA	52	5.5	f	-	0	3	1	2012-10-13 11:28:50+02
1988	Bunda dievč.,žltá na cvoky s kapucou,veľ.86,NEXT	52	2.6000000000000001	f	-	0	4	1	2012-10-13 11:28:51+02
1995	Svetrík dievč.,ružový,s kapucou,3 gombíky vpredu,veľ.86,CHEROKEE	52	1.2	f	-	0	11	2	2012-10-14 11:31:31+02
1994	Triga dievč.,biela,vpredu ružové myšky,s kapucou,veľ.68,OKAY	52	1.8	f	-	0	10	2	2012-10-13 17:03:24+02
1989	Triga chlapč.,zelená,vpredu nápis:RASCAL,s kapuc.,veľ.98,CHEROKEE	52	2	f	-	0	5	2	2012-10-13 16:02:29+02
2006	Tepláky dievč.,vínovočervené,veľ.68,OKAY	52	0.5	f	-	0	22	1	2012-10-13 11:29:48+02
1981	topánky tmavo šedé na suchý zips	51	2.5	f	-	0	36	2	2012-10-13 19:19:16+02
2008	Legíny tyrkysové (hrubšie),veľ.86/92,LINDEX	52	1.2	f	-	0	24	1	2012-10-13 11:30:04+02
2023	Čižmičky dievč.,tm.šedé,naboku zips,veľ.23,SKIPPY	52	4	f	-	0	39	2	2012-10-13 15:42:31+02
1967	menžestrové nohavice tmavohnedé	51	2.5	f	-	0	22	2	2012-10-13 14:46:08+02
2011	Čiapka dievč.,bledoruž.,vpredu "tvár s uškami",veľ.0-3mes.,CHEROKEE	52	0.5	f	-	0	27	1	2012-10-13 11:30:14+02
2001	Rifle dievč.,vpredu kvetinky a motýliky,veľ.1-1/2roka,GEORGE	52	2	f	-	0	17	2	2012-10-13 18:55:46+02
2007	Sada legíny+svetrík,šedo-ružové,veľ.86/92,LUPILU	52	3	f	-	0	23	2	2012-10-13 15:34:56+02
2014	Čiapka oranžová	52	0.5	f	-	0	30	1	2012-10-13 11:30:25+02
1985	Overal zelený na zips,vpredu macko v autíčku,NOVÝ	52	10	f	-	0	1	2	2012-10-13 17:01:44+02
2016	Čiapka+rukavice chlapč.,zeleno-biele,na zaväzovanie,HaM	52	1	f	-	0	32	1	2012-10-13 11:30:37+02
1982	tenisky adidas - modrý vzor	51	3	f	-	0	37	2	2012-10-13 17:49:24+02
1986	Overal bledomodrý na cvoky,vpredu havkovia,veľ.56	52	2.5	f	-	0	2	1	2012-10-13 11:30:53+02
2005	Sada dievč. teplákov 3ks (2xčervené,1xbiele) 	52	2	f	-	0	21	2	2012-10-13 14:46:07+02
2034	beneton mikina hroch obrazok tmavo  modra vel.122	53	2.2000000000000002	f	-	0	9	0	2012-10-11 20:59:21+02
2035	hm mikina bledo modra kapucna grade good napis vel.122/128	53	2.2000000000000002	f	-	0	10	0	2012-10-11 20:59:21+02
2036	mikina original marines čierna sive rukávy čer.nápis vel.6rokov	53	3.2999999999999998	f	-	0	11	0	2012-10-11 20:59:21+02
2037	svetrik hm loog doyers1901 nápis modro hnede káro vel.122	53	2.2000000000000002	f	-	0	12	0	2012-10-11 20:59:21+02
2038	svetrík výstrih v ružovo hnedé káro chlapčenský vel.122	53	2.2000000000000002	f	-	0	13	0	2012-10-11 20:59:21+02
2039	mikina loog modo biely pruh 48 nápis červený kapucňa vel.122	53	2.2000000000000002	f	-	0	14	0	2012-10-11 20:59:21+02
2040	mikina čislo 68 šedá biele káro kapucňa chlapčenská vel.122	53	2.2000000000000002	f	-	0	15	0	2012-10-11 20:59:21+02
2041	tepláky čierne lindex modré pruhy po stranách chlapč.vel.122/128	53	2.2000000000000002	f	-	0	16	0	2012-10-11 20:59:22+02
2042	čiapka hnedá zimná číslo 87 obojstranná chlapčenská	53	1.1000000000000001	f	-	0	17	0	2012-10-11 20:59:22+02
2043	čiapka zelená pletenná osmičková hnedý znak v predu BOY 1963	53	2.2000000000000002	f	-	0	18	0	2012-10-11 20:59:22+02
2044	Čiapka loog hnedá hnedá zimná v predu nášivka biela loog	53	1.1000000000000001	f	-	0	19	0	2012-10-11 20:59:22+02
2045	košela hm loog modro zelené káro s kapucňou chlapč.vel.128/134	53	2.2000000000000002	f	-	0	20	0	2012-10-11 20:59:22+02
2046	bunda Beneton zeleno šedá obojstranná 65 číslo RUGBY 1993 nápis	53	3.5	f	-	0	21	0	2012-10-11 20:59:22+02
2047	bunda Zara koža chlapčenská čierna vel.5-6 rokov 118cm s patentmi	53	12	f	-	0	22	0	2012-10-11 20:59:22+02
2048	bunda Zara šedá zimná 118cm chlapč.jemné šedé káro čislo v predu	53	3.2999999999999998	f	-	0	23	0	2012-10-11 20:59:22+02
2049	nohavice zateplené chlapčenské šedé zara na stiahnutie vel.134/140	53	5	f	-	0	24	0	2012-10-11 20:59:22+02
2050	adidas mikina s kap.tmavomo modrá bled.mod.pruhy vel.128	53	3.2999999999999998	f	-	0	25	0	2012-10-11 20:59:22+02
2051	sveter červený chlapč.znak v predu 1952 vel.122 uckovy výstrih	53	2.2000000000000002	f	-	0	26	0	2012-10-11 20:59:22+02
2052	mikina nike červná biele káro s kap.nap.JUST DO IT vel.122	53	3.2999999999999998	f	-	0	27	0	2012-10-11 20:59:22+02
2053	rifle chlapč.tmavo modré zeteplené hnedy npis.na vacku vel.122/128	53	2.2000000000000002	f	-	0	28	0	2012-10-11 20:59:22+02
2054	mikina zeteple.čierna biely v znak v predu na zips 1975 vel.122	53	2.2000000000000002	f	-	0	29	0	2012-10-11 20:59:22+02
2055	čiapka zimná šiltovka s naušníkmi a cvokmi na 6rokov	53	1.1000000000000001	f	-	0	30	0	2012-10-11 20:59:22+02
2056	bunda loop šedá chlapč.červene pruhy na rukavoch vel.122 zimná	53	2.1000000000000001	f	-	0	31	0	2012-10-11 20:59:22+02
2057	mikina tmav.modrá s kapucňou BAD BOY zips vel.8/134 biel.nap.	53	2.2000000000000002	f	-	0	32	0	2012-10-11 20:59:22+02
2059	flisová trigovica biela Hello Kitty,veľ.80,H&M	54	6	f	-	0	2	1	2012-10-13 09:50:55+02
2090	rukavičky šuštiakové ružové s modrou vločkou	54	2.5	f	-	0	33	2	2012-10-13 18:19:20+02
2061	svetrík do V ružový,veľ.9-12m,cherokee	54	2	f	-	0	4	1	2012-10-13 09:51:07+02
2062	svetrík ružový s krt.rukávom na 3gombíčky,veľ.6-9m	54	4	f	-	0	5	1	2012-10-13 09:51:14+02
2081	čiapka ružová ADIDAS	54	7	f	-	0	24	2	2012-10-14 11:08:28+02
2065	svetrík prúžkový na gombíky,veľ.6/12m,pitter patter	54	4	f	-	0	8	1	2012-10-13 09:51:29+02
2066	2ks rolák,bordový s kvietkami,biely.veľ.86/92,lupilu	54	4	f	-	0	9	1	2012-10-13 09:51:34+02
2067	svetrík rolákový s krt.rukávom s vyšitou kvetinkou hnedý,veľ.12-18m	54	3.5	f	-	0	10	1	2012-10-13 09:51:42+02
2068	rolák zelený zo zajacom	54	2.5	f	-	0	11	1	2012-10-13 09:51:50+02
2069	rolák červený Hello Kitty,veľ.74, C&A	54	2	f	-	0	12	1	2012-10-13 09:51:55+02
2070	tepláková súprava zelená semišová,trigovica+tepláky,veľ.18m	54	7	f	-	0	13	1	2012-10-13 09:51:59+02
2071	šuštiaková súprava NIKE,nohavice čierne+bunda čierno-ružová,veľ.86	54	15	f	-	0	14	1	2012-10-13 09:52:03+02
2072	šaty šedé s guličkami bielimi + svetrík s limčekom,veľ.86,zara	54	10	f	-	0	15	1	2012-10-13 09:52:19+02
2073	rifle so záplatami,veľ.13-18m,bonprix	54	9	f	-	0	16	1	2012-10-13 09:52:21+02
2074	menčestrové nohavice ružové na traky veľ.14m	54	7	f	-	0	17	1	2012-10-13 09:52:24+02
2075	menčestrové nohavice zelené s ružičkou veľ.82,zara	54	6	f	-	0	18	1	2012-10-13 09:52:29+02
2076	rifle podšité,veľ.12-18m, cherokee	54	4.5	f	-	0	19	1	2012-10-13 09:52:34+02
2077	nohavice krémové s opaskom kvietkovým podšité,veľ,9-12m,dopomini	54	5	f	-	0	20	1	2012-10-13 09:52:39+02
2078	nohavice šedé podšité,veľ.68,Kik	54	4.5	f	-	0	21	1	2012-10-13 09:52:42+02
2093	kožuch ružový+rukavičky,veľ.0-3m,cherokee	54	11	f	-	0	36	1	2012-10-13 09:52:58+02
2096	kabátik tenší šedý s čiernou ružou na 3gombíky,veľ.86,zara	54	9	f	-	0	39	2	2012-10-13 16:34:06+02
2095	nohavice oteplovačky ružové s papučkami na topánky,veľ.18m	54	5	f	-	0	38	1	2012-10-13 09:53:09+02
2060	flisová trigovica s kapucou s 2psíkmi,veľ.12/18m,minoti	54	3.5	f	-	0	3	2	2012-10-13 18:03:40+02
2097	vesta bordová,veľ.1/1,2 roka,cherokee	54	5	f	-	0	40	1	2012-10-13 09:53:16+02
2098	bunda fialová+oteplovačky na traky-súprava,veľ.6m	54	13	f	-	0	41	1	2012-10-13 09:53:23+02
2086	čiapka flisová ružová s uškami	54	2.5	f	-	0	29	1	2012-10-13 09:54:31+02
2063	tričko oranžové v strede s kvetinkou,veľ.80,C&A	54	3.5	f	-	0	6	2	2012-10-14 10:08:54+02
2091	čiapka štrikavaná biela s kvatinkou+šál biely	54	4.5	f	-	0	34	1	2012-10-13 09:54:39+02
2083	čiapka melírová fialová štrikovaná+rukavičky	54	4.5	f	-	0	26	1	2012-10-13 09:54:46+02
2080	čiapka červená so srnkou+šál so srnkou	54	4	f	-	0	23	1	2012-10-13 09:54:50+02
2087	čiapka flisová bledo ružová s mackom	54	2	f	-	0	30	2	2012-10-13 18:41:41+02
2085	čiapka-baranica ružová	54	3	f	-	0	28	1	2012-10-13 09:54:59+02
2092	ruakvičky ružové štrikované	54	2	f	-	0	35	1	2012-10-13 09:55:03+02
2079	rukavičky biele štrikované	54	2	f	-	0	22	1	2012-10-13 09:55:09+02
2084	čiapka biela s farebnými pruhmi štrikovaná podšitá flisom	54	3	f	-	0	27	1	2012-10-13 09:55:13+02
2082	čiapka bordová štrikovaná podšitá flisom	54	3.5	f	-	0	25	1	2012-10-13 09:55:16+02
2089	čiapka biela flisová s mackom	54	2	f	-	0	32	1	2012-10-13 09:55:22+02
2088	čiapka zimná tmavoružová so srdiečkom štrikovaná podšitá flisom	54	3	f	-	0	31	2	2012-10-13 18:20:14+02
2106	zimné topánky na 2lepačky cervené so srnkou,veľ.22	54	10	f	-	0	49	2	2012-10-13 16:39:57+02
2102	čižmy hanculky štrikované krémové,veľ.21	54	7	f	-	0	45	2	2012-10-13 16:57:10+02
2170	ružová mikina Coccodrillo č. 74 s kapucou	56	2	f	-	0	21	2	2012-10-13 17:06:36+02
2104	čižmy fialové na boku na zips,veľ.22	54	7	f	-	0	47	1	2012-10-13 09:55:52+02
2161	hnedý plet. Svetrík MarksSpencer 3-6 m.	56	2.5	f	-	0	12	2	2012-10-13 16:43:26+02
2169	čierna prechodná bunda HarleyDavidson č. 104 /oranžové výšivky/	56	15	f	-	0	20	2	2012-10-14 11:28:57+02
2107	poltopánky ružové na lepačku,veľ.21	54	4	f	-	0	50	1	2012-10-13 09:56:25+02
2134	rifle modré, na traky, s farebnými gombíkami, veľ. 80	55	1.5	f	-	0	27	1	2012-10-13 10:02:45+02
2133	rifle modré, veľ.2-3roky	55	4	f	-	0	26	1	2012-10-13 10:02:49+02
2132	menžetráky oteplené modré, veľ. 3-4roky	55	4	f	-	0	25	1	2012-10-13 10:02:52+02
2131	rifle bledomodré, nápis NARA, veľ. 3roky	55	1	f	-	0	24	1	2012-10-13 10:02:55+02
2130	menžestráky hnedé, veľ.2roky	55	1	f	-	0	23	1	2012-10-13 10:02:57+02
2129	menžestráky tmavomodré, veľ. 3roky	55	1	f	-	0	22	1	2012-10-13 10:02:59+02
2128	rifle čierne, veľ. 104	55	2	f	-	0	21	1	2012-10-13 10:03:02+02
2139	overal, šedo/oranžový, veľ. 110	55	9.5	f	-	0	32	2	2012-10-13 18:18:10+02
2114	mikina šedá s kocúrom, veľ.3roky	55	1	f	-	0	7	1	2012-10-13 10:03:19+02
2113	mikins bledozelená s lietadlom, veľ.116	55	4	f	-	0	6	1	2012-10-13 10:03:21+02
2138	pulóver štrikovaný, biely	55	2	f	-	0	31	1	2012-10-13 10:04:39+02
2112	mikina šedo/modro/béžová so zvieratkami, veľ. 3roky	55	4	f	-	0	5	1	2012-10-13 10:04:32+02
2137	pulóver štrikovaný, fialový	55	2	f	-	0	30	1	2012-10-13 10:04:43+02
2136	mikina modrá, veľ. 98	55	2.5	f	-	0	29	1	2012-10-13 10:04:47+02
2135	mikina šedá, veľ. 92	55	2.5	f	-	0	28	1	2012-10-13 10:04:50+02
2122	bundička, modrá na zips, nápis Baby Logg, veľ. 80	55	3	f	-	0	15	1	2012-10-13 10:04:56+02
2121	mikina tmavomodrá, nápis Prince, veľ. 2roky	55	1	f	-	0	14	1	2012-10-13 10:04:58+02
2120	tričko, tvamomodré, šedý prúžok, veľ. 122/128	55	2.5	f	-	0	13	1	2012-10-13 10:05:01+02
2119	mikina modrá, nápis BOY, veľ. 86/92	55	2	f	-	0	12	1	2012-10-13 10:05:04+02
2109	zimné topánky, koža bežovo/modré, veľ.20	55	7	f	-	0	2	2	2012-10-14 11:00:00+02
2126	tepláky tmavomodré, červený prúžok, 3roky	55	1.5	f	-	0	19	1	2012-10-13 10:05:19+02
2125	mikina modrá s kapucňou, nápis CANDIDO, veľ. 4roky	55	2.5	f	-	0	18	1	2012-10-13 10:05:25+02
2124	nohavice menžestrové, bledozelené na traky, veľ. 2roky	55	2	f	-	0	17	1	2012-10-13 10:05:27+02
2123	košielka flanelová, károvaná, zelená veľ. 1,5 roka	55	1	f	-	0	16	1	2012-10-13 10:05:30+02
2118	tričko bledozelené s hviezdičkou, veľ. 2-3 roky	55	1.5	f	-	0	11	1	2012-10-13 10:05:35+02
2117	tričko tmavozelené, veľ. 2-3roky	55	1	f	-	0	10	1	2012-10-13 10:05:37+02
2116	tričko hnedé, nápis 62, veľ. 2-3roky	55	1	f	-	0	9	1	2012-10-13 10:05:41+02
2149	pomožky protišmykové, fialové	55	1	f	-	0	42	1	2012-10-13 10:05:54+02
2148	čapica ružová s prasiatkom PIGLET	55	1	f	-	0	41	1	2012-10-13 10:05:57+02
2147	čapica maslová, s lietadielkom	55	1	f	-	0	40	1	2012-10-13 10:06:01+02
2146	čapica hnedá, nápis IMTD	55	1	f	-	0	39	1	2012-10-13 10:06:04+02
2103	tenisky čierne ferrari,veľ.23	54	12	f	-	0	46	2	2012-10-14 11:16:20+02
2143	čapica bledomodrá s 2 grngoľcami	55	1	f	-	0	36	1	2012-10-13 10:06:11+02
2142	čapica bledomodrá s 2 grngoľcami	55	1	f	-	0	35	1	2012-10-13 10:06:15+02
2141	čapica červená	55	1	f	-	0	34	1	2012-10-13 10:06:20+02
2140	čapica červená	55	1	f	-	0	33	1	2012-10-13 10:06:21+02
2110	snehule tmavomodré, Holman, veľ. 26	55	4	f	-	0	3	2	2012-10-13 18:45:21+02
2111	čižmy s kožušinou, modro,zelené, veľ.28	55	9	f	-	0	4	1	2012-10-13 10:06:38+02
2108	zimné topánky, šedé, na šnorovanie, veľ. 21	55	7	f	-	0	1	1	2012-10-13 10:06:45+02
2164	zelená bavln. Súprava /mikina+káro nohavice/ so žirafou č. 86	56	7	f	-	0	15	2	2012-10-14 11:09:27+02
2127	tepláky khaki, nápis STAR, veľ. 4-5rokov	55	1.5	f	-	0	20	2	2012-10-14 09:37:16+02
2162	rifle zateplené na traky KABI č. 74	56	3.5	f	-	0	13	1	2012-10-13 11:20:15+02
2163	ružové flís. Nohavice na traky so zajkom č. 74 cherokee	56	3.5	f	-	0	14	1	2012-10-13 11:20:18+02
2144	čapica prúžková, nápis SKATE, 	55	1.5	f	-	0	37	2	2012-10-14 11:09:54+02
2165	vrece na spanie modré so žirafami Babyland	56	4.5	f	-	0	16	1	2012-10-13 11:20:26+02
2166	modré menčestráky zateplené 3-6 m. BABY	56	3	f	-	0	17	1	2012-10-13 11:20:30+02
2167	bežová teplá bunda, na chrbáte psík 6 m. TulecTrend	56	8	f	-	0	18	1	2012-10-13 11:20:33+02
2152	bežový plet.svetrík s modro-červenými pruhmi č.92	56	3.5	f	-	0	3	1	2012-10-13 11:20:39+02
2153	pásiková modrá mikina flís 3-4 r. cherokee	56	3	f	-	0	4	1	2012-10-13 11:20:42+02
2154	modro-šedá mikina charisma č.110	56	3.5	f	-	0	5	1	2012-10-13 11:20:46+02
2156	next čierna chlapčenská bunda 3r.	56	5	f	-	0	7	1	2012-10-13 11:20:56+02
2157	ružový kvetový zimný overal 6-9 m. cherokee	56	8	f	-	0	8	1	2012-10-13 11:20:58+02
2158	cyklámen. Flís. Mikina s výšivkou kvety č. 80	56	2.5	f	-	0	9	1	2012-10-13 11:21:01+02
2159	červená mikina s kapucou Lupilu č. 86/92	56	2.5	f	-	0	10	1	2012-10-13 11:21:05+02
2160	biely plet. Svetrík s bodkami Minoti 6-12 m.	56	7	f	-	0	11	1	2012-10-13 11:21:08+02
2105	čižmy-snehule ružové s kožušinou s motýlikom,veľ.23	54	10	f	-	0	48	2	2012-10-13 16:57:10+02
2168	čierne rifle na traky 3-6 m. Osh Kosh	56	3.5	f	-	0	19	1	2012-10-13 11:21:32+02
2115	tričko outdour, prúžok, nápis 75, veľ. 3roky	55	2	f	-	0	8	2	2012-10-13 18:01:27+02
2101	bunda bordová s kapucou pogumovaná lesklá,veľ.80	54	12	f	-	0	44	2	2012-10-13 16:21:45+02
2184	riflová sukňa veľ.98	57	3	f	-	0	2	1	2012-10-13 09:59:35+02
2212	dievčenské rifle s kvetinkou veľ.68	57	1	f	-	0	30	2	2012-10-13 18:19:20+02
2187	dievčenská bunda s kapucou ružová veľ.80	57	3	f	-	0	5	1	2012-10-13 09:59:52+02
2207	ružová jesenná bunda s kapucňou veľ.98	57	3	f	-	0	25	2	2012-10-13 19:12:22+02
2200	ružové tričko s aplikáciou kvetiniek veľ.86	57	1	f	-	0	18	2	2012-10-13 18:23:22+02
2190	dievčenské tričko ružové s flitrami veľ.80	57	2	f	-	0	8	1	2012-10-13 10:00:07+02
2191	ružová flisová mikina veľ.86	57	2	f	-	0	9	1	2012-10-13 10:00:09+02
2192	zamatová súprava bunda s kapucou a nohavice veľ.86	57	3	f	-	0	10	1	2012-10-13 10:00:12+02
2234	bledomodrý svetrík, vpredu na zips , na rukávoch hnedé olemovanie veľ.98	58	4	f	-	0	6	2	2012-10-13 17:21:43+02
2193	biele tričko s obrázkom hello kitty veľ.92	57	0.5	f	-	0	11	1	2012-10-13 10:00:25+02
2194	ružové tričko s aplikáciou srdiečok veľ.80	57	3	f	-	0	12	1	2012-10-13 10:00:28+02
2195	ružový svetrík s mašličkou veľ.80	57	2	f	-	0	13	1	2012-10-13 10:00:31+02
2197	ruflová sukníčka na traky  s volánikom veľ.80	57	3	f	-	0	15	1	2012-10-13 10:00:40+02
2231	oteplovačky, sivá farba, tmavo sivá záplata na zadnej časti, veľ.152	58	8	f	-	0	2	2	2012-10-13 18:55:17+02
2199	ružovo-biele tričko s kvetinkovou aplikaciou veľ.92	57	2	f	-	0	17	1	2012-10-13 10:00:46+02
2179	cyklámen.biele topánky so srdiečkami Skippy č. 21	56	5	f	-	0	30	2	2012-10-13 18:25:05+02
2217	zateplené biele nohavice veľ.74	57	1	f	-	0	35	2	2012-10-13 17:47:00+02
2210	bundička modrá s kvetinovýmu aplikáciami veľ.74	57	2	f	-	0	28	1	2012-10-13 10:01:05+02
2214	dievčenské tričká,ružové s nápisoma a bodkované veľ.86	57	3	f	-	0	32	1	2012-10-13 10:01:16+02
2209	ružová blúzka s pásikom veľ. 74	57	1	f	-	0	27	2	2012-10-14 10:51:29+02
2206	ružový svetrík s kvetinkou na dva gombíky veľ.86	57	2	f	-	0	24	1	2012-10-13 10:01:28+02
2182	hnedé zateplené topánky BubleGummers č. 21	56	6	f	-	0	33	2	2012-10-14 09:48:06+02
2220	dievčenské tenisky  adidas bielo ružové veľ.25	57	5	f	-	0	38	2	2012-10-13 15:42:31+02
2229	zimné dievčenské topánky hnedo ružové na 3 suché gufo zipsy veľ.24	57	5	f	-	0	47	2	2012-10-13 19:11:14+02
2186	dievčenská ružová zimná bunda s kapucňou a rukavicami veľ. 98	57	3	f	-	0	4	2	2012-10-14 11:30:09+02
2189	set. ružové nohavice a pulovrík s mackom	57	3	f	-	0	7	2	2012-10-13 18:20:14+02
2216	biela zateplená bundička s mačičkou na prednom diely veľ. 74	57	2	f	-	0	34	1	2012-10-13 10:02:04+02
2211	modré šaty s tričkom, s mašličkami na sukničke veľ.74	57	4	f	-	0	29	1	2012-10-13 10:02:08+02
2204	ružovo biely svetrík na gombíky  veľ.74	57	2	f	-	0	22	1	2012-10-13 10:02:12+02
2202	ružové manchestráky na traky veľ.80	57	2	f	-	0	20	1	2012-10-13 10:02:16+02
2203	žlté tričko s kvetinkou a slovenským nápisom veľ. 92	57	2	f	-	0	21	1	2012-10-13 10:02:19+02
2185	mikina s kapucňou fialová, s flitrovou pandou na prednom diely veľ.98	57	2	f	-	0	3	2	2012-10-13 18:15:07+02
2173	fialové tepláky Grace /na vreckách strieb.šípky/ č. 86	56	2	f	-	0	24	2	2012-10-13 18:55:46+02
2196	dievčenský pulover hnedý s vružovou-fialovým vzorom okolo krku  veľ.92	57	4	f	-	0	14	2	2012-10-13 15:55:14+02
2219	oranžová zimná bunda s kapucňou a kvietkami v dolnej časti veľ.86 	57	3	f	-	0	37	2	2012-10-13 15:52:30+02
2227	zimné čierno-ružové dievčenské topánky  na dva suché zipsy veľ.27	57	3	f	-	0	45	1	2012-10-13 10:02:41+02
2225	dievčenské ružové topánočky na suchý zips fare veľ.27	57	5	f	-	0	43	1	2012-10-13 10:02:44+02
2228	zimné dievčenské topánky hnedo ružové te-por na 3 suché zipsy veľ.27	57	10	f	-	0	46	1	2012-10-13 10:02:49+02
2188	ružový zimný overal veľ.80-86	57	3	f	-	0	6	2	2012-10-13 19:11:27+02
2221	dievčenské tenisky  nike  bielo ružové veľ.26	57	5	f	-	0	39	1	2012-10-13 10:03:00+02
2226	hnedo-ružové dievčenské tiopánočky na suchý zips s kvetinkou veľ. 27	57	8	f	-	0	44	1	2012-10-13 10:03:08+02
2222	dievčenské tenisky s hello kitty  veľ.27	57	2	f	-	0	40	1	2012-10-13 10:03:24+02
2224	ružové dievčenske vyššie topánočky fare veľ. 24	57	5	f	-	0	42	1	2012-10-13 10:03:26+02
2223	bielo-fialové dievčenské topánočky s kvetinkami veľ.24	57	5	f	-	0	41	1	2012-10-13 10:03:29+02
2230	zimná  lyž.bunda, červeno čierno biela veľ.152	58	12	f	-	0	1	1	2012-10-13 10:34:13+02
2218	biely svetrík na gombíky  veľ.74	57	1	f	-	0	36	2	2012-10-13 18:55:46+02
2201	biely kabátik s motívom medvedíkov na prednom diely veľ. 62	57	2	f	-	0	19	2	2012-10-13 17:30:27+02
2232	súprava flanelová košielka + menčestráky na ľvem vrecku  vyšitý macko veľ.3-4 roky	58	10	f	-	0	3	1	2012-10-13 10:36:16+02
2235	kapsáčové nohavice hnedej farby, HM veľ.98	58	5	f	-	0	7	1	2012-10-13 10:36:47+02
2198	ružový vlnený svetrík na gombíky veľ. 86	57	3	f	-	0	16	2	2012-10-13 18:31:19+02
2213	dievčenské tričká,ružové kvetinkové  a bodkované veľ.86	57	3	f	-	0	31	2	2012-10-14 10:40:27+02
2181	čierne kožené tenisky Nike, biela fajka č. 22,5	56	9	f	-	0	32	1	2012-10-13 11:19:54+02
2180	zelenobežové topánky Protetika č. 20	56	5	f	-	0	31	1	2012-10-13 11:20:04+02
2177	fialová flísová čiapka, vyšitý chlapec Rendy	56	2.5	f	-	0	28	1	2012-10-13 11:21:19+02
2178	bieloružová čiapka s kvetinkou a flitrami Ander	56	2.5	f	-	0	29	1	2012-10-13 11:21:24+02
2171	biela flísová mikina s vyšitou žirafou Richelieu č. 68	56	3	f	-	0	22	1	2012-10-13 11:21:55+02
2172	Pásikové bielomodré tepláky sametové Smily č. 68	56	2	f	-	0	23	1	2012-10-13 11:21:57+02
2205	žlttý svtrík na jedn gombík s motílikmi  veľ.86	57	2	f	-	0	23	2	2012-10-13 18:57:46+02
2174	bežové flísové tepláky /na kolenách prešité kruhy/ 12-18 m.	56	2	f	-	0	25	1	2012-10-13 11:22:02+02
2175	hnedé tepláky Kenvelo /vpredu vyšitý býk/ č. 92/98	56	2	f	-	0	26	1	2012-10-13 11:22:06+02
2176	riflové legíny George č. 86	56	2	f	-	0	27	1	2012-10-13 11:22:08+02
2208	ružové tričko s moominkom na prednej strane veľ.98	57	2	f	-	0	26	2	2012-10-13 15:33:00+02
2262	červená tepláková bunda s kapucou, vpredu vačok, vel.104, 1 ks	59	1	f	-	0	14	2	2012-10-13 17:40:26+02
2279	tmavozelené vyteplené nohavice, zn.HM, vel.104, 1 ks	59	3	f	-	0	31	2	2012-10-13 15:26:50+02
2298	pásikavá modr-zeleno-hnedá čiapka, nová,zn.loana,vel.41,1 ks	59	1.5	f	-	0	50	2	2012-10-13 16:20:43+02
2243	károvaná košielka krátky rukáv zn.Palomino	58	3	f	-	0	15	1	2012-10-13 10:37:25+02
2269	bledohnedá menžestráková bunda, kapuca, gombíky, 1 ks	59	2.7999999999999998	f	-	0	21	2	2012-10-13 16:02:17+02
2241	zelená košielka zn.HM, na zapínaní modré prešívanie veľ.92	58	4	f	-	0	13	1	2012-10-13 10:37:46+02
2242	kárována košielka zn.NEXTveľ.92,bledo a tmavomodrý pásik	58	3	f	-	0	14	1	2012-10-13 10:37:52+02
2290	tmaohnedé pásikavé tričko s golierikom, vel.80, 1 ks	59	1.5	f	-	0	42	2	2012-10-14 10:41:43+02
2299	Svetlá hnedá menšestrová zimná súprava. Bundička-na chrbte 1, nohavice zateplené na pravom vrecku 1. Oranžová podšívka.	60	9	f	-	0	1	1	2012-10-13 10:46:00+02
2300	Tepláčiky oranžové, na bokoch pásiky bielo modré, nápis explore, velkosť 86	60	1.2	f	-	0	2	1	2012-10-13 10:50:49+02
2278	červené tričko s autom, dlhý rukáv modrý, vel.116,1 ks	59	0.80000000000000004	f	-	0	30	2	2012-10-13 17:59:36+02
2250	bledohnedé dlhé menžesteráky,vel.23 mes, disney, 1 ks	59	2	f	-	0	2	1	2012-10-13 11:39:55+02
2251	biele menžestráky vyteplené na traky,vel.62, 1 ks	59	2	f	-	0	3	1	2012-10-13 11:39:58+02
2245	tmavozelené tepláčiky , na pravo číslo 68, na bokoch biele pásiky	58	2	f	-	0	17	2	2012-10-14 10:15:35+02
2263	tmovomodré vyteplené nohavice, vel. 80, 1 ks	59	1.8	f	-	0	15	2	2012-10-13 17:49:24+02
2254	tmavohnedé menžestráky, vel. 2-3 roky, 1 ks	59	1.5	f	-	0	6	1	2012-10-13 11:40:05+02
2255	tmavomodré menžestráky dlhé, 1 ks	59	0.80000000000000004	f	-	0	7	1	2012-10-13 11:40:08+02
2252	tmavomodré dlhé teplé nohavice,vel.2,5 roka, 1 ks	59	2	f	-	0	4	2	2012-10-14 09:21:26+02
2239	modré rifle zn.NEXT veľ.98	58	4	f	-	0	11	2	2012-10-13 17:21:05+02
2258	šedé tričko s dlhým rukávom, vel. 1 rok, 1 ks	59	0.80000000000000004	f	-	0	10	1	2012-10-13 11:40:19+02
2257	vyteplené tmavohnedé menžestráky na traky, HM,vel.2-4 mes,1 ks	59	3	f	-	0	9	2	2012-10-13 16:43:26+02
2260	červená flisovaná bunda, vpredu dráčik, vel. 2-3 rok, 1 ks	59	1.5	f	-	0	12	1	2012-10-13 11:40:22+02
2261	zelená tepláková bunda, vel. 98, 1 ks	59	1.8	f	-	0	13	1	2012-10-13 11:40:25+02
2284	bledomodrá flisovaná čiapka so šálom, 2 ks	59	2	f	-	0	36	2	2012-10-13 17:40:26+02
2280	flisovaná bledozelená súprava, vpredu vačok, vel.98, 2 ks	59	2.2000000000000002	f	-	0	32	2	2012-10-13 17:54:20+02
2264	tepláková bundička-zeleno-bledá,vel.80,1 ks	59	0.5	f	-	0	16	1	2012-10-13 11:40:35+02
2265	vyteplené bledohnendé mežestráky, NEXT, vel.6-9 mes, 1 ks	59	2	f	-	0	17	1	2012-10-13 11:40:38+02
2266	vyteplené dlhé rifle, dole červené záložky, vel. 6-12 mes, 1 ks	59	0.90000000000000002	f	-	0	18	1	2012-10-13 11:40:40+02
2253	modré dlhé rifle, zn.HM, vel. 86, 1 ks	59	2.5	f	-	0	5	2	2012-10-13 17:47:48+02
2268	bielo modrá bunda s kapucou, vpredu soby, na cvoky, vel.80,1 ks	59	0.80000000000000004	f	-	0	20	1	2012-10-13 11:40:45+02
2247	Tričko s dlhým rukávom, dvojitý vzhľad, motív Simpsons, NEXT.veľ.146	58	3	f	-	0	19	2	2012-10-13 16:11:13+02
2270	bledohnedá vyteplená bundička, kapuca vpredu medved, 1 ks	59	2	f	-	0	22	1	2012-10-13 11:40:56+02
2293	zelené tepláky, vel.114, 1 ks	59	0.5	f	-	0	45	2	2012-10-13 19:10:34+02
2295	vyteplené nohavice bledohnedé,zn.HM,vel.80, 1 ks	59	1.2	f	-	0	47	2	2012-10-14 11:09:27+02
2273	tmavomodré tričko s dlhým rukávom, benetton, 1 ks	59	1.8	f	-	0	25	1	2012-10-13 11:41:01+02
2274	tmavomodré dlhé rifle, vpredu menžester, vel.104, 1 ks	59	1.5	f	-	0	26	1	2012-10-13 11:41:10+02
2240	tenšie modré rifle zn.Cherokee,veľ.2-3 roky	58	3	f	-	0	12	2	2012-10-14 12:50:36+02
2276	tmavozelené tričko s dlhým rukávom, vel. 92, 1 ks	59	0.80000000000000004	f	-	0	28	1	2012-10-13 11:41:15+02
2277	bledomodré tričko so šedým dlhým rukávom, vel.98, 1 ks	59	0.80000000000000004	f	-	0	29	1	2012-10-13 11:41:18+02
2281	bledozelená zepláková bunda, vel.104-110, 1 ks	59	1.8	f	-	0	33	2	2012-10-13 17:59:36+02
2249	zelené tričko s bielymi rukávmi, HM, vel.12-18 mes, 1 ks	59	1.8	f	-	0	1	2	2012-10-13 17:55:08+02
2294	zelené tepláky s modrými pásmi na bokoch,vel.104,1 ks	59	0.5	f	-	0	46	2	2012-10-13 18:10:29+02
2244	bledomodrá košielka zn.Mark spencer, jemný pásik 	58	3	f	-	0	16	2	2012-10-13 15:28:42+02
2282	šušťaková tmavozelená bunda s kapucou, vyteplená, vel.98,1 ks	59	3.5	f	-	0	34	1	2012-10-13 11:41:48+02
2285	bledomodrá flisovaná súprava,vpredu psík, vel.6-9 mes, 2 ks	59	0.80000000000000004	f	-	0	37	1	2012-10-13 11:41:57+02
2287	červená tepláková bunda, červená, zn,ADIDAS, vel.152, 1 ks	59	2.5	f	-	0	39	1	2012-10-13 11:42:30+02
2286	modrá tepláková bunda na zips s kapucou,vel.110, 1 ks	59	1.5	f	-	0	38	1	2012-10-13 11:42:01+02
2289	bledomodré tričko s dlhým bielym rukávom,vel.86,1 ks	59	1.8	f	-	0	41	1	2012-10-13 11:42:05+02
2267	zelená flisovaná bunda, vpredu barany, na boku modrý vačok, 1 ks	59	1.8	f	-	0	19	2	2012-10-13 17:47:48+02
2272	pásikavé tmavo- biele tričko s dlhým rukávom,HM,104, 1 ks	59	0.80000000000000004	f	-	0	24	2	2012-10-14 11:06:18+02
2283	bledomodré dlhé rifle, vel.94, 1 ks	59	1.8	f	-	0	35	1	2012-10-13 11:42:26+02
2288	tmavozelená tepláková bunda, vel.152,1 ks	59	2	f	-	0	40	1	2012-10-13 11:42:31+02
2291	bledomodré tričko,dlhý ruká,zn.s.oliver, vel.68,1 ks	59	0.80000000000000004	f	-	0	43	1	2012-10-13 11:42:39+02
2292	zelená tenká nepodšitá bunda, zn.loana,vel.98, 1 ks	59	2.2000000000000002	f	-	0	44	1	2012-10-13 11:42:41+02
2256	šedá bunda s kapucou, vpredu vačok, krokodíl, 1 ks, 	59	1.8	f	-	0	8	2	2012-10-14 09:13:01+02
2271	tmavo modré tričko, rukávy zelené,disney,vel.128, 1 ks	59	1	f	-	0	23	2	2012-10-13 19:09:27+02
2275	tmavomodré tričko s dlhým rukávom, vpredu znak NIKE,1 ks, 	59	1.2	f	-	0	27	2	2012-10-14 11:16:20+02
2297	vyteplená čiapka, vpredu baby, kaki farby,1 ks	59	0.80000000000000004	f	-	0	49	1	2012-10-13 11:42:59+02
2259	oranžové tričko s dlhým rukávom, disney,vel.2 roky, 1 ks	59	0.80000000000000004	f	-	0	11	2	2012-10-13 16:32:26+02
2246	Tričko s dlhým rukávom, dvojitý vzhľad, motív Simpsons, NEXT.veľ.146	58	3	f	-	0	18	2	2012-10-13 15:13:06+02
2355	kvietkovaná blúzka H&M, veľ. 80	62	4.5	f	-	0	2	1	2012-10-13 09:27:50+02
2356	červené rifle Next, veľ. 128	62	3.2000000000000002	f	-	0	3	1	2012-10-13 09:27:54+02
2357	riflová sukňa na traky Old navy, veľ. 6 rokov	62	4.5	f	-	0	4	1	2012-10-13 09:28:00+02
2358	červená lyžiarska bunda MK sport, veľ. 128	62	16	f	-	0	5	1	2012-10-13 09:28:16+02
2347	Śedé pančuchy s obrázkom Hello Kitty	61	2	f	-	0	16	2	2012-10-14 10:10:21+02
2329	Šaty dlhé ružové, na chrbte zapínanie na gombíky. Veľkosť 122-128	60	5.5	f	-	0	31	1	2012-10-13 10:46:35+02
2324	Vestička pásiková- bielo ružová s kapuckou, v predu vrecká, značka Bao bao, nápis Popular	60	2.2000000000000002	f	-	0	26	1	2012-10-13 10:46:58+02
2314	Mikina biela s kapucou, vpredu macko Pú na lietadle, veľkosť 92	60	2.2000000000000002	f	-	0	16	1	2012-10-13 10:47:09+02
2320	Tričko staruružové značka kiki, v predu nápis school celebrity kiki, veľkosť 86	60	1.2	f	-	0	22	1	2012-10-13 10:47:21+02
2321	Tričko žlté, vpredu húpací koník, značka Items, veľkosť 86	60	1	f	-	0	23	1	2012-10-13 10:47:28+02
2322	Tričko oranžové, vpredu pavúčik, na pleci zapínanie na gombík, značka Tulec trend, veľkosť 23 mesiacov.	60	2.2000000000000002	f	-	0	24	1	2012-10-13 10:47:35+02
2323	Tričko biele s oranžovým rukávom, vpredu lev, veľkosť 92	60	1.2	f	-	0	25	1	2012-10-13 10:47:42+02
2306	Tričko zelené dlhý rukáv Cheroke, bubáci a nápi Little sport, vek 2-3 roky 	60	1.2	f	-	0	8	1	2012-10-13 10:47:51+02
2307	Tričko farebné pásiky, koník a ťava, nápis Animals & Safari, veľkosť 80.	60	1.2	f	-	0	9	1	2012-10-13 10:47:53+02
2308	Tričko svetlohnedé so sobíkom a vreckom vpredu, zateplené, Bebiko, veľkosť 98	60	2.2000000000000002	f	-	0	10	1	2012-10-13 10:49:03+02
2331	Šaty čierno žlto kárované, na bokoch gombíky na zapínanie, v predu na prsiach vrecko, model Laura	60	4.5	f	-	0	33	1	2012-10-13 10:49:15+02
2330	Bundička modrá menšestrová, na rukávoch a goliery s bielimi pásikmi, na chrbte výšivka býk s nápisim Iron Company	60	3.2000000000000002	f	-	0	32	1	2012-10-13 10:49:22+02
2335	Modré rifle podšité červ.flisom,zn.Gap	61	4.5	f	-	0	4	2	2012-10-13 17:54:20+02
2310	Pančušky tmavo modré s bielimi pásikmi, veľkosť 74-80	60	1.5	f	-	0	12	1	2012-10-13 10:49:33+02
2315	Mikina biea s kapucou, vpredu vrecká, nápis Extreme 65, veľkosť 2-3 roky	60	2	f	-	0	17	1	2012-10-13 10:49:47+02
2316	Mikina s kapucou kapučínová farba, vpredu sivo biele vrecko, značka Gaji, veľkosť 86	60	2.2000000000000002	f	-	0	18	1	2012-10-13 10:49:52+02
2302	Rifle modré s červenou gumičkou na páse, značka cheroke, velkosť 86	60	3	f	-	0	4	1	2012-10-13 10:50:04+02
2303	Nohavice tmavo hnedé- na páse čierna pracka na sťahovanie v páse, vzadu vrecká na suchý zips, veľkosť 92.	60	4	f	-	0	5	1	2012-10-13 10:50:14+02
2304	Nohavice fialové Pocopiano, na zadnom vrecku nápis Euro kids, veľkosť 92.	60	2	f	-	0	6	1	2012-10-13 10:50:21+02
2328	Body bledomodré na celom sú psíci a autíčka, krátky rukáv	60	1.2	f	-	0	30	1	2012-10-13 10:50:29+02
2327	Body biele, krátky rukáv, modrý lem, v predu psík dalmatín, velkosť 98	60	1.2	f	-	0	29	1	2012-10-13 10:50:32+02
2326	Body biele dlhý rukáv, modrý lem, v predu psík a mačička, veľkosť 98	60	1.2	f	-	0	28	1	2012-10-13 10:50:37+02
2301	Rifle modré Basket boy na lavom vrecku výšivka Littla rock, veľkosť 86	60	4	f	-	0	3	1	2012-10-13 10:50:45+02
2319	Tričko s tmavohnedými a svetlohnedými pásikmi, pri krku oranžový límec a oranžové rukávy. Veľkosť 80.	60	1.2	f	-	0	21	1	2012-10-13 10:50:57+02
2317	tričko čisti zelené F&F, veľkosť 1-2 roky	60	1.2	f	-	0	19	1	2012-10-13 10:51:01+02
2318	Tričko oranžové, vpredu nápis For kids only 8, veľkosť 1-2 roky.	60	1.2	f	-	0	20	1	2012-10-13 10:51:05+02
2313	Roláčik štrikovaný hnedý s pásikmi: oranžový, modrý, biely. H&M, veľkosť 3-4 roky	60	6.5	f	-	0	15	1	2012-10-13 10:51:11+02
2312	Vestička hnedá s bielimi pásikmi H&M, v predu autíčko, veľkosť 12-18 mesiacov	60	2.2000000000000002	f	-	0	14	1	2012-10-13 10:51:15+02
2340	Šedé tričko dlh.rukáv s nápismi a striebornou korunou zn.HM	61	2.5	f	-	0	9	2	2012-10-13 17:09:37+02
2332	Tmavo šedá bunda s ruž.zipsom a odop.kapucou,zn.HM,vel134	61	15.5	f	-	0	1	1	2012-10-13 11:27:07+02
2333	Vojensky zelená obojstr.bunda s tm.modrým flisom,zn.Benetton	61	9.5	f	-	0	2	1	2012-10-13 11:27:14+02
2334	Fialove nohavice podšité flisom s bielymi pásmi a nápis Sport 16	61	5.5	f	-	0	3	1	2012-10-13 11:27:20+02
2341	Śedé tričko,dlh.rukáv modrý nápis Athletics,zn.FF	61	2	f	-	0	10	2	2012-10-14 11:09:27+02
2352	Modrý bundo-pršiplášť s obrázkami 101 dalmatíncov	61	3	f	-	0	21	1	2012-10-13 11:29:50+02
2348	Bielo-červený spací overal so srdiečkami a macko pú,vel.68	61	1.5	f	-	0	17	2	2012-10-13 17:56:04+02
2311	Mikina modrá s kapucou cheroke, v predu nápis 1st mate,  vrecko vpredu, veľkosť 1-2 roky	60	2.5	f	-	0	13	2	2012-10-13 16:36:03+02
2309	Pančušky tmavo modré s hviezdičkami, veľkosť 62-68	60	1.5	f	-	0	11	2	2012-10-13 17:17:43+02
2336	Hnedá vesta s kožušin.kapucou zn.Generation	61	6.5	f	-	0	5	1	2012-10-13 11:28:12+02
2337	Zeleno-biely sveter so srdiečkami a pásmi,ruž.zipsom,podšitý,zn.HM	61	5.5	f	-	0	6	1	2012-10-13 11:28:41+02
2338	Tm.šedá mikina s kapucou so srdiečkom london girls	61	3.5	f	-	0	7	1	2012-10-13 11:28:45+02
2351	Bl.šedé tepláky s obrázkom Minny,zn.Disney,vel.134	61	2	f	-	0	20	2	2012-10-13 16:06:44+02
2345	2pack roláky tm.modrý+šedý s nápismi ,zn.Lupilu	61	3	f	-	0	14	1	2012-10-13 11:29:04+02
2346	Tm.ružové pančuchy zn.HM,vel.122-128	61	1	f	-	0	15	1	2012-10-13 11:29:11+02
2353	Biele dievčenské korčule na ľad,zn.Davos,vel.33	61	10.5	f	-	0	22	2	2012-10-14 10:46:42+02
2359	prúžkovaný spací vak H&M so zvieratkami, veľ. 86/98	62	8.6999999999999993	f	-	0	6	2	2012-10-13 19:33:27+02
2349	Modré rifle zn.Next	61	2	f	-	0	18	1	2012-10-13 11:29:34+02
2350	Tm.fialové tepláky s nápisom na páse vel.128	61	1.5	f	-	0	19	1	2012-10-13 11:29:39+02
2339	Ružovo-biele thermo prádlo legíny+tričko zn.Crivit	61	5.5	f	-	0	8	2	2012-10-13 16:29:43+02
2344	Smotanovo biely rolák,zn.C&A,vel.122	61	2	f	-	0	13	1	2012-10-13 11:29:58+02
2343	Zelené tepláky s bielymi šnúrkami,zn.HM,vel.104	61	4.5	f	-	0	12	2	2012-10-13 15:44:00+02
2342	Modré pásikové tričko,dlh.rukáv,zn.HM,vel.98-104	61	1.5	f	-	0	11	2	2012-10-13 15:15:37+02
2405	tyrkysovo-bielo-hnedá blúzka s kvietkami, veľ. 110/116	63	3.8999999999999999	f	-	0	2	1	2012-10-13 09:17:37+02
2378	biele tričko s nápisom s. Oliver	62	3.7999999999999998	f	-	0	25	2	2012-10-13 18:55:17+02
2408	bodkovaný flísový kabátik Next, tmavoružovo-bledoružový, veľ. do 3-6 mes. 	63	6.5	f	-	0	5	1	2012-10-13 09:18:18+02
2409	blúzka Mila blue, hnedo-tyrkysová, veľ. 86	63	4.2999999999999998	f	-	0	6	1	2012-10-13 09:18:21+02
2410	kárované šaty H&M, ružovo-oranžovo-hnedo-biele, veľ. 9-12 mes.	63	4.2000000000000002	f	-	0	7	1	2012-10-13 09:18:25+02
2412	rifľová sukňa Cherokee, veľ. 2-3 roky	63	2.8999999999999999	f	-	0	9	2	2012-10-14 11:59:29+02
2413	kvietkovaná blúzka H&M, tyrkysovo-modro-hnedo-ružová, veľ. 68	63	4.5	f	-	0	10	1	2012-10-13 09:18:56+02
2397	žltá bundička s kačičkou a kapuckou Circo, veľ. 3 roky	62	4.9000000000000004	f	-	0	44	2	2012-10-13 17:54:58+02
2415	fialová bunda s kapuckou Cherokee, veľ. 8-9 rokov	63	9.5	f	-	0	12	1	2012-10-13 09:19:13+02
2416	prúžkové tričko s mašľou vpredu H&M, veľ. 86 	63	3.8999999999999999	f	-	0	13	1	2012-10-13 09:19:23+02
2419	čierna prešívaná vesta Benetton, veľ. 11-12	63	7.9000000000000004	f	-	0	16	1	2012-10-13 09:19:33+02
2420	šedý svetrík Zara, veľ. 18-24 mes.	63	4	f	-	0	17	1	2012-10-13 09:19:37+02
2421	oranžová flísová trigovica Cicerone, veľ. 104	63	4.7999999999999998	f	-	0	18	1	2012-10-13 09:19:47+02
2414	ružové body so zajkom Cherokee, veľ. 56	63	1.8	f	-	0	11	2	2012-10-13 17:30:27+02
2363	ružové tenisky Adidas, veľ. 20	62	8.1999999999999993	f	-	0	10	2	2012-10-13 16:34:29+02
2399	podšité hnedé nohavice H&M, veľ. 74	62	5.9000000000000004	f	-	0	46	2	2012-10-13 19:19:16+02
2425	ružové tričko s kvetinkami a srdiečkami Minoti, veľ. 6-12 mes.	63	1.5	f	-	0	22	1	2012-10-13 09:20:18+02
2417	ružový svetrík vpredu s dvoma kvietkymi Name it, veľ. 74	63	5.2000000000000002	f	-	0	14	1	2012-10-13 09:21:37+02
2418	3/4 rifle Zara, veľ. 98	63	6.2000000000000002	f	-	0	15	1	2012-10-13 09:21:40+02
2360	oranžová vestička s kapucou Cicerone, veľ. 104	62	4.7000000000000002	f	-	0	7	1	2012-10-13 09:28:38+02
2364	riflový kabátik Next s kvetinkou a kapucou podšitý červeným flísom, veľ. 86 + klobúčik	62	8.9000000000000004	f	-	0	11	1	2012-10-13 09:28:49+02
2423	cyklamenová chlpatka Dopo dopo, veľ. 80	63	7.9000000000000004	f	-	0	20	2	2012-10-13 16:27:15+02
2362	čierne lakovky na zaväzovanie s motýlikom, veľ. 19	62	4.2000000000000002	f	-	0	9	1	2012-10-13 09:29:23+02
2422	červený kabátik Zara, veľ. 18-24	63	5.2000000000000002	f	-	0	19	2	2012-10-13 17:13:47+02
2365	šedé čižmičky s kvietkom Kornecki, veľ.21	62	9.9000000000000004	f	-	0	12	1	2012-10-13 09:29:52+02
2367	modré topánočky s kožušinkou Elefanten, veľ. 21	62	7.5	f	-	0	14	1	2012-10-13 09:32:16+02
2366	červené topánočky Elefanten, veľ. 18	62	6.5	f	-	0	13	1	2012-10-13 09:31:42+02
2368	béžová nočná košieľka Prenatal s obrázkami a vačkom, dolu sa dá stiahnuť	62	3.2999999999999998	f	-	0	15	1	2012-10-13 09:32:25+02
2369	ružové tričko so šedo-striebornými pásikmi Reserved, veľ. 134 cm	62	3.7999999999999998	f	-	0	16	1	2012-10-13 09:32:27+02
2370	béžový oteplený komplet s výšivkou - vesta+nohavice Palomino, veľ. 104	62	14.9	f	-	0	17	1	2012-10-13 09:32:34+02
2371	rifle so srdiečkami Next, veľ. 6-9 mes. 	62	2.5	f	-	0	18	1	2012-10-13 09:32:47+02
2372	bielo - modré nohavice Mini mode s drobnými kockami, 2-3 roky	62	1.8999999999999999	f	-	0	19	1	2012-10-13 09:32:49+02
2373	ružová bodkovaná čiapka F&F s mašličkou a rukavicami, veľ. 12-24 mes.	62	2.8999999999999999	f	-	0	20	1	2012-10-13 09:32:55+02
2374	ružová zavinovačka Richelieu	62	5.2000000000000002	f	-	0	21	1	2012-10-13 09:33:05+02
2391	lyžiarska kombinéza Outfit žlto-čierna, veľ. 92	62	10.9	f	-	0	38	2	2012-10-13 15:44:00+02
2376	ružová osuška Calvin Klein s kvietkami	62	5.5	f	-	0	23	1	2012-10-13 09:33:27+02
2424	biely svetrík s ružovými pásikmi a kapucou YKK, veľ. 3 mes.	63	2.8999999999999999	f	-	0	21	2	2012-10-13 18:55:46+02
2379	ružové tričko so šedými kvietkami H&M, veľ. 68 	62	2.8999999999999999	f	-	0	26	1	2012-10-13 09:34:35+02
2382	ružová kombinéza s kapuckou a kožušinkou Zara, veľ. 74	62	14.9	f	-	0	29	1	2012-10-13 09:34:47+02
2380	biele tričko s myškou Cherokee, veľ. 56	62	1.3999999999999999	f	-	0	27	1	2012-10-13 09:35:11+02
2381	podšité mink nohavice H&M, veľ. 74	62	5.9000000000000004	f	-	0	28	1	2012-10-13 09:35:14+02
2383	šedo-čierny kabátik + klobučik Loana, veľ. 98	62	7.5	f	-	0	30	1	2012-10-13 09:35:18+02
2384	modrá kombinézka Pussycat, veľ. 68	62	8.1999999999999993	f	-	0	31	1	2012-10-13 09:35:21+02
2386	vianočné body so sobíkmi+papučky Tesco, veľ. 6-9 mes. 	62	3.2000000000000002	f	-	0	33	1	2012-10-13 09:35:45+02
2387	ružová bundička s nápisom Circus girl, Kenvelo, veľ. 6 rokov	62	5.9000000000000004	f	-	0	34	1	2012-10-13 09:35:51+02
2388	modro-biela trigovica Nike s nápisom Girls, veľ. 128-140	62	7.9000000000000004	f	-	0	35	1	2012-10-13 09:36:01+02
2389	ružovo-bielo-červená vzorovaná čiapočka na zaväzovanie, veľ. 43	62	3.7999999999999998	f	-	0	36	1	2012-10-13 09:36:03+02
2390	červená bundička Snow&company, veľ. 74	62	6.2000000000000002	f	-	0	37	1	2012-10-13 09:37:35+02
2361	červené topánočky s kvetinkou Elefanten, veľ. 22	62	5.9000000000000004	f	-	0	8	2	2012-10-13 16:08:53+02
2393	čierna prešívaná vesta Radar, veľ. 98/104	62	5.5	f	-	0	40	1	2012-10-13 09:37:52+02
2392	hnedá prešívaná vesta A punto, veľ. 128	62	5.5999999999999996	f	-	0	39	1	2012-10-13 09:38:02+02
2394	ružové body s hríbikami a vtáčikmi Mothercare, veľ. 3-6 mes. 	62	1.3999999999999999	f	-	0	41	1	2012-10-13 09:38:06+02
2395	body s ružovými a modrými hríbikami Mothercare, veľ. 3-6 mes. 	62	1.3999999999999999	f	-	0	42	1	2012-10-13 09:38:09+02
2396	ružová prešívaná vesta Coccodrillo, veľ. 122	62	6.2000000000000002	f	-	0	43	1	2012-10-13 09:38:13+02
2406	kvetinkové tričko Old navy, zeleno-fialovo-šedé, veľ. 3 roky	63	4.5	f	-	0	3	2	2012-10-13 18:24:20+02
2398	riflový kabátik Next s kvetinkou a kapucou podšitý červeným flísom, veľ. 104	62	8.5	f	-	0	45	1	2012-10-13 09:38:39+02
2411	šedý svetrík Mila blue, veľ. 86	63	4.5999999999999996	f	-	0	8	2	2012-10-14 10:41:43+02
2400	zimná farebná kombinéza Ten club, veľ. 86 	62	8.9000000000000004	f	-	0	47	1	2012-10-13 09:39:16+02
2401	ružovo-šedé snehule Sorel, veľ. 23	62	15.9	f	-	0	48	1	2012-10-13 09:39:34+02
2402	modrá flísová mikina s kapucou Kiddy´s, veľ. 98	62	5.9000000000000004	f	-	0	49	1	2012-10-13 09:39:47+02
2403	fialové body so srnkou H&M, Disney 	62	2.2000000000000002	f	-	0	50	1	2012-10-13 09:39:53+02
2377	ružové sako Benetton, veľ. XL	62	7.2000000000000002	f	-	0	24	1	2012-10-13 09:40:55+02
2375	hnedá flísová bundička www, veľ. 80	62	6.2000000000000002	f	-	0	22	2	2012-10-13 14:46:07+02
2497	dupačky biele s padnou + kabatik, vel. 56	65	5	f	-	0	13	1	2012-10-13 08:27:11+02
2430	zelené šaty s hnedými bodkymi, vpredu na gombíky Next, veľ. 9-12 mes. 	63	3.7999999999999998	f	-	0	27	2	2012-10-13 17:13:47+02
2493	3 ks teplakov, biele-zajkovia, mackovia,zvieratka. Vel. 56-62	65	3	f	-	0	9	1	2012-10-13 08:27:41+02
2494	3 ks teplakov,zelene žirafa, modré a zelené vel. 62	65	3	f	-	0	10	2	2012-10-13 17:03:24+02
2491	overal bielý s myškou . Vel. 56	65	1.5	f	-	0	7	2	2012-10-13 16:02:17+02
2492	2 ks teplakov .biele a krémove, velk.56	65	3	f	-	0	8	1	2012-10-13 08:28:40+02
2487	bežové nohavice, vel. 3 r. 	65	2	f	-	0	3	1	2012-10-13 08:28:47+02
2486	spací vak, bieli s kačičkou , vel. 68	65	1	f	-	0	2	1	2012-10-13 08:28:55+02
2438	tmavo modré rifle  F&F, veľ. 9-12 mes.	63	2.5	f	-	0	35	2	2012-10-13 16:21:45+02
2485	modrý svetrík s velkým M, vel. 74	65	1.5	f	-	0	1	1	2012-10-13 08:29:08+02
2488	modrá buncička (prechodná) vel. 68	65	1	f	-	0	4	1	2012-10-13 08:30:28+02
2426	béžové oteplené nohavice Fasion Girl, veľ.110	63	6.9000000000000004	f	-	0	23	1	2012-10-13 09:20:23+02
2427	ružové tričko s kvetinkami ružovo-bielo-hnedými Adams, veľ. 86.	63	2.2999999999999998	f	-	0	24	1	2012-10-13 09:20:31+02
2428	kárované červeno-zelené šaty Lindex, veľ. 98	63	7.9000000000000004	f	-	0	25	1	2012-10-13 09:20:34+02
2429	žlto-modré tričko Nike, vpredu nápis Victory, veľ. 104-110	63	7.9000000000000004	f	-	0	26	1	2012-10-13 09:20:52+02
2433	ružová tepláková súprava H&M, vrch s hnedými kvietkami a kapucou, veľ. 74	63	6.5	f	-	0	30	2	2012-10-13 17:30:27+02
2431	béžové oteplené nohavice s mackom Bout´chou, veľ. 23 mes.	63	5.9000000000000004	f	-	0	28	1	2012-10-13 09:21:04+02
2432	béžové menžestrové šaty s kvietkami a vačkami, veľ. 74	63	3.2000000000000002	f	-	0	29	1	2012-10-13 09:21:11+02
2459	Kombinéza biela s mackami	64	3	f	-	0	6	2	2012-10-13 18:53:01+02
2434	ružová mikinka H&M, s hnedými kvietkami a kapucou, veľ. 62	63	3.7999999999999998	f	-	0	31	1	2012-10-13 09:21:50+02
2435	biele pyžamko s farebnými hviezdičkami F&F, veľ. 0 mes. 	63	2.8999999999999999	f	-	0	32	1	2012-10-13 09:22:42+02
2436	šedé šaty so striebornou nitkou Girl2girl, veľ. 98	63	7.9000000000000004	f	-	0	33	1	2012-10-13 09:22:52+02
2437	hnedý kabátik Zara, 12-18 mes.	63	4.9000000000000004	f	-	0	34	1	2012-10-13 09:22:58+02
2495	modré teplaky pasikove , vel. 56	65	1.6000000000000001	f	-	0	11	2	2012-10-13 16:25:44+02
2439	modré rifle Marks&Spencer, veľ. do 3 mes.	63	3.5	f	-	0	36	1	2012-10-13 09:23:12+02
2440	modré rifle L.O.G.G., veľ. 62	63	3.7000000000000002	f	-	0	37	1	2012-10-13 09:23:39+02
2441	tmavomodré rifle podšité ružovou pleteninou Marks&Spencer, veľ. 3-6 mes.	63	4.2000000000000002	f	-	0	38	1	2012-10-13 09:23:54+02
2442	rifle L.O.G.G., veľ. 12-18 mes.	63	5.5	f	-	0	39	1	2012-10-13 09:24:02+02
2443	ružovo-biely spací vak s kvetinkami a zajačikom One little bunny	63	7.9000000000000004	f	-	0	40	1	2012-10-13 09:24:14+02
2449	rifle Hello Kitty H&M, veľ. 86 mes.	63	7.2999999999999998	f	-	0	46	2	2012-10-14 10:40:27+02
2445	žltá bunda s modrou kombináciou a kapucou Krümel, veľ. 86	63	5.7000000000000002	f	-	0	42	1	2012-10-13 09:24:56+02
2447	oranžový svetrík so slniečkami K.F. company, veľ. 104	63	3.8999999999999999	f	-	0	44	1	2012-10-13 09:25:00+02
2448	ružové capačky vnútri s kožušinkou, veľ. 0-3 mes.	63	2.2000000000000002	f	-	0	45	1	2012-10-13 09:25:09+02
2450	rifľový kabátik Zara, veľ. 9-12 mes.	63	6.7000000000000002	f	-	0	47	1	2012-10-13 09:25:36+02
2451	rifľové šaty Zara, veľ. 12-18 mes.	63	5.5999999999999996	f	-	0	48	1	2012-10-13 09:25:53+02
2452	šedo-ružové capačky s kvietkami Cherokee, veľ. 12-18 mes.	63	2.5	f	-	0	49	1	2012-10-13 09:26:03+02
2453	zelený svetrík so slniečkami K.F. company, veľ. 110	63	3.8999999999999999	f	-	0	50	1	2012-10-13 09:26:47+02
2446	ružové topánočky na šnurovanie Impidimpi, veľ. 23	63	7.2000000000000002	f	-	0	43	1	2012-10-13 09:26:59+02
2474	Spací vak Macko PU	64	5	f	-	0	21	1	2012-10-13 11:02:04+02
2458	Kombinéza oranžová s rukavičkami	64	3	f	-	0	5	1	2012-10-13 11:02:32+02
2457	Kombinéza modrá s mackami +rukavice+nožičky	64	3	f	-	0	4	1	2012-10-13 11:02:53+02
2444	tmavomodré rifle podšité ružovou pleteninou Early days veľ. 18-23 mes.	63	4.7999999999999998	f	-	0	41	2	2012-10-13 19:04:25+02
2465	Dupky s včeličkou	64	1.5	f	-	0	12	1	2012-10-13 11:03:49+02
2461	Dupky modré s tučniakom	64	5	f	-	0	8	1	2012-10-13 11:04:03+02
2462	Dupky kravičkové	64	3	f	-	0	9	1	2012-10-13 11:04:33+02
2466	Dupačky s kravičkou a zvieratkamy	64	3	f	-	0	13	1	2012-10-13 11:05:28+02
2476	Plienka TOTSBOTS zelená s bielimi hviezdičkami	64	12	f	-	0	23	1	2012-10-13 11:06:04+02
2477	Rukavice biele	64	1	f	-	0	24	1	2012-10-13 11:06:39+02
2480	Dupky Winter Time	64	2	f	-	0	27	1	2012-10-13 11:07:30+02
2479	Body dlhý rukáv modrý páásik	64	0.5	f	-	0	26	1	2012-10-13 11:07:54+02
2482	Kojenecká košieľka biela	64	1.5	f	-	0	29	1	2012-10-13 11:08:08+02
2481	Kojenecká košieľka s ružovýým lemom	64	1.5	f	-	0	28	1	2012-10-13 11:08:26+02
2478	Čiapočka zajačik	64	4	f	-	0	25	1	2012-10-13 11:08:43+02
2463	Tričko dlhý rukáv XXX BABY	64	1	f	-	0	10	1	2012-10-13 11:09:11+02
2468	Tričko dlhý rukáv L.BEAR BLUE	64	1.5	f	-	0	15	1	2012-10-13 11:09:33+02
2464	Tričko pásikavé s efektom dvoch rukávou	64	1	f	-	0	11	1	2012-10-13 11:09:59+02
2471	Tričko s mackom a kanoe	64	1.5	f	-	0	18	1	2012-10-13 11:10:18+02
2467	Dupačky s mackom a sovičkou	64	2	f	-	0	14	1	2012-10-13 11:10:34+02
2469	Body dlhý rukáv -modrý pásik	64	1	f	-	0	16	1	2012-10-13 11:10:51+02
2470	Body dlhý rukáv biele so sloníkom a myškou	64	1	f	-	0	17	1	2012-10-13 11:11:02+02
2472	Tričko dlhý rukáv červené	64	1	f	-	0	19	1	2012-10-13 11:11:23+02
2473	Novorodenecká košielka biela	64	1	f	-	0	20	1	2012-10-13 11:11:31+02
2490	pyžmko biele, zajko a myš. Vel. 56	65	2	f	-	0	6	2	2012-10-13 15:51:45+02
2516	opalovačky disney zajac vel.62	65	1	f	-	0	32	1	2012-10-13 08:24:01+02
2514	2ks, opalovačky zelené pásikové , MILK BOYS vel. 56-62	65	3.6000000000000001	f	-	0	30	1	2012-10-13 08:23:35+02
2517	opalovačky s pásikavé s golierom vel. 62	65	1	f	-	0	33	1	2012-10-13 08:24:09+02
2522	3ks, dupačky biele s mašlami a slniečkom vel.62	65	3	f	-	0	38	1	2012-10-13 08:24:20+02
2515	opalovačky biele ovečky vel.62	65	1.6000000000000001	f	-	0	31	1	2012-10-13 08:24:28+02
2518	košielka modrá zo zvieratkami 56	65	1.6000000000000001	f	-	0	34	1	2012-10-13 08:24:38+02
2519	2ks bile tričká s dlhým rukávom vel. 62	65	1	f	-	0	35	1	2012-10-13 08:24:55+02
2520	tričko s golierom pasikavé (zeleno-modré) vel. 74	65	1	f	-	0	36	1	2012-10-13 08:25:35+02
2524	3ks body krátke, modré,bile,zvieratká vel 56-62	65	3	f	-	0	40	1	2012-10-13 08:25:48+02
2499	2 ks,dupačky žlte (šarkán,svrček) 68	65	1	f	-	0	15	1	2012-10-13 08:25:58+02
2505	body dlhé,šedé snoopy, vel. 50	65	2	f	-	0	21	1	2012-10-13 08:26:07+02
2502	čiapočka modrá s korytnačkou, 62	65	1.5	f	-	0	18	1	2012-10-13 08:26:14+02
2508	body dlhý rukav, fialové , vel. 56	65	1	f	-	0	24	1	2012-10-13 08:26:37+02
2534	Tričko dlhý rukáv-šedo-modro pásikavé s kapucňou,vpredu nápis-CHEROKEE(veľ.12-18Months)	66	1.7	f	-	0	10	2	2012-10-13 17:47:48+02
2498	dupačky biele malý sloník + košielka, vel.62	65	1.6000000000000001	f	-	0	14	1	2012-10-13 08:27:17+02
2503	2 ks, dupačky modre bear polar 62-68	65	2	f	-	0	19	2	2012-10-13 19:02:12+02
2509	3 ks, body krátky rukav, bielo-zelené s husenicami,modré psí,a zelené pásikove, vel. 62	65	3	f	-	0	25	1	2012-10-13 08:28:00+02
2511	2 ks,body dlhé, modre pásiky vel.56-62	65	1.6000000000000001	f	-	0	27	1	2012-10-13 08:28:11+02
2504	2 ks, body krátke modrá lupilu , pásikove , s dinosaurom) 56	65	3.1000000000000001	f	-	0	20	1	2012-10-13 08:29:21+02
2507	3ks, body krátky rukav, biele s mackom, modrý psík a modrý medve., vel. 56	65	3	f	-	0	23	1	2012-10-13 08:29:27+02
2556	Pulóver -bledohnedý, vpredu krátky zips,rukávy záplaty -junior (12-18monts)	66	2	f	-	0	32	2	2012-10-14 09:56:54+02
2513	opalovačky modré, krátky rukáv,na ramena vel. 56-62	65	3	f	-	0	29	1	2012-10-13 08:29:50+02
2510	3 ks,body krátky rukáv, (mackovia, vílí, žeriav) vel. 56-62	65	3	f	-	0	26	1	2012-10-13 08:30:00+02
2512	3ks,body dlhé , zeleno-žlté pásiky,biely sloník,sloníci vel. 62	65	2.6000000000000001	f	-	0	28	1	2012-10-13 08:30:11+02
2506	3 ks, body dlhý rukav,2x modré s mackami,1x psi, 56,62,68	65	3	f	-	0	22	1	2012-10-13 08:30:20+02
2525	Čiapka pre dojča - bledozelená so šiltíkom, na uväzovanie - RADA 	66	3	f	-	0	1	1	2012-10-13 09:59:16+02
2526	Čiapka pre dojča - bledučkomodrá, vpredu biele pásiky - Lady Ann	66	2.1000000000000001	f	-	0	2	1	2012-10-13 09:59:19+02
2550	Tričko dlhý rukáv -červené, vpredu auto -F&F(5-6yrs)	66	2	f	-	0	26	2	2012-10-13 18:33:37+02
2528	Čiapka - zimná s vrkočmi - modrá - SPIDER-MAN	66	2	f	-	0	4	1	2012-10-13 09:59:22+02
2530	Čiapka - zimná -  tri pásy: odtiene hnedej 	66	1.1000000000000001	f	-	0	6	1	2012-10-13 09:59:31+02
2531	Overal-farebné pásiky,šedé rukávy, obr. zebra a lev -miniclub(3-6mths)	66	2.5	f	-	0	7	1	2012-10-13 09:59:33+02
2532	Overal-tmavomodro-bielakáva pásikové tričko,bielakáva nohavice-prací kord -CHEROKEE (veľ.56cm)	66	3.5	f	-	0	8	1	2012-10-13 09:59:38+02
2533	Tričko dlhý rukáv-obr.Scooby-doo!,farba olivovozelená, biele rukávy(veľ.12-18Months)	66	2	f	-	0	9	1	2012-10-13 09:59:39+02
2527	Čiapka - pásiková, hnedá - hore rozdelená na tri cípy 	66	1.1000000000000001	f	-	0	3	2	2012-10-13 18:32:59+02
2535	Tričko dlhý rukáv -modré,obr. stegosaurus, vzadu nápis stegosaurus(18-24Months)	66	1.7	f	-	0	11	1	2012-10-13 09:59:43+02
2536	Tričko dlhý rukáv -bledohnedé, vpredu obr.TOW TRUCK-CHEROKEE(2-3yrs)	66	1.7	f	-	0	12	1	2012-10-13 09:59:47+02
2537	Tričko dlhý rukáv -modré, vpredu obrázok so zipsom-CHEROKEE (4-5yrs) 	66	1.5	f	-	0	13	1	2012-10-13 09:59:48+02
2538	Tričko dlhý rukáv -tmavomodré, vpredu nápis AUTHENTIC 1973(4-5yrs)	66	1.2	f	-	0	14	1	2012-10-13 09:59:51+02
2539	Tričko dlhý rukáv -biele, vpredu modré palmy( 4-5yrs)	66	1.1000000000000001	f	-	0	15	1	2012-10-13 09:59:54+02
2540	Tričko dlhý rukáv -zeleno-biele pásiky,biele rukávy,obr.červené auto-CHEROKEE (4-5yrs) 	66	2.5	f	-	0	16	1	2012-10-13 09:59:56+02
2541	Tričko dlhý rukáv -žlté, rukávy hnedé,pravý rukáv nápis,plecia pásiky (veľ. 98-110cm)	66	2	f	-	0	17	1	2012-10-13 09:59:58+02
2549	Tričko dlhý rukáv -tmavomodré, vpredu 3 gombičky -CHEROKEE (5-6yrs)	66	1.6000000000000001	f	-	0	25	2	2012-10-13 16:45:05+02
2543	Tričko dlhý rukáv -bledohnedé, vpredu obr. Lietadlo - GEORGE(4-5yrs)	66	1.3999999999999999	f	-	0	19	1	2012-10-13 10:00:02+02
2544	Tričko dlhý rukáv -hnedé, rukávy zelené - CHEROKEE (4-5yrs)	66	2.1000000000000001	f	-	0	20	1	2012-10-13 10:00:04+02
2545	Tričko dlhý rukáv -žlté, vpredu nápis:Number01 Athlete -CHEROKEE (4-5yrs)	66	2	f	-	0	21	1	2012-10-13 10:00:07+02
2546	Tričko dlhý rukáv -tmavomodré - GEORGE  (4-5yrs) 	66	1.6000000000000001	f	-	0	22	1	2012-10-13 10:00:09+02
2554	Tričko dlhý rukáv -biele+tričko krátky rukáv modro-šedo-bielo pásikové -lupilu(veľ.110-116) 	66	4	f	-	0	30	2	2012-10-13 16:13:10+02
2548	Tričko dlhý rukáv -modré, vpredu obr. čierny vlk - lupilu(4-5yrs)	66	1.7	f	-	0	24	1	2012-10-13 10:00:15+02
2500	2 ks, dupačky (ckom,modro-rúžove s myškou) 68	65	2	f	-	0	16	2	2012-10-13 17:17:43+02
2501	2 ks čiapocky (biela s botkami,biela)	65	2	f	-	0	17	2	2012-10-13 18:53:01+02
2552	Tričko dlhý rukáv -oranžové, obrázok+nápis: PRO BIKER -F&F(5-6yrs)	66	2.5	f	-	0	28	2	2012-10-13 16:17:37+02
2542	Tričko dlhý rukáv -bledomodré, vpredu nápis:WOLF, POLAR BASE(veľ.104)	66	1.8	f	-	0	18	2	2012-10-13 16:45:05+02
2551	Tričko dlhý rukáv -zelené, rukávy bledé, vpredu auto+nápis:No.1 CHAMP -F&F(5-6yrs)	66	2	f	-	0	27	2	2012-10-13 16:17:37+02
2553	Tričko dlhý rukáv -červené, obrázok+nápis: SKATE TEAM -F&F(5-6yrs)	66	2.5	f	-	0	29	2	2012-10-13 16:17:37+02
2555	Pulóver -bledohnedý,patenty olemované tmavohnedo-CHEROKEE(18-24mths)	66	4	f	-	0	31	1	2012-10-13 10:00:46+02
2547	Tričko dlhý rukáv -červené s palmami (4-5yrs) 	66	1.1000000000000001	f	-	0	23	2	2012-10-13 16:04:20+02
2557	Pulóver -modrý, vpredu krátky zips, vpredu pásiky -adams(3years)	66	2.1000000000000001	f	-	0	33	2	2012-10-13 15:30:01+02
2824	Menčestráky hnedé	72	3	f	-	0	12	2	2012-10-13 15:26:40+02
2571	Bunda -zimná, tmavošedá s kapucňou, vnútri chlpatka -CHEROKEE (5-6yrs)	66	6	f	-	0	47	2	2012-10-13 16:32:00+02
2576	ružové gumáčky bodkované, na boku kvetinka, vel. 20	67	2.5	f	-	0	2	1	2012-10-13 08:30:23+02
2575	ružové snehule zn. Reebok, vel. 21	67	9.9000000000000004	f	-	0	1	2	2012-10-13 16:21:45+02
2560	Mikina -flauš-modrá -pásiková s kapucňou - Ladybird(3-4years)	66	2	f	-	0	36	2	2012-10-13 17:40:26+02
2580	fialová zimná prešívaná bunda na cvočky, vel. 9-12mes.	67	6.5	f	-	0	6	1	2012-10-13 08:30:50+02
2581	ružový zimný overal  na zips s kapucou, vel. 74	67	9.9000000000000004	f	-	0	7	1	2012-10-13 08:30:53+02
2582	ružový kabátik s kapucou s uškami ( flisový ), vel. 62-68	67	2.5	f	-	0	8	1	2012-10-13 08:30:56+02
2570	Oteplovačky -modré na traky, na ľavej nohe vrecko (110cm)	66	3.2999999999999998	f	-	0	46	2	2012-10-13 19:24:46+02
2584	tepláková súprava - ružová bunda, bordo teplák, strieborný lem, vel.74	67	3	f	-	0	10	1	2012-10-13 08:31:02+02
2574	Overal - tmavomodrý, rukávy zvrchu bledomodré s červeným pásikom(veľ.104)	66	4.5	f	-	0	50	2	2012-10-13 15:44:00+02
2586	tepláková súpr. - červená bunda, béžové mackové tepláky, veľ. 68	67	1.2	f	-	0	12	1	2012-10-13 08:31:07+02
2577	hnedé semišové čižmy na suchý zips, vel. 20	67	2.5	f	-	0	3	2	2012-10-13 16:11:13+02
2588	spací vak ružový na zips, 110 cm, v dolnej časti mačička	67	2	f	-	0	14	1	2012-10-13 08:31:17+02
2604	zeleno čierne tričko s dlh. rukávom BLU, vel. 162	67	2	f	-	0	30	2	2012-10-13 18:13:48+02
2590	fialové tepláky na traky s kvetinkami a s nápisom Happy day...vel.74	67	2	f	-	0	16	1	2012-10-13 08:31:46+02
2565	Nohavice - hnedé menžestráky -NEXT(12-18months) 	66	2	f	-	0	41	2	2012-10-13 18:36:12+02
2593	tepl. súprava, biela bunda s potlačou, modrý teplák, vel. 80	67	2	f	-	0	19	1	2012-10-13 08:32:01+02
2594	riflové nohavice, červená široká guma na páse, vel. 9-12m.	67	2	f	-	0	20	1	2012-10-13 08:32:03+02
2595	tepl. súpr. Lonsdale, ružovo-šedá, bunda pásiky + kapuca, vel.12-18m.	67	4.5	f	-	0	21	1	2012-10-13 08:32:07+02
2596	ružová tepl. súprava s Minie s modrými trblietkami,vel. 12-18 m.	67	3	f	-	0	22	1	2012-10-13 08:32:10+02
2597	biely flisový kabátik, vnútro fialové guličky, dvojrad. zap. vel. 80	67	4.5	f	-	0	23	1	2012-10-13 08:32:12+02
2583	fialová háčkovaná čiapka s kvetinkou a bielym lemom, vel. 6-9 mes. 	67	1.5	f	-	0	9	2	2012-10-13 19:11:27+02
2561	Mikina - tepláková bunda, šedá, na zips, vpredu vrecká (3-4yrs) 	66	2.5	f	-	0	37	2	2012-10-14 12:50:36+02
2600	predlžená mikina s kapuc. šedá s kamienkami, vel. 10-11rokov	67	2	f	-	0	26	1	2012-10-13 08:32:27+02
2601	šedý pásikavý rolák s mašličkami na vreckách, vel. 152	67	2	f	-	0	27	1	2012-10-13 08:32:31+02
2602	fialové šaty s károsukňou a opaskom, vel. 146	67	4	f	-	0	28	1	2012-10-13 08:32:33+02
2566	Nohavice - bledohnedé menžestráky -RESERVED kids(116cm)	66	1.2	f	-	0	42	2	2012-10-13 16:04:20+02
2569	Vesta -prešívaná šedo-zelená, teplá -CHEROKEE (2-3yrs)	66	6	f	-	0	45	2	2012-10-13 18:22:48+02
2605	čiernobiely kockovaný kabátik s kapucou, vel. 10-11 rokov	67	12	f	-	0	31	1	2012-10-13 08:32:44+02
2606	ružová šušť. bunda, vel. 11-12 rokov	67	7	f	-	0	32	1	2012-10-13 08:33:08+02
2607	kožená bunda, biela káva, patenty dole aj na rukávoch, vel. 9-10 rokov	67	16	f	-	0	33	1	2012-10-13 08:33:12+02
2558	Mikina -bledohnedá,obrázok:los,stromčeky,vrchy-GEORGE(3-6 Months)	66	2.2000000000000002	f	-	0	34	1	2012-10-13 10:00:52+02
2573	Overal - bledohnedý,kapucňa s kožušinkou,krytý zips,gombíky do slučiek, vpredu dve vrecká, ľavý rukáv vrecko(veľ.92cm) 	66	3.5	f	-	0	49	2	2012-10-13 17:49:24+02
2562	Mikina - tmavomodrá na zips s kapucňou,patenty pásikové,rukávy:pásy ako patent(veľ-110)	66	2.7000000000000002	f	-	0	38	1	2012-10-13 10:01:06+02
2585	ružový overal s kapucou s uškami, pol pásiky, II.pol s mackom, vel.68	67	1.8999999999999999	f	-	0	11	2	2012-10-13 15:40:33+02
2599	biele hačkované bolerko so srdiečkami, vel. 146	67	1	f	-	0	25	2	2012-10-14 12:31:05+02
2598	šedá mikina s ruž. srdcom a flitrami + kapuca, vel.146/152	67	3	f	-	0	24	2	2012-10-13 18:46:04+02
2587	ružová zateplená súpr. s drobnými bodkami a mašlou na bundičke, 68	67	3.5	f	-	0	13	2	2012-10-13 16:06:08+02
2572	Bunda -zimná s kapucňou, hnedo-oranž.-bledohnedá,nápis:STRONG 1989 (veľ.116)	66	3.2000000000000002	f	-	0	48	2	2012-10-13 15:30:01+02
2591	ružové tričko s čierno strieb. kvetinkami a tmavoruž. bolérkom, vel. 80	67	2	f	-	0	17	2	2012-10-13 18:31:20+02
2568	Vesta -bledohnedá, vpredu 4 vrecká	66	1.3	f	-	0	44	2	2012-10-13 18:22:48+02
2564	Nohavice - tmavohnedé menžestráky - CHEROKEE (2-3yrs)	66	2.5	f	-	0	40	2	2012-10-14 09:48:06+02
2613	tmavomodré tepláky, zn. F&F, veľ. 0-3 mes.	68	1.5	f	-	0	6	2	2012-10-13 16:43:26+02
2563	Tepláky - čierne s bielym pásikom na bokoch - CHEROKEE(3-4yrs)	66	1.5	f	-	0	39	2	2012-10-13 15:33:34+02
2589	ružové tepláky na traky so srdiečkami a nápisom Som..., vel. 80	67	2	f	-	0	15	2	2012-10-13 18:07:21+02
2608	dvojvrstvová čiapka, bielo-modrý pásik, zn. monak, veľ. 40-42 cm	68	2	f	-	0	1	2	2012-10-13 15:51:45+02
2617	biela obojstranná mikinka, pásik-hviezdičky, veľ. 68	68	1.5	f	-	0	10	1	2012-10-13 11:32:26+02
2616	bledomodrá mikinka s kapucňou, zn. motion wear, veľ. 68	68	2	f	-	0	9	1	2012-10-13 11:32:32+02
2603	tepl. súpr. žltá bunda-šedé nohavice, vel. 152/158	67	5	f	-	0	29	2	2012-10-13 16:03:35+02
2614	šedé tričko mcqueen,s červeným autíčkom, zn. disney, veľ. 0-3 mes.	68	1	f	-	0	7	1	2012-10-13 11:32:40+02
2579	čierne kožené topánky so zelenou apl. na suchý zips, vel. 20	67	2.8999999999999999	f	-	0	5	2	2012-10-13 16:52:37+02
2612	bledohnedé kárované nohavice, podšité bavlnou, zn. dopo mini, veľ. 62	68	2	f	-	0	5	1	2012-10-13 11:33:00+02
2611	tmavomodré nohavice, podšité bavlnou, zn. okay, veľ. 62	68	2	f	-	0	4	1	2012-10-13 11:33:05+02
2610	bledošedá prešívaná zateplená bundička, zn. F&F, veľ. 3-6 mes.	68	4	f	-	0	3	1	2012-10-13 11:33:10+02
2609	flisový bledomodrý overal, zn. playshoes, veľ. 62	68	4	f	-	0	2	1	2012-10-13 11:33:14+02
2615	šedé polotričko, zn. snoopy, veľ. 68	68	1	f	-	0	8	2	2012-10-13 15:51:45+02
2567	Rifle - modré, na ľavej nohe vrecko a nášivka FULL POWER 23 -lupilu (116cm) 	66	2	f	-	0	43	2	2012-10-13 15:26:40+02
2640	škoricové tehotenské nohavice, zn. maderna, veľ. 36-38	68	7	f	-	0	33	1	2012-10-13 11:30:11+02
2639	červené kárované papučky, dĺžka podrážky 12,5 cm	68	1.5	f	-	0	32	1	2012-10-13 11:30:16+02
2637	zelené nohavice, zn. yes kids, veľ. 4 	68	2	f	-	0	30	1	2012-10-13 11:30:25+02
2636	ružová nepremokavá bunda, veľ. 122/128 	68	4	f	-	0	29	1	2012-10-13 11:30:30+02
2635	čierna zimná bunka, kapucňa s kožušinkou, zn. reserved, v. 116	68	6	f	-	0	28	1	2012-10-13 11:30:35+02
2634	ružová čiapka, našivka macka vpredu, zn. euro-term, veľ. 2	68	1	f	-	0	27	1	2012-10-13 11:30:41+02
2633	ružová čiapka, vyšité kvetinky vpredu, zn. aquamarine, veľ. 48 cm	68	1	f	-	0	26	1	2012-10-13 11:30:44+02
2628	chlpatá ružová súprava - čiapka, bundička, nohavice, veľ. 80	68	2.5	f	-	0	21	1	2012-10-13 11:31:23+02
2627	bledoružová mikinka, zn. hanny, veľ. 74	68	1.5	f	-	0	20	1	2012-10-13 11:31:41+02
2625	ružová zimná čiapka, vpredu kožišinka, nášivka macka, veľ. 40-42 cm	68	2	f	-	0	18	1	2012-10-13 11:31:47+02
2624	rifle, vpredu nášivka veverička, vzadu hrošík, zn. okay, veľ. 68	68	2.5	f	-	0	17	1	2012-10-13 11:31:52+02
2623	biele body 3 ks, 2 so vzorom, 1 žlto-biely pásik, zn. F&F, veľ. 3-6 mes.	68	2	f	-	0	16	1	2012-10-13 11:31:54+02
2622	modré body 3 ks, 2 s tigríkom, modro-biely pásik, zn. disney, v. 3-6 m.	68	3	f	-	0	15	1	2012-10-13 11:31:59+02
2621	overaly 3 ks, 2 s levíkmi, 1 modro-biely pásik, zn. F&F, veľ. 0-3 mes.	68	3	f	-	0	14	1	2012-10-13 11:32:03+02
2620	overaly 2 ks, modrý s tigríkom, modro-biely pásik, zn. disney, v.0-3 m.	68	3	f	-	0	13	1	2012-10-13 11:32:08+02
2618	súprava-obojstranná mikinka, 2 ks polodupačky, zn. F&F, veľ. 6-9 mes.	68	4	f	-	0	11	1	2012-10-13 11:32:22+02
2638	šedá zimná čiapka, s očkami a uškami, zn. F&F, veľ. 1-2 r.	68	1	f	-	0	31	2	2012-10-13 17:10:51+02
2619	polodupačky 2ks, bledomodré, modro-biely pásik, zn. F&F, v. 3-6 mes.	68	2	f	-	0	12	2	2012-10-13 17:10:51+02
2630	biele tričko, nášivky stromčeky, mačičky, zn. cherokee, veľ. 86	68	1	f	-	0	23	2	2012-10-13 18:20:14+02
2632	ružová flisová mikinka s kapucňou, nášivka macko, veľ. 6-9 mes.	68	2	f	-	0	25	2	2012-10-13 18:57:46+02
2631	tričká 2 ks, modré a biele, nariasený okraj, zn. cherokee, veľ. 86	68	1	f	-	0	24	2	2012-10-13 19:11:27+02
2626	ružová dvojvrstvová čiapka, vpredu korytnačka, veľ. 40-42 cm	68	1	f	-	0	19	2	2012-10-14 10:36:19+02
2629	súprava - šedé nohavice, 2ks tričká, zn. adams kids, veľ. 86	68	4	f	-	0	22	2	2012-10-14 10:40:27+02
2737	dievčenské papuče, vel.20, 2 ks	69	1.5	f	-	0	47	1	2012-10-13 11:31:21+02
2738	dievčenské topánky, ružovo-biele, protetika,vel.20	69	7	f	-	0	48	1	2012-10-13 11:31:29+02
2698	vyteplené rifle,vpredu na kolenách kvetinky,vel.74,next,1 ks	69	1.5	f	-	0	8	2	2012-10-13 16:34:29+02
2732	modrý flisovaný komplet, zn.chicco, vel.56,2 ks	69	1.6000000000000001	f	-	0	42	2	2012-10-13 18:40:10+02
2725	ružová jesenná bunda, s kapucou, vel.S,1 ks	69	2.5	f	-	0	35	2	2012-10-13 16:44:40+02
2691	ružová zimná bunda s kapucou,vel.9-12 mes,1 ks	69	3	f	-	0	1	1	2012-10-13 11:32:19+02
2693	fialový overal na gombíky, kapuca,vpredu motív srnky,vel74,1 ks	69	8	f	-	0	3	1	2012-10-13 11:32:32+02
2695	biely novorodenecký overal s výšivkou na cvoky, vel.62, 1 ks	69	8	f	-	0	5	2	2012-10-13 16:25:44+02
2696	zelená bunda s kapucou, vpredu motív mačky,next,vel.98,1 ks	69	6	f	-	0	6	2	2012-10-13 16:34:06+02
2715	biele body,hore na bokoch na cvoky,zn.sofija,vel.68,1 ks	69	1	f	-	0	25	1	2012-10-13 11:32:57+02
2716	semišový ružový komplet,vpredu s ovečkou,zn.HM,vel.62,2 ks	69	3	f	-	0	26	1	2012-10-13 11:33:04+02
2731	ružov dupačkové nohavice,HM,vel.56,1 ks	69	0.80000000000000004	f	-	0	41	2	2012-10-14 10:22:23+02
2701	ružové tepláky, vel.9-12 mes, 1 ks	69	1	f	-	0	11	2	2012-10-13 17:50:54+02
2710	kvietkované tričko,biely dlhý rukáv,vel.68,1 ks	69	1	f	-	0	20	2	2012-10-13 17:30:27+02
2739	dievčenská čiapka, vpredu mačka, biely volánik, 1 ks	69	2	f	-	0	49	2	2012-10-13 19:11:27+02
2721	ružová vyteplená bundička s kapucou, mačka,vel.9-12 me,1 ks	69	1	f	-	0	31	1	2012-10-13 11:33:35+02
2722	bodkované dupačky na cvoky,vpredu mašla,vel. 62, 1 ks	69	2.5	f	-	0	32	1	2012-10-13 11:33:39+02
2724	dlhé modré rifle, vel. 152, 1 ks	69	0.90000000000000002	f	-	0	34	1	2012-10-13 11:33:48+02
2699	semišová bundička bielo-ružová s kapucou,vel.12-18 mes,1 ks	69	1.8	f	-	0	9	2	2012-10-13 17:30:27+02
2706	ružový pletený svetrík na 2 gombíky vpredu,vel.9 mes,1 ks	69	2	f	-	0	16	1	2012-10-13 11:34:10+02
2697	fialová flisovaná bunda s kapucou,na pravej str.vačok,vel.74,1 ks	69	2	f	-	0	7	2	2012-10-13 18:03:40+02
2708	pásikavé tričko modro-biele,next,vel.3-6 mes,1 ks	69	2	f	-	0	18	1	2012-10-13 11:34:23+02
2709	biele tričko,dlhký rukáv,zn.ca,vel.74,1 ks	69	1.5	f	-	0	19	1	2012-10-13 11:34:27+02
2707	overa-žltý vyteplený na traky,disney,vel.74,1 ks	69	2	f	-	0	17	2	2012-10-13 17:56:04+02
2714	biele novorodenecké tričká na bočné zapínanie,vel.62,3 ks	69	2.5	f	-	0	24	2	2012-10-13 16:02:17+02
2711	kockovaná košela,biely dlhý rukáv,vel.68,1 ks	69	1.5	f	-	0	21	1	2012-10-13 11:34:46+02
2713	zelená zimná bunda na zips,vpredu 2 gombíky,zara baby,vel.2-3,1 ks	69	6	f	-	0	23	2	2012-10-13 16:08:53+02
2712	štrikovaný pulovrik, hnedo-biely,s V,zn.zara baby,vel.9-12mes,1 ks	69	3	f	-	0	22	1	2012-10-13 11:34:50+02
2743	Tenisky adidas biele ,dlžka nozky 14,5cm	70	5	f	-	0	3	1	2012-10-13 11:35:00+02
2744	Topanočky vyššie hnedé na boku BG,dlžka nožky15cm	70	5	f	-	0	4	1	2012-10-13 11:35:05+02
2740	pásikavá dievčenská čiapka,vpredu kvetym RDX,1 ks	69	2	f	-	0	50	2	2012-10-13 18:07:21+02
2694	žltá zimná bunda s kapucou a kožušinou,vel.9-12 mes, 1 ks	69	2.5	f	-	0	4	2	2012-10-13 18:38:14+02
2700	menžestrákové kvietkované nohavice, dole na gumu,vel.74,1 ks	69	2	f	-	0	10	1	2012-10-13 11:35:04+02
2729	ružové flisované nohavičky pre novor,vlavo medved,vel.62,1 ks	69	1	f	-	0	39	2	2012-10-14 10:22:23+02
2702	vyteplené bledé rifle s kvetinkou na pravej nohe,vel.6-9 mes,1 ks	69	1.8	f	-	0	12	2	2012-10-13 18:07:21+02
2745	Pršiplašt modry s bielymi motylikmi 12-18 m.	70	8	f	-	0	5	2	2012-10-13 18:23:19+02
2703	ružové tepláky, skôr cyklamenové, vel.9-12 mes,1 ks	69	1	f	-	0	13	1	2012-10-13 11:35:14+02
2704	ružový svetrík na gombíky, zn:HM,vel.74,1 ks	69	3	f	-	0	14	1	2012-10-13 11:35:56+02
2718	body so sloníkom,bavlnené,japitex,vel.68,1 ks	69	0.80000000000000004	f	-	0	28	2	2012-10-13 17:30:27+02
2705	ružové tepláky,zn.HM,vel.74,1 ks	69	1	f	-	0	15	1	2012-10-13 11:36:05+02
2726	riflová sukna, vzadu mašla, 1 ks	69	1	f	-	0	36	1	2012-10-13 11:36:10+02
2719	body so žirafou, bavlnené,vel.68,1 ks	69	0.80000000000000004	f	-	0	29	2	2012-10-13 17:30:27+02
2727	riflová sukna, vpredu náps girls stam, 1 ks,	69	0.80000000000000004	f	-	0	37	1	2012-10-13 11:36:19+02
2742	Cižmičky ružové s kožušinkou vnutri,dlžka nožky 12cm	70	2.5	f	-	0	2	2	2012-10-13 15:44:08+02
2723	kompelt-svetrík a dupačky,vpredu slimáky,vel.62,2 ks	69	3.7999999999999998	f	-	0	33	2	2012-10-14 11:17:02+02
2730	bodkované -bielo-ružové dupačkové nohavice,HM,vel.56,1 ks	69	0.80000000000000004	f	-	0	40	1	2012-10-13 11:36:31+02
2733	modré flisované dupačkové nohavice, loana,vel.56,1 ks	69	0.80000000000000004	f	-	0	43	2	2012-10-14 12:58:25+02
2717	pásikavé červen body,velk.74,1 ks	69	0.80000000000000004	f	-	0	27	2	2012-10-14 10:07:54+02
2734	modré flisované dupačkové nohavice, vel.3-6 mes., 1 ks	69	0.5	f	-	0	44	1	2012-10-13 11:36:44+02
2735	flisované fialové nohavice, vel.62, 1 ks	69	0.80000000000000004	f	-	0	45	1	2012-10-13 11:36:48+02
2736	flisované pásikavé nohacice, vel.62,1 ks	69	0.80000000000000004	f	-	0	46	1	2012-10-13 11:36:49+02
2746	Bundička ružová so zajačikom vpredu,s kapucnou 6-9 m.	70	8	f	-	0	6	2	2012-10-14 10:16:27+02
2720	biele dupačky vpredu zo zajacom, vel. 56,1 ks	69	1.8	f	-	0	30	2	2012-10-13 18:40:10+02
2692	bodkovany kabatik	69	2	f	-	0	2	1	2012-10-13 11:37:34+02
2741	Cižmičky fialove s kvietkami,dlžka nožky 12cm	70	2.5	f	-	0	1	2	2012-10-13 15:44:08+02
2728	ružová flisovaná bunda,s kapucou, vel.122,1 ks	69	1	f	-	0	38	2	2012-10-13 15:20:36+02
2777	modrá mikina s mackom velkost 74	71	1	f	-	0	2	1	2012-10-13 08:13:04+02
2779	modrá Adidas mikina velkost 68	71	1	f	-	0	4	1	2012-10-13 08:13:43+02
2778	červená mikina, vpredu vprecko	71	2	f	-	0	3	1	2012-10-13 08:13:35+02
2780	šedo-modrá mikina s ovečkou, velkost 6-9mes	71	2	f	-	0	5	1	2012-10-13 08:13:54+02
2785	hnede menčestraky, vel.62	71	2	f	-	0	10	2	2012-10-14 10:25:05+02
2782	modrá mikina , velkost 62	71	1	f	-	0	7	1	2012-10-13 08:14:08+02
2783	ružová mikina 	71	1.5	f	-	0	8	1	2012-10-13 08:14:13+02
2784	hnede nohavice, velkost 74	71	1.5	f	-	0	9	1	2012-10-13 08:14:22+02
2768	Menžestrové šaty,fialové s ružovymi malymi kvietkami,3-6 m.	70	3	f	-	0	28	2	2012-10-14 10:29:01+02
2786	červené nohavice	71	1.5	f	-	0	11	1	2012-10-13 08:14:40+02
2787	rifle	71	2.1000000000000001	f	-	0	12	1	2012-10-13 08:14:49+02
2759	Svetrik s kapucou šedo-biele pasiky,červeny lem,12-18 m.	70	3.5	f	-	0	19	2	2012-10-13 17:24:17+02
2760	Biely overal na spanie,s mackom vpredu,6-9 m.	70	3.5	f	-	0	20	2	2012-10-13 16:41:59+02
2790	rifle na traky, 	71	2.1000000000000001	f	-	0	15	1	2012-10-13 08:15:15+02
2791	modré pruzkove nohavice	71	1.6000000000000001	f	-	0	16	1	2012-10-13 08:15:24+02
2792	zelené nohavice	71	1.6000000000000001	f	-	0	17	1	2012-10-13 08:15:29+02
2793	blede nohavice	71	2.1000000000000001	f	-	0	18	1	2012-10-13 08:15:37+02
2794	modre trakove nahovice	71	3.1000000000000001	f	-	0	19	1	2012-10-13 08:15:45+02
2795	modre teplaky	71	1.3	f	-	0	20	1	2012-10-13 08:15:52+02
2796	bledo modre teplaky	71	1.3	f	-	0	21	1	2012-10-13 08:15:58+02
2798	šede teplaky	71	1	f	-	0	23	1	2012-10-13 08:16:09+02
2799	čierne teplaky	71	1	f	-	0	24	1	2012-10-13 08:16:15+02
2800	modre teplaky so sedými patentami	71	1	f	-	0	25	1	2012-10-13 08:16:21+02
2801	modre teplaky s kapsickou na boku	71	1	f	-	0	26	1	2012-10-13 08:16:24+02
2802	zelena bunda	71	2.6000000000000001	f	-	0	27	1	2012-10-13 08:16:31+02
2820	Bunda kaki , vnútro červené	72	4	f	-	0	8	2	2012-10-14 11:00:00+02
2805	bledohneda ciapka	71	1	f	-	0	30	1	2012-10-13 08:17:20+02
2806	zelena čiapka	71	1	f	-	0	31	1	2012-10-13 08:17:23+02
2807	modra čiapka	71	1	f	-	0	32	1	2012-10-13 08:17:45+02
2808	ruzový overal	71	2.1000000000000001	f	-	0	33	1	2012-10-13 08:17:48+02
2809	zlty overal	71	3	f	-	0	34	1	2012-10-13 08:17:56+02
2773	Tričko s dlhym rukavom,pasikove,oranžovy lem pri krku,6-9 m.	70	1.5	f	-	0	33	2	2012-10-13 15:51:45+02
2761	Rifle modré s ružovym pásom na šnurku,12-18 m.	70	4	f	-	0	21	2	2012-10-13 15:34:57+02
2815	Modrá zimná bunda nike	72	8	f	-	0	3	2	2012-10-14 10:09:32+02
2781	oranžova mikina, velkost 62-68	71	2	f	-	0	6	2	2012-10-14 10:16:26+02
2813	Ružová bunda	72	3	f	-	0	1	1	2012-10-13 10:52:40+02
2814	Mikina tmavo modrá	72	1.7	f	-	0	2	1	2012-10-13 10:52:54+02
2819	Sveter dlhý šedý dievčenský	72	3	f	-	0	7	1	2012-10-13 10:53:18+02
2818	Mikina modrá	72	1.7	f	-	0	6	1	2012-10-13 10:53:27+02
2817	Rifle dievčenské	72	2	f	-	0	5	1	2012-10-13 10:53:43+02
2816	Riflová bunda s kožušinkou	72	3	f	-	0	4	1	2012-10-13 10:53:54+02
2756	Mikinka zeleno-šeda pasiková s levikom vpredu,vel.80	70	2.5	f	-	0	16	2	2012-10-14 13:00:39+02
2811	hnede s cervenými pruzkami topanocky	71	3.1000000000000001	f	-	0	36	2	2012-10-13 15:29:14+02
2747	Mikina so zajačikom fialová ,vel.80	70	2.5	f	-	0	7	1	2012-10-13 11:35:24+02
2748	Mikina šedá s červenym rukavom a s kapucou,vel.86	70	3	f	-	0	8	1	2012-10-13 11:35:29+02
2749	Flisová mikinka,modrá s kvietkami s kapucou,vel.86	70	3	f	-	0	9	1	2012-10-13 11:35:33+02
2750	Ružová mikina s kvietkom vpredu s kapuckou,vel.86	70	3	f	-	0	10	1	2012-10-13 11:35:39+02
2751	Fialová mikina pasiková s kapucou,s mašličkou naspodu 0-3 m.	70	3	f	-	0	11	1	2012-10-13 11:35:43+02
2772	Tričko s dlhym rukavom,bielo-červené s kvietkami,12-18 m.	70	1.5	f	-	0	32	2	2012-10-13 17:06:36+02
2753	Bundička flisová tmavoružová s kvietkami,s kapucou,vačky,vel.80/86	70	4	f	-	0	13	1	2012-10-13 11:37:17+02
2763	Mikina ružová s kapucou vpredu,vyšivana+flitre,vel.68	70	3	f	-	0	23	2	2012-10-13 19:11:09+02
2755	Suprava biela flisová,teplacky+mikina,mašlicka ,6-9 m.	70	4	f	-	0	15	1	2012-10-13 11:37:24+02
2757	Suprava ružová,teplačky+mikina,vpredu motyliky a kvietky,6-12 m.	70	4	f	-	0	17	1	2012-10-13 11:37:32+02
2771	Tričká 3 kusy,dlhy rukav,červený pasik,hnedy pasik,bežove,6-12 m.	70	4	f	-	0	31	2	2012-10-13 18:37:02+02
2775	Fusak ružový s tmavoružovym lemom na rukavoch,baby,9-12 m.	70	8	f	-	0	35	2	2012-10-13 17:50:54+02
2752	Biela kožušinová bundička s kapucou,s uškami a myškou 0-3 m.	70	2.5	f	-	0	12	2	2012-10-13 17:06:36+02
2766	Menžestrové hnede nohavice,oteplene,so žltou kvetinkou,vel.92	70	3.5	f	-	0	26	2	2012-10-13 15:39:02+02
2789	pruzkove nohavice	71	1.6000000000000001	f	-	0	14	2	2012-10-13 16:11:13+02
2822	Oteplovaky smotanové	72	4	f	-	0	10	2	2012-10-14 09:23:58+02
2764	Tričko modré s dlhym rukavom okolo krku vyšivka+gombiky,9-12 m.	70	1.5	f	-	0	24	1	2012-10-13 11:38:04+02
2765	Mikina červená kombinovaná s modrym pásikom,vpredu macko,vel.92	70	2.5	f	-	0	25	1	2012-10-13 11:38:11+02
2810	topanockiy picco	71	3.1000000000000001	f	-	0	35	2	2012-10-13 15:48:43+02
2804	oteplovacky modre	71	3.1000000000000001	f	-	0	29	2	2012-10-14 10:50:29+02
2767	Suprava,riflové šaty+tričko pásikové farebne,6-12 m.	70	4	f	-	0	27	2	2012-10-14 10:40:27+02
2769	Pančušky ružové so sukničkou,s havkom,vel.68/74	70	2	f	-	0	29	1	2012-10-13 11:38:28+02
2770	Mikina žlta flisovás kapucou,s rybkami a mackom,vel.9 mesiacov	70	2.5	f	-	0	30	1	2012-10-13 11:38:32+02
2774	Fusak ružovy kožušinkový s kapucou,zajko dole vpredu,6-9 m.	70	8	f	-	0	34	2	2012-10-13 18:41:41+02
2788	rifle s opaskom	71	2.1000000000000001	f	-	0	13	2	2012-10-13 17:10:51+02
2762	Ružovy župan s kapucou so zajkom vpredu,vel.92	70	5	f	-	0	22	2	2012-10-13 15:56:01+02
2754	Bundička ružová s kapucou,vpredu vyšite kvietky,vačky,vel.92	70	3	f	-	0	14	2	2012-10-13 18:49:05+02
2758	Bunda zimná ružova s mackom vpredu,kožušinka vnutri,vel.80	70	5	f	-	0	18	2	2012-10-13 18:20:14+02
2821	Kabát čierny, vnútro ružové	72	8	f	-	0	9	2	2012-10-13 15:01:38+02
2882	Čižmy čierne s bielou kožušinou vnútri a bielou podrážkou nové, veľ.21	73	1.5	f	-	0	40	1	2012-10-13 08:56:08+02
2860	topánky semišové kotníkové bledohnedé s kožušinou Wuzhou, veľ. 30	73	1.5	f	-	0	18	1	2012-10-13 08:56:20+02
2881	čižmy čierne so strieborným vzorom, Icetex, veľ. 38	73	2	f	-	0	39	1	2012-10-13 08:56:30+02
2868	pyžamo zeleno-modré nové Formycula, veľ. 164	73	1	f	-	0	26	2	2012-10-13 18:07:58+02
2861	topánky bielo-modré s kožušinovou výplňou Conway, veľ. 29	73	1	f	-	0	19	1	2012-10-13 08:56:55+02
2872	trigovica bielo-ružová X-Mail, veľ. 140	73	1	f	-	0	30	2	2012-10-13 18:46:04+02
2839	Mikina zelené s kožušinkou	72	5	f	-	0	27	2	2012-10-13 15:26:40+02
2886	trigovica čierna,šedopásik.vklad vo V-výstrihuSTACCATO, v.M=ca140	73	1.5	f	-	0	44	1	2012-10-13 09:13:45+02
2834	Čižmy hnedé	72	4	f	-	0	22	2	2012-10-13 18:18:10+02
2869	sveter pásikavý bielo- bledomodro-sýtomodrý Baty Fashion 2, veľ. 140	73	1	f	-	0	27	2	2012-10-13 18:46:04+02
2879	Tričko s dlhým rukávom zelené V a vzorom, KIKStar, 140	73	1	f	-	0	37	2	2012-10-13 15:19:34+02
2855	nové čierne kotníkové topánku, vnútri kužušina Tao, veľ. 20	73	1.5	f	-	0	13	2	2012-10-13 17:26:55+02
2878	rolák bielo-ružovo-žlto-modro-zelený Only, veľ.S	73	1.5	f	-	0	36	1	2012-10-13 09:14:33+02
2885	rolák pásik. Ruž-biel-hnedý CRASH, v.140	73	1.5	f	-	0	43	2	2012-10-13 17:26:55+02
2851	tepláky flisové tmavomodré Dopodopo  veľ.140	73	1	f	-	0	9	1	2012-10-13 09:14:43+02
2874	tepláky biele s červeným pásikom na boku Children, veľ. 132	73	2	f	-	0	32	1	2012-10-13 09:14:48+02
2853	biele trčiko slávnostné s bielim vzorom vpredu bez zn. veľ. cca 134	73	1.5	f	-	0	11	2	2012-10-13 18:46:04+02
2887	Nohavice dlhé bledomodréMIXED. FIBRES, v.9-10r	73	1.5	f	-	0	45	1	2012-10-13 09:15:10+02
2870	rifle modré dievčenské Here There, veľ. 146	73	3	f	-	0	28	1	2012-10-13 09:15:19+02
2858	biele tričko s hnedými korálikmi vpredu ,bez zn. veľ. cca 134	73	1	f	-	0	16	2	2012-10-14 11:21:04+02
2857	zimná čiapka ružová indiánska s flaušovým vnútrom, veľ. 10 rokov	73	1	f	-	0	15	2	2012-10-13 16:57:51+02
2877	Tričko s dlhým rukávom čierne s ružovobielym vzorom, veľ.134	73	1.5	f	-	0	35	2	2012-10-13 17:09:37+02
2863	rolák béž.-oranž.-hnedý Breeze, veľ. cca 134	73	2	f	-	0	21	1	2012-10-13 09:15:41+02
2876	Tričko s dlhým rukávom čierne so strieb.vzorom, vel.134-140	73	1.5	f	-	0	34	2	2012-10-13 18:11:14+02
2859	biela košeľa bez zn. veľ. cca 146	73	1.5	f	-	0	17	2	2012-10-14 09:44:16+02
2875	Tričko s dlhým rukávom ružové so strieb.hviezdou ONE, veľ. 140	73	1.5	f	-	0	33	1	2012-10-13 09:16:19+02
2889	tričko biele v-výstrih,ROBENTON, v.M= ca140	73	1	f	-	0	47	1	2012-10-13 09:16:24+02
2865	sveter ružový nový s bielimi pásmi, veľ. 140	73	2	f	-	0	23	1	2012-10-13 09:17:01+02
2837	Modré tričko pásikavé, dlhý rukáv	72	1.2	f	-	0	25	2	2012-10-14 10:00:32+02
2856	zimná čiapka červená indiánska s flaušovým vnútrom, veľ. 10 rokov	73	1	f	-	0	14	2	2012-10-13 16:44:41+02
2852	rolák pásikavý biel.-mod.-fial. Cherokee veľ.10 rokov	73	1	f	-	0	10	2	2012-10-13 17:26:55+02
2864	rolák čierko- šedo- béžový Breeze, veľ. cca 134	73	1.5	f	-	0	22	2	2012-10-13 18:10:52+02
2871	sveter béžový chlapčenský so zipsom Pro-Tec, veľ. 8 rokov	73	1	f	-	0	29	1	2012-10-13 09:17:58+02
2849	trigovica tmavomodrá v-výstrih, nápis BODY MEVR,v. 152	73	1	f	-	0	7	1	2012-10-13 09:18:07+02
2883	rolák bledoružový bez zn. veľ. 128	73	1.5	f	-	0	41	2	2012-10-13 17:26:55+02
2843	zimná bledomodrá bunda Etirel, veľ. 140	73	2	f	-	0	1	1	2012-10-13 09:18:21+02
2867	košeľa s vestou v jednom Michele Boyard, veľ 36	73	2	f	-	0	25	2	2012-10-13 18:13:48+02
2848	jesenná hnedá bunda Lu Kai, veľ. 146	73	2	f	-	0	6	2	2012-10-13 15:20:36+02
2845	zimná tmavomodrá bunda s kapucou a košušinou School Life, veľ. 140	73	2	f	-	0	3	1	2012-10-13 09:18:43+02
2873	sveter pásikavý bielo-bledozeleno -sýtozelený Baty Fashion 2, veľ. 140	73	2	f	-	0	31	1	2012-10-13 09:18:51+02
2846	bledomodrá vesta s kapucou a ružovým flaušovým futrom, veľ. 	73	2	f	-	0	4	1	2012-10-13 09:18:59+02
2844	čierna zimná bunda s kapucou s kožušinou Fishbone, veľ. XS	73	3	f	-	0	2	1	2012-10-13 09:19:05+02
2866	jesenná čierna chlapčenská bunda CEYLAN, veľ. 160	73	4	f	-	0	24	1	2012-10-13 09:19:10+02
2838	Zelené pásikavé tričko, dlhý rukáv	72	1.2	f	-	0	26	1	2012-10-13 10:49:24+02
2880	Tričko s dlhým rukávom pásik,čiernomodré batik, Starangel, veľ. 134	73	1	f	-	0	38	1	2012-10-14 11:18:53+02
2888	nohavice dlhé bledovínové, znacka R- v krúžku,v.150	73	1	f	-	0	46	2	2012-10-13 18:31:20+02
2830	Pyžamo spiderman- šedo čierne	72	2	f	-	0	18	1	2012-10-13 10:50:15+02
2835	Tepláková súprava modrá	72	3	f	-	0	23	1	2012-10-13 10:50:32+02
2826	Šuštiakové nohavice šedé	72	1.7	f	-	0	14	1	2012-10-13 10:51:01+02
2833	Čižmy ice tex čierno šedé	72	10	f	-	0	21	1	2012-10-13 10:51:14+02
2836	Čierne tričko puma	72	4	f	-	0	24	2	2012-10-13 18:20:47+02
2825	Tričko hnedé, dlhý rukáv	72	1.3	f	-	0	13	2	2012-10-13 15:49:54+02
2840	Modrá vesta	72	1	f	-	0	28	2	2012-10-14 14:08:20+02
2827	Šuštiakové nohavice čierne adidas	72	3	f	-	0	15	1	2012-10-13 10:52:16+02
2850	tepláky oranžové Nike veľ.140	73	2	f	-	0	8	2	2012-10-13 16:36:44+02
2828	Mikina bledomodrá s kosoštvorcami	72	2	f	-	0	16	1	2012-10-13 10:52:45+02
2829	Tričko bledomodré spongy bob	72	1.3	f	-	0	17	1	2012-10-13 10:52:48+02
2847	jesenná oranžová bunda Etirel  na 14 r. veľ 164 	73	2	f	-	0	5	2	2012-10-13 15:01:38+02
2831	Bunda adidas biela	72	12	f	-	0	19	1	2012-10-13 10:54:45+02
2890	modré flisové gaťuše na traky, vpredu zajko,hnedé lemovanie, veľ.62	74	2	f	-	0	1	1	2012-10-13 11:54:38+02
2891	ružový flisový overal, vpredu macko, hnedé lemovanie, veľ.62	74	2.5	f	-	0	2	1	2012-10-13 11:54:43+02
2832	Sveter dlhý farebný	72	3	f	-	0	20	2	2012-10-13 14:59:36+02
2937	tmavomodré slim rifle,vzadu vačky,veľ.104	74	2.5	f	-	0	48	2	2012-10-14 12:49:03+02
2943	syto zlte chlpate nohavice s naprsenkou s 3 mackami,velkost neuvedena, ale asi 62	75	2	f	-	0	4	1	2012-10-13 10:06:29+02
2933	súprava bavlnené dupačky+body modrý pásik,veľ.62	74	3.5	f	-	0	44	2	2012-10-13 17:03:24+02
2941	cerv.overal s kapuc.s brmb.vlavo vys.fareb.postava, zapin.hore aj na noh.na cvoky, pred.vac.vysiv, v. 68, z. Cadette Rouselle	75	4	f	-	0	2	1	2012-10-13 10:06:55+02
2940	tm.mod.plet. kompletne kozusinou podsity svetrik s kapucnou na zips, zn. Cherokee,v.68	75	5	f	-	0	1	1	2012-10-13 10:07:01+02
2939	ružové body so sivými pásikmi, volániky na rukávoch,veľ.68	74	2	f	-	0	50	2	2012-10-13 16:46:23+02
2944	obojstr.cerv.overal,vlavo s nasit. mackom, viacfareb.lemy,2 vrec.,stah. v pase na snur., zapin. na zips, v. 74/80, zn. Formicula 	75	5	f	-	0	5	1	2012-10-13 10:07:25+02
2946	cervene capacky, biele kozusinkove lemovanie,zn. Smyk-Land, v.11	75	2	f	-	0	7	1	2012-10-13 10:07:32+02
2936	čierne+fialové,strieborné kotníkové tenisky s hviezdičkami,veľ.26	74	5	f	-	0	47	1	2012-10-13 11:51:43+02
2909	cyklménová súprava,tepláky+mikina s kapucou, pásikové ukončenie,veľ.74	74	4	f	-	0	20	1	2012-10-13 11:51:52+02
2945	sedo-hnedy sustiak. overal, kapucna s kozus., navleky na nohach, zapin. na 2 zipsy, vlavo vysity 3 mackovia	75	8	f	-	0	6	1	2012-10-13 19:01:15+02
2911	modré slim rifle,vzadu vačky s oranžovým štepovaním, veľ.122	74	6	f	-	0	22	1	2012-10-13 11:52:27+02
2912	modré slim rifle, vzadu vačky s príklopkami,ozdobné sťahovanie,veľ.1166,00	74	6	f	-	0	23	1	2012-10-13 11:52:32+02
2913	ružový zimný kvetinkový overal s kapucou,podšitý flisom,veľ.68	74	8	f	-	0	24	1	2012-10-13 11:52:43+02
2914	fialový chlpatkový kožúšok,podšitý saténom, veľ.104	74	8	f	-	0	25	1	2012-10-13 11:52:54+02
2915	červeno-čierny zimný overal s kapucou, opasok,veľ.122	74	10	f	-	0	26	1	2012-10-13 11:53:00+02
2918	ružová flisová čiapka,biele lemovanie,vpredu kvetinka, veľ.68	74	2.5	f	-	0	29	1	2012-10-13 11:53:16+02
2919	pásikové hnedo-ružovo-biele tepláky, veľ.92	74	2	f	-	0	30	1	2012-10-13 11:53:19+02
2920	ružové velúrové tepláky, dolu volán,veľ.68	74	1.7	f	-	0	31	1	2012-10-13 11:53:24+02
2917	súprava smotanová čiapka+šál,vpredu macko, veľ.68	74	3.5	f	-	0	28	1	2012-10-13 11:53:27+02
2916	šedá flisová čiapka, nápis Extreme	74	2.5	f	-	0	27	1	2012-10-13 11:53:30+02
2921	zelené nohavice,vzadu vačky,veľ.68	74	1.7	f	-	0	32	1	2012-10-13 11:53:34+02
2922	žltý velúrový overal,límec s hviezdičkou,vpredu obrázok zvieratka,veľ.62	74	2	f	-	0	33	1	2012-10-13 11:53:40+02
2923	žltý velúrový overal,vpredu obrázok zajacov,zapínanie vzadu,veľ.62	74	2	f	-	0	34	1	2012-10-13 11:53:44+02
2901	ružové oteplovačky, vpredu macko a kvietky, veľ.68	74	2.5	f	-	0	12	2	2012-10-13 18:03:40+02
2925	fialové bavlnené tričko,vpredu obrázok myšky,veľ.74	74	2	f	-	0	36	1	2012-10-13 11:53:50+02
2926	ružové bavlnené tričko,vpredu našitý zajac,pásikové rukávy,veľ.68	74	2	f	-	0	37	1	2012-10-13 11:53:51+02
2927	biele bavlnené tričko s Hello Kitty,veľ.62	74	2	f	-	0	38	1	2012-10-13 11:53:53+02
2928	biele bavlnené tričko s kvetinkami,volánik okolo krku,veľ.62	74	1.7	f	-	0	39	1	2012-10-13 11:53:55+02
2929	ružové bavlnené tričko so srdiečkami,prestrihnuté pod prsiami,volániky na rukávoch, veľ.62	74	1.7	f	-	0	40	1	2012-10-13 11:53:57+02
2930	zelenkavé bavlnené tričko, vpredu mačička,veľ.68	74	1.5	f	-	0	41	1	2012-10-13 11:54:00+02
2931	biele bavlnené tričko s mačičkami,veľ.68	74	1.5	f	-	0	42	1	2012-10-13 11:54:03+02
2932	ružové tričko s dvojitým efektom-pásikové,vpredu výšivky,veľ.68	74	1.7	f	-	0	43	1	2012-10-13 11:54:05+02
2904	ružová vesta podšitá flisom, vpredu vačky s hnedým lemom, veľ.92	74	2.7000000000000002	f	-	0	15	2	2012-10-13 17:06:36+02
2934	súprava zelenkavé bavlnené dupačky+body,výšivka žabky,veľ.62	74	3.5	f	-	0	45	1	2012-10-13 11:54:12+02
2935	súprava zelenkavý bavlnený kabátik+dupačky,vpredu obrázok postavičiek,veľ.62	74	3.5	f	-	0	46	1	2012-10-13 11:54:15+02
2893	biela flisová hríbiková mikinka,podšitá bavlnou,veľ.62	74	3	f	-	0	4	2	2012-10-14 13:06:53+02
2938	sivé slim rifle,ružové štepovanie,vzadu vačky,veľ.104	74	2.7000000000000002	f	-	0	49	1	2012-10-13 11:54:22+02
2942	sedo-zel.plet.svet.na zips, tm. mod.lem. okolo krku, ruk. a na spodu, vzadu c.72, zn.C&A, v.68	75	3	f	-	0	3	2	2012-10-13 17:01:44+02
2892	ružový flisový overal,vpredu botičky,dolu na nožičkách mašličky, veľ.68 2,5	74	2.5	f	-	0	3	1	2012-10-13 11:54:45+02
2894	čierna chlapčenská moto mikina s kapucou,červené pásy na rukávoch, veľ.116	74	3	f	-	0	5	1	2012-10-13 11:54:50+02
2895	chlapčenské modré rifle,vzadu ozdobné sťahovanie, veľ.116	74	4.5	f	-	0	6	1	2012-10-13 11:54:53+02
2910	zelenkavá bundička s kapucou, vpredu mackoa zipsy, veľ.74	74	4	f	-	0	21	2	2012-10-13 18:28:03+02
2897	hnedý svetrík s kapucou,na rukáve macko,nápis Logg,veľ.62	74	2.5	f	-	0	8	1	2012-10-13 11:55:32+02
2898	ružová flisová pelerínka,po obvode strapce,nápis Babe,veľ. 92	74	2.5	f	-	0	9	1	2012-10-13 11:55:37+02
2896	cyklaménová chlpatá mikina na tri gombíky,vpredu hríbik,veľ.68	74	4	f	-	0	7	2	2012-10-13 18:07:21+02
2900	ružová mikinka Reebok, pásikové lemy, veľ.68	74	3	f	-	0	11	1	2012-10-13 11:55:43+02
2899	flisová kvetinková mikina s kapucou, pásikový vačok, veľ.74	74	4	f	-	0	10	2	2012-10-13 18:03:40+02
2903	modré tričko,vpredu obrázok chlapca, tmavomodré rukávy, veľ.116	74	3	f	-	0	14	1	2012-10-13 11:55:51+02
2924	ružové bavlnené tričko,vpredu obrázok kocúra Garfielda,veľ.80	74	2.5	f	-	0	35	2	2012-10-13 17:11:15+02
2905	ružová čiapočka Hello Kitty,podšitá flisom, vpredu mačka, veľ.68	74	3	f	-	0	16	1	2012-10-13 11:55:58+02
2906	ružová velúrová súprava, tepláky+mikina na zips,vpredu prasiatko Piglet,68	74	4.5	f	-	0	17	1	2012-10-13 11:56:02+02
2907	ružové nohavice podšité bavlnou, vzorové,vačky, veľ.56	74	2.5	f	-	0	18	1	2012-10-13 11:56:10+02
2908	modrá flisová súprava,nohavice+mikina,vpredu výšivka a brmbolce, veľ.68	74	4.5	f	-	0	19	1	2012-10-13 11:56:12+02
2947	smot.- bez.- hnedy vak na spanie,zapin na cvoky, s postavou mackabez rukavov, v. 6-12, zn. Cherokee	75	5	f	-	0	8	2	2012-10-13 16:02:17+02
2967	obojstr.bordovo-ruzova bunda s kapucnou, na zips, vpredu vysity klokani, zn. Zebra, v.98	75	10	f	-	0	28	1	2012-10-13 10:04:20+02
2966	bez. rifl bunda s plet ruk. zapin na cvoky, 2 hor. vrecka, 1 boc.,zad. sedy napis Kimbaloo, v. 62, zn. Kimbaloo 	75	2	f	-	0	27	1	2012-10-13 10:04:28+02
2959	mod.- cerv.-biela plys. trig, hor. zapin. na krku na  gomb.,vpredu s vrec.s gomb. a mackom, cerv.patenty, v.62zn. Babysana	75	2	f	-	0	20	1	2012-10-13 10:04:34+02
2958	viacfareb. kockov. flanel. kosela, cerveno-zel.-mod-zlto-biela, dlhy rukav, na gombiky, v. neud asi 80, zn. Lady Ann 	75	2	f	-	0	19	1	2012-10-13 10:04:42+02
2957	bledo-modra zimna bunda, potlac psikov a opiciek, podsita flausom, zn. Cherokee, v. 62 	75	5	f	-	0	18	1	2012-10-13 10:04:48+02
2956	cervene zimne nohavice, bocne vrecka, v. 12-18 mes., zn Baby GAP	75	2	f	-	0	17	1	2012-10-13 10:04:56+02
2965	viacfarebne pasikave termo pancusky,ruzovo-tyrkysovo-fialove, motiv macky,v.92/98	75	2	f	-	0	26	1	2012-10-13 10:05:01+02
2963	zlto- biely plys. dupack. overal, s mod. pasik. vlavo hore vysiv.zlto-mod. zirafa, boc.hor. zap.a na noh., na pat.,v.92, zn.Panda	75	3	f	-	0	24	1	2012-10-13 10:05:11+02
2962	ruzove frote dupacky , patenty v rozkroku, kravicka na hrudi,zn. Marani, v.74	75	2	f	-	0	23	1	2012-10-13 10:05:15+02
2961	plet.ruz.-biely melir.svet.s kapuc., zapin. na kvet.gomb., vys.bielo-ruz.kvet,zn. Adams,v.68	75	3	f	-	0	22	1	2012-10-13 10:05:20+02
2960	ruzovy flausovy overal s kapucnou, na cvoky, zn. Cherokee,v.74	75	6	f	-	0	21	1	2012-10-13 10:05:26+02
2951	bez.-hnedy pasik. dupack.overal s dlhym ruk., potlac macka na hrudi, vzadu na patentky,  z. CA, v.80 	75	3	f	-	0	12	1	2012-10-13 10:05:45+02
2952	sustiak.zel.bunda na zips, podsita kapuc.oranz.flausom, 3 lesne zvieratka,zn.Ladybird,v.74	75	3	f	-	0	13	1	2012-10-13 10:06:43+02
2950	2-vrstvove tricko, dlhy rukav, viacfareb mod. ruk.,  nasite viacfareb. postavicky priseriek,zn. TU, v.74/80	75	2	f	-	0	11	1	2012-10-13 10:05:49+02
2954	ruz. detska frote osuska s kapucnou s  viacfareb.vysivkou zaby, zn. Babyline	75	3	f	-	0	15	1	2012-10-13 10:06:10+02
2955	ruc.plet.viacfareb.pas.dupack.overal s kapuc., mod.-hnedo-bez.-zel.-bord.na zips,asi v. 56	75	4	f	-	0	16	1	2012-10-13 10:06:20+02
2953	sus.sedo-modra bunda s kapucnou na zips,vpredu s nasitym vreckom,zn. Beebies,v.68	75	2	f	-	0	14	1	2012-10-13 10:06:49+02
2949	plet. zelene palciak.rukavice s nasit.babikou, spojene snurkou, velkost neuved., ale asi 92	75	2	f	-	0	10	1	2012-10-13 10:07:07+02
2989	sedy pulover,vpredu napis cherokee, na boku gombiky, zn. Cherokee, v.68 	75	3	f	-	0	50	1	2012-10-13 10:07:38+02
2983	pleteny bledo-modry svetrik s podsitou kapucnou,na gombiky,zn.Cherokee, v. 68	75	3	f	-	0	44	1	2012-10-13 10:07:45+02
2988	or.-bielo-mod.trig.troyer,dvoj.vzhlad, vpr.aj vzadu potlac Pooh s tigrom,zn Disney,v 74 	75	3	f	-	0	49	1	2012-10-13 10:07:58+02
2986	olivove podsite mencestraky, vzadu na vrecku vysity psik,zn. HiM baby, v.62	75	3	f	-	0	47	1	2012-10-13 10:08:05+02
3001	červené šušťákové nohavice, 1-2 roky	76	4.5	f	-	0	12	2	2012-10-13 17:18:28+02
2977	moherovy staroruzovy  pleteny svetrik na gombiky, zn. Orchestra Kazibao France,v.104	75	2	f	-	0	38	1	2012-10-13 10:08:20+02
2982	zelenk.svet.na zips,vpredu s vrec., potlac 83 vlavo pri vrecku, odlis.plet. ruk.,zn. Eagle,v.80	75	2	f	-	0	43	1	2012-10-13 10:08:27+02
2978	ruzovy prepinaci kabatik, vysity ruzovy tulen na boku,zn. Domaja,v.68	75	2	f	-	0	39	1	2012-10-13 10:08:32+02
2970	ruz.tricko, dlhy rukav, vpredu velka potlac dievcatko, srnka, domcek, strom,zn. Artena,v.98	75	2	f	-	0	31	1	2012-10-13 10:08:39+02
2995	kockovaný fusak na spanie so snehuliakom	76	5.5	f	-	0	6	2	2012-10-13 18:36:12+02
2968	viacfarebne pasikave tricko, dlhy rukav,oranzovo-tyrkysovo-ruzova, zn. Lucky Lax,v.98	75	2	f	-	0	29	1	2012-10-13 10:08:52+02
2971	hnede otepl. na traky, vnut. ruz. podsivka, na boku na noh. fareb gulicky, zapin na zips a 2 cvoky, v. 110, zn. Reserved	75	8	f	-	0	32	1	2012-10-13 10:09:05+02
2972	bielo-mod. pruh. flaus.trig., s kapuc., s klok. vrec., vpredu so sedym slonom, v.68, zn. Cherokee	75	3	f	-	0	33	1	2012-10-13 10:09:21+02
2973	cerveno-modra pruh. podsita plet. capica, v.62, zn. Cherokee	75	2	f	-	0	34	1	2012-10-13 10:09:28+02
2975	modra capica, vpredu  nasity kvet, zavaz na biele snurky,velkost neudana, zn. Broel	75	2	f	-	0	36	1	2012-10-13 10:09:42+02
2974	bielo-mod. semis. pruh. capica, na zavaz.,velkost ani znacka neudane	75	1	f	-	0	35	1	2012-10-13 10:09:52+02
2984	cierno-modre sustiak. topanky, na 2 lepky, modro-cierne presivanie zn. Bobbi Shoes, v.29	75	5	f	-	0	45	1	2012-10-13 10:10:03+02
2979	bielo-ruz.dievc.tenisky,2 suche zipsy,koza,zn. Reebok,v.25	75	11	f	-	0	40	1	2012-10-13 10:10:15+02
2980	cerveno-sede tenisky, syntetika, po bokoch 4 kvety, snur.,zn.Starheight, v.25	75	5	f	-	0	41	1	2012-10-13 10:10:28+02
2981	zeleno-sede tenisky, syntetika,po bokoch oranz.pasiky,2 suche zipsy,zn. Liliworld, v.25	75	5	f	-	0	42	1	2012-10-13 10:10:36+02
2991	 ružové tričko s dlhým rukávam v predu s kvetinkou, veľkosť 92	76	2	f	-	0	2	1	2012-10-13 11:07:45+02
2990	biely svetrík s kapucou, zn. Cherokee	76	5	f	-	0	1	1	2012-10-13 11:07:49+02
2992	červeno-zelono-modrá tepláková súprava v predu s mackom	76	2	f	-	0	3	1	2012-10-13 11:07:52+02
2993	oranžovo-biely svetrík na zips, veľkosť 104	76	4	f	-	0	4	1	2012-10-13 11:08:02+02
2998	ružový kabátik s kvetinkami, zn. Next, veľkosť 86	76	7	f	-	0	9	1	2012-10-13 11:08:12+02
2997	šedo-ružová zimná bunda s kapucou v predu so psíkom	76	5	f	-	0	8	1	2012-10-13 11:08:20+02
2985	tm.mod.rifle, podsite bledo-mod.flausom,vpredu pod vreckami vysity tiger, zn Disney, v.68	75	5	f	-	0	46	2	2012-10-13 18:57:57+02
2969	zel.tric.dlhy rukav, potlac roz.predmetov vpredu a zelenych kvetov na ruk.,zn.Artena,v.98	75	2	f	-	0	30	2	2012-10-13 18:23:22+02
2994	biele tričko s dlhým rukávom v predu s bábikou, veľkosť 92	76	2.5	f	-	0	5	1	2012-10-13 11:08:42+02
2996	zeleno-modré šaty v predu s mackami	76	3	f	-	0	7	1	2012-10-13 11:08:46+02
3002	bledo fialová vesta s kapocou, na 3-4 roky	76	5	f	-	0	13	1	2012-10-13 11:09:49+02
3000	tmavo ružový overal s detským motívom, 1-2 roky	76	5	f	-	0	11	1	2012-10-13 11:10:05+02
2999	bordová zimná bunda, zn. Kenvelo, na dva roky	76	8	f	-	0	10	2	2012-10-13 16:55:58+02
3055	ružové maskáčové tričko	77	2	f	-	0	16	2	2012-10-13 19:32:16+02
3042	ružová, veľkosť 4-7 rokov	77	4	f	-	0	3	1	2012-10-13 09:23:05+02
3066	ružové šatky spoločenské	77	5	f	-	0	27	1	2012-10-13 09:23:19+02
3070	ružové menžestrové šaty 2-3 roky	77	4.5	f	-	0	31	1	2012-10-13 09:23:31+02
3048	rifle modré, veľkosť 116	77	2	f	-	0	9	1	2012-10-13 09:25:23+02
3046	nohavice hnedé, veľkosť 134	77	3	f	-	0	7	1	2012-10-13 09:24:14+02
3006	hnedé tričko s dlhým rukávom s nápisom Music Lover, zn. Wenice, veľ. 116	76	2	f	-	0	17	2	2012-10-13 16:49:36+02
3072	bundička ADIDAS, 2 roky	77	2	f	-	0	33	2	2012-10-14 11:31:31+02
3044	rifle modré, veľkosť 7-9 rokov	77	3	f	-	0	5	1	2012-10-13 09:25:45+02
3050	tepláčky tmavomodré, veľkosť 116	77	1.5	f	-	0	11	1	2012-10-13 09:27:42+02
3008	ružová zimná bunda s kapucou, 2-3 roky	76	6	f	-	0	19	2	2012-10-13 18:23:22+02
3043	rifle modré KENVELO s výšivkou, veľkosť 8-9	77	4	f	-	0	4	1	2012-10-13 09:27:15+02
3045	rifle čierne, veľkosť 7-9 rokov	77	4	f	-	0	6	2	2012-10-13 18:07:08+02
3073	tmavomodré body	77	1	f	-	0	34	1	2012-10-13 09:28:13+02
3074	žltý roláčik, veľkosť 92	77	0.80000000000000004	f	-	0	35	1	2012-10-13 09:28:18+02
3075	menžestráčky smotanové, veľkosť 104	77	1	f	-	0	36	1	2012-10-13 09:28:26+02
3037	čierne vyššie tenisky s hviezdičkami na šnúrovanie, veľ. 26	76	2.5	f	-	0	48	2	2012-10-13 17:44:19+02
3067	biele body so sobmi	77	0.40000000000000002	f	-	0	28	1	2012-10-13 09:28:54+02
3068	pyžamko dupačky	77	0.5	f	-	0	29	1	2012-10-13 09:29:01+02
3069	ružové body	77	0.40000000000000002	f	-	0	30	1	2012-10-13 09:29:05+02
3011	červeno-čierne rukavice, palčiaky s nápisom Ski	76	1	f	-	0	22	2	2012-10-14 11:06:45+02
3059	biele tričko s nápisom, 5-6 rokov	77	2	f	-	0	20	2	2012-10-13 17:24:39+02
3057	ružové tričko s kapucňou BENETTON, veľkosť 110	77	2	f	-	0	18	1	2012-10-13 09:29:22+02
3056	ružové tričko s pásikavými rukávmi, veľkosť 116	77	2	f	-	0	17	2	2012-10-13 17:24:39+02
3076	menžestráčky fialové, 2 roky	77	1	f	-	0	37	2	2012-10-13 17:31:15+02
3060	pyžamko s morskou pannou, 5-6 rokov	77	3	f	-	0	21	1	2012-10-13 09:29:34+02
3061	pyžamko ružové, 5-6 rokov	77	3	f	-	0	22	1	2012-10-13 09:29:38+02
3047	ružové nohavice oteplené, veľkosť 116	77	2	f	-	0	8	2	2012-10-13 15:07:45+02
3062	ružové gumáčky, veľkosť 28	77	3	f	-	0	23	2	2012-10-13 15:05:01+02
3051	riflová bundička modrá, 5-6 rokov	77	2	f	-	0	12	1	2012-10-13 09:30:10+02
3064	červené čižmičky, veľkosť 29	77	3	f	-	0	25	1	2012-10-13 09:31:56+02
3063	fialové čižmičky, veľkosť 28	77	4	f	-	0	24	1	2012-10-13 09:32:04+02
3009	ružové rukavice s Barbie, palčiaky	76	1	f	-	0	20	2	2012-10-13 15:05:01+02
3041	zimná bunda strieborná, veľkosť   6-10 rokov	77	4	f	-	0	2	2	2012-10-13 18:46:04+02
3049	tepláčky ADIDAS, veľkosť 116	77	4	f	-	0	10	2	2012-10-14 11:16:20+02
3012	flaušová červená čiapka so psíkmi na zavezovanie	76	1	f	-	0	23	1	2012-10-13 11:09:11+02
3058	svetlomodré tričko	77	0.80000000000000004	f	-	0	19	2	2012-10-13 17:09:37+02
3035	ružové snehule, veľ. 27	76	5	f	-	0	46	2	2012-10-13 17:00:09+02
3005	krémové tričko s dlhým rukávom, zn. Wenice, veľkosť 116	76	2	f	-	0	16	1	2012-10-13 11:09:24+02
3004	biele tričko s dlhým rukávom vpredu s kvetinkou, veľkosť 98	76	2	f	-	0	15	1	2012-10-13 11:09:27+02
3053	ružová menžestrová sukňa, 5-7 rokov	77	2.5	f	-	0	14	2	2012-10-13 15:05:01+02
3016	ružové tričko s dlhým rukávom s kvetinkami a motýľmi	76	2	f	-	0	27	1	2012-10-13 11:09:36+02
3015	zeleno-ružové tričko s kvetinkou, veľ. 104	76	2	f	-	0	26	1	2012-10-13 11:09:40+02
3014	šedo-biele tričko s dlhým rukávom s kapucou, vpredu baletka, veľ. 98/104	76	2	f	-	0	25	1	2012-10-13 11:09:42+02
3010	modro-biele rukavice so zajkom, palčiaky	76	1	f	-	0	21	2	2012-10-13 18:36:12+02
3032	béžová flaušová trigovica s kvetinko, tn. Zara, veľ. 92-97	76	4	f	-	0	43	1	2012-10-13 11:10:27+02
3031	modrá trigovica so psíkom	76	1	f	-	0	42	1	2012-10-13 11:10:29+02
3030	biela trigovica s vlkom	76	2	f	-	0	41	1	2012-10-13 11:10:31+02
3029	žlto-červená trigovica s mackom	76	1.5	f	-	0	40	1	2012-10-13 11:10:35+02
3028	modro-šedý flaušový klobúk so žltými kvetinkami	76	2	f	-	0	39	1	2012-10-13 11:10:54+02
3071	rifličky	77	2	f	-	0	32	2	2012-10-13 18:04:39+02
3027	červená čiapka na zavezovanie s nápisom My Best Cup	76	3	f	-	0	38	1	2012-10-13 11:10:57+02
3025	červená flaušová súprava na zapínanie vpredu	76	1	f	-	0	36	1	2012-10-13 11:11:11+02
3024	oranžové pyžamo s motýľom, veľ 98-104	76	2	f	-	0	35	1	2012-10-13 11:11:15+02
3023	bledo modré pyžamo so Včielkou Májou,veľ. 104	76	2	f	-	0	34	1	2012-10-13 11:11:20+02
3022	biele pyžamo s myškami a jahodami, veľ. 110	76	2	f	-	0	33	1	2012-10-13 11:11:31+02
3021	bledo modrá tenká bunda na patenty bez kabude, zn. Chicco	76	3	f	-	0	32	1	2012-10-13 11:11:35+02
3020	ružová tenká bunda s kapucou s kvetinkami	76	4	f	-	0	31	1	2012-10-13 11:11:49+02
3019	zelená tenká bunda s kapucou, veľ. 110	76	3	f	-	0	30	1	2012-10-13 11:11:53+02
3018	ružové lyžiarske rukavice, palčiaky 	76	1	f	-	0	29	1	2012-10-13 11:11:58+02
3017	ružová tepláková súprava s nápisom Best Girl, veľ. 98	76	3.5	f	-	0	28	1	2012-10-13 11:12:03+02
3026	bielo-žlto-oranžovo-zelený štrikovaný svetrík	76	1.5	f	-	0	37	1	2012-10-13 11:12:08+02
3033	čierne vysoké čižmy so zipsom, veľ. 29	76	3.5	f	-	0	44	1	2012-10-13 11:12:37+02
3007	biely rolák s dlhým rukávon vpredu ruž. motýľ, veľ 116	76	2	f	-	0	18	2	2012-10-13 17:01:33+02
3034	čiene čižmy so zipsom s kvetinkami, veľ. 29	76	2	f	-	0	45	1	2012-10-13 11:12:59+02
3038	fialovo-ružové tenisky na suchý zips, veľ. 24	76	3	f	-	0	49	1	2012-10-13 11:13:32+02
3039	červené papučky s detským motývom, veľ. 22	76	1.5	f	-	0	50	1	2012-10-13 11:13:40+02
3036	červené snehule, veľ. 28	76	3.5	f	-	0	47	1	2012-10-13 11:14:07+02
3054	tmavoružová menžestrová sukňa, 5-7 rokov	77	2.5	f	-	0	15	2	2012-10-13 15:01:38+02
3078	bundička modro-biela, veľkosť 92	77	1.5	f	-	0	39	1	2012-10-13 09:28:43+02
3082	ponožky 	77	0.80000000000000004	f	-	0	43	1	2012-10-13 09:30:35+02
3081	rukavičky biele	77	0.29999999999999999	f	-	0	42	1	2012-10-13 09:31:13+02
3079	čiapočka modrá	77	0.80000000000000004	f	-	0	40	1	2012-10-13 09:31:17+02
3080	čiapočka svetlomodrá	77	0.80000000000000004	f	-	0	41	1	2012-10-13 09:31:20+02
3133	Komplet do detskej postielky	78	2	f	-	0	49	1	2012-10-13 12:32:51+02
3118	Tepláková súprava so žirafou	78	1	f	-	0	34	1	2012-10-13 12:32:59+02
3101	Biele menžestrové nohavice na traky,macko Teddy, veľ. 0-3m	78	4	f	-	0	17	1	2012-10-13 12:33:08+02
3135	Oteplovačky čierne ME&YOU,veľ.122/128	79	2	f	-	0	1	2	2012-10-14 09:37:16+02
3120	Dupačky modré s xichtom	78	0.5	f	-	0	36	2	2012-10-13 16:41:59+02
3099	Zimný plyš. Komplet s ľadovým medvoďom- 2d, veľ. 62	78	4	f	-	0	15	1	2012-10-13 12:33:25+02
3119	Tepláková súprava teplá  s kvetinkou, veľ. 2	78	1	f	-	0	35	1	2012-10-13 12:33:34+02
3114	Dupačky s bodynkom, modré s ovečkou, veľ. 56	78	3	f	-	0	30	2	2012-10-13 19:02:12+02
3106	Bledo a tmavo modrý dupačkový overal, veľ. 0-3m	78	2	f	-	0	22	1	2012-10-13 12:33:50+02
3097	Zimný plyš. Overal s kapucňou, veľ. 68	78	3	f	-	0	13	2	2012-10-14 13:05:37+02
3098	Zimný plyš. Komplet s ľadovým medvoďom- 2d, veľ. 68	78	4	f	-	0	14	2	2012-10-14 12:58:26+02
3136	Bunda šedá,Kenvelo veľ.7-8 r.	79	3	f	-	0	2	2	2012-10-13 18:33:44+02
3095	Zimná šedá kombinéza, veľ. 68	78	4	f	-	0	11	1	2012-10-13 12:34:13+02
3096	Modrý svetrík, s levíkom a nášivkami na lakťoch, veľ. 3-6m	78	2	f	-	0	12	1	2012-10-13 12:34:17+02
3100	Zelený sveter na zips, hnedá nášivka macka, veľ. 0-3m	78	2	f	-	0	16	1	2012-10-13 12:34:22+02
3112	Dupačky s kabátikom, modré s ježkom, veľ. 68	78	3	f	-	0	28	2	2012-10-13 19:02:12+02
3103	Modrý dupačkový overal s korytnačkami, veľ.68	78	1.5	f	-	0	19	1	2012-10-13 12:34:28+02
3104	Modrý dupačkový overal so žirafami	78	1.5	f	-	0	20	1	2012-10-13 12:34:30+02
3105	Biely dupačkový overal s mackami, veľ. 62	78	1.5	f	-	0	21	1	2012-10-13 12:34:32+02
3121	Dupačky modro-biele s mackom, veľ. 68	78	0.5	f	-	0	37	2	2012-10-13 19:02:12+02
3108	Zelený dupačkový overal s kravičkou, veľ. 0-3m	78	1	f	-	0	24	1	2012-10-13 12:34:37+02
3109	Modrý dupačkový overal s farmou, veľ. 0-3m	78	1	f	-	0	25	1	2012-10-13 12:34:39+02
3110	Modrý dupačkový overal s autíčkom, veľ. 0-3m	78	1	f	-	0	26	1	2012-10-13 12:34:41+02
3144	Oteplovačky čierne KILLTEC,veľ.162	79	7	f	-	0	10	2	2012-10-13 17:11:15+02
3143	Fleecová čiapka ružová, uväzovanie pod krkom	79	1	f	-	0	9	1	2012-10-13 12:34:51+02
3094	Zimná zelená kombinéza, veľ. 3-6m	78	6	f	-	0	10	2	2012-10-13 17:56:04+02
3111	Dupačky s kabátikom, modré so zajačikom, veľ. 74	78	3	f	-	0	27	2	2012-10-13 16:38:46+02
3117	Tepláky prúžkové teplé , modro-biele, veľ. 3-6m	78	0.5	f	-	0	33	1	2012-10-13 12:35:06+02
3115	Hrubé tepláky tmavo modré	78	1	f	-	0	31	2	2012-10-13 17:49:24+02
3093	Zimná červená kombinéza- šedo-modré pásy, veľ. 86	78	7	f	-	0	9	2	2012-10-14 09:48:06+02
3122	Hnedé tričko s dlhým rukávom, yachting, veľ. 98	78	0.5	f	-	0	38	1	2012-10-13 12:35:18+02
3146	Fleecová čiapka zelená, uväzovanie pod krkom	79	1	f	-	0	12	1	2012-10-13 12:35:11+02
3123	Modrá mikina, s č. 63, veľ. 98	78	0.5	f	-	0	39	1	2012-10-13 12:35:21+02
3124	Modrá mikina s mackami, veľ. 62	78	0.5	f	-	0	40	1	2012-10-13 12:35:23+02
3125	Modrá mikina s č. 24, veľ. XL	78	0.5	f	-	0	41	1	2012-10-13 12:35:25+02
3126	Modré tričko s obrázkom troch žiab, veľ. 110-116	78	0.5	f	-	0	42	1	2012-10-13 12:35:26+02
3127	Modrá mikina so zajkom s udicou, veľ. 86-92	78	0.5	f	-	0	43	1	2012-10-13 12:35:28+02
3128	Modrá mikina s kačkou	78	0.5	f	-	0	44	1	2012-10-13 12:35:31+02
3148	Fleecová čiapka+rukavice+šál,modré	79	1	f	-	0	14	1	2012-10-13 12:35:24+02
3129	Modrý svetrik s mackom, veľ. 68	78	0.5	f	-	0	45	1	2012-10-13 12:35:36+02
3130	Modré tričko Happy jungle	78	0.5	f	-	0	46	1	2012-10-13 12:35:37+02
3131	Modré tričko Tiger, bear and duck	78	0.5	f	-	0	47	1	2012-10-13 12:35:40+02
3132	Podložka na kúpanie, macková	78	3	f	-	0	48	1	2012-10-13 12:35:41+02
3134	Tehotenské rifle na traky, veľ. S	78	10	f	-	0	50	1	2012-10-13 12:35:53+02
3113	Dupačkový overal s mackom Pú a tygríkomi, veľ. 50-56	78	1.5	f	-	0	29	2	2012-10-13 17:10:51+02
3139	Vesta hnedá,Disney	79	2	f	-	0	5	1	2012-10-13 12:37:26+02
3138	Tielka 5ks, F&F, veľ.9-10 r.	79	2	f	-	0	4	1	2012-10-13 12:37:31+02
3147	Fusak,modrý	79	4	f	-	0	13	1	2012-10-13 12:37:41+02
3149	Rifľová bunda s kožušinou Replay veľ. 6m.	79	3.5	f	-	0	15	1	2012-10-13 12:38:35+02
3116	Tepláky prúžkové, modro-biele, veľ. 110-116	78	0.5	f	-	0	32	2	2012-10-13 15:44:00+02
3142	Pršiplášť,zelený so žltými motýľmi veľ.6r.	79	1	f	-	0	8	2	2012-10-13 18:07:58+02
3107	Modr--biely dupačkový overal s mackom, veľ. 3m	78	1	f	-	0	23	2	2012-10-13 19:02:12+02
3102	Modrý dupačkový overal s kačičkami, veľ.2	78	1.5	f	-	0	18	2	2012-10-13 18:53:01+02
3141	Tričko dlhý rukáv olivovozelené,NIKE 12 r.	79	2	f	-	0	7	1	2012-10-13 12:39:33+02
3140	Tričko dlhý rukáv s límčekom,maskáčové,veľ.11 r.	79	2	f	-	0	6	1	2012-10-13 12:39:36+02
3145	Trigovica na zips modrá s oranžovým pásikom,Adidas veľ.128	79	2	f	-	0	11	2	2012-10-13 15:26:50+02
3137	Overal,červený s ľadovým medveďom,veľ.74	79	4	f	-	0	3	2	2012-10-13 15:55:14+02
3217	šaty ružové, veľ. 5/6rokov	81	5	f	-	0	5	1	2012-10-13 10:09:11+02
3218	bunda zimná, krémová s kapucňou, veľ. 6	81	7	f	-	0	6	1	2012-10-13 10:09:16+02
3219	šaty hnedé, veľ. 5/6rokov, 	81	5	f	-	0	7	1	2012-10-13 10:09:19+02
3169	Bledomodré nohavičky, podšité	80	1	f	-	0	7	2	2012-10-14 12:58:25+02
3214	svetrík bielo/strieborný, 3 gombíčky, veľ.7-8rokov	81	10	f	-	0	2	1	2012-10-13 10:09:47+02
3215	kabátik kožušinkový, veľ. 6-7rokov	81	8	f	-	0	3	1	2012-10-13 10:09:53+02
3156	Korčule čierne veľ.31	79	8	f	-	0	22	2	2012-10-14 10:46:43+02
3164	Overal biely, na cvoky, so zajkami "Peter Rabbit"	80	1.5	f	-	0	2	1	2012-10-13 10:39:24+02
3166	Overal zelený, flaušový, macko s číslami	80	1.6000000000000001	f	-	0	4	1	2012-10-13 10:39:30+02
3165	Overal modrý, flaušový, macko s číslami	80	1.6000000000000001	f	-	0	3	1	2012-10-13 10:39:32+02
3174	Overal, zimný, bledo-hnedý, s kapucou a návlekmi na chodidlá, dva sloníky	80	4.2000000000000002	f	-	0	12	1	2012-10-13 19:01:27+02
3196	Dupačkové nohavičky, biele, na gumu	80	1.8999999999999999	f	-	0	34	2	2012-10-13 18:20:14+02
3189	Pulóver, modrý, strakatý, pri krku na gombíky	80	1.2	f	-	0	27	2	2012-10-13 17:49:24+02
3171	Béžový overal, zimný, modrí a hnedí mackovia, "Historie Dours"	80	2	f	-	0	9	1	2012-10-13 10:39:50+02
3172	Bunda modrá so zeleným pásom, zips, "LEGO"	80	2.5	f	-	0	10	1	2012-10-13 10:39:54+02
3173	Rifľová bunda, zateplená, na cvoky, maskáčový motív	80	3.1000000000000001	f	-	0	11	1	2012-10-13 10:39:56+02
3175	Bunda, zeleno-modrá, pásiková, s kapucou, na zips, F&F	80	3.8999999999999999	f	-	0	13	2	2012-10-13 16:36:03+02
3177	Tepláky, na traky, bledomodré s modrým	80	2	f	-	0	15	2	2012-10-13 17:09:37+02
3176	Pulovrík, modro-čierny prúžkový, "Marks&Spencer"	80	1.8999999999999999	f	-	0	14	1	2012-10-13 10:40:10+02
3170	Bunda hnedá, zvnútra flauš, s kapucou, na zips, "Helicopter"	80	3.8999999999999999	f	-	0	8	2	2012-10-13 17:47:48+02
3178	Nohavice, modré, menčestrové, "NEXT"	80	1.3	f	-	0	16	1	2012-10-13 10:40:15+02
3179	Rifle tehotenské, čierne	80	5	f	-	0	17	1	2012-10-13 10:40:33+02
3180	Tehotenské nohavice, hnedé, guma v páse	80	12	f	-	0	18	1	2012-10-13 10:40:43+02
3181	Tehotenské tričko s dlhým rukávom, guličkový vzor, šnúrka na spodu	80	3.8999999999999999	f	-	0	19	1	2012-10-13 10:40:47+02
3182	Overal tmavomodrý, flaušový, "Playful"	80	2.5	f	-	0	20	1	2012-10-13 10:40:54+02
3183	Overal, bledo-modrý s bielym, na cvoky, s čiapočkou	80	2.8999999999999999	f	-	0	21	1	2012-10-13 10:41:00+02
3184	Overal modrý, na rozopínanie medzi nohami, "I must ZZZ"	80	1.8999999999999999	f	-	0	22	1	2012-10-13 10:41:03+02
3185	Overal na spanie, na zips, bledomodrý	80	1.5	f	-	0	23	1	2012-10-13 10:41:09+02
3186	Svetrík štrikovaný, na gombíky, béžový	80	1.2	f	-	0	24	1	2012-10-13 10:41:12+02
3187	Šaty,šedé, na gombíky s kvetinkami	80	1.5	f	-	0	25	1	2012-10-13 10:41:16+02
3188	Pančuchy, modré, pásiky	80	1.2	f	-	0	26	1	2012-10-13 10:41:21+02
3203	Nohavice čierne, podšité, riflové kolená	80	3.8999999999999999	f	-	0	41	2	2012-10-13 17:49:24+02
3220	sukňa cyklaménová, bodkovanáveľ. 110/116	81	5	f	-	0	8	2	2012-10-14 12:01:37+02
3190	Nohavice na traky, šedé, žabka na zipse	80	2	f	-	0	28	2	2012-10-14 11:28:57+02
3192	Body, modré "Cactus clone"	80	1.2	f	-	0	30	1	2012-10-13 10:41:36+02
3193	Nohavičky sametové, modré	80	1.8999999999999999	f	-	0	31	1	2012-10-13 10:41:39+02
3194	Nohavice, šedé, na gumu	80	3.1000000000000001	f	-	0	32	1	2012-10-13 10:41:41+02
3195	Nohavice menčestrové, bledomodré, s myškou	80	1.1000000000000001	f	-	0	33	1	2012-10-13 10:41:48+02
3167	Komplet flaušový - kabátik+nohavice, hnedo-biely, s mackom	80	2.8999999999999999	f	-	0	5	2	2012-10-13 18:53:01+02
3198	Flaušový pulovrík, gombíky pri krku, čierny, ružové rukávy	80	1	f	-	0	36	1	2012-10-13 10:41:55+02
3199	Pulóver červený, modré  a béžové pásiky na hrudi	80	0.90000000000000002	f	-	0	37	1	2012-10-13 10:41:57+02
3200	Nohavice, hnedé na traky, nášivka s mackom	80	0.90000000000000002	f	-	0	38	1	2012-10-13 10:42:01+02
3201	Nohavice zelené, zateplené	80	1.8999999999999999	f	-	0	39	1	2012-10-13 10:42:04+02
3202	Pulovrík štrikovaný, biely	80	1	f	-	0	40	1	2012-10-13 10:42:08+02
3168	Modré menčestráky, podšité	80	0.90000000000000002	f	-	0	6	2	2012-10-13 18:14:07+02
3204	Pulovrík béžový, flaušový, s kapuckou, macko	80	1.2	f	-	0	42	1	2012-10-13 10:42:14+02
3205	Tričko s dlhým rukávom, tyrkysové, motýlik	80	1.5	f	-	0	43	1	2012-10-13 10:42:17+02
3206	Bunda béžová, na zips, "Little explorer"	80	1.8999999999999999	f	-	0	44	1	2012-10-13 10:42:20+02
3207	Overal, biely, sametový, "Arctic friends"	80	1.7	f	-	0	45	1	2012-10-13 10:42:22+02
3208	Legíny, červené	80	1.8	f	-	0	46	1	2012-10-13 10:42:27+02
3209	Nohavice na traky, kockové, bielo-modré	80	1.5	f	-	0	47	1	2012-10-13 10:42:33+02
3210	Tričko s dlhým rukávom, bledomodré s medvedíkmi	80	1.1000000000000001	f	-	0	48	1	2012-10-13 10:42:40+02
3211	Body, zelené	80	0.69999999999999996	f	-	0	49	1	2012-10-13 10:42:42+02
3212	Body, tielko, biele	80	0.90000000000000002	f	-	0	50	1	2012-10-13 10:42:45+02
3161	Školská taška Herlitz,kostlivci + vrecko na prezúvky+peračník	79	17	f	-	0	27	1	2012-10-13 12:34:43+02
3152	Tričká s dlhým rukávom 3ks, veľ. 6 mesiacov (zelené, modré, biele)	79	1	f	-	0	18	1	2012-10-13 12:35:01+02
3162	Fleecové rukavice oranžové spojené šnúrkou	79	1	f	-	0	28	1	2012-10-13 12:35:07+02
3154	Bunda na zips biela s kapucou,veľ.176 	79	4	f	-	0	20	1	2012-10-13 12:37:51+02
3155	Bunda na zips zelená s kapucou,veľ.176 	79	4	f	-	0	21	1	2012-10-13 12:38:01+02
3153	Kombinéza svetlozelená EX10,veľ.116	79	10	f	-	0	19	1	2012-10-13 12:38:18+02
3163	Červený flaušový kabátik so zajkom, na gombíky	80	1.5	f	-	0	1	2	2012-10-13 15:56:01+02
3151	Šušťáky zateplené,čierne GS, veľ. 134	79	1	f	-	0	17	2	2012-10-13 15:49:54+02
3159	Tenisky biele LinShi veľ.32	79	2.5	f	-	0	25	1	2012-10-13 12:40:16+02
3191	Nohavice rifľové na traky	80	1.8999999999999999	f	-	0	29	2	2012-10-14 11:16:20+02
3160	Tenisky čierne+maskáčové,suchý zips,veľ.34 Mercury	79	8	f	-	0	26	1	2012-10-13 12:40:30+02
3158	Tenisky čierne s modrým pásikom,Adidas veľ.32	79	3	f	-	0	24	1	2012-10-13 12:40:33+02
3157	Gumáky šedé s očami veľ.30	79	1.5	f	-	0	23	1	2012-10-13 12:40:38+02
3286	Biele dupačky s dlhým rukávkom, zapínanie cvoky, s hnedou potlačou macíka, zn.F&F, veľ. 0-3 m.	84	2.6000000000000001	f	-	0	6	2	2012-10-13 17:03:24+02
3287	Bielo-žlté pruhované dupačky s dlh.rukávkom, zapínanie cvoky, zn. F&F, veľ. 0-3 mesiace	84	2.6000000000000001	f	-	0	7	2	2012-10-14 10:15:35+02
3285	Biele dupačky s dlhým rukávkom, zapínanie cvoky, s mackom na ľavej strane, zn.F&F, veľ. 0-3 m.	84	2.6000000000000001	f	-	0	5	1	2012-10-13 09:04:33+02
3284	Ružové dupačky, dlhý rukáv s kvietkovou potlačou, zn. F&F, veľ. 0-3 mesiace	84	2.6000000000000001	f	-	0	4	1	2012-10-13 09:04:37+02
3221	menžestráky cyklaménové, veľ. 110	81	5	f	-	0	9	1	2012-10-13 10:09:24+02
3222	šaty úpletové, tmavomodré, veľ. 134	81	1	f	-	0	10	1	2012-10-13 10:09:30+02
3223	rifle s motýlikmi a ružovým opaskom, veľ.110	81	4	f	-	0	11	1	2012-10-13 10:09:34+02
3224	tričko červené, MIMIE, veľ. 104	81	2	f	-	0	12	1	2012-10-13 10:09:36+02
3225	ružové tričko s MIMIE, veľ. 104	81	2	f	-	0	13	1	2012-10-13 10:09:38+02
3226	ružové tričko so srdiečkom, veľ. 104	81	2	f	-	0	14	1	2012-10-13 10:09:39+02
3248	kombinéza s kapucňou, modrá	82	4	f	-	0	22	1	2012-10-13 10:11:07+02
3271	tehotenská košeľa, biela+fialové kocky, L	82	3	f	-	0	45	1	2012-10-13 10:11:13+02
3270	tehotenská blúzka biela C&A, veľ.40/42	82	8	f	-	0	44	1	2012-10-13 10:11:22+02
3278	Kabát chlapčenský čierny zn. Silver Wings veľ. 98	83	4	f	-	0	7	2	2012-10-13 17:14:39+02
3232	komplet nohavice šedé +košeľotričko zelené s dlhým rukávom, veľ. 86	82	10	f	-	0	6	1	2012-10-13 10:11:49+02
3233	plienky bavlnené látkové, potlač pre medveď, slon 2ks	82	3	f	-	0	7	1	2012-10-13 10:14:24+02
3234	plienky bavlnené látkové, biele 6ks	82	5	f	-	0	8	1	2012-10-13 10:14:43+02
3237	komplet mikina modrá  s kapucňou s eskimákom + tepláčky 74/80	82	3	f	-	0	11	1	2012-10-13 10:15:02+02
3235	zaviňovačka biela s výšivkou 70x70cm, 2ks	82	5	f	-	0	9	1	2012-10-13 10:15:37+02
3247	kombinéza s kapucňou kožušinka, modrá, potlač autíčka	82	10	f	-	0	21	2	2012-10-14 10:16:33+02
3229	detské bavlnené osušky biele 2ks	82	5	f	-	0	3	1	2012-10-13 10:16:21+02
3243	komplet bundička+nohavice oteplené, bledomodré s macíkom 12/18 mesiacov	82	6	f	-	0	17	1	2012-10-13 10:16:30+02
3257	capačky žlté s havkom, 0-3mesiace	82	1	f	-	0	31	1	2012-10-13 10:16:46+02
3258	capačky modré s tigríkom, 0-3mesiace	82	1	f	-	0	32	1	2012-10-13 10:16:50+02
3254	čapičky oteplené, biela+modro/biela prúžok, 3-6mesiacov	82	4	f	-	0	28	1	2012-10-13 10:16:56+02
3253	čapičky  BABY, modrá+žltá, 0-3 mesiace, 2ks	82	4	f	-	0	27	1	2012-10-13 10:17:04+02
3259	čižmičky šedé, 0-3mesiace	82	1	f	-	0	33	2	2012-10-14 10:25:05+02
3255	čapičky modrá tuleň+zelená včielka, 0-3mesiace	82	4	f	-	0	29	1	2012-10-13 10:17:19+02
3251	pančušky zelené, 3-6 mesiacov, 2ks	82	4	f	-	0	25	1	2012-10-13 10:17:25+02
3231	papučky macko pu, modré, veľ. 26	82	4	f	-	0	5	1	2012-10-13 10:17:34+02
3245	spací vak, bledožltý, dlžka od krku po spodok, 60cm	82	2	f	-	0	19	1	2012-10-13 10:17:40+02
3244	oteplené dupačky, biele, potlač macko,zajac, veľ.6-9mesiacov	82	2	f	-	0	18	1	2012-10-13 10:17:42+02
3240	overal santa, červený, veľ. 6-9mesiacov	82	4	f	-	0	14	1	2012-10-13 10:17:49+02
3239	mikina zateplená oranžová uva + modrá winter bear, veľkosť 74	82	3	f	-	0	13	1	2012-10-13 10:17:57+02
3250	kombinéza s kapucňou, modrá s potlačou zajko	82	4	f	-	0	24	1	2012-10-13 10:18:07+02
3249	tepláčky s packami, modré+béžové prúžkové	82	4	f	-	0	23	1	2012-10-13 10:18:12+02
3241	podprsenka kojenecká biela, veľ. 90B	82	4	f	-	0	15	1	2012-10-13 10:18:23+02
3242	podprsenka kojenecká biela, veľ. 90B	82	4	f	-	0	16	1	2012-10-13 10:18:28+02
3256	ponošky mix, 0-6mesiacov, 6ks	82	1	f	-	0	30	1	2012-10-13 10:18:37+02
3246	oteplený komplet bunda+nohavice na traky, potlač modrý havko	82	8	f	-	0	20	2	2012-10-13 17:17:11+02
3279	Bundička tmavo modrá šustiaková zn. Kids kenvelo veľ. 92-98	83	3	f	-	0	8	1	2012-10-13 11:16:19+02
3277	Čiapka fialová vpredu obrázok princezien, zn. Disney	83	1	f	-	0	6	1	2012-10-13 11:16:25+02
3276	Čiapka ružová vpredu obrázok princezien, zn. Disney 	83	0.5	f	-	0	5	1	2012-10-13 11:16:27+02
3272	Biely pulóver červený nórsky vzor veľ. 86/92	83	1	f	-	0	1	2	2012-10-13 18:10:52+02
3273	Cyklámenové menžestrové šaty  zn. Cherokee veľ. 104	83	2	f	-	0	2	1	2012-10-13 11:16:39+02
3274	Tepláky šedé veľ. 110 cm zn. Cherokee - úplne nové 	83	2	f	-	0	3	2	2012-10-13 15:26:40+02
3236	menžestráky na traky, bežové, veľ. 62, kompas výšivka z predu	82	2.5	f	-	0	10	2	2012-10-13 15:51:45+02
3275	Rodžery zimné šedé čierne prešívanie oranžové veľ. 4, zn. Adidas	83	10	f	-	0	4	2	2012-10-13 16:37:00+02
3282	Zimná károvaná bundička s kapuckou tmavo-ružová s bielou,zn.Baby Club, veľ. 80	84	10	f	-	0	2	2	2012-10-13 16:48:23+02
3238	komplet tričko prúžkové modro/žlté so somárikom+tepláčky, veľ. 68	82	2	f	-	0	12	2	2012-10-13 19:02:12+02
3252	čapičky OUTLAST, modrá+zelená, 0-3mesiace, 2ks	82	5	f	-	0	26	2	2012-10-14 09:44:16+02
3332	Chlap.tričko dlhý rukáv zeleno biele vel.116	85	1	f	-	0	21	2	2012-10-14 11:24:23+02
3304	Papučky červené so sobíkom vpredu (capačky), patent bielo červené prúžky, veľ. 6-12 mesiacov	84	1.2	f	-	0	24	1	2012-10-13 09:03:23+02
3301	Biela čiapka teplá na šnúrky, vpredu macko, hore 2 ušká, veľ. 46	84	1.2	f	-	0	21	1	2012-10-13 09:03:34+02
3338	Chlap.polokosela šedo modrý pásik vel.122-128	85	2	f	-	0	27	2	2012-10-13 18:20:47+02
3305	Capačky hnedé čižmičkové s kožušinkou, vzadu na suchý zips, veľ. 6-12, zn. F&F	84	3	f	-	0	25	1	2012-10-13 09:03:53+02
3292	Dupačky dlhé nožičky, bez rukáva ružové, zapínanie gombíky, obrázok mačička,vtáčik a nápis, zn. K&Y, veľ. 74	84	3.7000000000000002	f	-	0	12	1	2012-10-13 09:04:03+02
3290	Ružovo biela károvaná košeľka s dlhým rukávkom na gombíky a s dvoma vreckami, zn. DOPO MINI, veľ.68	84	3	f	-	0	10	1	2012-10-13 09:04:17+02
3316	Chlap.modrá mikina so žltým nápisom vel.128	85	5	f	-	0	5	2	2012-10-13 17:14:39+02
3288	Biele dupačky s dlh.rukávkom, s ružovou potlačou Bambi a motýliky, ružové lemovanie, zn. F&F, veľ. 0-3 mesiace	84	2.6000000000000001	f	-	0	8	1	2012-10-13 09:04:25+02
3291	Sýro ružové tričko dlhý rukáv, vpredu motýlik našitý, zn. DOPO MINI, veľ. 68 ( 4-6 mes.)	84	2.7000000000000002	f	-	0	11	1	2012-10-13 09:04:42+02
3293	Tričko biele dlhý rukáv, 3 motýliky vpredu, veľ.74	84	1.2	f	-	0	13	2	2012-10-13 17:30:27+02
3312	Chlap.košela-hnedo biela pásiková veľ.122	85	6	f	-	0	1	2	2012-10-13 18:34:08+02
3295	Ružové tričko dlhý rukáv s V-výstrihom na výstrihu 2 gombíky, zn. Okay, veľ. 68 ( 4-6mes.)	84	2.5	f	-	0	15	1	2012-10-13 09:04:55+02
3300	Mikinka ružová na zips s kapuckou, zn. F&F, veľ. 9-12 mesiacov	84	1.8	f	-	0	20	1	2012-10-13 09:05:03+02
3294	Bavlnené biele tričko s limčekom, dlhý rukáv, na gombíky, potlač levík, slon,žirafa,zebra,lístky, veľ.0-3 mesiace	84	1.3	f	-	0	14	2	2012-10-13 18:40:10+02
3311	Bledo ružová čiapka so šiltíkom, vpredu vyšitý snehuliak s brmbolcom, zn. Richelieu, veľ. 2 ( 9-12 mesiacov)	84	1	f	-	0	31	2	2012-10-13 18:55:46+02
3309	Tmavo ružové kotníkové topánky po bokoch so srdiečkami, s dvoma prackami na suchý zips, gumová podrážka,veľ.20,zn.Bubble	84	6	f	-	0	29	1	2012-10-13 18:59:30+02
3307	Papučky ružové s tmavoružovým lemovaním,v predu na šnurovanie, potlač macko,kotva,písmenká a vlajky, veľ, 20	84	4	f	-	0	27	1	2012-10-13 09:05:35+02
3341	Chlap.polokosela modrá s pásikom vel.122	85	3	f	-	0	30	2	2012-10-13 15:26:40+02
3308	Bledučko fialové plátenné topánky, s tmavoružovou gumovou podrážkou na suchý zips, zn. Kornecki, veľ. 20	84	4	f	-	0	28	1	2012-10-13 09:05:42+02
3313	Chlap.košela ružová pásiková vel.116	85	6	f	-	0	2	1	2012-10-13 12:40:28+02
3315	Chlap.riflové trojšvrtové nohavice vel.116	85	6	f	-	0	4	1	2012-10-13 12:40:50+02
3302	Červená čiapka s mickey mouskou, veľ. Cca 1,5-2 roky	84	1.3	f	-	0	22	2	2012-10-13 15:42:31+02
3314	Chlap.riflové trojšvrtové nohavice vel.116	85	6	f	-	0	3	1	2012-10-13 12:41:21+02
3320	Chlap.sveter červený so vzorom vel.110-116	85	9	f	-	0	9	1	2012-10-13 12:48:50+02
3339	Chlap.tričko biele s hnedou potlačou vel.122	85	3	f	-	0	28	2	2012-10-13 15:56:17+02
3319	Chlap.mikina červená Hot oil vel.116	85	6	f	-	0	8	1	2012-10-13 12:49:01+02
3318	Chlap.mikina hnedo tyrkysova kocka vel.122	85	4	f	-	0	7	1	2012-10-13 12:49:06+02
3317	Chlap.zelená mikina vel.128	85	5	f	-	0	6	1	2012-10-13 12:49:12+02
3306	Capačky kožušinkové krémové, chlpaté, vpredu na šnurovanie, zn. Coccodrillo, veľ. 4 (6-12mesiacov)	84	2.6000000000000001	f	-	0	26	2	2012-10-14 09:37:16+02
3344	Chlap.termosuprava bledo modrá tielko+spodky vel.116	85	2	f	-	0	33	1	2012-10-13 12:49:37+02
3298	Bodíčka  biele dlhý rukáv, s ružovou potlačou hlavy zajka, zn. BABY CLUB, veľ. 80	84	1.8	f	-	0	18	2	2012-10-13 17:30:27+02
3336	Chlap.tričko dlhý rukáv béžové vel.122	85	2	f	-	0	25	1	2012-10-13 12:50:10+02
3297	Biele bodíčka dlhý rukáv, ružové lemovanie s ružovým zajkom vpredu, zn. BABY CLUB, veľ. 80	84	1.8	f	-	0	17	2	2012-10-13 17:30:27+02
3343	Chlap.polokosela tmavozelená vel.110	85	3	f	-	0	32	1	2012-10-13 12:52:34+02
3303	Fialové rukavičky zimné, štrikované spojené šnúrkou s kvetinkou na patente, veľ. 9-12 mesiacov	84	1	f	-	0	23	2	2012-10-13 17:47:00+02
3296	Ružové šaty s volánikom, ružovo-hnedé bodky, zapínanie cvoky na limci, obrázok myška s kvetinkou,zn. TU, veľ. 3-6 m.	84	3	f	-	0	16	2	2012-10-13 18:12:37+02
3331	Chlap.tričko dlhý rukáv červeno čierne vel.128	85	2	f	-	0	20	1	2012-10-13 12:57:55+02
3289	Biele dupačky s dlh.rukávkom s potlačou ružového zajka, zapínanie cvoky, zn. F&F, veľ. 0-3 mesiace	84	2.6000000000000001	f	-	0	9	2	2012-10-13 16:06:08+02
3337	Chlap.tričko dlhý rukáv oranž.s potlačou motorky vel.116	85	2	f	-	0	26	2	2012-10-13 16:10:29+02
3335	Chlap.tričko dlhý rukáv tmavo modré vel.122	85	2	f	-	0	24	2	2012-10-13 16:10:29+02
3340	Chlap.tričko dlhý rukáv s kapucou ice age zelené vel.122	85	3	f	-	0	29	2	2012-10-13 16:13:10+02
3345	Chlap.rolák slovenka tyrkys vel.130	85	1	f	-	0	34	2	2012-10-13 16:13:10+02
3408	snehule richter zelene s oranžovym vel.27	87	8	f	-	0	25	2	2012-10-13 16:11:17+02
3391	tepláky modré umbro 122	87	2	f	-	0	8	2	2012-10-14 09:44:16+02
3410	košela tik tak kockovana modro biela s kapucou tmavo modrou vel.98	87	2	f	-	0	27	1	2012-10-13 11:02:51+02
3349	Chlap.pyžamo Cars šede 116-122	85	2	f	-	0	38	2	2012-10-13 16:24:03+02
3351	Chlap.trigovica s kapucou na zips Cars vel.116-122	85	4	f	-	0	40	2	2012-10-13 16:50:32+02
3393	rifle okej velkosť 122 svetlo modre	87	2	f	-	0	10	1	2012-10-13 11:03:50+02
3394	bunda zimná kenvelo šeda s kockovanou hnedou podšívkou velkosť 116/122	87	7	f	-	0	11	1	2012-10-13 11:03:56+02
3392	oteplovaky tmavo modre velkosť 140 s vreckami a bielymi pásikmi na boku 	87	3	f	-	0	9	2	2012-10-13 15:11:23+02
3400	mikina adidas svetlo modra vel.104 	87	3.5	f	-	0	17	1	2012-10-13 11:04:07+02
3411	teplaokova suprava smily 110 tmavo modra so žltym mackami a autičkom na bruchu	87	4	f	-	0	28	1	2012-10-13 11:04:14+02
3389	nohavice kenvelo velkosť 126/132 šedé kapsáče	87	3.5	f	-	0	6	1	2012-10-13 11:04:22+02
3388	sveter kenvelo tmavo červeny aplikácia na rukávoch velkosť 128	87	3.5	f	-	0	5	1	2012-10-13 11:04:24+02
3371	Ružové tričko s motýlikom	86	1.5	f	-	0	20	2	2012-10-13 19:09:27+02
3386	 košela palomino červeno čierno modro biela velkosť 122 s aplikácoiu na chrbte	87	3	f	-	0	3	1	2012-10-13 11:04:33+02
3385	rolák bobito velkosť 140 modrý s chlapcom na bruchu	87	2	f	-	0	2	1	2012-10-13 11:04:36+02
3405	bunda prechodna c&a vel.128	87	5.5	f	-	0	22	1	2012-10-13 11:04:43+02
3375	Bledomodré rukavice na šnúrke	86	0.69999999999999996	f	-	0	24	2	2012-10-13 16:39:57+02
3364	Zimná podšitá čiapka s brmbolcom, šedo - ružová	86	2	f	-	0	13	2	2012-10-13 15:11:38+02
3372	Ružové tričko na gombičky, biely rukáv	86	1.5	f	-	0	21	2	2012-10-13 18:55:46+02
3403	teplakova suprava nike šedo modro biela vel.104/110 s oranžovym napisomo na chrbte	87	20	f	-	0	20	1	2012-10-13 11:05:07+02
3395	tričko s dl.rukavom palomino vel.122 pasikavý modro červeno bielo šedy s nápisom	87	2	f	-	0	12	2	2012-10-13 16:49:36+02
3390	tepláky umbro 122 čierne	87	2	f	-	0	7	2	2012-10-14 09:44:16+02
3367	Chlapčenská zelená károvaná košeľa	86	3	f	-	0	16	2	2012-10-14 10:53:50+02
3399	bunda zimná obojstranna šedá s bežovým pásom vel.cca104	87	3.5	f	-	0	16	1	2012-10-13 11:05:29+02
3352	Šedá tepláková súprava, pásiková kapucňa a rukávy	86	5	f	-	0	1	1	2012-10-13 11:14:45+02
3357	Tmavomodrá podšitá vesta s kapucňou + žlté tričko s mačkou	86	3	f	-	0	6	1	2012-10-13 11:14:57+02
3359	Biela kožušinová bundička s kapucňou, macková podšívka	86	3.5	f	-	0	8	1	2012-10-13 11:15:13+02
3354	Červané tričko s dlhým rukávom, nažehlený krtko	86	1.5	f	-	0	3	1	2012-10-13 11:15:24+02
3355	Oranžové body s potlačou auta, dlhý biely rukáv	86	0.59999999999999998	f	-	0	4	1	2012-10-13 11:15:38+02
3356	Biele body s dlhým rukávom, bledohnedé pásiky	86	0.59999999999999998	f	-	0	5	1	2012-10-13 11:15:40+02
3362	Zelený pletený sveter s kapucňou na zips	86	2	f	-	0	11	1	2012-10-13 11:15:45+02
3363	Sveter béžový na zips s golierikom	86	2	f	-	0	12	1	2012-10-13 11:15:48+02
3374	Bledomodrá zimná čiapka s bielym šiltom a uškami	86	1.2	f	-	0	23	1	2012-10-13 11:15:53+02
3365	Ružové podšité nohavice	86	2	f	-	0	14	1	2012-10-13 11:16:02+02
3366	Súprava - ružové tričko krátky rukáv, biele tričko dlhý rukáv	86	1.5	f	-	0	15	1	2012-10-13 11:16:03+02
3384	Sveter palomino velkosť 122 páskovaný béžovo-zelený s kapucou	87	3	f	-	0	1	2	2012-10-14 11:04:47+02
3368	Tmavomodré tričko s dlhým rukávom s nažehleným mackom	86	1.5	f	-	0	17	1	2012-10-13 11:16:13+02
3409	teplaky adams vel.116 modre so zelenymi pasmi	87	1.5	f	-	0	26	2	2012-10-14 09:44:16+02
3382	Zimné topánky na šnurovanie modro - červené	86	3	f	-	0	31	2	2012-10-13 18:04:39+02
3369	Bordové tričko s dlhým rukávom, medveď Revel Stoke	86	1.5	f	-	0	18	2	2012-10-14 09:21:26+02
3387	košela kenvelo velkosť 116/128 kockovaná bielo žlto zeleno červená s kapucou	87	3	f	-	0	4	2	2012-10-13 18:59:37+02
3360	Bieločervená súprava - nohavice a tričko so sobíkom	86	1.5	f	-	0	9	1	2012-10-13 11:16:57+02
3361	Béžová flísová bunda s kapucňou na zips	86	2	f	-	0	10	1	2012-10-13 11:16:58+02
3358	Šedé hrubé tepláky s bielymi pásikmi	86	1.5	f	-	0	7	1	2012-10-13 11:17:01+02
3406	snehule richter tmavo hnede soranžovým lepiace vel.28	87	6	f	-	0	23	2	2012-10-13 15:26:50+02
3373	Tmavomodrá šuštiaková bunda s kapucňou, žltá podšívka	86	3.5	f	-	0	22	1	2012-10-13 11:17:15+02
3402	mikina nike tmavo šeda vel.104/110 bielo modry napis	87	5	f	-	0	19	2	2012-10-13 16:45:05+02
3376	Riflové šaty na gombičky, biely pletený svetrík s fialovými bodkami	86	6	f	-	0	25	1	2012-10-13 11:17:28+02
3380	Béžovo - červená zimná bunda s kapucňou	86	2.5	f	-	0	29	1	2012-10-13 11:17:41+02
3377	Ružová súprava - nohavice, bunda s kapucňou a eskimákom	86	2.5	f	-	0	26	1	2012-10-13 11:17:46+02
3378	Ružovo - modrý vzorovaný zimný overal s kapucňou	86	2.5	f	-	0	27	1	2012-10-13 11:17:51+02
3379	Tmavomodrá bunda s kapucňou a mackom, bodkovaná podšívka	86	2	f	-	0	28	1	2012-10-13 11:17:58+02
3398	oteplovaky čierne na vrecku napis sport vel.cca128	87	3.5	f	-	0	15	2	2012-10-13 18:11:14+02
3383	Chlapčenský modrožltý ruksak s macko + ladvinka	86	3	f	-	0	32	1	2012-10-13 11:18:12+02
3353	Bordový rolák na zips, pleteninové rukávy	86	4	f	-	0	2	1	2012-10-13 11:18:21+02
3346	Chlap.termotricko dlhý rukav modre vel.116	85	2	f	-	0	35	1	2012-10-13 12:50:27+02
3370	Pásikové tričko šedo - modro - červené, nažehlený vláčik	86	1.5	f	-	0	19	2	2012-10-13 17:59:21+02
3347	Chlap.termotricko krátky rukav čierne vel.116	85	2	f	-	0	36	1	2012-10-13 12:54:50+02
3404	bunda zimna hneda vel.116 skapucou a kožušinou next	87	5	f	-	0	21	2	2012-10-13 16:24:03+02
3348	Chlap.pyžamo šede Disney vel.104-110	85	2	f	-	0	37	1	2012-10-13 12:57:12+02
3350	Chlap.pyžamo modro červený pásik 	85	2	f	-	0	39	1	2012-10-13 12:58:05+02
3397	tepláková suprava puma ružovo biela vel.L	87	12	f	-	0	14	2	2012-10-13 15:11:23+02
3453	súprava mikinka s tepláčkami tyrk-ruž.-čierna sweet&cute	89	2	f	-	0	1	2	2012-10-13 17:11:15+02
3434	dievčenská kabátová bunda, bordovo-červená	88	3	f	-	0	1	2	2012-10-13 17:17:11+02
3422	mikina bordova cherokee s napisom 7/8	87	2.5	f	-	0	39	1	2012-10-13 11:00:13+02
3429	menšestraky tirkisove na traky 68	87	1	f	-	0	46	1	2012-10-13 11:00:18+02
3432	overal loana 74 s medvedikmi modry	87	2.5	f	-	0	49	1	2012-10-13 11:00:22+02
3433	rifle s kockovanym okrajom baby roller 74 	87	1.5	f	-	0	50	1	2012-10-13 11:00:26+02
3431	nohavice oteplene kids 60 šede s červenym okrajom 	87	1	f	-	0	48	1	2012-10-13 11:00:30+02
3421	mikina šeda smily 98/104 s nakladnym autom 	87	2.5	f	-	0	38	1	2012-10-13 11:00:38+02
3443	bledomodrá bunda	88	2.5	f	-	0	10	2	2012-10-13 19:06:08+02
3419	bunda menčestrova s kockovanou podšivkou h&m 62	87	2	f	-	0	36	1	2012-10-13 11:00:51+02
3428	mikina cherokee kaki 5/6 s levom a kapucou 	87	2.5	f	-	0	45	1	2012-10-13 11:00:55+02
3418	zavinovačka modra s mačkou frote 	87	4	f	-	0	35	1	2012-10-13 11:01:04+02
3417	zavinovačka bežova s mačkou frote 	87	4	f	-	0	34	1	2012-10-13 11:01:19+02
3415	teplakova suprava spiderman 110 	87	2	f	-	0	32	1	2012-10-13 11:01:25+02
3425	tričko big ben 80 kaki s psikom	87	1.5	f	-	0	42	1	2012-10-13 11:01:43+02
3426	mikina smily 98/104 flakata bielo modra s 5	87	2	f	-	0	43	1	2012-10-13 11:01:46+02
3427	prechodna bunda george 92/98 šeda modra červena	87	2.5	f	-	0	44	1	2012-10-13 11:01:53+02
3466	body pásikavé so srdiečkom3-6mes.	89	2	f	-	0	14	2	2012-10-13 18:03:40+02
3423	bunda zimna tmavo svetlo modro červeno komponet 122	87	5	f	-	0	40	1	2012-10-13 11:02:36+02
3416	menčestraky hnede denim co 98	87	2	f	-	0	33	1	2012-10-13 11:02:41+02
3412	nohavice modre mariaqueita 92 	87	2	f	-	0	29	1	2012-10-13 11:02:47+02
3444	modrá bunda so svetlejším okrajom, možnosť odopnúť rukávy	88	2.5	f	-	0	11	1	2012-10-13 11:51:05+02
3477	čiapka teplá bielozelená	89	1.5	f	-	0	25	2	2012-10-13 17:50:54+02
3464	roláčik fialový pásikavý	89	5.5	f	-	0	12	2	2012-10-13 19:09:27+02
3451	biely pletený sveter na gombíky	88	1.2	f	-	0	18	2	2012-10-13 18:46:04+02
3413	čapica ušinaka bežova pletena s kožušinou	87	1.5	f	-	0	30	2	2012-10-13 16:57:51+02
3447	sivá bunda	88	1.5	f	-	0	14	1	2012-10-13 11:52:02+02
3465	ružová mikinka Adorable v.9mes	89	1.6000000000000001	f	-	0	13	2	2012-10-13 18:55:46+02
3420	bunda zelena frote 56 absorba	87	2	f	-	0	37	2	2012-10-13 18:57:46+02
3436	modré rifle s dinosaurom	88	1.8	f	-	0	3	1	2012-10-13 11:52:55+02
3446	červený sveter s kapucňou na zapínanie s gombíkmi	88	1.8999999999999999	f	-	0	13	1	2012-10-13 11:53:06+02
3452	ružový pletený sveter	88	0.69999999999999996	f	-	0	19	1	2012-10-13 11:53:12+02
3449	biele tepláky s modroružovým prúžkom	88	1	f	-	0	16	1	2012-10-13 11:53:21+02
3450	svetložltá mikina - nápis POP STAR	88	0.90000000000000002	f	-	0	17	1	2012-10-13 11:53:27+02
3484	mikina ružová s kapuckou a kvietkami v. 9-12mes.	89	2	f	-	0	32	2	2012-10-13 15:55:14+02
3483	čiapočka s uškami ružová	89	1.5	f	-	0	31	2	2012-10-13 16:00:42+02
3439	tričko béžové so srdiečkami	88	1.1000000000000001	f	-	0	6	1	2012-10-13 11:53:45+02
3438	tričko biele s ružovým okrajom a nápisom, dlhý rukáv	88	0.90000000000000002	f	-	0	5	1	2012-10-13 11:53:50+02
3437	sivé tepláky	88	0.90000000000000002	f	-	0	4	1	2012-10-13 11:53:55+02
3454	ružové zateplené tričko s mackom v. 74	89	1.5	f	-	0	2	1	2012-10-13 12:23:19+02
3430	suprava teplaky +vesta semišova s dračikom modra 	87	2	f	-	0	47	2	2012-10-13 17:17:11+02
3456	ružová bundička so srdiečkom 3-6mes.	89	4	f	-	0	4	1	2012-10-13 12:23:28+02
3478	mikina fialová s nápisom GIRLS ROCK v.13-14r.	89	2.2000000000000002	f	-	0	26	2	2012-10-13 15:49:54+02
3458	tmavošedé nohavice 146/152	89	3	f	-	0	6	2	2012-10-13 16:29:43+02
3480	nohavice s trakmi tmavoružové Tup-tup v.74	89	1.5	f	-	0	28	2	2012-10-13 16:46:23+02
3455	riflova bundička Baby - club v. 68	89	2.5	f	-	0	3	1	2012-10-13 12:24:56+02
3459	rifle tmavomodré Next v.74	89	4	f	-	0	7	1	2012-10-13 12:25:02+02
3461	rolačik šedý melírovaný	89	1.5	f	-	0	9	1	2012-10-13 12:25:12+02
3474	mikinka Next ružová s kapuckou 6-9mes.	89	3	f	-	0	22	1	2012-10-13 12:25:21+02
3468	tenisky Nike v.19mes.	89	7.2000000000000002	f	-	0	16	2	2012-10-13 15:44:08+02
3445	ružová bunda s kapucňou dlhšia, kvietková potlač	88	2.5	f	-	0	12	2	2012-10-13 18:07:58+02
3475	nohavice zateplené v.164 tmavošedé	89	1.8999999999999999	f	-	0	23	1	2012-10-13 12:26:18+02
3467	čiapočka bieloružová s bodkami a vzorom	89	1.3999999999999999	f	-	0	15	2	2012-10-13 15:40:33+02
3470	zelené tričko dl.rukáv Wenice s autíčkom	89	1.5	f	-	0	18	1	2012-10-13 12:29:17+02
3473	čiapočka Next 3-6mes.flaušová s kvietkami	89	2.5	f	-	0	21	1	2012-10-13 12:29:22+02
3414	oteplovaky šede ydi116/122	87	5	f	-	0	31	2	2012-10-13 17:59:36+02
3472	čiapočka Next 3-6mes.ružová s motýlikom	89	2.2000000000000002	f	-	0	20	1	2012-10-13 12:29:39+02
3463	ružový overal s limčekom  a volánikmi 9/12mes.	89	2.5	f	-	0	11	1	2012-10-13 12:29:46+02
3471	tričko čierne dlhy rukáv s napisom Beautiful v. 152	89	1.8	f	-	0	19	2	2012-10-13 15:34:56+02
3457	zelene tričko so zebričkou nápis Little zebra	89	2	f	-	0	5	1	2012-10-13 12:30:06+02
3469	svetrík bielosmotanový Next na gombíky	89	2.2999999999999998	f	-	0	17	1	2012-10-13 12:30:32+02
3440	biely rolák, dlhý rukáv	88	1	f	-	0	7	2	2012-10-13 15:59:01+02
3479	overal na spinkanie ružový s mačičkou	89	0.90000000000000002	f	-	0	27	1	2012-10-13 12:30:45+02
3448	červená bunda s kožušinkovou kapucňou a opaskom, dlhšia	88	3.7000000000000002	f	-	0	15	2	2012-10-13 16:57:51+02
3441	ružový sveter - rolák s vyšitými kvietkami	88	1.5	f	-	0	8	2	2012-10-13 15:52:30+02
3481	bunda prechodná modrá s kapuckou vzorovaná v.80	89	1.5	f	-	0	29	1	2012-10-13 12:31:33+02
3482	rifle bledomodré v.25 s bielou výšivkou okolo vačkov	89	5	f	-	0	30	1	2012-10-13 12:31:41+02
3476	rifle bledomodré Marks&Spencer	89	4	f	-	0	24	1	2012-10-13 12:31:45+02
3460	bunda zelena dievčenská Cherokee v.152	89	4.4000000000000004	f	-	0	8	2	2012-10-13 14:59:36+02
3520	Biela drevene detska postielka	91	50	f	-	0	1	0	2012-10-11 21:54:25+02
3521	Kokosovy madrac do postielki	91	20	f	-	0	2	0	2012-10-11 21:54:25+02
3522	modre teniski vysoke.vel28.5	91	15	f	-	0	3	0	2012-10-11 21:54:25+02
3523	čierne teplaki chlapcenske .vel115cm	91	7	f	-	0	4	0	2012-10-11 21:54:25+02
3524	bielo hneda pružkovana trigovica.vel 104cm	91	7	f	-	0	5	0	2012-10-11 21:54:25+02
3525	Hneda chlapčenska trigovica,kapuca.vel 104cm	91	7	f	-	0	6	0	2012-10-11 21:54:25+02
3526	štrikovany modro biely svetrik,šal,čiapica.vel 104 cm	91	7	f	-	0	7	0	2012-10-11 21:54:25+02
3527	červena sukna.vel86 cm	91	5	f	-	0	8	0	2012-10-11 21:54:25+02
3528	Nosič deti chicco	91	40	f	-	0	9	0	2012-10-11 21:54:25+02
3529	Červeny otepleny vak na kočik	91	30	f	-	0	10	0	2012-10-11 21:54:25+02
3530	Modry vak na kočik vel.80 cm	91	15	f	-	0	11	0	2012-10-11 21:54:25+02
3531	Ružovy spiacy vak obrayok hroch.	91	15	f	-	0	12	0	2012-10-11 21:54:25+02
3532	cervena trigovica dievcenska,kapuca,zips+teplaki cervene.vel 18 m	91	10	f	-	0	13	0	2012-10-11 21:54:25+02
3533	biela rigovica,gombiki.vel 12 mes	91	5	f	-	0	14	0	2012-10-11 21:54:25+02
3534	cervena trigovica,napis na ruke,kapuca,zips.vel 6 mes	91	7	f	-	0	15	0	2012-10-11 21:54:25+02
3535	seda trigovica,kapuca,gombiki.vel 74cm	91	5	f	-	0	16	0	2012-10-11 21:54:25+02
3536	modry štrikovani svetrik+šal.vel 104cm	91	7	f	-	0	17	0	2012-10-11 21:54:25+02
3537	pružkovana ciapica+šal.vel 54cm	91	5	f	-	0	18	0	2012-10-11 21:54:25+02
3538	pružkovana ciapica+šal.vel 54cm	91	5	f	-	0	19	0	2012-10-11 21:54:25+02
3539	modre dievcenske dzinsi,i.vel 86cm	91	7	f	-	0	20	0	2012-10-11 21:54:25+02
3540	modro seda chlapcenska trigovica tenka,dlhy rukav.vel 110cm	91	6	f	-	0	21	0	2012-10-11 21:54:25+02
3541	modro cierna pružkovana chlapcenska trigovica tenka,dlhy rukav.vel 110cm	91	5	f	-	0	22	0	2012-10-11 21:54:25+02
3542	sedo cierna pruzkovana tenka trigovica,kapuca.vel110cm	91	6	f	-	0	23	0	2012-10-11 21:54:25+02
3543	seda trigovica biely dlhy rukav,kapuca.vel 104cm	91	6	f	-	0	24	0	2012-10-11 21:54:25+02
3544	cervena trigovica tenka,cierni pruzki.vel 110cm	91	6	f	-	0	25	0	2012-10-11 21:54:25+02
3545	modra trigovica,biely rukav.napis a kvetinki.vel 86 cm	91	5	f	-	0	26	0	2012-10-11 21:54:25+02
3546	biela trigovicka,kvetinki cervene.vel 86cm	91	5	f	-	0	27	0	2012-10-11 21:54:25+02
3547	seda trigovica,obrazok zajacik.vel 86 cm	91	6	f	-	0	28	0	2012-10-11 21:54:25+02
3548	ruzova trigovica tenka obrazok macicka.vel86 cm	91	6	f	-	0	29	0	2012-10-11 21:54:25+02
3549	seda tenka trigovicka.obrazok farebna macicka.vel86 cm	91	6	f	-	0	30	0	2012-10-11 21:54:26+02
3550	seda tenka trigovicka.obrazok farebna macicka.vel 98cm	91	6	f	-	0	31	0	2012-10-11 21:54:26+02
3551	modra bunda na zimu,kapuca.vel  6mes	91	15	f	-	0	32	0	2012-10-11 21:54:26+02
3552	zelene chlapcenske oteplovaki.vel 98 cm	91	6	f	-	0	33	0	2012-10-11 21:54:26+02
3553	Fialove topanki dievcenske.vel 6(UK)	91	10	f	-	0	34	0	2012-10-11 21:54:26+02
3554	biele bodicko,dlhy rukav.obrazki zajacikovja.vel 12 mes	91	3	f	-	0	35	0	2012-10-11 21:54:26+02
3555	modre teplaki.vel 104 cm	91	7	f	-	0	36	0	2012-10-11 21:54:26+02
3518	bunda zimná khaki-béžová, Hot oil, veľkosť 146/152	90	12	f	-	0	16	1	2012-10-13 11:14:05+02
3519	bunda zimná červeno, bielo, čierna, veľkosť 158	90	13	f	-	0	17	1	2012-10-13 11:14:16+02
3503	rifle modre kenvelo, velkost 10	90	2.5	f	-	0	1	1	2012-10-13 11:14:31+02
3513	nohavice flisove béžové Timbuktoo, veľkosť 152	90	2.5	f	-	0	11	2	2012-10-13 18:46:04+02
3505	košela flanelová kárová modrá, veľkosť 10	90	1.5	f	-	0	3	1	2012-10-13 11:14:46+02
3506	trigovica khaki Timeout, veľkosť 10	90	2.5	f	-	0	4	1	2012-10-13 11:14:53+02
3495	súprava body+menčestrové šatičky 3-6mes.	89	5	f	-	0	43	2	2012-10-13 19:11:27+02
3508	košeľa zelená Kenvelo, veľkosť 10	90	2.5	f	-	0	6	1	2012-10-13 11:15:15+02
3509	nohavice tmavomodré Walter style, veľkosť 158	90	1.5	f	-	0	7	1	2012-10-13 11:15:27+02
3510	rolák modrý, Sara, veľkosť 146	90	1.5	f	-	0	8	1	2012-10-13 11:15:48+02
3511	bunda riflová čierna TCM, veľkosť 146-152	90	3	f	-	0	9	1	2012-10-13 11:15:55+02
3512	nohavice modré Kenvelo, veľkosť 10	90	2.5	f	-	0	10	1	2012-10-13 11:16:04+02
3507	košeľa zelená károvaná Kenvelo, veľkosť 10	90	2.5	f	-	0	5	2	2012-10-13 18:55:17+02
3514	košeľa hnedá károvaná Alive	90	1.5	f	-	0	12	1	2012-10-13 11:16:18+02
3515	košeľa zelená Savvy, veľkosť 152	90	1.5	f	-	0	13	1	2012-10-13 11:16:25+02
3516	rifle modre Okay, veľkosť 152	90	1.5	f	-	0	14	1	2012-10-13 11:16:31+02
3486	snehule Strarheight bordové v. 37	89	5	f	-	0	34	1	2012-10-13 12:22:55+02
3490	knižka Fisher Price	89	5	f	-	0	38	2	2012-10-14 11:14:31+02
3489	kožušinkové papučky smotanové	89	3.5	f	-	0	37	2	2012-10-13 16:36:03+02
3488	snehule čierno-bordové na 2suché zipsy	89	2.1000000000000001	f	-	0	36	1	2012-10-13 12:23:42+02
3492	papučky červene 	89	1.2	f	-	0	40	1	2012-10-13 12:23:49+02
3502	komplet šál+čiapka oranžový	89	1.5	f	-	0	50	2	2012-10-13 17:17:43+02
3491	prve topanočky bielo-modre	89	1.2	f	-	0	39	1	2012-10-13 12:24:16+02
3504	nohavice flisove modre tesco, velkost 9-10	90	2.5	f	-	0	2	2	2012-10-13 17:31:41+02
3500	biely sametový komplet s ružovou ozdobou	89	6	f	-	0	48	1	2012-10-13 12:25:33+02
3494	čiapočka ružová s kvietkom	89	2.2000000000000002	f	-	0	42	1	2012-10-13 12:25:50+02
3493	vestička oranžová	89	6	f	-	0	41	1	2012-10-13 12:26:32+02
3487	prechodná bundička ružová	89	1.2	f	-	0	35	1	2012-10-13 12:27:04+02
3498	mikina cyklamenova v.62/68 na zips	89	1.5	f	-	0	46	1	2012-10-13 12:31:03+02
3499	ružové menčestrové šaty	89	1.2	f	-	0	47	2	2012-10-13 16:34:29+02
3501	zelený overal na cvoky	89	4.5	f	-	0	49	1	2012-10-13 12:31:24+02
3485	tunika ružová Cherokee 9-12mes. S vačkami a kvietkom	89	2.2000000000000002	f	-	0	33	1	2012-10-13 12:31:29+02
3496	šaty zelene komb.s červenou volany na spodku Alphabet	89	2.5	f	-	0	44	2	2012-10-13 15:33:00+02
3556	ružové tričko, prúžok, s bielym golierom	92	0.5	f	-	0	1	1	2012-10-13 12:40:43+02
3557	modro čierna lyžiarska bunda s kapucou	92	10	f	-	0	2	2	2012-10-13 14:59:36+02
3607	ružová mikinka na cvočky zn. Beebies, veľ. 62 - 68	93	4	f	-	0	2	1	2012-10-13 11:32:50+02
3608	fialové pásikové tepláčiky zn. Vea, veľ. 56	93	3	f	-	0	3	1	2012-10-13 11:32:53+02
3609	bledoružový overal Maminka+ocinko=Lilianka, zn. Bess, veľ. 74	93	5	f	-	0	4	1	2012-10-13 11:32:56+02
3610	cyklaménový overal Minnie zn. Disney, veľ. 86	93	5	f	-	0	5	1	2012-10-13 11:32:58+02
3611	bielozelené polodupačky zn. flexi, veľ. 2 M	93	2.5	f	-	0	6	1	2012-10-13 11:33:01+02
3613	cyklamenovy overal Scooby Doo zn.Tinko, veľ. 62	93	5	f	-	0	8	1	2012-10-13 11:33:07+02
3614	cyklamenové tričko s ldhým rukávom zn. Okay, veľ. 68	93	2.5	f	-	0	9	1	2012-10-13 11:33:11+02
3615	svetlooranžový svetrík na zips zn.Items, veľ. 68	93	4	f	-	0	10	1	2012-10-13 11:33:13+02
3567	bledoružový rolak	92	0.5	f	-	0	12	2	2012-10-13 19:12:22+02
3617	červené froté dupačky zn. Mim veľ. 62	93	3.5	f	-	0	12	1	2012-10-13 11:33:19+02
3562	tmavomodrá chlap mikina coccordilo	92	1.5	f	-	0	7	2	2012-10-13 18:20:47+02
3619	cyklamenove body s nasitym trickom zn. F&F, veľ. 3 - 6 M	93	3.5	f	-	0	14	1	2012-10-13 11:33:25+02
3620	suprava flisove ruzove noh.na traky a body zn. F&F, veľ. 6 - 9 M	93	5	f	-	0	15	1	2012-10-13 11:33:27+02
3621	ruzova bunda s kapucňou a kožušinou zn. Baby, veľ. 68	93	4.5	f	-	0	16	1	2012-10-13 11:33:31+02
3603	fialkový župan s vyšitou princeznou	92	1.5	f	-	0	48	2	2012-10-13 17:44:19+02
3623	ružová huňatá mikinka na cvočky, veľ. 62	93	4	f	-	0	18	1	2012-10-13 11:33:36+02
3624	fialová vesta zn. F&F, veľ. 86	93	4	f	-	0	19	1	2012-10-13 11:33:39+02
3626	huňatý ružový pulóvrik zn. Disney, veľ. 0 - 3 M	93	3.5	f	-	0	21	1	2012-10-13 11:33:46+02
3625	flísový ružový overal zn. TU, veľ. 68 - 74	93	4	f	-	0	20	1	2012-10-13 11:33:48+02
3627	cyklamenová zimná bundička zn. Cherokee, veľ. 3 - 6 M	93	5	f	-	0	22	1	2012-10-13 11:33:52+02
3628	flísové bieloružové dupačky so srdiečkom zn. Domaja, veľ. 68	93	3	f	-	0	23	1	2012-10-13 11:33:57+02
3629	bledožltý svetrík na gombíky zn. Mini mode, veľ. 3 - 6 M	93	4	f	-	0	24	1	2012-10-13 11:34:00+02
3630	ružová flísová bundička na cvočky s kapucňou, veľ. 6 - 12 M	93	4	f	-	0	25	1	2012-10-13 11:34:02+02
3594	krémové čižmičky Skippy	92	4.5	f	-	0	39	1	2012-10-13 12:36:00+02
3591	hnedé chlapč. Pančuchy 	92	0.5	f	-	0	36	2	2012-10-14 11:06:18+02
3584	pasík rolak chlapč tenký	92	1	f	-	0	29	2	2012-10-13 18:06:11+02
3601	kremove tričko dlh. Rukáv, kapuska s potlačou kvetiniek a srdiečok	92	4	f	-	0	46	1	2012-10-13 12:36:14+02
3592	hnedé zateplené pančušky	92	1	f	-	0	37	2	2012-10-13 15:29:14+02
3604	krémová flisová mikina	92	0.80000000000000004	f	-	0	49	1	2012-10-13 12:36:28+02
3570	fialové rukavičky, palčiaky	92	1	f	-	0	15	2	2012-10-13 16:39:57+02
3595	modrý bavlnený rolak	92	1.5	f	-	0	40	1	2012-10-13 12:36:35+02
3586	tmavomodrý pletený rolak hrubší	92	2	f	-	0	31	1	2012-10-13 12:36:41+02
3585	šedooranžový hrubší rolak na zips, stojačík	92	1.5	f	-	0	30	1	2012-10-13 12:36:46+02
3599	šedá mikina so stojačikom GAP	92	1.2	f	-	0	44	1	2012-10-13 12:36:56+02
3590	chlapčenské šedozelené pyžamo	92	1	f	-	0	35	2	2012-10-13 18:11:14+02
3583	šedý pletený rolak hrubší	92	1.2	f	-	0	28	1	2012-10-13 12:37:03+02
3597	tmavomodrý nátelník dlh. Rukáv	92	0.5	f	-	0	42	1	2012-10-13 12:37:11+02
3618	ružové menžestrové nohavice na traky zn.Peter Rabbit, veľ. 68	93	4.5	f	-	0	13	2	2012-10-13 18:20:14+02
3581	žlto ružová čiapka pletená	92	1	f	-	0	26	2	2012-10-13 16:57:51+02
3580	oranžové flisové nohavice s kvetinkami	92	1	f	-	0	25	2	2012-10-13 15:58:24+02
3605	šedozelená mikina na zips Rebel	92	1.2	f	-	0	50	1	2012-10-13 12:37:47+02
3589	bordová mikinka s vtáčikom	92	1	f	-	0	34	1	2012-10-13 12:37:51+02
3576	biele tričko dlh, rukáv s chlapcom	92	1	f	-	0	21	1	2012-10-13 12:38:00+02
3575	modrá kockovaná košela, dlh. Rukáv	92	2.5	f	-	0	20	1	2012-10-13 12:38:05+02
3573	ružový hrubší rolak s kvetinkou	92	1	f	-	0	18	1	2012-10-13 12:38:13+02
3578	farebný pásik rolak hubší	92	1	f	-	0	23	1	2012-10-13 12:38:18+02
3582	biele bavlnené pančušky	92	1.2	f	-	0	27	1	2012-10-13 12:38:24+02
3566	hnedé zimné topánky Superfit	92	5	f	-	0	11	1	2012-10-13 12:38:28+02
3579	krémový dievčenský rolak hrubší	92	1.5	f	-	0	24	2	2012-10-13 16:52:32+02
3574	 biele nátelníky, 2 kusy, cena spolu	92	0.80000000000000004	f	-	0	19	1	2012-10-13 12:38:38+02
3602	kremova flisova mikina hrubšia LC	92	1	f	-	0	47	2	2012-10-14 10:20:38+02
3571	chlapčenské hnedo oranžové pyžamo	92	1	f	-	0	16	1	2012-10-13 12:38:52+02
3572	žlto ružová čiapka s bomrlcami	92	3	f	-	0	17	1	2012-10-13 12:38:58+02
3568	modrá vzorovaná čiapka so šálom	92	2	f	-	0	13	1	2012-10-13 12:39:03+02
3569	červenočierna čiapka so šalom a rukavicami	92	3.5	f	-	0	14	1	2012-10-13 12:39:07+02
3593	čierne kopačky	92	1.5	f	-	0	38	1	2012-10-13 12:39:15+02
3596	bledomodrý rolak	92	0.5	f	-	0	41	2	2012-10-13 16:06:44+02
3587	ružové tepláčiky 	92	1	f	-	0	32	2	2012-10-13 16:50:17+02
3561	krémovo modry chlapč sveter WS	92	2.5	f	-	0	6	1	2012-10-13 12:39:35+02
3559	fialovo biela lyžiarska bunda s kapuckou	92	10	f	-	0	4	1	2012-10-13 12:39:37+02
3622	biele menžestrové nohavice s kvetinkami zn. Next, veľ. 9 - 12 M	93	5	f	-	0	17	2	2012-10-13 17:13:47+02
3564	kremový flisový rolak s Minie	92	1.5	f	-	0	9	1	2012-10-13 12:39:48+02
3598	zateplené ponožky 2 kusy /modré a červené/	92	0.5	f	-	0	43	1	2012-10-13 12:39:58+02
3616	cyklamenove teplaky na traky zn. FROG, veľ. 80/86	93	3.5	f	-	0	11	2	2012-10-13 18:55:46+02
3588	biely nátelník dlh. Rukáv	92	1	f	-	0	33	1	2012-10-13 12:40:09+02
3563	krémový rolak B	92	0.5	f	-	0	8	1	2012-10-13 12:40:13+02
3565	tmavoružový hrubší rolak s kvetinkou	92	2	f	-	0	10	1	2012-10-13 12:40:32+02
3560	červené papučky s koníkom	92	3	f	-	0	5	1	2012-10-13 12:40:49+02
3600	čierna mikina s farebnou potlačou Athlettick	92	1	f	-	0	45	2	2012-10-13 15:11:23+02
3631	cyklaménové sametové tričko s dlhým rukávom veľ. 3 - 6 M	93	3	f	-	0	26	1	2012-10-13 11:34:06+02
3632	pásikový svetrík na 3 gombíčky zn. Cherokee, veľ. 3 - 6 M	93	4	f	-	0	27	1	2012-10-13 11:34:08+02
3633	fialové body s rolákom dlhý rukáv zn. Frog, veľ. 6 - 9 M	93	3.5	f	-	0	28	1	2012-10-13 11:34:10+02
3634	ružový hrubý overal na zimu zn. Sweet Baby, veľ. 6 - 9 M	93	8	f	-	0	29	1	2012-10-13 11:34:12+02
3635	hrubá rifl.bunda s cyklam. Podšívkou zn. Mini Mode, veľ. 0 - 3 M	93	8	f	-	0	30	1	2012-10-13 11:34:15+02
3636	fialové podšité nohavice zn. F&F, veľ. 6 - 9 M	93	4	f	-	0	31	1	2012-10-13 11:34:18+02
3637	bledoružová bunda zn.Kids Baby-Kap, veľ. 74	93	5	f	-	0	32	1	2012-10-13 11:34:21+02
3638	ružová bunda s kapucňou zn. Celebrity Baby, veľ. 9 - 12 M	93	5	f	-	0	33	1	2012-10-13 11:34:23+02
3655	fialový kabátik s kožušinkou zn. Next, veľ. 6 - 9 M	93	6	f	-	0	50	2	2012-10-13 16:50:31+02
3640	modré rifle na traky s písmenkami 	93	3	f	-	0	35	1	2012-10-13 11:34:41+02
3641	modré rifličky zn. H&M, veľ. 68	93	3	f	-	0	36	1	2012-10-13 11:34:46+02
3642	cyklaménový overal Ľúbim maminku a ocinka zn. Bess, veľ. 68	93	6	f	-	0	37	1	2012-10-13 11:34:49+02
3643	cyklaménové nohavice zn. Okay, veľ. 74	93	3.5	f	-	0	38	1	2012-10-13 11:34:52+02
3644	fialovoružové pásikové tričko s dlhým rukávom zn. Okay, veľ. 74	93	3	f	-	0	39	1	2012-10-13 11:34:56+02
3645	bledoružový overal s nápisom LILIANKA zn. Bess, veľ. 68	93	5	f	-	0	40	1	2012-10-13 11:34:59+02
3647	cyklam.súprava tričko s dlhým rukávom a tepláky zn. CDRL, veľ. 74	93	6	f	-	0	42	1	2012-10-13 11:35:08+02
3648	bledoružová flísová súprava mikina a tepláky zn. Frog, veľ. 62 - 68	93	5	f	-	0	43	1	2012-10-13 11:35:12+02
3649	bieloružová flísová súprava zn. TV, veľ. 3 - 6	93	5	f	-	0	44	1	2012-10-13 11:35:21+02
3650	zelené body s dlhým rukávom zn. Albi Baby, veľ. 74	93	2	f	-	0	45	1	2012-10-13 11:35:23+02
3651	bledoružová súprava mikina s kr. rukávom a tepláčiky, veľ. 56 - 62 	93	4	f	-	0	46	1	2012-10-13 11:35:25+02
3652	cyklam.-guličková súpr. tričko dlhý rukáv a gate, zn. Disney, veľ. 62	93	6	f	-	0	47	1	2012-10-13 11:35:29+02
3653	bieložlté pásikové dupačky zn. Items, veľ. 56 	93	2	f	-	0	48	1	2012-10-13 11:35:36+02
3654	krémové polodupačky veľ. 68	93	2.5	f	-	0	49	1	2012-10-13 11:35:38+02
3668	pyžamko ružovej farby, zajačik s mockom vpredu.vel.6-9	94	3.5	f	-	0	13	1	2012-10-13 11:44:33+02
3663	ružový uterák Macko Puf.Disney Baby, 100%polyester	94	3	f	-	0	8	1	2012-10-13 11:44:43+02
3665	tričko na dojčenie, čierne na ramienky	94	2.5	f	-	0	10	1	2012-10-13 11:44:54+02
3667	pyžamko fialovel farby s vtáčikmi,kvietkom a motýlik, F§F.vel. 6-9mes.	94	2.5	f	-	0	12	1	2012-10-13 11:45:01+02
3669	pyžamko ružovej farby,zajačik na lavej strane s nápisom Piglet.Zn.Disnej Baby.vel.18-24mes	94	3	f	-	0	14	1	2012-10-13 11:45:07+02
3670	tehu fialovy top 9fashion, nazov CORA, velkost S, amarant	95	8.9000000000000004	f	-	0	1	1	2012-10-13 11:57:44+02
3673	tricko next bledoruzove s maslickou dlhy rukav, c. 92	95	2.2000000000000002	f	-	0	4	1	2012-10-13 11:57:47+02
3676	sede mencestraky Topolino, 80	95	4	f	-	0	7	1	2012-10-13 11:57:49+02
3677	bledoruzovy hruby overal, nakres zajka, c. 86	95	7.9000000000000004	f	-	0	8	1	2012-10-13 11:57:52+02
3679	modre riflove satecky, cherokee, c. 86	95	3.5	f	-	0	10	1	2012-10-13 11:58:04+02
3681	bledomodre rifle s kvietkami, baby croc, 6-12 mesiacov	95	3.2999999999999998	f	-	0	12	1	2012-10-13 11:59:12+02
3682	ruzove teplaky Katval 10, velkost 110	95	2.7000000000000002	f	-	0	13	1	2012-10-13 11:59:12+02
3683	smotanove zateplene mencestraky, 12 mesiacov, vysite 3 capky	95	3	f	-	0	14	1	2012-10-13 11:59:14+02
3684	bledomodre dupacky Loana so zajkom, c. 68	95	2.2000000000000002	f	-	0	15	1	2012-10-13 11:59:16+02
3686	smotanovy overalik s mackom Pu, Disney, George, first size	95	2.3999999999999999	f	-	0	17	1	2012-10-13 11:59:19+02
3687	mencestraky smotanove mothercare, 3-6 mesiacov	95	2.8999999999999999	f	-	0	18	1	2012-10-13 11:59:21+02
3688	ruzovy overalik s mackom, early days, newborn	95	2.2999999999999998	f	-	0	19	1	2012-10-13 11:59:24+02
3690	kaki gate image kids, c. 68	95	3.2000000000000002	f	-	0	21	1	2012-10-13 11:59:27+02
3692	bledofialove gate Next, 3-6 mesiacov	95	2.6000000000000001	f	-	0	23	1	2012-10-13 11:59:32+02
3693	rifle na traky s ruzovym vnutrom mothercare, 6-9 mesiacov	95	3	f	-	0	24	1	2012-10-13 11:59:34+02
3694	bledoruzove mencestraky na traky Milou, c. 74	95	3	f	-	0	25	1	2012-10-13 11:59:37+02
3695	modre mencestraky na traky Perfect pals, 12 m.	95	3	f	-	0	26	1	2012-10-13 11:59:39+02
3691	tmavosede gate image kids, c. 74	95	3.2000000000000002	f	-	0	22	2	2012-10-13 17:47:48+02
3674	ruzova teplakova supravicka herma, 62	95	4.9000000000000004	f	-	0	5	1	2012-10-13 11:59:48+02
3672	bieloruzova teplakova suprava s flitrami, 24m, mon petit	95	5.9000000000000004	f	-	0	3	1	2012-10-13 11:59:51+02
3671	sametove gate na traky F&F s bielym body, 3-6 mesiacov	95	3.2999999999999998	f	-	0	2	1	2012-10-13 11:59:53+02
3685	bielofialove tenisky magnus, c. 25	95	2.8999999999999999	f	-	0	16	1	2012-10-13 12:00:06+02
3678	biele tenisky protetika, c. 27	95	8.5	f	-	0	9	1	2012-10-13 12:00:09+02
3675	adidas bieloruzove tenisky, c. 26	95	7.5	f	-	0	6	1	2012-10-13 12:00:13+02
3680	bledoseda teplakova suprava, mikinka + teplacky, early days, 3-6 m.	95	4.4000000000000004	f	-	0	11	2	2012-10-13 16:02:17+02
3639	huňatá ružová bunda s kapucňou a rožkami zn. HaiDi, veľ. 9 - 12 M	93	5	f	-	0	34	2	2012-10-13 16:06:08+02
3646	súprava na zimu overal a hrubá bunda veľ. 74	93	10	f	-	0	41	2	2012-10-13 18:19:20+02
3721	Ružová jesenná bunda s kapucňou a kvetink. Podšívkou veľ. 86	96	7	f	-	0	2	1	2012-10-13 10:13:10+02
3722	Ružová bunda so zajkom Cherokee veľ. 80	96	6	f	-	0	3	1	2012-10-13 10:13:21+02
3740	Ružová súprava Hello Kitty bundička + gate 2-4 mes.	96	7	f	-	0	21	2	2012-10-13 18:03:40+02
3707	tyrkysova trigovica cherokee, 3-4 roky	95	3.2999999999999998	f	-	0	38	2	2012-10-13 17:18:28+02
3725	Ružová H&M trigovica Hello Kitty veľ. 98-104	96	6	f	-	0	6	1	2012-10-13 10:13:45+02
3702	ruzove teplacky s mikinkou, Disney, 3-4 roky	95	2.7999999999999998	f	-	0	33	2	2012-10-14 10:10:21+02
3742	Next ružové tepláky veľ. 2-3 mes.	96	4	f	-	0	23	2	2012-10-13 17:18:28+02
3753	Ružová pásikavá trigovica Millie, bodkovaná kapucňa 98 cm	96	5	f	-	0	34	1	2012-10-13 10:17:15+02
3748	Rifle Hello Kitty H&M  9-12 mes.	96	8	f	-	0	29	1	2012-10-13 10:14:46+02
3746	Pásikavé bielo červené Disney šaty 1-1a1/2 roka	96	5	f	-	0	27	1	2012-10-13 10:14:53+02
3745	biele Disney tričko s Minnie veľ. 98	96	4	f	-	0	26	1	2012-10-13 10:14:58+02
3743	Tričko pásikavé Keep cool - Lady Ann veľ. 92	96	3	f	-	0	24	1	2012-10-13 10:15:05+02
3724	Zelená vesta s nápisom Apples veľ. 98	96	10	f	-	0	5	2	2012-10-13 17:18:28+02
3744	Tričko ružové biely rukáv so žirafou veľ. 80 cm	96	3.5	f	-	0	25	1	2012-10-13 10:15:14+02
3734	ružová tepláková súprava s bielou kapucňou Baby Club veľ. 86	96	6	f	-	0	15	1	2012-10-13 10:15:24+02
3739	TOM a Jerry červené tričko veľ. 92	96	3	f	-	0	20	1	2012-10-13 10:15:34+02
3726	ružový svetrík s opaskom a vačkami veľ. 98/104	96	5	f	-	0	7	2	2012-10-13 18:49:05+02
3737	Kockovaná šedo ružová trigovica Kenvelo veľ. 108-114	96	6	f	-	0	18	1	2012-10-13 10:15:50+02
3736	Biela plyšová H&M bundička  veľ. 4-6 mes.	96	7	f	-	0	17	1	2012-10-13 10:15:55+02
3733	čiapka ružovo biela s macíkmi T Trend veľ. 46	96	2	f	-	0	14	1	2012-10-13 10:15:59+02
3738	Pásikavé ružovo červené pletené H&M šaty veľ. 98/104	96	6	f	-	0	19	1	2012-10-13 10:16:04+02
3732	Bodkovaná červeno biela Next trigovica 2-3 roky	96	8	f	-	0	13	1	2012-10-13 10:16:09+02
3730	červené menčestráky NEXT veľ. 2-3 roky	96	5	f	-	0	11	1	2012-10-13 10:16:40+02
3735	Ružový overal s prasiatkom a dlhým rukávom Disney veľ. 3-6 mes.	96	6	f	-	0	16	1	2012-10-13 10:16:37+02
3729	bledomodrá trigovica Princess veľ. 12-18 mes.	96	3.5	f	-	0	10	1	2012-10-13 10:16:45+02
3728	Páskavý svetrík ružovo-zeleno biely Dirkje veľ. 80	96	4	f	-	0	9	1	2012-10-13 10:16:51+02
3750	Bledohnedé next menčestráky na traky veľ. 12-18 mes.	96	9	f	-	0	31	2	2012-10-13 17:13:47+02
3723	Biely zimný overal s ružovým lemovaním FIGI veľ. 80	96	10	f	-	0	4	2	2012-10-13 17:41:44+02
3762	Zip zap ružová bundička s kapucňou veľ.62/68	96	9	f	-	0	43	1	2012-10-13 10:18:00+02
3761	Rifle Cherokee s ružovým pásom veľ. 2-3 roky	96	5	f	-	0	42	1	2012-10-13 10:18:14+02
3701	biele flisove satecky s vilou a kvetinkami, cherokee, 3-6 mesiacov	95	2.7000000000000002	f	-	0	32	2	2012-10-13 16:50:52+02
3759	Sukňa s trakmi a motýlikom Cherokee veľ. 1-1 a 1/2 roka	96	7	f	-	0	40	1	2012-10-13 10:18:28+02
3757	H&M rifle Fit squin  veľ. 98	96	10	f	-	0	38	1	2012-10-13 10:18:39+02
3751	Riflová sukňa s ružovým pásikom Cherokee veľ. 9-12 mes.	96	3	f	-	0	32	1	2012-10-13 10:18:45+02
3752	Tmavoružová trigovica s kvietkami 86/92	96	4	f	-	0	33	1	2012-10-13 10:18:51+02
3755	Pásikavá čiapka, červené lemovanie s rybičkou veľ. 49	96	2	f	-	0	36	1	2012-10-13 10:18:58+02
3754	Ružové tričko Hello Kitty s mašličkami veľ. 86 cm	96	6	f	-	0	35	1	2012-10-13 10:19:03+02
3756	Rifle Early days  12-18 mes.	96	3	f	-	0	37	1	2012-10-13 10:19:07+02
3731	Tričko Next  pásikavé s dievčatkom veľ. 1 a1/2-2 roky	96	6	f	-	0	12	2	2012-10-13 17:06:36+02
3741	Ružová súprava H&M so srdiečkami bundička+gate  veľ. 2-4 mes.	96	8	f	-	0	22	1	2012-10-13 10:26:18+02
3758	Reserved rifle s kvietkovaným pásom veľ. 98	96	9	f	-	0	39	1	2012-10-13 10:26:29+02
3717	tehu top bielocierny + biele tricko na ramienka, herma, M	95	9.9000000000000004	f	-	0	48	1	2012-10-13 11:58:00+02
3697	bledomodro biela tepla ciapocka, Richelieu, c. 56	95	3	f	-	0	28	1	2012-10-13 11:58:09+02
3698	bledoruzova mikinka s kvetinkami, cherokee, 12-18 m.	95	3.2000000000000002	f	-	0	29	1	2012-10-13 11:58:13+02
3699	modrobiely bavlneny svetrik na gombiky domaja, c. 62	95	2.3999999999999999	f	-	0	30	1	2012-10-13 11:58:18+02
3749	Tepláky ružové Cherokee veľ. 2-3 roky	96	2	f	-	0	30	2	2012-10-13 16:55:58+02
3700	smotanovoruzova ciapka My pupill, nakresy zajkov a mackov	95	2.6000000000000001	f	-	0	31	1	2012-10-13 11:58:19+02
3763	ružové H&M tričko so srdiečkami veľ. 80	96	4	f	-	0	44	2	2012-10-14 13:06:53+02
3703	biely zajko hracka, cherokee, one size	95	2.2000000000000002	f	-	0	34	1	2012-10-13 11:58:27+02
3704	ruzovosedy overalik bebessi, 62	95	2.8999999999999999	f	-	0	35	1	2012-10-13 11:58:29+02
3705	seda trigovica cherokee, 3-4 roky	95	3.2999999999999998	f	-	0	36	1	2012-10-13 11:58:32+02
3706	bledoruzova trigovica s bambi, Disney, 12-18 m.	95	3.2000000000000002	f	-	0	37	1	2012-10-13 11:58:34+02
3727	Biela NEXT trigovica s kapucňou a dievčatkom vpredu veľ. 92	96	9	f	-	0	8	2	2012-10-13 17:18:28+02
3708	ruzova trigovica, cherokee, 4-5 rokov	95	3.2999999999999998	f	-	0	39	1	2012-10-13 11:58:39+02
3709	bledomodry svetrik na gombiky, damini, c. 98	95	2.2000000000000002	f	-	0	40	1	2012-10-13 11:58:45+02
3711	tehu rifle modre, Yessica, C&A, velkost SK 34	95	7.9000000000000004	f	-	0	42	1	2012-10-13 11:58:49+02
3712	tehu rifle tmavomodre, Yessica, C&A, velkost 34	95	7.9000000000000004	f	-	0	43	1	2012-10-13 11:58:53+02
3713	tehu tricko zelene PAULA, herma, M	95	6.9000000000000004	f	-	0	44	1	2012-10-13 11:58:58+02
3714	tehu tricko ruzove, herma, S	95	6.9000000000000004	f	-	0	45	1	2012-10-13 11:59:00+02
3715	tehu tricko biele dlhy rukav, flitrovy napis baby, herma, S	95	6.9000000000000004	f	-	0	46	1	2012-10-13 11:59:03+02
3716	tehu top smotanovy dlhy rukav PARIS, s cipkou, 9fashion, velkost S	95	7.9000000000000004	f	-	0	47	1	2012-10-13 11:59:05+02
3718	tehu cierne elastaky Yessica, C&A, velkost 32/34	95	6.9000000000000004	f	-	0	49	1	2012-10-13 11:59:59+02
3719	tehu cierny sveter, herma, L	95	9.9000000000000004	f	-	0	50	1	2012-10-13 12:00:01+02
3760	H&M rifle fit super squin veľ. 92	96	4	f	-	0	41	2	2012-10-13 16:20:44+02
3802	modrá čapica so šálom WINNIE /2ks/- macko	97	0.69999999999999996	f	-	0	33	2	2012-10-14 09:21:26+02
3811	Overal-fusak ružový s kožuš.kapucňou veľ. 0-3 mes.	98	5	f	-	0	5	2	2012-10-14 10:48:25+02
3775	žltá teplá mikina NORTHLAND, v.116	97	3	f	-	0	6	2	2012-10-13 18:26:49+02
3774	žltá mikina s motívom GGOBYS 55, v.140	97	0.80000000000000004	f	-	0	5	1	2012-10-13 08:32:03+02
3771	tričká 2ks, béžové s pásikom+béžové s oranžovým nápisom	97	1.5	f	-	0	2	2	2012-10-13 19:10:34+02
3776	červená mikina celorozopinateľná	97	1.5	f	-	0	7	1	2012-10-13 08:32:15+02
3777	modrá bundička – DOMAJA, v.110 /mikina/	97	1	f	-	0	8	1	2012-10-13 08:32:20+02
3794	modročierna SOFT SHELL bunda v.120	97	8	f	-	0	25	2	2012-10-13 17:49:24+02
3779	ružová mikina-ESPIRIT, v.116-122	97	1.5	f	-	0	10	1	2012-10-13 08:32:34+02
3780	hnedá mikina olemovaná oranžovým v.116	97	2	f	-	0	11	1	2012-10-13 08:32:43+02
3781	hnedé rifle vek4	97	3	f	-	0	12	1	2012-10-13 08:32:49+02
3782	pyžamo, bledomodré v.104, obrázok MACKO	97	1.5	f	-	0	13	1	2012-10-13 08:32:58+02
3801	modoržltá čapica so šiltom /zimná/	97	0.5	f	-	0	32	2	2012-10-13 15:30:01+02
3785	tehotenské manchestrové nohavice, čierne v.158-164	97	5	f	-	0	16	1	2012-10-13 08:33:20+02
3804	modré topánky zimné RITEX na suchý zips v.30	97	5	f	-	0	35	2	2012-10-13 16:09:44+02
3787	voduodpudivé nohavice v.110 McKinley	97	5	f	-	0	18	1	2012-10-13 08:33:42+02
3788	flaušová súprava, zelená /2ks/-bunda+nohavice	97	2	f	-	0	19	1	2012-10-13 08:33:50+02
3792	prechodná bunda modrá s kapucňou v golieri v.116-122	97	5	f	-	0	23	2	2012-10-13 15:26:40+02
3790	ochranný plášť na výtvarnú IKEA	97	0.5	f	-	0	21	1	2012-10-13 08:34:24+02
3791	fialová bunda s kapucňou	97	6	f	-	0	22	1	2012-10-13 08:34:33+02
3784	zateplené šušťaky zelené v.110-116	97	2	f	-	0	15	2	2012-10-13 15:26:40+02
3793	prechodná bunda, modročervené karo	97	3	f	-	0	24	1	2012-10-13 08:34:55+02
3764	ružové tričko s pásik. Rukávmi Palomino veľ. 110	96	3	f	-	0	45	2	2012-10-13 17:55:08+02
3796	tehotenské hnedé manchestráky na traky v.S	97	9	f	-	0	27	1	2012-10-13 08:35:32+02
3825	Pásikavé ružovo červené pletené H&M šaty veľ. 98/104	98	6	f	-	0	19	2	2012-10-13 15:43:35+02
3798	modrá čapica s červeným lemom	97	0.29999999999999999	f	-	0	29	1	2012-10-13 08:35:56+02
3829	Next zelené tepláky veľ. 2-3 mes.	98	4	f	-	0	23	2	2012-10-13 17:18:28+02
3800	poloklobúčik modrooranžový MACKO WINNIE	97	0.5	f	-	0	31	1	2012-10-13 08:36:02+02
3797	papuče CROSS v.31	97	0.5	f	-	0	28	2	2012-10-13 15:38:37+02
3766	H&M tričko ružové s kvietkami veľ. 74	96	3	f	-	0	47	2	2012-10-14 10:08:54+02
3803	zateplené gumáčky modré  SPORTS v.29	97	2	f	-	0	34	1	2012-10-13 08:36:34+02
3805	zimné topánky AQUAMAX v.30	97	8	f	-	0	36	1	2012-10-13 08:37:48+02
3813	červený svetrík s opaskom a vačkami veľ. 98/104	98	5	f	-	0	7	2	2012-10-13 16:52:32+02
3773	čierne tričko s modro-oranžovým nápisom, v.104	97	1	f	-	0	4	2	2012-10-13 18:22:27+02
3769	ružový pletený svetrík 0-3 mes.	96	1.5	f	-	0	50	1	2012-10-13 10:17:28+02
3765	súprava 3 overaly s myškami veľ. 0-3 mes.	96	4	f	-	0	46	1	2012-10-13 10:17:42+02
3789	traky na nohavice /2ks/	97	0.5	f	-	0	20	2	2012-10-13 15:20:36+02
3768	next elasťáky ružovo modré pásikavé veľ. 1 a 1/2-2 roky	96	1.5	f	-	0	49	2	2012-10-13 18:12:37+02
3772	tričká 2ks,/modré formula+zelený vláčik/, v.104	97	1.5	f	-	0	3	2	2012-10-14 10:45:13+02
3807	Zimná bunda hnedá s fialovou podšívkou s kapucňou veľ.98	98	10	f	-	0	1	2	2012-10-13 16:57:10+02
3824	Kockovaná šedo ružová trigovica Kenvelo veľ. 108-114	98	6	f	-	0	18	2	2012-10-13 16:57:10+02
3812	Ružová H&M trigovica Hello Kitty veľ. 98-104	98	6	f	-	0	6	1	2012-10-13 10:20:22+02
3795	hnedé manchestráky macko WINNIE	97	2	f	-	0	26	2	2012-10-14 11:32:13+02
3810	Biely zimný overal s ružovým lemovaním FIGI veľ. 80	98	10	f	-	0	4	1	2012-10-13 10:20:44+02
3809	Ružová bunda so zajkom Cherokee veľ. 80	98	6	f	-	0	3	1	2012-10-13 10:20:52+02
3808	Ružová jesenná bunda s kapucňou a kvetink. Podšívkou veľ. 86	98	7	f	-	0	2	1	2012-10-13 10:20:56+02
3816	bledomodrá trigovica Princess veľ. 12-18 mes.	98	3.5	f	-	0	10	2	2012-10-13 17:05:32+02
3832	biele Disney tričko s Minnie veľ. 98	98	4	f	-	0	26	1	2012-10-13 10:21:10+02
3830	Tričko pásikavé Keep cool - Lady Ann veľ. 92	98	3	f	-	0	24	1	2012-10-13 10:21:14+02
3817	červené menčestráky NEXT veľ. 2-3 roky	98	5	f	-	0	11	2	2012-10-13 17:18:29+02
3827	Ružová súprava Hello Kitty bundička + gate 2-4 mes.	98	7	f	-	0	21	1	2012-10-13 10:21:30+02
3828	Ružová súprava H&M so srdiečkami bundička+gate  veľ. 2-4 mes.	98	8	f	-	0	22	1	2012-10-13 10:21:55+02
3831	Tričko ružové biely rukáv so žirafou veľ. 80 cm	98	3.5	f	-	0	25	1	2012-10-13 10:23:55+02
3833	Pásikavé bielo červené Disney šaty 1-1a1/2 roka	98	5	f	-	0	27	1	2012-10-13 10:24:39+02
3826	TOM a Jerry červené tričko veľ. 92	98	3	f	-	0	20	1	2012-10-13 10:24:50+02
3786	tepláky bledošedé+tmavošedé /2sk/, v.104-110/	97	2	f	-	0	17	2	2012-10-13 16:07:39+02
3823	Biela plyšová H&M bundička  veľ. 4-6 mes.	98	7	f	-	0	17	1	2012-10-13 10:25:06+02
3822	Ružový overal s prasiatkom a dlhým rukávom Disney veľ. 3-6 mes.	98	5	f	-	0	16	1	2012-10-13 10:25:11+02
3818	Tričko Next  pásikavé s dievčatkom veľ. 1 a1/2-2 roky	98	6	f	-	0	12	1	2012-10-13 10:25:16+02
3820	čiapka ružovo biela s macíkmi T Trend veľ. 46	98	2	f	-	0	14	1	2012-10-13 10:25:21+02
3815	Páskavý svetrík ružovo-zeleno biely Dirkje veľ. 80	98	4	f	-	0	9	2	2012-10-13 17:13:47+02
3819	Bodkovaná červeno biela Next trigovica 2-3 roky	98	8	f	-	0	13	1	2012-10-13 10:25:31+02
3778	modrá bundička – KENVELO /mikina/	97	1.3	f	-	0	9	2	2012-10-13 17:30:27+02
3799	modra čapica s hviezdami	97	0.5	f	-	0	30	2	2012-10-13 17:17:43+02
3814	Biela NEXT trigovica s kapucňou a dievčatkom vpredu veľ. 92	98	9	f	-	0	8	1	2012-10-13 10:25:46+02
3767	zavinovačka hnedá s macíkmi	96	3.5	f	-	0	48	2	2012-10-13 15:20:36+02
3873	rifle chlapčenské, veľ.12-18mes.	99	2	f	-	0	17	2	2012-10-13 16:21:45+02
3860	bledomodré mačičkové celé papučky na suchý zips,veľ.21	99	1.1000000000000001	f	-	0	4	1	2012-10-13 10:08:14+02
3894	nohavice na traky, tmavomodré, obrázok žirafa aj na nohovici, veľ.86cm	99	1	f	-	0	38	2	2012-10-13 16:41:59+02
3893	šedá zimná čiapka so šiltom,zelené vločky, veľ.12mes.	99	0.5	f	-	0	37	2	2012-10-13 17:47:48+02
3853	H&M tričko ružové s kvietkami veľ. 74	98	3	f	-	0	47	2	2012-10-14 13:05:37+02
3869	7párov chlapč.bavln.ponožiek,3ksPrúžky,4ksDvojfar.veľ. 19-22cm	99	1.2	f	-	0	13	2	2012-10-14 10:25:05+02
3855	ružový pletený svetrík  0-3 mes.	98	1.5	f	-	0	49	2	2012-10-13 16:46:23+02
3877	fleece trigovica, modrá so stojačikom+obrázok FLIPa,veľ.86-92cm	99	1	f	-	0	21	2	2012-10-13 17:47:48+02
3861	tmavomodré papučky, kovové zapínanie, veľ.19,5	99	0.5	f	-	0	5	2	2012-10-14 13:01:37+02
3857	zimné kožene topánky,vysoké,hnedé s biel.kožuš.šnurky +zips,veľ.22	99	10	f	-	0	1	2	2012-10-13 15:48:43+02
3889	bledomodráZim.súprava:čiapka sGongol.+šál,motývVločky,veľ.12-18mes.	99	1.5	f	-	0	33	1	2012-10-13 10:10:23+02
3885	froté oranžové dupačky s tmavooranžovými kvietkami, veľ.6-12mes.	99	0.40000000000000002	f	-	0	29	1	2012-10-13 10:10:31+02
3884	froté oranžové dupačky s tmavooranžovými kvietkami, veľ.6-12mes.	99	0.40000000000000002	f	-	0	28	1	2012-10-13 10:10:39+02
3888	čierne chlapč. Nohavice,zn. Obäibi, veľ.12mes.	99	0.59999999999999998	f	-	0	32	1	2012-10-13 10:10:54+02
3887	Bielo-modrý kabátik na cvoky, obrázky sloníky a motýle, veľ.74cm	99	0.5	f	-	0	31	1	2012-10-13 10:10:59+02
3886	fleece trigovica,šedo-modro-biela s číslom 3 na chrbte, veľ.6-9mes.	99	0.5	f	-	0	30	1	2012-10-13 10:11:08+02
3883	čierna fleec.trigovica s nápisom“ROCKSPORT“ vKrém.pruhu,veľ.18mes.	99	2	f	-	0	27	1	2012-10-13 10:11:15+02
3865	šedýZim.overal-kapucňa sKožuš.oranž.podšív.veľ.12-18mes.+návlekNôh	99	5	f	-	0	9	2	2012-10-13 18:08:59+02
3867	zimná krémová bunda s oranž. Podšívkou, medvedík PU,veľ.68cm	99	5	f	-	0	11	1	2012-10-13 10:11:36+02
3858	tmavomodré poltopánky s gum. špicou,suchý zips, veľ.22	99	3.5	f	-	0	2	2	2012-10-13 16:39:57+02
3868	dievč.modré menčestrové nohavice, zelená podšívka, veľ.92cm	99	1.5	f	-	0	12	1	2012-10-13 10:12:55+02
3872	Krémovo-zeleno-oranž.trigovica s kapucou,veľ.9-12mes.,obrázok zebra,žirafa,slon	99	1	f	-	0	16	1	2012-10-13 10:13:05+02
3878	nohavice na traky, bielo-modré prúžky, obrázky mackov,veľ.6-9mes.	99	0.5	f	-	0	22	2	2012-10-13 17:17:11+02
3834	Next súprava čiapka + rukavice s hviezdičkami 1-2 roky	98	4	f	-	0	28	2	2012-10-13 16:34:06+02
3862	Botasky-bielo-modro-čierne s rybyčkami, suchý zips veľ.22	99	2.5	f	-	0	6	2	2012-10-13 19:06:26+02
3874	fleece trigovica, žltá s tmavomodrým patentom,veľ.18mes.zajačikovia obrázok	99	0.5	f	-	0	18	1	2012-10-13 10:13:31+02
3876	2ks biele bodýčko, dlhý rukáv, v predu obrázok,zn. ZARA	99	0.5	f	-	0	20	1	2012-10-13 10:13:42+02
3856	čierna kenvelo trigovica 4-5 rokov	98	3	f	-	0	50	2	2012-10-13 17:35:08+02
3875	zele.teplák.súpr.veľ.18m.trigovica s Límcom aMackami vPredu+zel.gate	99	2	f	-	0	19	1	2012-10-13 10:14:00+02
3870	4páry froté ponožiek s rúžičkou,veľ.0-6mes.	99	0.5	f	-	0	14	1	2012-10-13 10:14:16+02
3880	body na celé telo 100%bavlna,bledomodré, veľ.9-12mes.	99	0.5	f	-	0	24	2	2012-10-13 18:31:20+02
3881	body na celé telo 100%bavlna,žlto-bielo-modré prúžky, veľ.9-12mes.	99	0.5	f	-	0	25	2	2012-10-13 18:31:20+02
3891	šedé tepláky,užší strih, veľ.12-18mes. zn. tesco	99	0.5	f	-	0	35	2	2012-10-14 12:50:36+02
3890	bodýčko na celé telo +čiapka, vianoč.motýv-sob,veľ.6-9mes.	99	1	f	-	0	34	2	2012-10-13 15:33:00+02
3879	body na celé telo 100%bavlna,bielo-modré-kockové,veľ.9-12mes.	99	0.5	f	-	0	23	2	2012-10-14 10:32:58+02
3871	4páry chlapč.ponožiek, ozdobný vzor z trojuholníkov,veľ.0-6mes.	99	0.59999999999999998	f	-	0	15	1	2012-10-13 10:15:34+02
3892	tmavomodré tepláky, užší strih, veľ. 12-18mes.zn tesco	99	0.5	f	-	0	36	1	2012-10-13 10:15:40+02
3845	Reserved rifle s kvietkovaným pásom veľ. 98	98	9	f	-	0	39	1	2012-10-13 10:20:28+02
3836	Tepláky fialové Cherokee veľ. 2-3 roky	98	2	f	-	0	30	1	2012-10-13 10:21:39+02
3837	Bledohnedé next menčestráky na traky veľ. 12-18 mes.	98	9	f	-	0	31	1	2012-10-13 10:21:42+02
3852	súprava 3 overaly Macko Pu veľ. 6-9 mes.	98	4	f	-	0	46	1	2012-10-13 10:22:03+02
4092	Hnede Rival topanocky s ruzovou vlnkou a maslickou	104	7.9000000000000004	f	-	0	33	2	2012-10-13 16:55:58+02
3840	Ružová pásikavá trigovica Millie, bodkovaná kapucňa 98 cm	98	5	f	-	0	34	1	2012-10-13 10:22:10+02
3859	tmavomodré papučky,kovové zapínanie,veľ.21	99	1	f	-	0	3	2	2012-10-13 17:36:18+02
3839	Tmavoružová trigovica s kvietkami 86/92	98	4	f	-	0	33	2	2012-10-13 16:48:23+02
3854	zavinovačka hnedá s macíkmi	98	3.5	f	-	0	48	1	2012-10-13 10:22:38+02
3851	ružové tričko s pásik. Rukávmi Palomino veľ. 110	98	3	f	-	0	45	1	2012-10-13 10:22:49+02
3850	ružové H&M tričko so srdiečkami veľ. 74	98	5	f	-	0	44	1	2012-10-13 10:22:54+02
3849	H&M tepláky ružové veľ. 86	98	4	f	-	0	43	1	2012-10-13 10:22:59+02
3848	Rifle Cherokee s ružovým pásom veľ. 2-3 roky	98	5	f	-	0	42	1	2012-10-13 10:23:02+02
3847	H&M rifle fit super squin veľ. 92	98	8	f	-	0	41	1	2012-10-13 10:23:06+02
3846	Sukňa s trakmi a motýlikom Cherokee veľ. 1-1 a 1/2 roka	98	7	f	-	0	40	1	2012-10-13 10:23:11+02
3844	H&M rifle Fit squin  veľ. 98	98	10	f	-	0	38	1	2012-10-13 10:23:21+02
3842	Pásikavá čiapka, červené lemovanie s rybičkou veľ. 49	98	2	f	-	0	36	1	2012-10-13 10:23:36+02
3841	Ružové tričko Hello Kitty s mašličkami veľ. 86 cm	98	6	f	-	0	35	1	2012-10-13 10:23:41+02
3843	Rifle Early days  12-18 mes.	98	3	f	-	0	37	1	2012-10-13 10:23:47+02
3882	bavl.body sLímcom na celé telo,bledo aTmavomodré pruhy, veľ.9-12mes.	99	0.59999999999999998	f	-	0	26	2	2012-10-13 16:36:03+02
3835	Rifle Hello Kitty H&M  9-12 mes.	98	8	f	-	0	29	1	2012-10-13 10:24:43+02
3866	zimná šedá bunda, kapucňa s kožuš.,podšívka modrýFleec,veľ.6-12mes.znak soba,pletený patent na rukávoch a spodku	99	6	f	-	0	10	2	2012-10-13 17:09:36+02
3864	čierne oteplováčky- nové , veľ.86-92cm	99	6	f	-	0	8	2	2012-10-13 15:21:44+02
3933	Fialové legíny s trblietkami, veľ. 104	100	1.5	f	-	0	28	2	2012-10-13 18:50:04+02
3897	plyšovýOveral,bledošedý sČerven.doplnkami,veľ.68cm.zn.Twinnies	99	1.5	f	-	0	41	1	2012-10-13 10:09:17+02
3898	2ks pančušky,zvieratkoNaZadku,veľ.6-12mes.tmavé-krava,krém.-ovca	99	0.5	f	-	0	42	1	2012-10-13 10:09:26+02
3903	červen.tepláky,s3mi ozdobnými vreckami-čiernočerven.f.veľ.86cm	99	1	f	-	0	47	1	2012-10-13 10:11:49+02
3904	fleece tepláky, farba vojenská zelená, na spodu biely lem, veľ.18mes.	99	1	f	-	0	48	1	2012-10-13 10:11:54+02
3901	čierne tepláky s vreckom na zadku, veľ. 18-24mes. 	99	1	f	-	0	45	1	2012-10-13 10:12:01+02
3902	bledozelené tepláky s bielym sloníkom, veľ. 80Cm	99	0.80000000000000004	f	-	0	46	1	2012-10-13 10:12:09+02
3940	zateplený biely overal, s mackom vpredu, pre novorodenca,zn. F&F	101	4.5	f	-	0	6	2	2012-10-13 16:00:42+02
3942	zateplené menčestrové hnedozelené trakové nohavice,s fial.kvetmi na ľavej nohe, veľ.cca 9-12	101	1	f	-	0	8	2	2012-10-13 19:19:16+02
3956	ružová zimná čiapka so zlatou korunkou	101	1.5	f	-	0	22	2	2012-10-13 18:20:14+02
3905	bledošedé tepláky s tmavým pruhom po bokoch, veľ.3-6mes.	99	1	f	-	0	49	2	2012-10-13 15:51:45+02
3934	Mikina modročervená, s golierikom, veľ. 116	100	2.5	f	-	0	29	1	2012-10-13 11:21:32+02
3931	Oranžová mikina na zips, s nápismi, veľ. 134-140	100	2.5	f	-	0	26	1	2012-10-13 11:21:34+02
3925	Žltá vetrovková vesta, veľ. 86-104	100	2	f	-	0	20	1	2012-10-13 11:21:40+02
3928	Červeno biele teplé rukavice ( palčiaky ), veľ. 1-2 roky	100	1	f	-	0	23	1	2012-10-13 11:21:48+02
3930	Šedé otepľovačky, veľ. 98 - 104	100	5	f	-	0	25	2	2012-10-13 18:01:27+02
3929	Šedo-oranžová zimná kombinéza s kapucňou, veľ. 98-104	100	7	f	-	0	24	1	2012-10-13 11:22:00+02
3921	Vestička H&M, prešívaná, veľ. 80-104	100	2	f	-	0	16	2	2012-10-13 18:12:37+02
3923	Vestička vlnená so srdiečkom, veľ. 74	100	1	f	-	0	18	1	2012-10-13 11:22:46+02
3922	Ružová tepláková bundička s kapucňou, veľ. 104	100	2	f	-	0	17	1	2012-10-13 11:22:50+02
3926	Teplá ružová čapica so šnúrkami, veľ. 1-2 roky	100	1.5	f	-	0	21	2	2012-10-13 18:19:20+02
3920	Čierne tričko s dlhým rukávom a kapucňou, veľ. 90	100	0.5	f	-	0	15	1	2012-10-13 11:22:57+02
3919	Ružové tričko s dlhým rukávom, veľ. 24 mes.	100	0.5	f	-	0	14	1	2012-10-13 11:23:00+02
3913	Jesenný bledý kabátik s opaskom a kapucňou, veľ. 104	100	7	f	-	0	8	2	2012-10-13 16:49:36+02
3918	Dievčenské rifle s preš. kvet. Vzorom, veľ. 80	100	3	f	-	0	13	1	2012-10-13 11:23:18+02
3907	Olivová vnútri kožuš., zimná kombinéza zn. H&M, na zips, 0– 6 mes.	100	10	f	-	0	2	2	2012-10-13 17:01:44+02
3912	Smotanová mikina, veľ. 12 – 18 mes.	100	0.5	f	-	0	7	1	2012-10-13 11:24:01+02
3916	Ružovo – smotanová vestička so zipsom, veľ. 80	100	1.5	f	-	0	11	1	2012-10-13 11:24:57+02
3910	Hnedý kožuštek zn. Cherokee, veľ. Na 2-3 roky	100	10	f	-	0	5	1	2012-10-13 11:24:49+02
3915	Ružová mi kina so zipsom, veľ. 80	100	1.5	f	-	0	10	1	2012-10-13 11:25:04+02
3914	Ružová mi kina vpredu s vyš. Zajkom, veľ. 74	100	2	f	-	0	9	1	2012-10-13 11:25:09+02
3908	Červená zimná kombinéza, spredu vyšitý macko, na zips, veľ. 80-92	100	5	f	-	0	3	1	2012-10-13 11:25:50+02
3932	Biely svetrík na zips s kapucňou, veľ. 98-104	100	3	f	-	0	27	2	2012-10-14 12:12:11+02
3909	Ružová kožušinová vestička zn. Cherokee, veľ. 68	100	5	f	-	0	4	1	2012-10-13 11:26:01+02
3924	Ružová vetrovka s kapucňou, veľ. 68	100	3	f	-	0	19	2	2012-10-13 17:30:27+02
3906	Bordový menčestrový kabátik na gombíky, veľ. 104	100	5	f	-	0	1	1	2012-10-13 11:26:16+02
4093	Cierne lakovky na bku s kvetinkami Peddy c.23	104	7.9000000000000004	f	-	0	34	1	2012-10-13 12:05:11+02
3935	Komplet-bodkové ruž.tričko a pásikavé ruž.legínky,veľ.9m.(Carters)	101	4	f	-	0	1	1	2012-10-13 12:10:52+02
3936	tričko s dlhými rukávmi, bordové,modré a ružové bodky, veľ. 12-18	101	0.40000000000000002	f	-	0	2	1	2012-10-13 12:10:59+02
3937	ružová zimná čiapka so zajačími ušami, zn. Rada	101	0.5	f	-	0	3	1	2012-10-13 12:11:28+02
3938	riflové šaty, olemované ružovo bodkovanými volánikm, veľ. 9-12	101	3	f	-	0	4	1	2012-10-13 12:11:43+02
3939	tmavo ružová tepláková súprava,s motýľom, zn.Faded Glory, veľ. 12m	101	3.5	f	-	0	5	1	2012-10-13 12:11:49+02
3945	zateplený bordový overal, zn. Cherokee, veľ.0-3	101	1	f	-	0	11	2	2012-10-14 10:16:34+02
3899	riflová bunda na cvoky, nenosená,veľ.74cm,zn.OSKARS'S mini	99	2	f	-	0	43	2	2012-10-13 18:38:14+02
3941	rifľová bundička,s ružovou károvanou podšívkou, zn.Next, veľ. 3-6m.	101	2.5	f	-	0	7	1	2012-10-13 12:12:18+02
3917	Rifle za teplené s vyš. Motýlikom, veľ. 104	100	3	f	-	0	12	2	2012-10-13 16:20:44+02
3947	ružová flaušová mikinka, nápis: Kethmandu, veľ. 1Rok	101	2.5	f	-	0	13	1	2012-10-13 12:12:34+02
3946	fialkové body s dlh.rukávmi, nápis: I´m adorable, zn.Okie-dokie, 6-9m.	101	0.5	f	-	0	12	1	2012-10-13 12:12:43+02
3943	ružová flísová mikinka, zn. Cherokee, veľ. 12-18m	101	2	f	-	0	9	1	2012-10-13 12:13:01+02
3948	ružové kárované šaty, zn. H&M, veľ. 74	101	3	f	-	0	14	1	2012-10-13 12:13:09+02
3950	2x tričko s dlhým rukávom, ružové a biele, zn. Cherokee, veľ. 6-9m.	101	1	f	-	0	16	1	2012-10-13 12:13:17+02
3949	Komplet-fialk. mikina+tmavofialové menčestráky,zn.Carters, veľ.12m	101	5	f	-	0	15	1	2012-10-13 12:13:27+02
3952	hnedé zateplené nohavice na traky s mackom,nápis e-baby, veľ.98/104	101	3	f	-	0	18	1	2012-10-13 12:13:43+02
3911	Slabo hnedý dievčenský kožuštek zn. Next, veľ. 68	100	5	f	-	0	6	2	2012-10-14 10:48:25+02
3953	ružové podšité menčestráky s manžetami, zn. F&F, veľ.9-12	101	2.5	f	-	0	19	1	2012-10-13 12:14:20+02
3954	ružové kárované menčestráky,zn. Topolino, veľ. 74	101	2.5	f	-	0	20	1	2012-10-13 12:14:22+02
3944	zateplený kvietkovaný ružový šuštiakový overal s rukavicami, veľ.9-12	101	5	f	-	0	10	2	2012-10-13 18:20:14+02
3955	ružová tunika s mašličkou, zn. H&M, veľ.74	101	1.2	f	-	0	21	1	2012-10-13 12:14:33+02
3957	tehotenské tričko hnedé s bielymi rukávmi, zn. Yessica, veľ.L	101	4	f	-	0	23	1	2012-10-13 12:14:39+02
3927	Háčkovaná ružová čapica, veľ. 1-2 roky	100	1.5	f	-	0	22	2	2012-10-13 15:42:31+02
4012	ružová vesta na gombíky, č. 18-23 mes.	103	3	f	-	0	3	2	2012-10-14 11:59:29+02
3998	Páskatá čiapka Next podšitá so šiltom	102	3	f	-	0	39	2	2012-10-13 16:29:43+02
4014	červená šušťáková bunda s bielo čiernym pruhovaným lemom	103	1.5	f	-	0	5	1	2012-10-13 08:58:57+02
4015	slabo fialová mikina s kapucnou, č. 116, značka item	103	2.2999999999999998	f	-	0	6	1	2012-10-13 08:59:00+02
4016	červená menčestráková bunda s Mickey mousom, lienkové gombíky	103	2	f	-	0	7	1	2012-10-13 08:59:03+02
4017	červený kabát cherokee s opaskom, č. 122	103	9	f	-	0	8	1	2012-10-13 08:59:07+02
3993	Páskaté tričko s cvokmi pri krku, veľ. 92	102	3	f	-	0	34	2	2012-10-14 09:07:16+02
4019	červené sametové nohavice, na páse so vzorom, č. 116	103	2.2999999999999998	f	-	0	10	1	2012-10-13 08:59:22+02
4020	slabo oranžové menčestráky č. 116	103	2.2999999999999998	f	-	0	11	1	2012-10-13 08:59:25+02
4021	slabo ružové nohavice, dole s konžušinkou, zn. Barbie, č. 116	103	2	f	-	0	12	1	2012-10-13 08:59:26+02
4022	rifle s kvetinami a kvetinovým opaskom, č. 116	103	2.2999999999999998	f	-	0	13	1	2012-10-13 08:59:29+02
4023	fialové menčestráky č. 116	103	2.2000000000000002	f	-	0	14	1	2012-10-13 08:59:32+02
3962	Modré oteplovačky v páse do gumy, modré zipsy a šnúrka	102	2	f	-	0	3	1	2012-10-13 10:29:40+02
3963	Modré podšité roll-up nohavice s helikoptérou, Next, veľ. 6-9 mesiacov	102	8	f	-	0	4	1	2012-10-13 10:29:43+02
3980	Zelený sveter s oranžovými pruhmi, veľ. 18 mesiacov	102	3	f	-	0	21	2	2012-10-13 17:54:58+02
3975	Modré rifle s farebným opaskom, zn. Cherokee, veľ. 2-3 roky	102	5	f	-	0	16	1	2012-10-13 10:34:00+02
3967	Čierne rifle Next s oranžovým opaskom, veľ. 92	102	4	f	-	0	8	1	2012-10-13 10:30:03+02
4011	biely plyšový overal, na kapucni ušká, logo little bear	103	6	f	-	0	2	2	2012-10-14 11:17:01+02
3977	Bledomodrá zimná bunda s kapucou, veľ. 62/68	102	8	f	-	0	18	1	2012-10-13 10:30:13+02
4003	Čierne snehule s oranžovou šnúrkou, veľ. 22/23	102	9	f	-	0	44	2	2012-10-13 18:08:59+02
3981	Flísová mikina tmavomodrá s bledým pruhom, Early days, veľ.12-18mes	102	5	f	-	0	22	1	2012-10-13 10:30:50+02
3978	Tmavomodrá vesta Cherokee, veľ. 2-3 roky	102	7	f	-	0	19	1	2012-10-13 10:30:37+02
3979	Prechodná bunda bielo-modro-červená, veľ. 98	102	5	f	-	0	20	1	2012-10-13 10:30:47+02
3983	Tmavomodrý svetrík na zips Cherokee, veľ. 2-3 roky	102	4	f	-	0	24	1	2012-10-13 10:30:54+02
3984	Hnedo-modrý svetrík s kapucou New look, veľ. 98	102	4	f	-	0	25	1	2012-10-13 10:30:57+02
3985	Bordovo-hnedý svetrík s gombíkmi Next, veľ. 92	102	12	f	-	0	26	1	2012-10-13 10:31:01+02
3988	Páskaté tričko s dlhým rukávom a dinosaurami Next, veľ. 86	102	3.5	f	-	0	29	2	2012-10-13 17:24:17+02
3982	Bledomodrá flísová mikina so somárikom, veľ. 86	102	4	f	-	0	23	2	2012-10-13 17:30:15+02
3991	Červené tričko s helikoptérou Lupilu, veľ. 86/92	102	1.5	f	-	0	32	1	2012-10-13 10:31:23+02
3989	Červené tričko s bielymi rukávmi Cherokee, veľ. 92	102	2	f	-	0	30	1	2012-10-13 10:31:27+02
3990	Modré tričko s červenými rukávmi Cherokee, veľ. 92	102	2	f	-	0	31	1	2012-10-13 10:31:30+02
3992	Tyrkysové tričko s mackom Lindex, veľ. 92	102	4.5	f	-	0	33	1	2012-10-13 10:31:37+02
3994	Hnedé tričko s líškou C&A, veľ. 92	102	4	f	-	0	35	2	2012-10-14 09:21:26+02
3969	Podšité bledé menžestráky H&M, dolu do gumy, veľ. 80	102	4	f	-	0	10	2	2012-10-14 11:08:28+02
3995	Fialové tričko s nápisom, Palomino, veľ. 92	102	3.5	f	-	0	36	1	2012-10-13 10:32:00+02
3996	Fialové tričko s nápisom, Palomino, veľ. 104	102	4	f	-	0	37	1	2012-10-13 10:32:04+02
4007	Šedé tričko s dlhým rukávom, Pumpkin Patch, veľ. 134	102	7.7000000000000002	f	-	0	48	1	2012-10-13 10:32:19+02
4009	Bledá chlpatka Next, veľ. 98	102	11	f	-	0	50	1	2012-10-13 10:32:25+02
4006	Komplet- modré podšité rifle s páskatým tyrkys tričkom, Next, veľ. 104	102	7.5	f	-	0	47	1	2012-10-13 10:32:32+02
3986	Tmavomodrá súprava s tigrom-mikina+tepláky, veľ. 2-4 roky	102	4	f	-	0	27	1	2012-10-13 10:32:44+02
3968	Tmavomodré podšité rifle Cherokee, veľ. 2-3 roky	102	6	f	-	0	9	2	2012-10-13 17:30:27+02
4005	Čiapka s dinosaurom, tmavomodrá+bledý pásik, veľ. 2-4 roky	102	1.5	f	-	0	46	1	2012-10-13 10:32:58+02
4001	Bledomodrá čiapka podšitá s hasičským autom	102	1	f	-	0	42	1	2012-10-13 10:33:05+02
4000	Farebná páskatá čiapka podšitá flísom, veľ. 86/98	102	2	f	-	0	41	1	2012-10-13 10:33:08+02
3999	Červená čiapka Next podšitá	102	3	f	-	0	40	1	2012-10-13 10:33:12+02
3959	hnedá menčestrová tehotenská sukňa, zn. Yessica, veľ.40	101	8	f	-	0	25	2	2012-10-13 17:03:24+02
3997	Modrá čiapka s brmbolcom a raketou na šnúrky, podšitá flísom	102	3	f	-	0	38	1	2012-10-13 10:33:24+02
3976	Flísom podšité menžestráky na traky, veľ. 80	102	9	f	-	0	17	1	2012-10-13 10:33:32+02
3966	Tmavohnedé menžestráky Next, veľ. 92	102	6	f	-	0	7	1	2012-10-13 10:33:40+02
3965	Podšité nohavice H&M, veľ. 74, naspodu do gumy + zips	102	5	f	-	0	6	1	2012-10-13 10:33:46+02
3964	Tmavomodré podšité nohavice Early days, veľ. 6-12 mesiacov	102	5	f	-	0	5	1	2012-10-13 10:33:52+02
3974	Rifle Next, veľ. 92, modré	102	2	f	-	0	15	1	2012-10-13 10:34:04+02
3973	Modré rifle, červené prešívanie, veľ. 1,5-2 roky	102	7	f	-	0	14	1	2012-10-13 10:34:09+02
3972	Tmavosivé nohavice/rifle C&A, veľkosť 92	102	7	f	-	0	13	1	2012-10-13 10:34:13+02
3971	Tmavomodré podšité roll-up nohavice Next, veľ. 86	102	7	f	-	0	12	1	2012-10-13 10:34:19+02
3970	Rifle na traky Next, veľ. 104	102	12	f	-	0	11	1	2012-10-13 10:34:26+02
4008	Tenisky Puma, veľ. 34,5	102	9.9000000000000004	f	-	0	49	1	2012-10-13 10:34:35+02
4004	Zimné topánky na 2 suché zipsy, tmavomodré s kožušinou, veľ. 25	102	4	f	-	0	45	1	2012-10-13 10:34:43+02
4002	Zimné topánky tmavomodré DEI-tex, veľ. 25	102	8	f	-	0	43	1	2012-10-13 10:34:52+02
3958	béžová mančestrová bundička, s ružovou podšívkou, zn. Cherokee	101	2	f	-	0	24	1	2012-10-13 12:13:49+02
4018	sivá tepláková súprava, bieločervené pásikové futro, č. 68	103	5	f	-	0	9	2	2012-10-13 18:57:57+02
3987	Páskatý modro-bielo svetrík C&A, veľ. 92	102	3	f	-	0	28	2	2012-10-13 17:24:17+02
4013	slabo zelená bunda s kapucnou, na kapucni kožušinka, vzor vločiek	103	8	f	-	0	4	2	2012-10-13 16:20:43+02
4025	oranžové menčestráky s motívom Macka Puh na kolenách, 8 rokov	103	1.2	f	-	0	16	1	2012-10-13 08:59:39+02
4026	rifle č. 128, motýle na vreckách vpredu aj vzadu a flitre	103	5	f	-	0	17	1	2012-10-13 08:59:44+02
4027	čierny dlhý sveter na tri gombíky	103	2.2999999999999998	f	-	0	18	1	2012-10-13 08:59:55+02
4028	biely sveter (chlpatý, zn. cherokee)	103	4	f	-	0	19	1	2012-10-13 08:59:58+02
4029	čierny kabát s kvetmi a kapucnou	103	1.3	f	-	0	20	1	2012-10-13 09:00:20+02
4030	teplý biely sveter s kapucnou, č. 62. kravicka vlavo dole	103	4	f	-	0	21	1	2012-10-13 09:00:22+02
4031	suknička volánova s kvietkami dole 86-92	103	1.3	f	-	0	22	1	2012-10-13 09:00:23+02
4045	tmavo ružové tričko sametové s dlhými rukávmi, 8-9 rokov	103	2	f	-	0	36	2	2012-10-13 18:10:52+02
4034	 červený   klobúk	103	1	f	-	0	25	1	2012-10-13 09:00:40+02
4035	topánočky koženné béžovo-tmavozelené č. 20	103	4	f	-	0	26	1	2012-10-13 09:00:41+02
4056	zateplené šušťákové fialové nohavice, č. 128	103	1.3999999999999999	f	-	0	47	2	2012-10-13 16:57:51+02
4037	čierne tričko s flitrami 6-7 rokov	103	1	f	-	0	28	1	2012-10-13 09:00:55+02
4038	slabo ružový sveter, tmavo ružový lem, kvietky v strede	103	1.5	f	-	0	29	1	2012-10-13 09:00:57+02
4039	cyklámenový huňatý rolák, nápis flowers, tri kvietky, č. 128	103	6	f	-	0	30	1	2012-10-13 09:01:00+02
4040	rifle na 7-8 rokov, nad ľavým vreckom zips, zn. cherokee	103	2	f	-	0	31	1	2012-10-13 09:01:26+02
4041	červený klobúčik, károvaný lem s mašličkou	103	1.2	f	-	0	32	1	2012-10-13 09:01:28+02
4042	rifle č. 104, ornamentý na nohách, opasok na šnurovanie	103	1	f	-	0	33	1	2012-10-13 09:01:31+02
4043	červená čiapka s farebnými brmbolcami	103	1	f	-	0	34	1	2012-10-13 09:01:36+02
4044	slabo ružové tričko s dlhými rukávmi, zn. next, 4-5 rokov, hviezdičky 	103	1.2	f	-	0	35	1	2012-10-13 09:01:43+02
4070	Tmavohnede mencestraky na gumu v pase a patent zospodu CaA	104	3.5	f	-	0	11	2	2012-10-13 18:20:14+02
4032	fialová suknička s kvetmi 3-4 roky	103	1.3	f	-	0	23	2	2012-10-13 17:47:00+02
4036	bordové  tričko s dievčaťom	103	1.3	f	-	0	27	2	2012-10-13 16:44:41+02
4048	Ružovo-šedé tričko Hanna Montana s dlhými rukávmi, č. 134	103	2	f	-	0	39	1	2012-10-13 09:01:58+02
4050	bordová bundička s flitrami, zn. next, 5-6 rokov	103	8	f	-	0	41	1	2012-10-13 09:02:18+02
4049	ružové tepláky s nápisom balett princess, 5-6 rokov	103	1	f	-	0	40	1	2012-10-13 09:02:15+02
4051	rifle úzke, 7-8 rokov, 122-128, zn. kenvelo	103	7	f	-	0	42	1	2012-10-13 09:02:20+02
4052	čierne rifle, bielo-strieborné štepovanie, 7-8 rokov	103	3	f	-	0	43	1	2012-10-13 09:02:23+02
4053	zelený overal, rukávy modro-zelené pásiky	103	5	f	-	0	44	1	2012-10-13 09:02:27+02
4054	rifle na 6 rokov, zn. Squeeze girls	103	2	f	-	0	45	1	2012-10-13 09:02:35+02
4055	cyklámenový kožúštek, 6 rokov,zn. Adams	103	15	f	-	0	46	1	2012-10-13 09:02:41+02
4087	Zelene saty Early days	104	2.5	f	-	0	28	2	2012-10-13 17:20:39+02
4057	fialový sveter na zips s kapucnou, lemované kožušinkou, č. 110	103	1.5	f	-	0	48	1	2012-10-13 09:02:57+02
4058	ružová mikina s kapucnou, zn. item, vpredu vrecko	103	1.5	f	-	0	49	1	2012-10-13 09:03:01+02
4059	rifle na tráky, č. 68 s nápisom cheeky	103	2	f	-	0	50	1	2012-10-13 09:03:06+02
4434	Čierne legínky Lindex,116	113	2	f	-	0	48	1	2012-10-13 11:46:50+02
4065	Trigovica s kapucnou a Mickey Mouse	104	3.8999999999999999	f	-	0	6	2	2012-10-14 11:09:27+02
4061	Riflova sukna s vsitymi nohavicami vpredu vysivane 3kvietky	104	0.94999999999999996	f	-	0	2	1	2012-10-13 11:58:31+02
4062	Fialova sukna Girl2girl vlkost 98cm	104	1.8999999999999999	f	-	0	3	1	2012-10-13 11:58:55+02
4060	CAMPUS Mencestrove fialove saty s bielymi rukavmi vel. 86	104	1.3	f	-	0	1	2	2012-10-14 10:40:27+02
4077	Ruzova vzorovana ciapka s bielou podsivkou	104	1.5	f	-	0	18	2	2012-10-14 13:06:52+02
4047	červené sametové tričko s dlhými rukávmi a stojačikom	103	1.5	f	-	0	38	2	2012-10-13 16:44:41+02
4067	Ruzove saty na traky s vysivkou miskou a napisom Little Roo	104	2.2999999999999998	f	-	0	8	1	2012-10-13 11:59:27+02
4068	Cervene mencestrove saty s ruz gulickami,kvietkami a volanmi naspodu	104	1.8999999999999999	f	-	0	9	1	2012-10-13 11:59:31+02
4069	Hneda Mencestrova bunda na cvoky s kozusin.limcom	104	9.9000000000000004	f	-	0	10	1	2012-10-13 11:59:34+02
4064	Zlta trigovica s kapucnou,s kvietkami a napisom Pretty Flowers	104	2.8999999999999999	f	-	0	5	2	2012-10-13 18:37:02+02
4071	Modre rifle Okay velkost 98	104	5.2000000000000002	f	-	0	12	1	2012-10-13 11:59:42+02
4072	Mencestraky na traky s ruzovou podsivkou	104	3.8999999999999999	f	-	0	13	1	2012-10-13 11:59:47+02
4073	Biela sukna na traky Early days	104	2.2000000000000002	f	-	0	14	1	2012-10-13 11:59:50+02
4075	Biele tricko s dlhym rukavom a tmavomodrymi pasikmi	104	0.90000000000000002	f	-	0	16	1	2012-10-13 12:00:01+02
4079	Kaki nohavice s vysitymi kvetmi Nove s visackami PALOMINO	104	9.9000000000000004	f	-	0	20	1	2012-10-13 12:01:33+02
4091	Ruzovy komplet-pasikave teplaky a ruzova bundicka	104	2.8999999999999999	f	-	0	32	1	2012-10-13 12:02:02+02
4090	Kockova kosela s Mickey Mouse c.86	104	4.5	f	-	0	31	1	2012-10-13 12:02:10+02
4089	Riflova bunda na chrbate s cervenym napisom velkost 104	104	14.9	f	-	0	30	1	2012-10-13 12:02:16+02
4078	Pruzkove velurove saty Lindex Ruzovo-fialove pasiky	104	3.8999999999999999	f	-	0	19	1	2012-10-13 12:02:27+02
4088	Biele rukavice	104	0.69999999999999996	f	-	0	29	1	2012-10-13 12:02:33+02
4046	biele tričko s koníkom a srdiečkami, č. 134, zn. cactus clone	103	2	f	-	0	37	2	2012-10-13 17:30:27+02
4080	Cerveny sveter so zaplatami na laktoch novy s visackou	104	8.5	f	-	0	21	1	2012-10-13 12:02:45+02
4081	Cerveny svetrik na gombiky HM velkost 74	104	1.3	f	-	0	22	1	2012-10-13 12:03:03+02
4082	Seda suknicka s vysitou hviezdou MILOU velkost 80	104	2.2000000000000002	f	-	0	23	1	2012-10-13 12:03:09+02
4083	Cervena flisova trigovica so sobom a vysitym cislom 52	104	2.8999999999999999	f	-	0	24	1	2012-10-13 12:03:12+02
4084	Zlta bluzka na gombiky velkost 86	104	0.90000000000000002	f	-	0	25	1	2012-10-13 12:03:17+02
4085	Ruzova trigovica s napisom FITNESS	104	0.94999999999999996	f	-	0	26	1	2012-10-13 12:03:24+02
4086	Karovana kosela cerveno-modro-biela c.92	104	3.8999999999999999	f	-	0	27	1	2012-10-13 12:03:29+02
4076	Ruzova srdieckova ciapka s rukavicami	104	2.5	f	-	0	17	1	2012-10-13 12:03:38+02
4074	Ruzova vesta Next	104	8.6999999999999993	f	-	0	15	1	2012-10-13 12:04:00+02
4066	Cervene saty so sedymi kratkymi rukavmi malou mackovou brosnou	104	1.8999999999999999	f	-	0	7	2	2012-10-13 16:08:53+02
4111	ružové tepláky,F&F,veľ.4-5r.	105	2	f	-	0	2	2	2012-10-13 17:53:55+02
4133	biele tričko,CHEROKEE,vpredu kvetinky	105	1	f	-	0	24	2	2012-10-13 19:09:27+02
4113	šedé tepláky,CHEROKEE,5-6r.	105	3	f	-	0	4	1	2012-10-13 08:12:22+02
4103	Ruzova ciapka s kvetinkami	104	0.69999999999999996	f	-	0	44	2	2012-10-13 15:11:38+02
4120	tmavoružové tričko s dlhým rukávom,veľ.4r.	105	1	f	-	0	11	2	2012-10-13 18:04:43+02
4161	Koseľa H&M farebná 140                	106	2.7000000000000002	f	-	0	5	2	2012-10-13 19:27:00+02
4127	ružové tričko(TOY STORY3)JESSIE	105	1	f	-	0	18	2	2012-10-13 16:26:43+02
4123	šedé tričko,PALOMINO,veľ.104,vpredu tenisky	105	2	f	-	0	14	2	2012-10-13 17:44:18+02
4118	šedá trigovica,CHEROKEE,3-4r.,(mašlička)	105	2.5	f	-	0	9	2	2012-10-13 17:35:08+02
4162	Bordový rolák power Line116           	106	1.8999999999999999	f	-	0	6	2	2012-10-13 18:04:43+02
4134	bielofialova kvetinková trigovica,AUTHORITY	105	3	f	-	0	25	2	2012-10-13 18:36:15+02
4115	ružové tepláky,CHEROKEE(kvetinka),4-5r.	105	2	f	-	0	6	2	2012-10-13 17:53:55+02
4138	ružové pásikové tričko,veľ.110/116	105	0.5	f	-	0	29	2	2012-10-13 17:44:18+02
4121	ružové tričko s dlhým rukávom,(pásikové rukávy)	105	2	f	-	0	12	2	2012-10-13 18:35:49+02
4132	ružové kvetinkové tričko,PALOMINO,veľ.116	105	2	f	-	0	23	2	2012-10-13 19:24:46+02
4140	fialové tričko,PALOMINO,veľ.104	105	0.5	f	-	0	31	2	2012-10-13 16:26:43+02
4122	ružové tričko(MINNIE)	105	2	f	-	0	13	2	2012-10-13 17:50:54+02
4129	bledomodre tričko,vpredu dievčatko	105	1	f	-	0	20	1	2012-10-13 08:13:35+02
4130	hnedá trigovica,CHEROKEE,(PRETTY GIRL)	105	2	f	-	0	21	1	2012-10-13 08:13:39+02
4131	ružové tričko,vpredu GYMNASTIK TEAM	105	1	f	-	0	22	1	2012-10-13 08:13:43+02
4116	červené tepláky,veľ.110,(srdiečka)	105	1	f	-	0	7	2	2012-10-13 19:27:00+02
4125	ružové pásikové tričko(MINNIE)	105	2	f	-	0	16	2	2012-10-13 19:11:27+02
4137	ružové tričko,POLLY POCKET,kvetinkové rukávy	105	0.5	f	-	0	28	2	2012-10-13 18:50:04+02
4135	pásikové bieločervené tričko,CHEROKEE	105	1	f	-	0	26	1	2012-10-13 08:14:01+02
4101	Tmavomodre ifle Calvin Klein,vzadu na vrecku farebny napis	104	4.5	f	-	0	42	2	2012-10-14 11:01:13+02
4155	bordové zimné čižmy,PROTETIKA,veľ.28	105	10	f	-	0	46	2	2012-10-13 18:55:51+02
4153	šedé zimné topánky,veľ.22	105	2	f	-	0	44	2	2012-10-13 17:49:24+02
4139	modré tepláky,CHEROKEE,veľ.4-5r.,vpredu kvetinka	105	0.5	f	-	0	30	1	2012-10-13 08:14:17+02
4109	Ruzova polokosela -pasikava Topolino	104	4.2000000000000002	f	-	0	50	2	2012-10-13 16:48:23+02
4141	ružové pyžamo,veľ.2-4r.,vpredu mačička	105	2	f	-	0	32	1	2012-10-13 08:14:36+02
4142	jesenná modročervená bunda	105	1	f	-	0	33	1	2012-10-13 08:14:43+02
4143	riflová bunda,veľ.116,vpredu motýlik,srdiečka	105	3	f	-	0	34	1	2012-10-13 08:14:46+02
4144	ružová jesenná bunda,veľ.110/116,vpredu motýliky	105	3	f	-	0	35	1	2012-10-13 08:14:50+02
4165	Menžestr.ružová sukňa next 104        	106	2.7999999999999998	f	-	0	9	2	2012-10-13 16:06:44+02
4146	rifle veľ.122/128,LUSA	105	2	f	-	0	37	1	2012-10-13 08:15:00+02
4150	rifle,KENVELO,veľ.7-8r.	105	2	f	-	0	41	2	2012-10-13 15:49:21+02
4148	rifle,veľ.104,vpredu vrecká aj na boku	105	2	f	-	0	39	1	2012-10-13 08:15:08+02
4149	čierne rifle,veľ.128,dole vyšívané kvetinky	105	2	f	-	0	40	1	2012-10-13 08:15:13+02
4145	rifle veľ.128,vpredu vyšívané kvetinky	105	2	f	-	0	36	2	2012-10-13 16:02:29+02
4117	srdiečková trigovica,veľ.116	105	1.5	f	-	0	8	2	2012-10-13 16:20:44+02
4152	rifle,CHEROKEE,veľ.8-9	105	3	f	-	0	43	1	2012-10-13 08:15:37+02
4128	šedé tričko(MICKY MOUSE)	105	2	f	-	0	19	2	2012-10-13 17:50:54+02
4119	šedá prskaná trigovica	105	1	f	-	0	10	2	2012-10-13 17:35:08+02
4112	tmavoružové tepláky,F&F,4-5r.	105	3	f	-	0	3	2	2012-10-13 19:09:27+02
4124	červené tričko,CHEROKEE,vpredu sobík	105	2	f	-	0	15	2	2012-10-13 18:35:20+02
4154	bordové zimné čižmy,GIRLS,veľ.30	105	8	f	-	0	45	2	2012-10-13 17:09:37+02
4159	Fialové tričko F&F sova"nové"116      	106	2.7000000000000002	f	-	0	3	1	2012-10-13 09:54:02+02
4160	Tričko Reserved ružové"nové" 110      	106	2.7000000000000002	f	-	0	4	1	2012-10-13 09:54:05+02
4136	ružové nohavice,veľ.104	105	1	f	-	0	27	2	2012-10-14 09:37:16+02
4157	Vesta šedá-mačička 86                 	106	2.5	f	-	0	1	2	2012-10-13 18:12:37+02
4163	Sukňa Benetton barbie 110             	106	1.5	f	-	0	7	1	2012-10-13 09:54:32+02
4164	Hnedá-káro sukňa Zara kids 110        	106	2.5	f	-	0	8	1	2012-10-13 09:54:35+02
4166	Baranica fialová H&M 122/128"nová"    	106	3.5	f	-	0	10	1	2012-10-13 09:54:41+02
4151	šedé elastické rifle,F&F,CHEROKEE,veľ.8-9r.	105	2	f	-	0	42	2	2012-10-13 16:06:44+02
4095	Bledomodry kabatik s kapucnou,vnutorna podsivka vzorova-zajaciky	104	3.8999999999999999	f	-	0	36	1	2012-10-13 12:00:23+02
4108	Riflove saty s tenkymi farebnymi pasikmi hore CaA	104	3.7999999999999998	f	-	0	49	1	2012-10-13 12:00:35+02
4106	Ruzove sako s dvojradovym zapinanim (staroruzova)	104	10.5	f	-	0	47	1	2012-10-13 12:01:12+02
4158	Tunika pásik.H&M 116                  	106	2	f	-	0	2	2	2012-10-13 16:49:36+02
4105	Overal Campus so slonikom 	104	2.5	f	-	0	46	1	2012-10-13 12:01:27+02
4104	Tyrkys-ruzovo-fialovpo biela ciapka s brmbolcami	104	2.7000000000000002	f	-	0	45	1	2012-10-13 12:01:38+02
4147	šedé rifle,F&F,veľ.9-10r.,vpredu ligôtky	105	2	f	-	0	38	2	2012-10-13 15:31:16+02
4102	Bledomodre pruzkate nohavice FF	104	2.5	f	-	0	43	1	2012-10-13 12:01:46+02
4107	Hnede cizmicky s kvietkMI na boku	104	9.8000000000000007	f	-	0	48	2	2012-10-14 11:59:29+02
4094	Hnede mencestraky s vysivkou vlavo dolu	104	3.5	f	-	0	35	1	2012-10-13 12:01:55+02
4099	Seda vesticka Millow vel.68 S gumovou myskou a ruzovym vnutrom	104	5.9000000000000004	f	-	0	40	1	2012-10-13 12:03:48+02
4096	Ruzove platenky s maslickou Bobbi Shoes c.21	104	2.2000000000000002	f	-	0	37	2	2012-10-14 12:12:11+02
4098	Topanky FALCOTTO tmavomodre s cerveno sedou podrazkou c.18	104	9.9000000000000004	f	-	0	39	1	2012-10-13 12:04:28+02
4097	Fialkove platenky Benetton s bielou spicou	104	9.9000000000000004	f	-	0	38	1	2012-10-13 12:04:53+02
4114	fialové tepláky,F&F,veľ.4-5r.	105	3	f	-	0	5	2	2012-10-13 14:52:41+02
4170	Mikinka Guľ.next 110                  	106	4.5	f	-	0	14	2	2012-10-13 17:18:28+02
4203	Mikina 128 oranžová Adidas            	106	2.8999999999999999	f	-	0	47	2	2012-10-13 17:30:27+02
4189	Tričko H&M zelené lienka 110/116      	106	2.5	f	-	0	33	2	2012-10-13 16:50:17+02
4192	Čiapka H&M kitty 104                  	106	1.8999999999999999	f	-	0	36	1	2012-10-13 09:53:05+02
4172	Pončo ružové trbliet.Kappa            	106	2.2000000000000002	f	-	0	16	2	2012-10-13 18:04:43+02
4194	Ružový rolák Next 110                 	106	2.2000000000000002	f	-	0	38	1	2012-10-13 09:53:51+02
4167	Velúrová mikinka H&M ružová 116       	106	2.7999999999999998	f	-	0	11	1	2012-10-13 09:54:23+02
4179	Menž.sukňa H&M 122 ružová             	106	1	f	-	0	23	2	2012-10-13 19:12:22+02
4168	Žltá mikina Diesel 98                 	106	2.7999999999999998	f	-	0	12	2	2012-10-13 16:02:29+02
4169	Velúrová fialová mikina Girl 116      	106	2.5	f	-	0	13	1	2012-10-13 09:54:58+02
4199	Pyžam.vrch Cherokee víla 110          	106	1.5	f	-	0	43	2	2012-10-13 17:24:39+02
4185	Rifle šedé skinny next 128            	106	4.5	f	-	0	29	2	2012-10-13 18:55:17+02
4171	Pásik.predl.rolák H&M 134             	106	3.5	f	-	0	15	2	2012-10-13 15:34:57+02
4186	Rifle H&M modré 134                   	106	2.5	f	-	0	30	2	2012-10-13 15:33:34+02
4193	Svetrík H&M fialový pásik.110/116     	106	3.2999999999999998	f	-	0	37	2	2012-10-13 17:30:27+02
4190	Tričko hnedé koník H&M 110/116        	106	2.5	f	-	0	34	2	2012-10-13 17:29:26+02
4204	Mikina ružová Yushi 128               	106	1.5	f	-	0	48	1	2012-10-13 09:55:46+02
4201	Zamatová fialová mikinka Arizona 110  	106	2.2999999999999998	f	-	0	45	1	2012-10-13 09:56:06+02
4181	BUnda ružová Lupilu 110/116           	106	2.3999999999999999	f	-	0	25	1	2012-10-13 09:56:14+02
4182	Čiapka H&M ružová trblietky           	106	2.2999999999999998	f	-	0	26	1	2012-10-13 09:56:19+02
4210	Fleecové chlapčenské tepláky modré, vek 8 r. 	107	2	f	-	0	4	1	2012-10-13 19:07:15+02
4184	Rifle Dopodopo kvety 128              	106	3.8999999999999999	f	-	0	28	1	2012-10-13 09:56:30+02
4183	 Bekovka Adams kids cykl.ružová       	106	2.5	f	-	0	27	2	2012-10-13 19:04:25+02
4187	Fialové nohavice y-star128            	106	2.3999999999999999	f	-	0	31	2	2012-10-14 13:59:36+02
4217	Zeleny rolak s napisom, vel 134 	107	4	f	-	0	11	2	2012-10-14 10:57:37+02
4224	Pančuch. nohavice zelene, vel 134, nové	107	1	f	-	0	18	2	2012-10-13 19:14:04+02
4180	Bunda Cervená C&A 128                 	106	3.8999999999999999	f	-	0	24	1	2012-10-13 09:56:54+02
4176	 Rifle modré denim 128                	106	3.5	f	-	0	20	2	2012-10-13 18:43:15+02
4173	Rifle next 110                        	106	1.5	f	-	0	17	1	2012-10-13 09:57:02+02
4174	Cierne rifle H&M 128                  	106	2.5	f	-	0	18	1	2012-10-13 09:57:06+02
4175	Tepláky šedé H&M s kitty 134          	106	2	f	-	0	19	1	2012-10-13 09:57:11+02
4195	Rolák zelený Diam 122                 	106	2.3999999999999999	f	-	0	39	2	2012-10-13 18:43:15+02
4202	Sveter predĺž.S.oliver 140modrý       	106	1.3	f	-	0	46	1	2012-10-13 09:57:27+02
4191	Tričko Next kvety 98                  	106	2.2999999999999998	f	-	0	35	2	2012-10-13 16:30:23+02
4198	Ružová nočná košeľa snoppy 104        	106	1.8999999999999999	f	-	0	42	1	2012-10-13 09:57:34+02
4205	Mikina smotanová kik-star 116         	106	1.5	f	-	0	49	2	2012-10-13 17:26:55+02
4200	Pyžamo Marks&spencer 2 kusy 116       	106	2	f	-	0	44	1	2012-10-13 09:57:44+02
4188	Papučky Hello kitty H&M 30/31         	106	3.8999999999999999	f	-	0	32	1	2012-10-13 09:57:53+02
4211	Tmavomodrá jesenná budna s kapucou, vnútri pásikavá, vpredu macko, vel 128 	107	8	f	-	0	5	1	2012-10-13 10:43:41+02
4221	Zimná bunda zelená s kapucňou, vzadu "Teddy Bear", vel. 104	107	11	f	-	0	15	1	2012-10-13 10:43:50+02
4227	Bledomodrá jesenná bunda s kapucňou, vel. 104	107	6	f	-	0	21	1	2012-10-13 10:43:58+02
4222	Hnedo tyrkysova zimná bunda, stojačik, Kenvelo, vel 134 - 140 	107	13	f	-	0	16	1	2012-10-13 10:44:02+02
4212	Bledo a tmavomodrá bunda s kapucňou, zimná, na zadnej strane lyžiar, vel 128 	107	16	f	-	0	6	1	2012-10-13 10:44:08+02
4197	Pyž.vrch ružový marks&spencer110      	106	1.5	f	-	0	41	2	2012-10-13 16:26:43+02
4223	Hnedá vesta s kapucňou, vel. 134 	107	2	f	-	0	17	1	2012-10-13 10:44:17+02
4220	Tričko dlhý rukáv, hnedé - pásikavé, vel 134 	107	2.5	f	-	0	14	2	2012-10-14 10:57:37+02
4216	Bledomodrý rolak - obrazok Cyklo sport, vel. 134 	107	4	f	-	0	10	1	2012-10-13 10:44:22+02
4215	Bledomodrý rolák - tyrkys.farba, vel. 134 	107	4	f	-	0	9	1	2012-10-13 10:44:24+02
4219	Rolák biely, vel. 134 	107	3	f	-	0	13	1	2012-10-13 10:44:27+02
4214	Šedá vesta s bielymi a čiernymi pásikmi, vek 9-10 r.	107	2.5	f	-	0	8	2	2012-10-14 11:31:31+02
4177	Béžové nohavice C&A 122               	106	2.5	f	-	0	21	2	2012-10-14 11:35:58+02
4213	Bledomodrá vesta, napis Score, vek 8 r. 	107	2.5	f	-	0	7	1	2012-10-13 10:44:34+02
4230	Tmavomodrý sveter na zips, vel. 104	107	4	f	-	0	24	1	2012-10-13 10:44:41+02
4229	Tyrkysova trigovica, stojačik, obrazok auto - myš, vel. 98 	107	3	f	-	0	23	1	2012-10-13 10:44:55+02
4228	Teply sveter s kapucňou, béžovo šedy na zips, nápis 32 School, vel. 98	107	3	f	-	0	22	1	2012-10-13 10:45:00+02
4233	Tepláková bunda s kapucňou, hnedo oranžová, nápis "Hunting" , vel 122 - 128	107	4	f	-	0	27	2	2012-10-13 16:17:37+02
4178	Sukňa ovs-kids 122 béžová             	106	2	f	-	0	22	2	2012-10-13 15:17:55+02
4235	Nohavice - menčester, tmavo zelené, zateplené, vel. 92 	107	5.5	f	-	0	29	1	2012-10-13 10:45:39+02
4234	Nohavice - menčester, na traky, hnedé, vel 92	107	4	f	-	0	28	1	2012-10-13 10:45:43+02
4231	Rolák šedý, vel. 98 	107	2.5	f	-	0	25	1	2012-10-13 10:45:46+02
4232	Rolák bordový, vel 98 	107	2.5	f	-	0	26	1	2012-10-13 10:45:48+02
4236	Fleecová čiapka teplá, modrá, vel. 3 r. 	107	2.5	f	-	0	30	1	2012-10-13 10:46:12+02
4226	Hnedé jesenné topánky na suchý zips, vel. 33 	107	7	f	-	0	20	1	2012-10-13 10:46:21+02
4207	Zimné kožušinové topánky, hnedé John Garfield, vel. 32 	107	7	f	-	0	1	1	2012-10-13 10:47:28+02
4208	Chlapčenské lakové topánky na 1.sv.prijímanie, vel. 34	107	6	f	-	0	2	1	2012-10-13 10:48:25+02
4225	Modré gumenné čižmy /vzor bager, vel. 33	107	3.5	f	-	0	19	1	2012-10-13 10:48:43+02
4209	Fleecové chlapčenské tepláky hnedé, vek 8 r. 	107	2	f	-	0	3	2	2012-10-13 15:11:23+02
4248	Siva bunda Next s kapuckou s kozuskom, 6-9 mes 	108	10	f	-	0	2	1	2012-10-13 08:41:42+02
4270	červeno-hnedé otepľovačky s trakmi a vzorom na nohavici, veľ. 110	110	10	f	-	0	3	2	2012-10-14 10:42:32+02
4247	Kombineza Wedze, modro biela s kapuckou, 18 mes	108	17	f	-	0	1	1	2012-10-13 08:42:42+02
4245	Rifle chlapčenské, zn. Katval, vel 134 	107	7	f	-	0	39	1	2012-10-13 10:45:06+02
4246	Rifle chlapčenské, čierne140-146 	107	6	f	-	0	40	1	2012-10-13 10:45:14+02
4238	Pančuchy šedé, vel 92	107	0.5	f	-	0	32	1	2012-10-13 10:45:55+02
4244	Topánky hnedé, koženné na šnurovanie, vel. 21 	107	3.5	f	-	0	38	2	2012-10-13 17:36:18+02
4237	Modrá pásiková čiapka teplá, vel. 3 r. 	107	2.5	f	-	0	31	1	2012-10-13 10:46:13+02
4285	ružové nohavice, veľ. 7 rokov, 122	110	6	f	-	0	18	2	2012-10-13 19:12:44+02
4274	ružová vetrovka s kapucňou a výšivkou, veľ. 116/122	110	5	f	-	0	7	2	2012-10-14 10:57:36+02
4243	Topánky modré na šnurovanie, semiš, vel 23	107	3.5	f	-	0	37	1	2012-10-13 10:47:37+02
4242	Topánky hnedé, tmavá hnedá s bledou, šnurovanie a suchý zips, vel 26 	107	3.5	f	-	0	36	1	2012-10-13 10:47:39+02
4291	šedé pletené šaty s norskym vzorom a stuhou, veľ.110/116	110	4	f	-	0	24	2	2012-10-13 16:20:44+02
4266	Papučky červené na suchý zips,potlač mačička,č.21                                          2                                          	109	2.5	f	-	0	16	1	2012-10-13 11:24:13+02
4264	Papučky červené na šnorovanie,č.21                                                                 1,50	109	2	f	-	0	14	1	2012-10-13 11:24:16+02
4287	červené kordové nohavice, veľ. 5-6 rokov, 116	110	5	f	-	0	20	2	2012-10-13 16:50:17+02
4261	Tenisky modré s hviezdičkouč,21	109	3.5	f	-	0	11	1	2012-10-13 11:24:25+02
4260	Tenisky biele strblietkami zn.PUMA,č.21	109	5	f	-	0	10	1	2012-10-13 11:24:30+02
4239	Pančuchy šedé, vel 92	107	0.5	f	-	0	33	2	2012-10-13 17:21:43+02
4284	fialové termonohavice, veľ. 122	110	8	f	-	0	17	2	2012-10-13 15:52:30+02
4262	Tenisky bielo-ružové-love,č.21	109	2.5	f	-	0	12	2	2012-10-13 16:34:29+02
4273	ružová vetrovka s kapucňou a výšivkou, veľ. 92	110	5	f	-	0	6	2	2012-10-14 12:12:56+02
4241	Topánky chlapčenské zimné, na šnurovanie, modré s hnedou, vel. 26 	107	3.5	f	-	0	35	2	2012-10-13 19:19:16+02
4272	ružový zimný kožúštek s kapucňou a výšivkou, veľ. 4-5 rokov, 110	110	10	f	-	0	5	1	2012-10-13 15:14:38+02
4275	béžový overal s kapucňou a výšivkou mackov, veľ. 86-98	110	15	f	-	0	8	1	2012-10-13 15:14:43+02
4276	krémový overal s kapucňou a výšivkou jablka, veľ. 3-6 mes.	110	5	f	-	0	9	1	2012-10-13 15:14:44+02
4277	krémový sveter s kapucňou a výšivkou tučniaka, veľ. 80	110	2.5	f	-	0	10	1	2012-10-13 15:14:45+02
4278	krémový pulóver s výšivkou kvetu, veľ. 18 mes.	110	2.5	f	-	0	11	1	2012-10-13 15:14:47+02
4279	čierne termonohavice, veľ. 110	110	6	f	-	0	12	1	2012-10-13 15:14:48+02
4280	zateplené rifle s farebnými gombíkmi, veľ. 5 rokov	110	8	f	-	0	13	1	2012-10-13 15:14:49+02
4281	zateplené fialové kordové nohavice, veľ. 116	110	7	f	-	0	14	1	2012-10-13 15:14:52+02
4282	zateplené béžovo-hnedé nohavice s výšivkou, veľ. 18	110	7	f	-	0	15	1	2012-10-13 15:14:57+02
4283	zateplené ružové nohavice, veľ. 18	110	7	f	-	0	16	1	2012-10-13 15:14:58+02
4263	Čižmičky červené s lienkou,č.21	109	2.5	f	-	0	13	2	2012-10-13 16:39:57+02
4297	šedo-červená tepláková súprava NIKE, veľ. 92-98	110	8	f	-	0	30	2	2012-10-14 11:16:20+02
4286	zeleno-hnedé nohavice s opaskom a výšivkou na nohavici, veľ. 110	110	6	f	-	0	19	1	2012-10-13 15:15:01+02
4271	béžová vetrovka s kapucňou a vzorom Baby Minnie,veľ. 9-12 mes.	110	7	f	-	0	4	2	2012-10-13 18:19:20+02
4288	fialové kordové nohavice s flitrami, veľ. 122-128	110	6	f	-	0	21	1	2012-10-13 15:15:03+02
4289	rifle s opaskom a výšivkou na nohavici, veľ. 2	110	4	f	-	0	22	1	2012-10-13 15:15:04+02
4265	Papučky červené na klips,potlač námorník,č.21                                                   2	109	2.5	f	-	0	15	2	2012-10-13 16:08:53+02
4294	ružový rolák s pásmi a vzorom S.Oliver, veľ. 116/122	110	2.5	f	-	0	27	2	2012-10-13 17:35:08+02
4292	červený pletený pulóver s výšivkou kvetov, veľ. 5-6 rokov	110	3	f	-	0	25	1	2012-10-13 15:15:11+02
4293	modrý pletený sveter so zipsom a výšivkou, veľ. 4-5 rokov	110	3	f	-	0	26	1	2012-10-13 15:15:12+02
4296	hnedý sveter, veľ. 110/116	110	2	f	-	0	29	2	2012-10-13 18:50:04+02
4269	červeno-hnedá zimná vetrovka s kapucňou, vpredu vzor, veľ. 110	110	10	f	-	0	2	2	2012-10-13 16:20:43+02
4250	Navleky/dupky hnede s bielym lemovanim	108	1	f	-	0	4	2	2012-10-14 10:41:43+02
4298	ružový sveter so zipsom a kapucňou, veľ. 92-98	110	3	f	-	0	31	1	2012-10-13 15:15:17+02
4299	ružový sveter s výšivkou, veľ. 56	110	1.5	f	-	0	32	1	2012-10-13 15:15:20+02
4300	oranžový pulóver s kapucňou a zipsom, veľ. 62	110	1.5	f	-	0	33	1	2012-10-13 15:15:21+02
4301	ružový sveter s kapucňou, veľ. 104	110	2.5	f	-	0	34	1	2012-10-13 15:15:22+02
4302	modro-červené šaty s dlhým rukávom a vzorom kačky, veľ. 86 	110	3	f	-	0	35	1	2012-10-13 15:15:27+02
4268	ružová vetrovka s čiernym vzorom a kapucňou, 5000 mm, veľ. 122	110	15	f	-	0	1	2	2012-10-13 15:19:47+02
4290	červený pulóver s Hello Kitty, veľ. 110/116	110	3	f	-	0	23	2	2012-10-13 15:49:21+02
4295	krémové tričko s dlhým rukávom a vzorom Hello Kitty, veľ. 110/116	110	2	f	-	0	28	2	2012-10-13 15:49:21+02
4366	Mikina žltá srdiečková	112	2.2000000000000002	f	-	0	4	1	2012-10-13 08:30:03+02
4364	Modré rifle TERRANOVA XXS	112	3.2999999999999998	f	-	0	2	1	2012-10-13 08:30:07+02
4335	Zelenožltá zimná súprava s motívom macka, veľ. 12-18 mesiacov	111	3	f	-	0	18	2	2012-10-13 16:02:17+02
4367	Mikina zeleno-čierna	112	3.3999999999999999	f	-	0	5	1	2012-10-13 08:31:23+02
4346	Tmavomodrá čiapka s brmbolcami a rukavičkami, veľ. 3-4 roky	111	2.5	f	-	0	29	2	2012-10-13 16:39:57+02
4315	modro-ružový flísový sveter so zipsom, veľ. 104	110	2	f	-	0	48	2	2012-10-13 17:35:08+02
4314	ružový flísový sveter so zipsom, veľ. 3-4 roky, 104	110	2	f	-	0	47	2	2012-10-13 18:30:01+02
4357	Bledožlté dupačky s motívom dinosaura, veľ. cca 3 mesiace	111	2.2000000000000002	f	-	0	40	1	2012-10-13 09:06:45+02
4358	Fialové body s motívom zajka, zn. F&F, veľ. 3-6 mesiacov	111	1.5	f	-	0	41	1	2012-10-13 09:07:11+02
4359	Bledoružové body s detským motívom, veľ. 68	111	1.3	f	-	0	42	2	2012-10-13 17:30:27+02
4341	Biele body s motívom macka, veľ. 80	111	1.5	f	-	0	24	2	2012-10-13 17:30:27+02
4307	ružové pyžamo so vzorom Hello Kitty, veľ. 116	110	2	f	-	0	40	2	2012-10-13 15:49:21+02
4337	Tmavošedá mikina s kapucňou so svetlými rukávmi, veľ. 6-12 mes.	111	2.5	f	-	0	20	1	2012-10-13 09:08:05+02
4320	Bledomodrá mikina s motívom macka, veľ. 80	111	2	f	-	0	3	1	2012-10-13 09:08:12+02
4333	Bledohnedá mikina s kapucňou s motívom auta,zn.Frog, veľ.3-4roky	111	2.5	f	-	0	16	1	2012-10-13 09:08:24+02
4334	Ružový flisový overall na cvoky, zn.Frog, veľ. 3 mesiace	111	2.5	f	-	0	17	1	2012-10-13 09:08:33+02
4339	Tmavomodrá súprava so zelenými pásmi zn.H&M, veľ. 6-9mesiacov	111	6.5	f	-	0	22	1	2012-10-13 09:08:43+02
4361	Bieloružová čiapka, veľ. 6 mesiacov	111	1.5	f	-	0	44	2	2012-10-14 10:22:23+02
4328	Tmavomodré rifle na gumu s vreckom na predu, veľ. 9-12 mesiacov	111	3	f	-	0	11	1	2012-10-13 09:08:54+02
4348	Tmavomodré papučky s motívom macka, veľ. 115	111	4.5	f	-	0	31	1	2012-10-13 09:09:01+02
4332	Modrohnedá pásiková mikina s kapucňou, veľ. 3-4 roky	111	3.5	f	-	0	15	2	2012-10-13 17:40:26+02
4319	Bledomodrá zimná čiapka s brmbolcom, zn. Proman, veľ.cca 3-4 roky	111	2	f	-	0	2	1	2012-10-13 09:09:16+02
4356	Bledozelené dupačky na cvoky s motívom žirafy, veľ. 62	111	2.2999999999999998	f	-	0	39	2	2012-10-13 16:25:44+02
4350	Bieloružové pásikové dupačky na cvoky s motívom dievčatka, veľ.50/56	111	2.5	f	-	0	33	1	2012-10-13 09:09:31+02
4351	Bieloružové pásikové dupačky na cvoky s motívom dievčatka, veľ.62/68	111	2.5	f	-	0	34	1	2012-10-13 09:09:35+02
4322	Modré pančušky s motívom závodníka, veľ.  3-4 roky	111	1	f	-	0	5	2	2012-10-14 11:00:00+02
4354	Pestrofarebné body s dlhým rukávom, zn. F&F, veľ. 9-12 mesiacov	111	1	f	-	0	37	2	2012-10-13 18:07:21+02
4325	Tmavozelené manchesterové nohavice zateplené, veľ.12-18 mesiac.	111	3.5	f	-	0	8	2	2012-10-13 18:14:41+02
4353	Ružová zimná čiapka so srdiečkom, veľ. 34-36 cm	111	4	f	-	0	36	1	2012-10-13 09:09:51+02
4352	Ružová zimná mikina s motívom tučniaka, veľ. 56	111	3	f	-	0	35	1	2012-10-13 09:10:03+02
4311	červená vetrovka so zipsom a kapucňou, veľ. 5	110	2	f	-	0	44	2	2012-10-13 19:32:16+02
4338	Tmavomodré rifle zn.MINOTI s vreckom na boku, veľ. 12-18 mesiacov	111	3	f	-	0	21	1	2012-10-13 09:10:38+02
4329	Tmavomodré rifle s nápisom USA na kolene, veľ. 3-4 roky	111	2.5	f	-	0	12	1	2012-10-13 09:10:43+02
4326	Tmavomodré rifle s vreckami na bokoch, veľ. 122	111	1.5	f	-	0	9	1	2012-10-13 09:10:47+02
4340	Bledozelený rolák s detským motívom, veľ. 104	111	2.5	f	-	0	23	2	2012-10-13 15:44:00+02
4360	Bledoružové body so srdiečkami, zn. F&F, Veľ. 9-12 mesiacov	111	1	f	-	0	43	2	2012-10-13 18:20:14+02
4342	Šedomodré pásikové tričko s bielymi rukávmi,zn.Cherokee, veľ.4-5 rok	111	2.5	f	-	0	25	2	2012-10-14 11:09:27+02
4321	Bledozelená mikina s kapucňou s motívom psíka, veľ.cca 9-12 mes.	111	2	f	-	0	4	1	2012-10-13 09:11:20+02
4330	Tmavohnedá čiapka s nášivkou, veľ. 3-4 roky	111	1	f	-	0	13	1	2012-10-13 09:11:29+02
4345	Žltá športová bunda so zipsom, veľ. 110	111	2.5	f	-	0	28	1	2012-10-13 09:11:39+02
4347	Bielomodré papučky, veľ. 12,5/115	111	4	f	-	0	30	1	2012-10-13 09:11:42+02
4331	Čierna košeľa s dvoma vreckami napredu, veľ. 116	111	2.7999999999999998	f	-	0	14	1	2012-10-13 09:11:52+02
4327	Tmavomodré rifle na traky, veľ. 12-18 mesiacov	111	3.5	f	-	0	10	2	2012-10-13 18:14:41+02
4355	Ružové pásikové body s dlhým rukávom, veľ. 6-9 mesiacov	111	1	f	-	0	38	2	2012-10-13 18:03:40+02
4336	Tmavošedé kapsáčové nohavice na gumu, veľ. 4-5 rokov	111	3.5	f	-	0	19	1	2012-10-13 09:12:12+02
4362	Tehotenské rifle tmavomodré s čiernym elastickým pásom,zn.Yessica,veľ.38	111	15	f	-	0	45	1	2012-10-13 09:12:20+02
4303	tehlovočervená flísová vesta so zipsom, veľ. 116	110	2	f	-	0	36	1	2012-10-13 15:15:28+02
4304	oranžový flísový pulóver so zipsom a vzorom, veľ. 98 	110	2	f	-	0	37	1	2012-10-13 15:15:29+02
4305	žltý spací vak so zipsom a vzorom macka, veľ. 0-9 mes.	110	3	f	-	0	38	1	2012-10-13 15:15:30+02
4306	ružové sametové dupačky so vzorom macka, veľ. 86/92	110	2	f	-	0	39	1	2012-10-13 15:15:31+02
4363	Tmavo-šedé rifle veľ. 152	112	3.7000000000000002	f	-	0	1	2	2012-10-13 15:53:10+02
4308	riflová bunda s kovovými gombíkmi, veľ. 6	110	5	f	-	0	41	1	2012-10-13 15:15:35+02
4309	ružové nohavice, veľ. 122	110	4	f	-	0	42	1	2012-10-13 15:15:36+02
4310	hnedé nohavice, veľ. 18	110	4	f	-	0	43	1	2012-10-13 15:15:37+02
4344	Pletený sveter s " K " napredu, veľ. 12-18 mesiacov	111	2.5	f	-	0	27	2	2012-10-14 09:21:26+02
4318	Ružový zimný overal s kapucňou,zn.Cherokee, veľ.6-9mesiacov	111	5.9000000000000004	f	-	0	1	2	2012-10-13 19:19:16+02
4313	zateplené rifle s flitrami, veľ. 116	110	5	f	-	0	46	1	2012-10-13 15:15:41+02
4312	zateplené rifle s flitrami, veľ. 122	110	5	f	-	0	45	2	2012-10-13 19:16:52+02
4317	biely flísový sveter so zipsom a vzorom vločky a kvetu, veľ. 122	110	2	f	-	0	50	2	2012-10-13 15:20:36+02
4324	Šedý sveter so zipsom zn.KENVELO, veľ. 4-5 rokov	111	3.5	f	-	0	7	2	2012-10-13 15:26:50+02
4316	fialový flísový sveter so zipsom a vzorom vločky a kvetu, veľ. 122	110	2	f	-	0	49	2	2012-10-13 15:20:36+02
4380	Návliečky flanelové ružové MY LITTLE PONY 2 kusy	112	6	f	-	0	18	1	2012-10-13 08:28:12+02
4387	Mikinka s kapuckou Lisa Simpson, šedej farby, veľkosť 5-6 rokov	113	4.5	f	-	0	1	2	2012-10-14 11:21:04+02
4376	Bundička hnedá s kožušinou veľ.128	112	3	f	-	0	14	1	2012-10-13 08:28:28+02
4404	Tepláčky Adidas,1-2roky, tmavomodré biele pásiky	113	6	f	-	0	18	2	2012-10-13 17:18:28+02
4386	Kratke šede čižmy s bielou kožušinou a striebor. Gombikmi	112	2.7000000000000002	f	-	0	24	1	2012-10-13 08:28:40+02
4378	Pyžamové nohavice tm.rúžové s kvetinkou	112	0.59999999999999998	f	-	0	16	2	2012-10-13 15:01:38+02
4383	Tmavo fialová mikina so strieborným nápisom 	112	3.3999999999999999	f	-	0	21	1	2012-10-13 08:29:48+02
4371	Tričko dlhý rukáv zeleno-čierne so sovičkami	112	1.5	f	-	0	9	2	2012-10-13 18:28:04+02
4405	Bundička tepláková, adidas,1-2 roky, šedá s červeným, na zips, s kapuckou	113	6	f	-	0	19	2	2012-10-13 16:10:45+02
4415	Kvetinková tunika, Next 116,6 rokov, bledohnedé kvetinky, hnedé	113	3.5	f	-	0	29	2	2012-10-13 15:13:27+02
4377	Pyžamové tričko dl.rukáv s obrázkom BRATZ	112	0.69999999999999996	f	-	0	15	1	2012-10-13 08:30:28+02
4398	Pásikavá tunika,čierna-šedá,Lindex kids,116	113	3.5	f	-	0	12	2	2012-10-13 18:28:39+02
4381	Sukňa šedo-ružovo čierne káro BENETON	112	2	f	-	0	19	2	2012-10-13 15:34:57+02
4382	Zimná bunda čierna s fialovými a bielymi kruhmi s kapucou	112	8	f	-	0	20	1	2012-10-13 08:31:52+02
4368	Mikina šedo-čierna so strieborným nápisom	112	3.3999999999999999	f	-	0	6	2	2012-10-13 15:34:57+02
4379	Taška šedo-čierna zebrová s panáčikom	112	2.5	f	-	0	17	1	2012-10-13 19:15:04+02
4433	Tenisky Lacoste, biele, na suchý zips,23	113	11	f	-	0	47	1	2012-10-13 11:40:54+02
4417	Červené gumáky Manchester United, 25	113	6	f	-	0	31	1	2012-10-13 11:41:01+02
4425	Tunika, tričko s dlh.,rukávom, ružové s motýlikom,cherokee,3-4roky	113	2	f	-	0	39	2	2012-10-14 12:01:37+02
4384	Zimná bunda bielo-zeleno-šedé kocky	112	10	f	-	0	22	2	2012-10-13 15:34:56+02
4390	Tepl. bunda Lonsdale s kapuckou, čierna, 2-3roky, na zips, šedý pás na rukáve	113	5.5	f	-	0	4	1	2012-10-13 11:41:18+02
4389	Košela károvaná, šedé rukávy + kapucka, na gombíky, 3-4 roky, F&F, nová	113	4	f	-	0	3	1	2012-10-13 11:41:31+02
4414	Tričko s dlhým rukávom, biele,lisa simpson,5-6 rokov	113	1.5	f	-	0	28	2	2012-10-13 19:32:16+02
4392	Rifle Reserved, 1,5-2roky,92cm,bledá riflovina	113	6	f	-	0	6	1	2012-10-13 11:41:51+02
4393	Mikina s kapuckou,Rugby club,98,bielo-modrá	113	4	f	-	0	7	1	2012-10-13 11:41:58+02
4394	Bundička Esprit, 8-9rokov,128-134, na gombíky, bordovej farby	113	6	f	-	0	8	1	2012-10-13 11:42:03+02
4385	Čižmy fialové s remienkami kožušinové 36	112	9	f	-	0	23	2	2012-10-13 16:57:51+02
4396	Bundička s.Oliver,116-122, nová,ružovej farby, na cvočky	113	13	f	-	0	10	1	2012-10-13 11:42:16+02
4428	Kožené tenisky adidas,21,hnedé	113	5	f	-	0	42	1	2012-10-13 11:42:27+02
4397	Zimná bunda,čierna s kapuckou, Lazy town,5-6rokov,116,na zips	113	8	f	-	0	11	1	2012-10-13 11:42:34+02
4427	Snehulky Campri, 25,5, modré na suchý záps	113	5	f	-	0	41	2	2012-10-13 18:42:27+02
4399	Rifle Esprit, 116, 6 rokov	113	5	f	-	0	13	1	2012-10-13 11:42:44+02
4401	Suknička menžestrová, zelená,3/98, na boku vačky s vtáčikom,LC Waikiki	113	3	f	-	0	15	1	2012-10-13 11:42:52+02
4402	Tepláková súprava Benetton,červená,biely nápis, 2-3 roky	113	7	f	-	0	16	1	2012-10-13 11:43:10+02
4429	Menžestrové šatičky Next,bledé, s kvetinkami,6-9mesiacov	113	4	f	-	0	43	2	2012-10-13 16:34:29+02
4370	Predĺžená mikina čierno-biela kvetovaná	112	2.5	f	-	0	8	2	2012-10-14 10:22:48+02
4388	Tričko dlhý rukáv, Lindex, 98, červenej farby, potlač lev biely	113	1.5	f	-	0	2	2	2012-10-13 15:15:37+02
4416	Kvetinková košielka,Teranova kids,4-5 rokov, biela, ružové kvetinky, nová	113	7.5	f	-	0	30	1	2012-10-13 11:43:39+02
4418	Biela čapička + rukavičky, palčáky,1 rok	113	2	f	-	0	32	1	2012-10-13 11:43:44+02
4419	Pásikavá čiapka Diesel,ušanka, žltá-šedá-modrá	113	8	f	-	0	33	1	2012-10-13 11:44:00+02
4420	Upletová čiapka Ralph lauren, modrá so zeleným koníkom 	113	8	f	-	0	34	1	2012-10-13 11:44:09+02
4422	Nátelník s dlhým rukávom, modrý s ružovým, reserved,116cm	113	2	f	-	0	36	1	2012-10-13 11:44:14+02
4423	Rifle Armani,86cm, bledá riflovina	113	12	f	-	0	37	1	2012-10-13 11:44:40+02
4413	Úpletové šaty Ralph lauren,6rokov, ružovej farby	113	11	f	-	0	27	2	2012-10-13 16:34:06+02
4408	Ružová baranica, Lazy town, stephanie,na suchý zips	113	3	f	-	0	22	2	2012-10-14 12:12:11+02
4426	Tenké riflové nohavice,H&M,116,5-6rokov,nové bez visačky	113	9	f	-	0	40	1	2012-10-13 11:44:53+02
4395	Flaušová bunda, Lazy town,5-6rokov,na zips,Stephanie	113	6	f	-	0	9	2	2012-10-13 16:50:17+02
4431	Mikinka s kapuckou ružová,Next,9-12mesiacov	113	3	f	-	0	45	1	2012-10-13 11:45:02+02
4421	Košielka s dlhým rukávom, modrá na gombíky,ralph lauren, 2 roky	113	8.5	f	-	0	35	1	2012-10-13 11:46:55+02
4403	Sačko čierne, semišové, Adams kids,110,5 rokov	113	2.5	f	-	0	17	1	2012-10-13 11:45:19+02
4369	Mikina na zips tyrkiz LOVE LUCKY s čiernou kapucou	112	3.3999999999999999	f	-	0	7	2	2012-10-13 18:13:48+02
4424	Košielka s dlhým rukávom, barbie,3 rok	113	3	f	-	0	38	2	2012-10-13 16:20:44+02
4406	Jesenná bundička,H&M,hnedá,122,6-7rokov, s kapuckou, na zips	113	8.5	f	-	0	20	1	2012-10-13 11:45:33+02
4407	Čiapka No Fear, modrá s lebkou	113	2	f	-	0	21	1	2012-10-13 11:45:37+02
4409	Čiapka teplejšia so šiltom, bordová, s lebkou no fear	113	4	f	-	0	23	1	2012-10-13 11:45:41+02
4410	Károvaná košielka Lee Cooper,2-3 roky, na gombíky	113	4.5	f	-	0	24	1	2012-10-13 11:45:50+02
4411	Mikinka Ralph Lauren,s kapuckou na zips,2roky,tmavomodrá s červenou	113	7.5	f	-	0	25	1	2012-10-13 11:45:57+02
4412	Rifličky H&M,68	113	4	f	-	0	26	1	2012-10-13 11:46:12+02
4400	Tenisky Puma, 22, zelené s ružovou, brúsená koža	113	8	f	-	0	14	1	2012-10-13 11:46:36+02
4430	Rifle Zara,6-12 mesiacov,	113	4	f	-	0	44	1	2012-10-13 11:46:43+02
4432	Rifle Next,12-18mesiacov,	113	3	f	-	0	46	1	2012-10-13 11:47:06+02
4391	Pásikový svetrík, F&F,2-3 roky, modrá,zelená, červená,biela	113	3	f	-	0	5	2	2012-10-13 14:34:31+02
4436	Károvaná bundička šuštiaková,SAM,122 s kapucikou, 	113	7	f	-	0	50	1	2012-10-13 11:46:19+02
4435	Čierne haremové nohavice,6rokov,Miss Brum,kamienkové MB na páse	113	3	f	-	0	49	1	2012-10-13 11:46:25+02
4488	tmavomodra ciapka Hugo, 46-49 cm	115	3.2999999999999998	f	-	0	2	1	2012-10-13 11:52:40+02
4489	tmavomodro bledomodra ciapka Rada, c. 4, 46-48 cm	115	3.2999999999999998	f	-	0	3	1	2012-10-13 11:52:44+02
4490	modry hruby flisovy overal, napis teddy bear, velkost 74	115	5.5	f	-	0	4	1	2012-10-13 11:52:47+02
4491	zateplene tmavomodre rifle F&D jeans, velkost 74	115	3.8999999999999999	f	-	0	5	1	2012-10-13 11:52:52+02
4492	bledofialova mikinka Young, velkost 98	115	3.5	f	-	0	6	1	2012-10-13 11:52:55+02
4493	ruzova pletena ciapka Barbie s brmbolcom, 52 cm	115	3.5	f	-	0	7	1	2012-10-13 11:52:59+02
4494	rifle tmavomodre, hai di, velkost 68	115	3.2999999999999998	f	-	0	8	1	2012-10-13 11:53:02+02
4495	ruzova dlhsia mikinka na krku na uvazovanie, Young, c. 98	115	3.5	f	-	0	9	1	2012-10-13 11:53:05+02
4496	tmavosede hrubsie teplacky okay, 74	115	2.2999999999999998	f	-	0	10	1	2012-10-13 11:53:10+02
4497	tmavosede hrubsie teplacky okay, 74	115	2.2999999999999998	f	-	0	11	1	2012-10-13 11:53:13+02
4498	riflova suprava nanako modra s vysitymi motylikmi - velkost 2 roky	115	5.9000000000000004	f	-	0	12	1	2012-10-13 11:53:18+02
4499	biely overalik frote s tucniakom	115	2.2000000000000002	f	-	0	13	1	2012-10-13 11:53:24+02
4500	rifle power kids, velkost 92	115	2.8999999999999999	f	-	0	14	1	2012-10-13 11:53:28+02
4502	fialova mikinka Tesco, c. 98	115	3.2000000000000002	f	-	0	16	1	2012-10-13 11:53:39+02
4504	tmavomodre rifle C&A, c. 68	115	2.8999999999999999	f	-	0	18	1	2012-10-13 11:53:45+02
4505	zelene mencestraky Next, do 3 mesiacov	115	2.8999999999999999	f	-	0	19	1	2012-10-13 11:53:49+02
4507	ciapka bordova huna, velkost 48	115	2.2000000000000002	f	-	0	21	1	2012-10-13 11:53:59+02
4509	makucka cervena bundicka early days, 18-23 mesiacov	115	3.8999999999999999	f	-	0	23	1	2012-10-13 11:54:05+02
4510	flisova smotanova suprava tulec trend 6 mesiacov	115	4.5	f	-	0	24	1	2012-10-13 11:54:21+02
4511	bledomodro-tmavomodry overalik makky, 1 mesiac, nakres psikov	115	2.3999999999999999	f	-	0	25	1	2012-10-13 11:54:33+02
4512	bledoruzove body rolakove Kenguru gold, c. 74	115	2.7999999999999998	f	-	0	26	1	2012-10-13 11:54:35+02
4514	biele silonky so vzorom hrubsie	115	2.2000000000000002	f	-	0	28	1	2012-10-13 11:54:48+02
4501	sytoruzova mencestrova bunda na gombiky, 18-23 mesiacov	115	3.8999999999999999	f	-	0	15	2	2012-10-13 14:46:07+02
4503	bledoruzova zimna bunda Next, c. 92	115	3.2999999999999998	f	-	0	17	2	2012-10-13 16:34:29+02
4513	ruzove pancusky rewon 68-74, nakres mysiek	115	2.5	f	-	0	27	2	2012-10-13 16:52:32+02
4506	uzke cierne rifle Kenvelo, c. 108,114	115	3.8999999999999999	f	-	0	20	2	2012-10-13 17:44:18+02
4577	hnedý rolák, veľ. 116	117	1.5	f	-	0	1	0	2012-10-11 22:57:26+02
4578	ružový rolák, veľ. 116	117	1.5	f	-	0	2	0	2012-10-11 22:57:26+02
4579	tmavoružové tričko s dlhým rukávom, vzorom dievčaťa a psa, veľ. 122	117	2	f	-	0	3	0	2012-10-11 22:57:26+02
4580	ružové tričko s dlhým rukávom a vzorom Barbie Princezné, veľ. 122	117	2	f	-	0	4	0	2012-10-11 22:57:26+02
4562	Blúza -aj tehotenská, farby bledomodrej, jemný pásik a vpredu výšivka, veľkosť 42/44	116	2	f	-	0	26	1	2012-10-13 11:07:42+02
4566	Elegantné čierne šaty, v.44, HM	116	5	f	-	0	30	1	2012-10-13 11:07:53+02
4567	Body, farba modrý, zelený a žltý pásik, v. 0-3mes	116	0.5	f	-	0	31	1	2012-10-13 11:07:58+02
4527	bledohnede kozene semisove topanocky s rybickou KID, c. 22	115	6.5	f	-	0	41	2	2012-10-13 16:55:58+02
4569	Dojčenské nohavice, pásik bielo,ružovo-fialový,v. 56	116	1	f	-	0	33	1	2012-10-13 11:08:09+02
4529	zlta supravicka tepla flisova orko kids 74-80	115	5	f	-	0	43	2	2012-10-13 17:50:54+02
4571	Tričko, biele, ružové puntíky a drobná výšivka vpredu,v.0-3	116	0.5	f	-	0	35	1	2012-10-13 11:08:19+02
4575	Klokanka, zelená, HM v. 62	116	1	f	-	0	39	1	2012-10-13 11:08:24+02
4524	cierne kozusinkove topanky BALLY, c. 15	115	3.8999999999999999	f	-	0	38	2	2012-10-13 18:14:41+02
4573	Capačky, bledomodrém kožené, biely pásik, v.17	116	1	f	-	0	37	1	2012-10-13 11:08:42+02
4539	Teplé capačky (biele vlnené, vnútri kožušina, v. 0-3mes)	116	2	f	-	0	3	1	2012-10-13 11:08:48+02
4574	Capačky, plátenky,tyrkysové s nápisom baby baseball	116	1	f	-	0	38	1	2012-10-13 11:09:05+02
4545	2 ks spolu Dievčenské punčocháče (ružové+biele) v. 62-68	116	1	f	-	0	9	1	2012-10-13 11:09:09+02
4544	Teplá štrikovaná čiapka s rukavičkami. Ružovožltý pásik, kvetinky. 0-3mes.	116	4	f	-	0	8	2	2012-10-14 12:13:27+02
4572	čiapočka, biela s malými medvedíkmi a hviezdičkami	116	0.5	f	-	0	36	1	2012-10-13 11:09:23+02
4563	Blúza -aj tehotenská, farby modrej, č.42	116	2	f	-	0	27	1	2012-10-13 11:09:50+02
4564	Blúza -aj tehotenská, farby fialovo-oranžovej, vzor retro kvety, v.44	116	2	f	-	0	28	1	2012-10-13 11:10:00+02
4565	Blúza/šaty, farby modrej, so žltými kvetmi, v.40	116	2	f	-	0	29	1	2012-10-13 11:10:03+02
4551	2ks body (modro zelené + biele s labkami) v. 0-3, 	116	1	f	-	0	15	1	2012-10-13 11:10:22+02
4550	Body, biele s drobnými kvietkami, v. 62	116	0.5	f	-	0	14	1	2012-10-13 11:10:30+02
4549	Biele tričko, dlhý rukáv,v. 3-6	116	0.5	f	-	0	13	1	2012-10-13 11:10:32+02
4548	Ružové tričko, dlhý rukáv, fialové pásiky v. 6-9mes.	116	0.5	f	-	0	12	1	2012-10-13 11:10:35+02
4546	Žlté tričko s nohavicami (je na ňom sloník) v. 0-3mes.	116	1.5	f	-	0	10	1	2012-10-13 11:10:42+02
4533	makucka mikinka Next s ciapockou - pasikava, c. 86	115	3.5	f	-	0	47	2	2012-10-13 17:18:28+02
4541	Ružová mikina na zips, teplákovina, zn.NEXT, v.6-9mes	116	3	f	-	0	5	1	2012-10-13 11:11:42+02
4552	Tričko s gaťami, ružové s pásikmi, je na nich žirafa, v. 0-3mes	116	1.5	f	-	0	16	1	2012-10-13 11:11:47+02
4553	Body, farba zelenkavá, v. 56	116	0.5	f	-	0	17	1	2012-10-13 11:11:49+02
4554	Tričko s krátkym rukávom a bielymi mačkami, v 3-6m	116	1.5	f	-	0	18	1	2012-10-13 11:11:51+02
4555	Overal na spanie, ružový s nosorožcom, má pásikavé rukávy, oranžovo-fialové, v.56	116	1	f	-	0	19	1	2012-10-13 11:12:00+02
4556	Dupačky, bilo-ružové pásiky a vpredu aplikácia zvieratká, v. 4,1kg	116	0.5	f	-	0	20	1	2012-10-13 11:12:01+02
4557	Body, ružové s pásikmi, vpredu kreslený mcko, v. 0-3	116	0.5	f	-	0	21	1	2012-10-13 11:12:03+02
4558	Šatičky/košeľa, tmavá modrá, dole vyšívané kvety, v. 0-3m	116	2	f	-	0	22	1	2012-10-13 11:12:06+02
4537	Teplý zimný dievčenský overal s kapucňou (bordový s rôznymi kvetinovými vzormi, v.56-62cm)	116	15	f	-	0	1	1	2012-10-13 11:12:28+02
4538	Ružový flisový overal, v. 0-3mes	116	2.5	f	-	0	2	1	2012-10-13 11:12:35+02
4540	Biely flisový overal s kapucňou, v. 0-3mes	116	1.5	f	-	0	4	1	2012-10-13 11:12:43+02
4543	Modré capačky CHICCO,v.17	116	2	f	-	0	7	1	2012-10-13 11:12:46+02
4515	biely flisovy svetrik george, 3-4 roky	115	2.6000000000000001	f	-	0	29	1	2012-10-13 11:54:52+02
4516	bledomodre makucke gate zateplene, marks&spencer, c.62	115	2.7999999999999998	f	-	0	30	1	2012-10-13 11:55:34+02
4517	rifle zvonove RYB, c. 92	115	2.5	f	-	0	31	1	2012-10-13 11:55:37+02
4518	bledomodra makucka suprava, sveter na gombiky+polodupacky, 62-68	115	3.2999999999999998	f	-	0	32	1	2012-10-13 11:55:40+02
4519	biely overalik frote carters, 9 mesiacov	115	2.8999999999999999	f	-	0	33	1	2012-10-13 11:55:43+02
4520	riflova bundicka carters, 12 mesiacov	115	3.8999999999999999	f	-	0	34	1	2012-10-13 11:55:46+02
4559	Čiapočka, tenká, ružová-pásikatá, 0-3mes	116	0.5	f	-	0	23	2	2012-10-14 10:36:19+02
4522	hrube ruzove rewon pancusky, 68-74, nakresy guliciek	115	2.8999999999999999	f	-	0	36	1	2012-10-13 11:55:53+02
4523	bledozlty teplejsi svetrik s kacickou, little bundle, 68 cm	115	2.8999999999999999	f	-	0	37	1	2012-10-13 11:55:56+02
4528	bledoruzova deka Carters s napisom baby a slonikom	115	5.9000000000000004	f	-	0	42	1	2012-10-13 11:56:03+02
4576	Fialová bundička, zn. NEXT, v 9-12mes	116	8	f	-	0	40	2	2012-10-13 18:03:40+02
4530	smotanove tricko s havkami dlhy rukav, adams kids, 3-6 m.	115	2.2000000000000002	f	-	0	44	1	2012-10-13 11:56:09+02
4531	overalik biely s farebnymi zvieratkami, c.56	115	2.2000000000000002	f	-	0	45	1	2012-10-13 11:56:12+02
4532	bledoruzove tricko dlhy rukav TU, 4 roky	115	2.2000000000000002	f	-	0	46	1	2012-10-13 11:56:15+02
4570	Tepláky, ružové, HM, v. 68	116	1	f	-	0	34	2	2012-10-13 17:47:00+02
4534	zelene tricko dlhy rukav F&F, 9-12 m.	115	2.2000000000000002	f	-	0	48	1	2012-10-13 11:56:23+02
4535	tmavomodre tricko dlhy rukav F&F, 9-12 m.	115	2.2000000000000002	f	-	0	49	1	2012-10-13 11:56:27+02
4536	biela bavlnena ciapocka s farebnym kocikom, REPAL, c. 1	115	2.7999999999999998	f	-	0	50	1	2012-10-13 11:56:30+02
4525	kaki kozene topanky Tomar s bielou kozusinkou, c. 21	115	4	f	-	0	39	1	2012-10-13 11:56:38+02
4542	3 tričká s dlhým rukávom (ružové biele fialové) v.3-6mes.	116	2	f	-	0	6	2	2012-10-13 17:11:15+02
4526	talianske kozene topanocky, c. 20	115	2.2000000000000002	f	-	0	40	1	2012-10-13 11:56:49+02
4521	fialovy bodkovany frote overalik carters, 6 mesiacov	115	2.8999999999999999	f	-	0	35	2	2012-10-13 18:55:46+02
4568	Body, biele s malými medvedíkmi, v. 56	116	0.5	f	-	0	32	2	2012-10-13 16:25:44+02
4581	tehlovočervený pulóver so vzorom zajaca, veľ. 86	117	2	f	-	0	5	0	2012-10-11 22:57:26+02
4582	modré tričko s dlhým rukávom a vzorom S.Oliver, veľ. 116/122	117	2	f	-	0	6	0	2012-10-11 22:57:26+02
4583	ružový pletený sveter so zipsom, veľ. 4	117	3	f	-	0	7	0	2012-10-11 22:57:26+02
4584	krémový pletený sveter so zipsom, veľ. 8	117	3	f	-	0	8	0	2012-10-11 22:57:26+02
4585	zelená flísová tepláková súprava so vzorom hríbu, veľ. 110	117	5	f	-	0	9	0	2012-10-11 22:57:26+02
4586	pletená zimná ružová čiapka s brmbolcami, veľ. 5	117	2	f	-	0	10	0	2012-10-11 22:57:26+02
4587	pletená zimná ružovo-modrá čiapka s brmbolcami, veľ. 3	117	2	f	-	0	11	0	2012-10-11 22:57:27+02
4588	pletený modrý sveter so zipsom a vzorom macka, veľ. 86	117	2.5	f	-	0	12	0	2012-10-11 22:57:27+02
4589	ružový pletený pulóver so vzorom kvetov, veľ. 4 roky	117	3	f	-	0	13	0	2012-10-11 22:57:27+02
4590	oranžový flísový pulóver so vzorom dievčaťa, veľ. 3	117	2.5	f	-	0	14	0	2012-10-11 22:57:27+02
4591	oranžová flísová vesta so zipsom, kapucňou a vzorom dievčaťa, veľ. 3	117	2.5	f	-	0	15	0	2012-10-11 22:57:27+02
4592	žlto-modrá tepláková súprava, veľ. 74/80	117	4	f	-	0	16	0	2012-10-11 22:57:27+02
4593	ružovo-biely flísový pulóver so zipsom a vzorom tučniaka, veľ. 80	117	2	f	-	0	17	0	2012-10-11 22:57:27+02
4594	oranžový flísový pulóver so zipsom, veľ. 104	117	2	f	-	0	18	0	2012-10-11 22:57:27+02
4595	ružové tričko s dlhým rukávom a vzorom kvetov, veľ. 86	117	1.5	f	-	0	19	0	2012-10-11 22:57:27+02
4596	biele tričko s dlhým rukávom a vzorom dievčaťa a kvetov, veľ. 98	117	2	f	-	0	20	0	2012-10-11 22:57:27+02
4597	zelené tričko s dlhým rukávom a vzorom dievčaťa, veľ. 104	117	2	f	-	0	21	0	2012-10-11 22:57:27+02
4598	ružové tričko s dlhým rukávom a bielymi pásmi, veľ. 98-104	117	1.5	f	-	0	22	0	2012-10-11 22:57:27+02
4599	fialové tričko s dlhým rukávom a vzorom koňa, veľ. 122	117	2	f	-	0	23	0	2012-10-11 22:57:27+02
4600	ružové tričko s dlhým rukávom a vzorom mačky, veľ. 6	117	2	f	-	0	24	0	2012-10-11 22:57:27+02
4601	čierne tričko s dlhým rukávom a vzorom kvetov, veľ. 62	117	1.5	f	-	0	25	0	2012-10-11 22:57:27+02
4602	modré legíny, veľ. 7-8 rokov	117	3	f	-	0	26	0	2012-10-11 22:57:27+02
4603	oranžové flísové tepláky, veľ. 3	117	2	f	-	0	27	0	2012-10-11 22:57:27+02
4604	béžová flísová čiapka, veľ. 92-98	117	2	f	-	0	28	0	2012-10-11 22:57:27+02
4605	tmavozelené tepláky, veľ. 104	117	2	f	-	0	29	0	2012-10-11 22:57:27+02
4606	béžovo-ružová flísová súprava, veľ. 74	117	3.5	f	-	0	30	0	2012-10-11 22:57:27+02
4607	ružová súprava, veľ. 74	117	3.5	f	-	0	31	0	2012-10-11 22:57:27+02
4608	ružovo-fialová tepláková súprava, veľ.98	117	4	f	-	0	32	0	2012-10-11 22:57:27+02
4609	ružovo-modré tričko s dlhým rukávom, veľ. 98	117	2	f	-	0	33	0	2012-10-11 22:57:27+02
4610	hnedá tepláková súprava, veľ. 98	117	4	f	-	0	34	0	2012-10-11 22:57:27+02
4611	hnedá tepláková bunda so zipsom a kapucňou, veľ. 104-110	117	2.5	f	-	0	35	0	2012-10-11 22:57:27+02
4612	ružovo-modré pyžamo, veľ. 116	117	2	f	-	0	36	0	2012-10-11 22:57:27+02
4613	modro-ružová tepláková bunda so zipsom a kapucňou, veľ. 104-110	117	2.5	f	-	0	37	0	2012-10-11 22:57:27+02
4614	červený flísový sveter s kapucňou, veľ. 12-18 mes.	117	2	f	-	0	38	0	2012-10-11 22:57:27+02
4615	bledoružové pyžamo so vzorom slona, veľ. 104	117	2.5	f	-	0	39	0	2012-10-11 22:57:27+02
4616	zelený sveter so zipsom, veľ. 122	117	2.5	f	-	0	40	0	2012-10-11 22:57:27+02
4617	ružový flísový sveter, veľ. 80-86	117	2	f	-	0	41	0	2012-10-11 22:57:27+02
4618	fialové flísové tepláky, veľ. 18 mes.	117	1.5	f	-	0	42	0	2012-10-11 22:57:27+02
4619	krémové dupačky s mačkou a autom, veľ. 62	117	1	f	-	0	43	0	2012-10-11 22:57:27+02
4620	ružové dupačky s mackom, veľ. 62	117	1	f	-	0	44	0	2012-10-11 22:57:27+02
4621	ružové dupačky s mackami, veľ. 56-62	117	1	f	-	0	45	0	2012-10-11 22:57:27+02
4622	oranžovo-fialovo-biele dupačky, veľ. 74/80 	117	1.5	f	-	0	46	0	2012-10-11 22:57:27+02
4623	fialové tričko s dlhým rukávom, veľ. 116	117	2	f	-	0	47	0	2012-10-11 22:57:27+02
4624	ružovo-fialová tepláková súprava, veľ.104	117	4	f	-	0	48	0	2012-10-11 22:57:27+02
4625	ružová tepláková bunda, veľ. 128	117	2.5	f	-	0	49	0	2012-10-11 22:57:28+02
4626	béžovo-fialová flísová čiapka, veľ. 12 mes.	117	0.5	f	-	0	50	0	2012-10-11 22:57:28+02
4651	pulovrik s mackom v.68	118	1	f	-	0	25	1	2012-10-13 12:43:52+02
4649	ruzova bundicka na zips s kapucnou	118	2	f	-	0	23	1	2012-10-13 12:43:56+02
4630	biele saty na traky v.74 vpredu zajacik	118	2	f	-	0	4	2	2012-10-14 10:29:01+02
4647	zelena trigovica s kapucnou	118	0.80000000000000004	f	-	0	21	1	2012-10-13 12:44:00+02
4646	biely flausovy svetrik	118	2.5	f	-	0	20	1	2012-10-13 12:44:03+02
4643	biela ciapocka 	118	1	f	-	0	17	1	2012-10-13 12:44:38+02
4641	ruzova ciapocka 	118	0.5	f	-	0	15	1	2012-10-13 12:44:40+02
4638	cervena hackovana ciapka 	118	2	f	-	0	12	1	2012-10-13 12:45:06+02
4635	hnede capacky 	118	0.90000000000000002	f	-	0	9	1	2012-10-13 12:45:11+02
4636	biele capacky	118	0.69999999999999996	f	-	0	10	2	2012-10-13 18:07:58+02
4633	cervene tenisky capacky	118	0.5	f	-	0	7	1	2012-10-13 12:45:28+02
4653	červený pulovrik v.98/104 vpredu napis super wolf	118	2	f	-	0	27	2	2012-10-13 18:33:37+02
4632	ruzove nohavice v.68	118	1	f	-	0	6	1	2012-10-13 12:45:55+02
4631	bordovy pulovrik v.62	118	1	f	-	0	5	1	2012-10-13 12:45:57+02
4629	zelene saty vysivane v.3m. 	118	3	f	-	0	3	2	2012-10-14 10:29:01+02
4628	sedozelene saty H&M v. 74	118	1.5	f	-	0	2	1	2012-10-13 12:46:17+02
4627	sedobiele saty H&M v. 74	118	1.5	f	-	0	1	1	2012-10-13 12:46:19+02
4640	cierny pulovrik Damini 	118	1	f	-	0	14	1	2012-10-13 12:46:26+02
4648	bezova trigovica s kvetinkami 	118	1	f	-	0	22	2	2012-10-13 19:19:16+02
4644	pulovrik modry v. 0 – 3 m.	118	0.80000000000000004	f	-	0	18	1	2012-10-13 12:46:56+02
4642	pulovrik modro – biely 	118	0.80000000000000004	f	-	0	16	1	2012-10-13 12:47:10+02
4650	zelený pulóvrik v. 3-4 roky	118	3	f	-	0	24	1	2012-10-13 12:47:23+02
4645	pulovrik modry v. 0 – 3 m.	118	0.80000000000000004	f	-	0	19	1	2012-10-13 12:47:32+02
4639	ruzove capacky	118	0.5	f	-	0	13	2	2012-10-13 16:34:29+02
32	pančuchy ordové a ružové 2ks	1	0.5	f	-	0	31	1	2012-10-12 21:57:37+02
4662	bezova trigovica s kapucnou	118	1	f	-	0	36	1	2012-10-13 12:42:35+02
8	ružové tričko s falošnou košeľou 1,5 až 2 r	1	1.5	f	-	0	7	1	2012-10-12 22:50:01+02
4695	svetrik sivy, podsity, NEXT	119	8	f	-	0	19	2	2012-10-13 18:28:03+02
4706	teplakova suprava tmavo modra nova	119	5	f	-	0	30	1	2012-10-13 08:34:01+02
4710	2vesticky- kaki ,modra	119	2	f	-	0	34	1	2012-10-13 08:34:42+02
4723	vesticka ping pong	119	1	f	-	0	47	1	2012-10-13 08:34:49+02
4711	zelene nohavice  logg 80	119	3	f	-	0	35	1	2012-10-13 08:34:54+02
4697	teplaky hnede	119	2	f	-	0	21	1	2012-10-13 08:34:58+02
4656	modrý pulovrik v.98/104 vpredu napis super wolf	118	2	f	-	0	30	2	2012-10-13 18:10:52+02
4684	Svetrik pruhovany, mickey mouse s kapusnou	119	7	f	-	0	8	1	2012-10-13 08:35:17+02
4685	Vesticka modro biela tirolska	119	5	f	-	0	9	1	2012-10-13 08:35:35+02
4686	Teplakova suprava tmavo modra s pruhmi	119	4	f	-	0	10	1	2012-10-13 08:35:49+02
4660	biely pulovrik so srdieckami v.62	118	2	f	-	0	34	2	2012-10-13 17:06:36+02
4707	kabatik paddington	119	7	f	-	0	31	1	2012-10-13 08:36:40+02
4691	baranica	119	2	f	-	0	15	1	2012-10-13 08:36:45+02
4687	tenisky sivo oranzove-air 	119	4	f	-	0	11	1	2012-10-13 08:36:49+02
4701	kosela karovana, cerveno hneda	119	4	f	-	0	25	2	2012-10-13 17:24:17+02
4655	modry pulovrik drobne kvetinky	118	0.80000000000000004	f	-	0	29	2	2012-10-14 11:32:13+02
4688	tenisky modro biele	119	3	f	-	0	12	1	2012-10-13 08:37:02+02
4666	ruzova bundicka na zips s kapucnou v. 74	118	5	f	-	0	40	2	2012-10-14 10:51:29+02
4699	bunda menchestrova ladybird	119	5	f	-	0	23	2	2012-10-13 15:28:42+02
4676	dupacky biele s ruzovym lemom	118	1	f	-	0	50	2	2012-10-13 17:30:27+02
4700	bundicka zateplena, pieskova a mackom	119	6	f	-	0	24	1	2012-10-13 08:37:30+02
4709	mencestraky zeleno hnede, podsite 86	119	6	f	-	0	33	2	2012-10-13 18:36:12+02
4725	zelena teplakova bundicka	119	1	f	-	0	49	1	2012-10-13 08:37:51+02
4720	nohavice sive zateplene	119	4	f	-	0	44	1	2012-10-13 08:37:54+02
4719	nohavice modre karovane, zateplene	119	5	f	-	0	43	1	2012-10-13 08:38:00+02
4693	rifle podsite karovanou latkou	119	4	f	-	0	17	1	2012-10-13 08:38:06+02
4716	hnohavice na traky h&m 74	119	4	f	-	0	40	1	2012-10-13 08:38:12+02
4674	dupacky biele v.62	118	1	f	-	0	48	2	2012-10-13 18:40:10+02
4721	ciapka vzorovana	119	1.5	f	-	0	45	1	2012-10-13 08:38:59+02
4692	teplakova bunda tmavo modra best kids	119	5	f	-	0	16	1	2012-10-13 08:38:46+02
4722	ciapka s rohmi	119	1.5	f	-	0	46	1	2012-10-13 08:39:03+02
4705	3tricka s dlhym rukavom-zelene.bledozelene-sive	119	3	f	-	0	29	1	2012-10-13 08:39:31+02
4704	2tricky s dlhym rukavom 	119	3	f	-	0	28	1	2012-10-13 08:39:39+02
4703	svetrik bledomodry so zipsom 	119	3	f	-	0	27	1	2012-10-13 08:39:47+02
4702	svetrik pruhovany, modro biely	119	2	f	-	0	26	1	2012-10-13 08:39:52+02
4712	riflova bundicka	119	2	f	-	0	36	1	2012-10-13 08:39:56+02
4713	tricko cerveno modre-pruhovane	119	3	f	-	0	37	1	2012-10-13 08:40:00+02
4714	nohavice na traky h&m	119	4	f	-	0	38	1	2012-10-13 08:40:05+02
4715	zelena suprava coccodrillo	119	3	f	-	0	39	1	2012-10-13 08:40:11+02
4727	tmavomodré tričko, veľ. 3-6 m.	120	1.5	f	-	0	1	1	2012-10-13 09:45:48+02
4729	červené tričko s mimozemšťanom, veľ. 3-6 m.	120	1.5	f	-	0	3	1	2012-10-13 09:45:57+02
4728	béžové tričko s valcom, veľ. 68	120	1.5	f	-	0	2	1	2012-10-13 09:46:06+02
4730	biele tričko s nápisom "time for hugs", veľ. 9-12 m.	120	0.90000000000000002	f	-	0	4	1	2012-10-13 09:46:10+02
733	modry pulovrik vpredu opicka	16	1	f	-	0	44	1	2012-10-13 12:36:26+02
4689	papucky riflove                                                                   2eur	119	2	f	-	0	13	2	2012-10-13 17:17:43+02
4659	bledozlta trigovica vpredu ruzova vysivka 	118	1	f	-	0	33	1	2012-10-13 12:42:44+02
4658	ruzovy svetrik na uvazovanie	118	1	f	-	0	32	1	2012-10-13 12:42:46+02
4694	bunda ferrari cerveno modra	119	8	f	-	0	18	2	2012-10-13 18:28:04+02
4654	biely pulovrik vpredu napis I Love…….	118	1	f	-	0	28	1	2012-10-13 12:43:47+02
4670	body v.3/6 m. 2ks / biele so zvieratkom vpredu 2ks/	118	3	f	-	0	44	1	2012-10-13 12:44:16+02
4671	body v.3/6 m. 2ks / biele so zvieratkom vpredu, ruzove/	118	3	f	-	0	45	1	2012-10-13 12:44:19+02
4668	body v.3/6 m. 2ks / biele s ruzovymi bodkami, ruzove/	118	3	f	-	0	42	1	2012-10-13 12:44:25+02
4669	body v.3/6 m. 2ks / biele s napisom vpredu 2ks/	118	3	f	-	0	43	1	2012-10-13 12:44:32+02
4667	body v.3/6 m. 2ks / biele s ruzovymi bodkami, kvetinkove/	118	3	f	-	0	41	1	2012-10-13 12:45:51+02
4657	biely pulovrik s ruzovymi bodkami vpredu mickey mouse	118	0.80000000000000004	f	-	0	31	2	2012-10-13 18:19:20+02
4696	tricko pruhovane modro-zeleno- biele	119	1	f	-	0	20	2	2012-10-13 15:17:55+02
4661	tmavošedá trigovica v. 98	118	2	f	-	0	35	1	2012-10-13 12:47:15+02
4665	tmavomodré nohavice NEXT v. 3 r.	118	3	f	-	0	39	1	2012-10-13 12:47:26+02
4664	tmavomodré nohavice NEXT v. 3 r.	118	3	f	-	0	38	1	2012-10-13 12:47:42+02
4718	nohavice hnede gates	119	4	f	-	0	42	2	2012-10-13 17:53:55+02
4672	body v.74 	118	0.5	f	-	0	46	1	2012-10-13 12:48:07+02
4675	dupacky biele vpredu vrecka v. 62	118	1.5	f	-	0	49	1	2012-10-13 12:48:12+02
4708	tepla zavinovacky, zajko-siva	119	9	f	-	0	32	2	2012-10-14 10:25:05+02
4673	dupacky biele vpredu macka v.62	118	1	f	-	0	47	1	2012-10-13 12:48:22+02
4690	tenisky nike biele	119	2	f	-	0	14	2	2012-10-14 11:16:19+02
4663	pulovrik modry v. 0 – 3 m.	118	0.80000000000000004	f	-	0	37	2	2012-10-13 15:17:55+02
4733	modrošedé prúžkované tričko, veľ. 68	120	1.5	f	-	0	7	1	2012-10-13 09:46:22+02
4734	hnedá vesta s oranžovým tigrom, veľ. 74	120	1	f	-	0	8	1	2012-10-13 09:46:29+02
4778	RIFLE, MODRE, FF, OTEPLENE, VELKOST 3-4 ROKY	121	3.8999999999999999	f	-	0	2	2	2012-10-13 17:03:32+02
4791	TRIGOVICA MODRA S KAPUCOU, S CISLOM 23, VELKO 116-122	121	2.5	f	-	0	15	2	2012-10-13 16:45:05+02
4795	TRICKO, DL.RUKAV, MOTIV VLK, VELKOST 2-3 ROKY	121	1.2	f	-	0	19	2	2012-10-13 17:40:26+02
4738	oranžové tepláčiky sloník vpredu, veľ. 62	120	1.2	f	-	0	12	1	2012-10-13 09:46:55+02
4739	béžové rifle, veľ. 3-6 m.	120	1.8	f	-	0	13	1	2012-10-13 09:47:01+02
4740	šedé rifle, vyšúchaný vzhľad, podšité, veľ. 3-6 m.	120	3	f	-	0	14	1	2012-10-13 09:47:08+02
4741	modré zateplené pančušky s vláčikom, veľ. 56/62	120	0.5	f	-	0	15	1	2012-10-13 09:47:12+02
4742	súprava:zelené nohavice na traky, zelený kabátik s autíčkom, veľ. 62	120	2.5	f	-	0	16	1	2012-10-13 09:47:15+02
4743	modrý overal na spanie, veľ. 68	120	0.90000000000000002	f	-	0	17	1	2012-10-13 09:47:21+02
4744	set 3 pyžamiek: bodkované, modré, s dinosaurami, veľ. 3-6 m.	120	6	f	-	0	18	1	2012-10-13 09:47:29+02
4745	rifľová bunda modrá, veľ. 68	120	3	f	-	0	19	1	2012-10-13 09:47:39+02
4756	žltooražové dupačky, vpredu macko, veľ. 6-9 m.	120	1.2	f	-	0	30	2	2012-10-13 19:02:12+02
4747	zateplené prúžkované nohavice, veľ. 56	120	3	f	-	0	21	1	2012-10-13 09:47:55+02
4748	tmavomodré nohavice, vpredu sloník, veľ. 62	120	2	f	-	0	22	1	2012-10-13 09:48:33+02
4749	modrý prúžkovaný pulovrík, veľ. 56	120	3.5	f	-	0	23	1	2012-10-13 09:48:47+02
4750	hnedá kožušinková ušianka, veľ. 68	120	3	f	-	0	24	1	2012-10-13 09:48:56+02
4751	béžové kožušinkové rukavičky	120	1	f	-	0	25	1	2012-10-13 09:49:03+02
4752	bielomodré prúžkové body, veľ. 3-6 m.	120	1	f	-	0	26	1	2012-10-13 09:49:17+02
4754	biele body s modrými levíkmi, veľ. 3-6 m.	120	0.5	f	-	0	28	1	2012-10-13 09:49:26+02
4755	biela flísová mikinka, vpredu medvedík, veľ. 68	120	2	f	-	0	29	1	2012-10-13 09:49:31+02
4792	TRIGOVICA S KAPUCOU, MOTIV MCQUEEN, VELKOST 2-3 ROKY	121	3.5	f	-	0	16	2	2012-10-13 19:12:44+02
4757	bledomodrá čiapočka na šnúrky	120	0.5	f	-	0	31	1	2012-10-13 09:49:39+02
4758	zelená čiapočka-trpaslík	120	0.69999999999999996	f	-	0	32	1	2012-10-13 09:49:42+02
4759	jablkovo zelené body, veľ. 62	120	1.3	f	-	0	33	1	2012-10-13 09:49:45+02
4760	bielomodré body s medvedíkmi, veľ. 62	120	1	f	-	0	34	1	2012-10-13 09:49:56+02
4761	modré dupačky vpredu sloník veľ. 62	120	1.5	f	-	0	35	1	2012-10-13 09:50:00+02
4762	modrá flísová mikinka s autíčkom, veľ. 0-3 m.	120	2.5	f	-	0	36	1	2012-10-13 09:50:06+02
4763	zelenošedá flísová mikinka so psíkom, veľ. 62	120	3	f	-	0	37	1	2012-10-13 09:50:11+02
4764	žlté dupačky s medvedíkmi, veľ. 56	120	1.8	f	-	0	38	1	2012-10-13 09:50:14+02
4766	biele dupačky s mackom, veľ. 56	120	1.8	f	-	0	40	1	2012-10-13 09:50:25+02
4767	červený vianočný overal so snehuliakom, veľ. 68	120	2	f	-	0	41	1	2012-10-13 09:50:30+02
4736	biele tepláčiky, veľ. 62	120	1	f	-	0	10	2	2012-10-13 16:43:26+02
4769	biele body s farebnými prúžkami, veľ. 68	120	1	f	-	0	43	1	2012-10-13 09:50:40+02
4770	biele body s hviezdičkami, veľ. 68	120	1	f	-	0	44	1	2012-10-13 09:50:46+02
4771	biele body s hnedými prúžkami, veľ. 56	120	1	f	-	0	45	1	2012-10-13 09:50:49+02
4772	hnedé body so žirafou, veľ. 56	120	1	f	-	0	46	1	2012-10-13 09:50:50+02
4774	tmavomodrý kabátik next 9-12 m.	120	3	f	-	0	48	1	2012-10-13 09:51:01+02
4775	smotanovožltý kabátik veľ. 56-62	120	1	f	-	0	49	1	2012-10-13 09:51:08+02
4776	žltý overal na spanie s medvedíkmi, veľ. 68	120	1.5	f	-	0	50	1	2012-10-13 09:51:11+02
4785	TEPLAKY DIEVCENSKE, ZELENE, VELKOST 128	121	0.90000000000000002	f	-	0	9	1	2012-10-13 11:47:45+02
4786	VESTA ZELENA S KAPUCOU, MOTIV AUTO, VELKOST 68	121	5.5	f	-	0	10	1	2012-10-13 11:47:48+02
4787	BUNDA RIFLOVA, VELKOST 3-6 MESIACOV	121	4	f	-	0	11	1	2012-10-13 11:47:53+02
4788	PULOVER ZLTY, NAPIS BASEBALL, VELKOST 3 MESIACE	121	3.1000000000000001	f	-	0	12	1	2012-10-13 11:47:56+02
4789	ROLAK MODRY, MOTIV KARO, VELKOST L	121	2.7000000000000002	f	-	0	13	1	2012-10-13 11:47:59+02
4796	TRICKO, DL.RUKAV, MOTIV MCQUEEN, VELKOST 2-3 ROKY	121	1.3	f	-	0	20	2	2012-10-13 18:35:20+02
4735	farebná károvaná košeľa, veľ. 3-6 m.	120	1.2	f	-	0	9	2	2012-10-13 17:00:09+02
4765	zelený roláčik s lietadlom, veľ. 68	120	2	f	-	0	39	2	2012-10-14 13:00:39+02
4793	TRIGOVICA SEDA, ADIDAS, VELKOST 92	121	1.7	f	-	0	17	1	2012-10-13 11:48:13+02
4794	TRICKO, DL.RUKAV, MOTIV AUTO, VELKOST 3-4 ROKY	121	1.2	f	-	0	18	1	2012-10-13 11:48:22+02
4790	TRIGOVICA CERVENA S KAPUCOU,MOTIV RIFLE, 1-1,5 ROKOV	121	3.5	f	-	0	14	2	2012-10-13 17:54:58+02
4746	set 2 tepláčiky: tmavomodré, šedé, veľ. 3-6 m.	120	4	f	-	0	20	2	2012-10-13 18:57:57+02
4784	TEPLAKY SEDE, VELKOST 2-3 ROKY	121	1.2	f	-	0	8	2	2012-10-13 16:20:44+02
4797	TRICKO, DL.RUKAV, MOTIV DISNEY, VELKOST 3-4 ROKY	121	1.2	f	-	0	21	2	2012-10-13 15:22:10+02
4737	zelené prúžkované chlpaté nohavice, veľ. 68	120	1.8	f	-	0	11	2	2012-10-13 17:10:51+02
4800	TEPLAKOVA SUPRAVA, S CISLOM 86, VELKOST 2-3 ROKY	121	1.2	f	-	0	24	1	2012-10-13 11:48:58+02
4801	TRIGOVICA FLAUSOVA, CERVENA, VELKOST 86	121	1.2	f	-	0	25	1	2012-10-13 11:49:04+02
4802	BUNDA ZLTA, MOTIV VTAK, VELKOST 2 ROKY	121	3.7999999999999998	f	-	0	26	1	2012-10-13 11:49:07+02
4781	RIFLE, MODRE, COMPLICES, VELKOST 3 ROKY	121	2.1000000000000001	f	-	0	5	1	2012-10-13 11:51:35+02
4782	RIFLE, MODRE, LI-S JEANS, VELKOST 98	121	3.8999999999999999	f	-	0	6	1	2012-10-13 11:51:39+02
4777	RIFLE, MODRE, CHEROKEE, VELKOST 1-1,5 ROK	121	3.8999999999999999	f	-	0	1	1	2012-10-13 11:51:45+02
4799	TRICKO, DL.RUKAV, MOTIV OPICKA, VELKOST 1,5-2 ROKY	121	1.2	f	-	0	23	2	2012-10-13 17:09:37+02
4779	RIFLE, MODRE, TOPOLINO, VELKOST 98, OTEPLENE	121	3.8999999999999999	f	-	0	3	1	2012-10-13 11:51:55+02
4780	RIFLE, MODRE, HEIGHT, VELKOST 98-108	121	3.8999999999999999	f	-	0	4	1	2012-10-13 11:51:58+02
4798	TRICKO, DL.RUKAV, MOTIV OPICKA S AUTOM,VELKOST 1,5-2ROK	121	1.3	f	-	0	22	2	2012-10-13 15:15:37+02
4768	modrá ušianka kožušinková, veľ.56-62	120	2	f	-	0	42	2	2012-10-13 16:25:44+02
4783	TEPLAKY SEDE, MOTIV MCQUEEN, VELKOST 2-3 ROKY	121	2.2000000000000002	f	-	0	7	2	2012-10-13 14:34:31+02
4805	ZUPAN FAREBNY, VELKOST 104	121	2.2000000000000002	f	-	0	29	1	2012-10-13 11:47:15+02
4803	PYZAMO CHLAPCENSKE S PASIKMI, VELKOST 116	121	1.8999999999999999	f	-	0	27	1	2012-10-13 11:47:39+02
4806	ZUPAN CIERNY, VELKOST 140	121	3.2000000000000002	f	-	0	30	1	2012-10-13 11:47:33+02
4807	ROLAK ZELENY, MOTIV-ZVIERATKA, VELKOST 140	121	2.2000000000000002	f	-	0	31	1	2012-10-13 11:49:21+02
4809	TRICKO, DL.RUKAV, CERVENE S MOTIVOM, VELKOST 9-10 ROKO	121	1.2	f	-	0	33	2	2012-10-13 16:20:19+02
4830	ružový pulóver s mackom, vel.6	122	2.8999999999999999	f	-	0	4	2	2012-10-13 16:30:23+02
4810	TRICKO, DL.RUKAV, CERVENE NA 3 GOMBIKY, VELKOST 126	121	1.2	f	-	0	34	1	2012-10-13 11:49:35+02
4811	TRIGOVICA S KAPUCOU, ZELENA, VELKOST XS	121	1.8999999999999999	f	-	0	35	1	2012-10-13 11:49:38+02
4812	TRICKO, DL.RUKAV, S HVIEZDOU, VELKOST 140	121	3.2999999999999998	f	-	0	36	1	2012-10-13 11:49:44+02
4813	TRIGOVICA HNEDA, S CISLOM 69, VELKOST S	121	4	f	-	0	37	1	2012-10-13 11:49:52+02
4815	NOHAVICE DIEVCENSKE, SPORTOVE, FIALOVE, VELKOST 10 R	121	2.6000000000000001	f	-	0	39	1	2012-10-13 11:50:06+02
4816	POLOKOSELA, VZOR KAROVANE, VELKOST 7 ROKOV                               1,5	121	1.5	f	-	0	40	1	2012-10-13 11:50:12+02
4817	FLANELOVA KOSELA, VZOR KAROVANE, VELKOST 5 ROKOV	121	2.5	f	-	0	41	1	2012-10-13 11:50:13+02
4818	TRIGOVICA MODRA SO SPIDER-MAN, VELKOST 10 ROKOV	121	3.7000000000000002	f	-	0	42	1	2012-10-13 11:50:18+02
4819	ROLAK, VLNA, ZELENEJ FARBY, VELKOST 4-5 ROKOV	121	2.5	f	-	0	43	1	2012-10-13 11:50:29+02
4871	hnedé menčestráky na traky, podšité, v.24mes.	123	4	f	-	0	12	2	2012-10-13 17:54:20+02
4851	nohavice mečestrové  maskáče, zateplené, vel.6	122	0.5	f	-	0	25	2	2012-10-14 09:21:26+02
4822	SUPRAVA-SAL A CAPICA, MODRA S MACKOM	121	2.2000000000000002	f	-	0	46	1	2012-10-13 11:50:42+02
4825	HNIEZDO NA POSTIELKU SO ZVIERATKAM	121	4.5	f	-	0	49	1	2012-10-13 11:51:01+02
4827	bordové menčestráky vel. 116	122	3.5	f	-	0	1	2	2012-10-14 12:49:03+02
4824	VLOZKA DO ZAVINOVACKY, BIELA, NOVA	121	2.2000000000000002	f	-	0	48	1	2012-10-13 11:51:12+02
4826	CIERNE LAKOVE CHLAPCENSKE TOPANKY,VELKOST 28	121	3.5	f	-	0	50	1	2012-10-13 11:52:13+02
4844	rolák sivý úpletový	122	0.5	f	-	0	18	2	2012-10-13 15:44:00+02
4832	fialová bunda s guličkami JUST PLAY, vel 128/134	122	4	f	-	0	6	2	2012-10-13 15:49:21+02
4843	tričko dlhý rukáv modro oranžové, 128	122	0.5	f	-	0	17	1	2012-10-13 12:13:51+02
4842	šál pásikavý oranžovo-červeno modrý	122	0.29999999999999999	f	-	0	16	1	2012-10-13 12:13:54+02
4841	šál biely	122	0.20000000000000001	f	-	0	15	1	2012-10-13 12:13:58+02
4840	šál hnedý dlhýýý	122	0.5	f	-	0	14	1	2012-10-13 12:14:12+02
4837	tepláčky bledomodré LADY ANN	122	1.2	f	-	0	11	1	2012-10-13 12:14:15+02
4836	tepláčky béžové na traky s mackom	122	1	f	-	0	10	1	2012-10-13 12:14:19+02
4863	detska tmavomodrá bunda s kapucou a vláčikom,MARKSSPENCER,2r.	123	7	f	-	0	4	2	2012-10-13 17:08:51+02
4834	čiapočka SEEFORT -tmavomodrá s pásikmi	122	1	f	-	0	8	1	2012-10-13 12:14:24+02
4867	zelená šušťaková bundička zn.CHEROKEE, v. 18-24mes.	123	1.5	f	-	0	8	2	2012-10-13 16:36:03+02
4846	bunda modrá	122	1.5	f	-	0	20	2	2012-10-14 11:06:18+02
4828	fialový pulóver YES KIDS	122	2.8999999999999999	f	-	0	2	1	2012-10-13 12:14:41+02
4861	kožuch hnedý s výšivkami,bielou kožušinkou,9 -10r.	123	10	f	-	0	2	2	2012-10-14 13:46:01+02
4859	tehotenská sukňa, krátka, modrá	122	1	f	-	0	33	1	2012-10-13 12:14:52+02
4873	hnedá tepláková súprava zn.HM, v.86 s tigrom	123	3	f	-	0	14	2	2012-10-13 19:12:44+02
4857	roláčik pásikový	122	1	f	-	0	31	1	2012-10-13 12:14:57+02
4855	nohavice kárované, KATVAL, 116	122	0.5	f	-	0	29	1	2012-10-13 12:15:01+02
4854	tričko, dlhý rukáv, zeleno-modré, s límčekom	122	0.59999999999999998	f	-	0	28	1	2012-10-13 12:15:05+02
4858	roláčik oranžový, 98	122	0.5	f	-	0	32	2	2012-10-13 18:06:11+02
4852	menčestráky na traky, tm.modré, KIDS, vel110	122	1	f	-	0	26	1	2012-10-13 12:15:14+02
4856	lyžiarsky overal červeno-šedý, 104	122	4	f	-	0	30	2	2012-10-14 09:23:58+02
4849	bunda na zips šedá s potlačou CARS, 122	122	1	f	-	0	23	1	2012-10-13 12:15:50+02
4848	súprava šál+čiapka štrikovaná, zeleno béžová	122	0.69999999999999996	f	-	0	22	1	2012-10-13 12:15:53+02
4820	VESTA MODRA, ZATEPLENA NA ZIPS, VELKOST 3 ROKY	121	2.1000000000000001	f	-	0	44	2	2012-10-13 17:21:05+02
4850	topánky oranžové, 21	122	1	f	-	0	24	1	2012-10-13 12:17:05+02
4831	zimná bunda fialová YOUYOU vel.6	122	6.9000000000000004	f	-	0	5	1	2012-10-13 12:17:20+02
4808	TRIGOVICA ADIDAS, SEDA S KAPUCOU, VELKOST 128	121	4.9000000000000004	f	-	0	32	2	2012-10-13 16:09:44+02
4829	ružový sveter na zips	122	2.5	f	-	0	3	2	2012-10-14 09:59:14+02
4839	topánky modro-zelené, veľ21	122	2	f	-	0	13	1	2012-10-13 12:17:47+02
4865	hnedý svetrík podšitý kožušinkou hnedou	123	2	f	-	0	6	2	2012-10-14 11:28:41+02
4838	topánočky -bielo.ružové so psíkom, veľ.13	122	1	f	-	0	12	1	2012-10-13 12:17:57+02
4875	hnedé menčestráky zn.ALPHABET, s vačkami	123	2	f	-	0	16	1	2012-10-13 12:58:01+02
4874	hnedé zateplené menčestráky zn.WENICE, v.146	123	3	f	-	0	15	1	2012-10-13 12:58:04+02
4821	CAPICA, ZELENO-BIELO-ORANZOVEJ FARBY, SO SILTOM	121	1.8999999999999999	f	-	0	45	2	2012-10-13 19:32:16+02
4864	zelená bunda s kapucou zn.SUCCESS	123	5	f	-	0	5	2	2012-10-13 16:39:58+02
4853	svetrík hnedý štrikovaný, 12-18m	122	1	f	-	0	27	2	2012-10-13 17:54:58+02
4870	zelenohnedé nohavice NEXT, v.1,5-2r.	123	5	f	-	0	11	1	2012-10-13 12:58:26+02
4869	zelené menčestráky zn.LADYBIRD, v.12-18mes.	123	2	f	-	0	10	1	2012-10-13 12:58:31+02
4872	flísová bundička s kapucou,prúžková, 12-18mes.	123	2	f	-	0	13	2	2012-10-13 16:36:03+02
4860	lyžiarske nohavice červene zn.RUCANOR,v. 140	123	15	f	-	0	1	2	2012-10-13 16:57:51+02
4847	bunda teenage hnedá s ružovým nápisom OAKLEY	122	1	f	-	0	21	2	2012-10-13 17:17:43+02
4823	DEKA DO KOCARA, MODRO BIELA SO ZIRAFOU	121	3.5	f	-	0	47	2	2012-10-14 11:53:36+02
4835	tepláčky zelené so psíkmi	122	1.2	f	-	0	9	2	2012-10-13 17:05:32+02
4866	hnedý menčestrový kabátik s kapucou zn.DYSNEY, 9-12mes.	123	2	f	-	0	7	2	2012-10-13 17:12:25+02
4862	čierna bunda s kapucou,zn.MARKSSPENCER, 11 -12r.	123	10	f	-	0	3	1	2012-10-13 12:59:07+02
4845	šál červený fleesový	122	0.29999999999999999	f	-	0	19	2	2012-10-13 15:20:36+02
4941	Modré šušťačky na gumu vpedu aj vzadu vrecká zn.h&m veľ116	125	1.5	f	-	0	25	2	2012-10-13 16:07:39+02
4926	Rifle roll-up modré s farebnou výšivkou na vreckách zn. Next veľ. 10R	125	5	f	-	0	10	1	2012-10-13 10:21:25+02
4933	Župan froté ružový s opaskom vpredu vyšitý mackovia zn. George veľ.4-5R	125	3.5	f	-	0	17	2	2012-10-13 17:45:45+02
4894	svetrik s kapucou, modrošedý prúžok zn.HM, v.86	123	1.5	f	-	0	35	2	2012-10-13 15:28:42+02
4919	Chlapčenské sako hnedé zn L.O.O.G.veľ.92,vzadu vyšitá 2	125	3	f	-	0	3	2	2012-10-13 15:28:42+02
4909	pyzamko ruzove dupacky	124	2	f	-	0	13	2	2012-10-14 10:36:19+02
4927	Menžestráky do gumy tyrkisové,vzadu nápis track zn.Me too veľ.2R	125	3	f	-	0	11	1	2012-10-13 10:22:01+02
4886	mikina modrý prúžok zn.MARKSPENCER, 12-18mes.	123	0.5	f	-	0	27	2	2012-10-13 17:49:24+02
4920	Košeľa chlapčenská modrá prúžkovaná zn Kids by lindex veľ.86	125	2	f	-	0	4	2	2012-10-13 15:28:42+02
4924	Čiapka modrá s brmbolcom na zaväzovanie vpredu výšivka zn.Iltom,veľ42	125	1.2	f	-	0	8	1	2012-10-13 10:22:30+02
4931	Klobúk riflový modrý podšitý vpredu vtáčiky zn.Next 	125	4	f	-	0	15	1	2012-10-13 10:22:33+02
4935	Rolák ružový vpredu bicykle zn.zuppa	125	1.5	f	-	0	19	1	2012-10-13 10:23:23+02
4936	Rolák ružový zn. Adams veľ.7R	125	1.2	f	-	0	20	1	2012-10-13 10:23:25+02
4922	Mikina s kapucňou zap.na 2 gom.pásová šedozelená vpredu Mickey	125	1	f	-	0	6	2	2012-10-13 17:47:48+02
4938	Blúzka modrá na zaväz.okolo krku vpredu výšivkazn.Campus veľ.116	125	1	f	-	0	22	1	2012-10-13 10:23:40+02
4934	Sveter dlhý modrý so strapcami zn. Miss m	125	3.5	f	-	0	18	1	2012-10-13 10:23:47+02
4891	rolák ružovobiele prúžky zn.GAP, 12r.	123	1.5	f	-	0	32	2	2012-10-13 16:29:43+02
4895	čiapka pletená ružovobiela podšitá bielym flisom, s vrkočmi	123	1.5	f	-	0	36	2	2012-10-13 15:42:31+02
4929	Tenisky so šnúrkami na boku zips ružové kotníkové veľ. 29	125	4	f	-	0	13	1	2012-10-13 10:25:09+02
4930	Tenisky na lepenie modroružové veľ.29	125	2.5	f	-	0	14	1	2012-10-13 10:25:12+02
4943	Čiapka tyrkisová červený lem vpredu mickey mouse zn.Disney veľ.54cm	125	3	f	-	0	27	1	2012-10-13 10:25:27+02
4939	Rifle modré vpredu aj vzadu vvýšivka zn.adams veľ.7R	125	5	f	-	0	23	1	2012-10-13 10:25:34+02
4940	Sveter na gomíky farebný pásový zn cherokee veľ.4-5R	125	1.5	f	-	0	24	1	2012-10-13 10:25:39+02
4932	Mikina s kapucňou pásová modrobiela ružový nápis zn.Dopodopo veľ110	125	4	f	-	0	16	2	2012-10-13 16:20:44+02
4899	ruzova suprava / teplaky a bundicka na zips s kapucnou	124	4	f	-	0	3	1	2012-10-13 12:32:52+02
4902	biele flausove papucky	124	0.59999999999999998	f	-	0	6	1	2012-10-13 12:32:56+02
4881	čierna plyšová mikina s kapucou zn.MISS EVIE, 12-13r.	123	2	f	-	0	22	2	2012-10-14 12:16:42+02
4925	Mikina biela flísová s kapucňou lem kožušinka zn.Naf Naf veľ.2-3R	125	1.5	f	-	0	9	2	2012-10-13 17:36:30+02
4897	pleteny hnedy pulovrik v. 3/4 r.	124	3	f	-	0	1	1	2012-10-13 12:33:09+02
4901	riflove gate na traky	124	1	f	-	0	5	1	2012-10-13 12:33:12+02
4900	modre teplaciky 	124	0.69999999999999996	f	-	0	4	1	2012-10-13 12:33:16+02
4898	pleteny bezovy sveter vpredu na zips	124	3	f	-	0	2	2	2012-10-14 11:28:57+02
4883	tričko s kapucou ružovozelené zn.SUPERGIRL, 10r.	123	1.5	f	-	0	24	2	2012-10-13 18:31:21+02
4907	pyzamko kvetinkove dupacky	124	2	f	-	0	11	1	2012-10-13 12:33:24+02
4906	pyzamko dupacky pasikave oranzovo/ruzove	124	1	f	-	0	10	1	2012-10-13 12:33:27+02
4916	detske topanky zimne s kozusinkou v.22	124	4	f	-	0	20	1	2012-10-13 12:33:35+02
4913	bledoruzove pancusky v.62/68	124	1	f	-	0	17	1	2012-10-13 12:33:48+02
4914	fialkove pancusky v.62/68	124	1	f	-	0	18	1	2012-10-13 12:33:49+02
4912	biele pancusky s dodkami 	124	1	f	-	0	16	1	2012-10-13 12:33:55+02
4905	biele pyzamko dupacky v. 62 cm	124	1	f	-	0	9	1	2012-10-13 12:33:58+02
4904	biele pyzamko dupacky	124	1	f	-	0	8	1	2012-10-13 12:34:06+02
4911	biele dupacky s bledomodrymi obrazkami	124	1	f	-	0	15	1	2012-10-13 12:34:11+02
4910	biele dupacky 	124	2	f	-	0	14	1	2012-10-13 12:34:22+02
4915	dievcenske rifle v.8	124	3.5	f	-	0	19	1	2012-10-13 12:34:26+02
4877	hnedé menčestráky podšité, 9-12mes., zn.GEORGE	123	2	f	-	0	18	2	2012-10-13 17:09:37+02
4937	Sukňa ružová zamatová s trblietkami dolu volán	125	1	f	-	0	21	2	2012-10-13 16:06:44+02
4884	pulover modrý prúžkový zn.CHEROKEE, v.1,5-2r.	123	1	f	-	0	25	2	2012-10-13 15:28:42+02
4903	bledomodre rukavicky na snurke	124	0.59999999999999998	f	-	0	7	2	2012-10-13 17:30:15+02
4908	pyzamko s ruzovymi bodkami dupacky	124	2	f	-	0	12	2	2012-10-13 18:03:40+02
4889	ružový rolák s flitrami zn.CQ, 10-11r.	123	1.5	f	-	0	30	2	2012-10-13 16:57:51+02
4896	súprava: čiapka,šál,rukavice,šedoružové s flitrami zn.CHEROKEE	123	1.5	f	-	0	37	2	2012-10-13 16:58:47+02
4888	nohavice zateplené hnedé, ružové prúžky zn.ALPINEPRO,v.152-158	123	8	f	-	0	29	1	2012-10-13 12:56:52+02
4887	bundička s kapucou, vačkami, farebná, v.92	123	1.5	f	-	0	28	1	2012-10-13 12:56:55+02
4892	mikina tm.modrá s kapucou zn. PALOMINO	123	1.5	f	-	0	33	2	2012-10-13 17:49:24+02
4885	pulover prúžkový modročervený zn.HM, 9-12mes.	123	1	f	-	0	26	1	2012-10-13 12:57:04+02
4928	Topánky kotníkové hnedé na šnurovanie zn. George veľ.23	125	8	f	-	0	12	2	2012-10-13 15:28:42+02
4882	mikina biela s oranžovými prúžkami zn.MARKSPENCER, 9-10r.	123	2	f	-	0	23	2	2012-10-13 19:09:27+02
4921	Sveter modrý podšitý s kapucňou zn. George veľ.3-6M	125	2	f	-	0	5	2	2012-10-14 10:16:26+02
4923	Nohavice bledé do gumy vpredu 2 vrecká, vyšitá vlajka veľ.3-6M	125	1.5	f	-	0	7	2	2012-10-14 12:58:26+02
4880	sveter s kapucou a kožušinkou zn.CRASHONE, v.146-152	123	3	f	-	0	21	1	2012-10-13 12:57:42+02
4879	staroružové noh. S vačkami zn.PLAYFUL, v.140	123	3	f	-	0	20	1	2012-10-13 12:57:46+02
4878	tmavomodré menčestráky zn.NEXT LIME, 9-10r.	123	2.5	f	-	0	19	1	2012-10-13 12:57:50+02
4893	mikina modrozelena s kap.,prúžková zn.CHEROKEE, 2r.	123	0.5	f	-	0	34	2	2012-10-13 17:28:01+02
4876	zelené menčestráky na traky, v.18mes.	123	2	f	-	0	17	1	2012-10-13 12:57:59+02
4942	Čiapka pásová modrobiela s malým šiltom veľ.51-52 cm	125	1.5	f	-	0	26	2	2012-10-13 15:23:25+02
5156	Tričko bielo/modro šedé CHEEKY	131	0.5	f	-	0	22	2	2012-10-13 16:49:36+02
4969	Biele tepláky s vačkom na stehne na jednej nohe a na 2. nápis 	126	0.69999999999999996	f	-	0	16	2	2012-10-13 18:39:59+02
4944	Ušianka šedá vzadu výšivka zn.Next veľ.3-5R	125	6	f	-	0	28	1	2012-10-13 10:22:46+02
4953	Nohavice šedé po bokoch modrý pás,vzadu vrecká zn. Next,veľ.3R	125	2.5	f	-	0	37	1	2012-10-13 10:23:01+02
4950	Šušťačky modré po bokoch biely pás,dolu  zips,vzadu vrecká zn Nike 	125	5	f	-	0	34	1	2012-10-13 10:23:15+02
4946	Bunda šušť.modrá na zips s kapucňou zn Marks spencer motív vláčik Tomáš	125	7	f	-	0	30	1	2012-10-13 10:24:03+02
4945	Bunda riflová zateplená na zips s odnímateľnou kapucňou zn Annil 	125	9	f	-	0	29	1	2012-10-13 10:24:15+02
4949	Oteplovaky čierne na traky dolu a po bokoch reflex prvky zn.h§m veľ.92	125	11.699999999999999	f	-	0	33	1	2012-10-13 10:24:29+02
4956	Hnedá trigovica s bicyklami	126	1.2	f	-	0	3	2	2012-10-14 11:06:18+02
4973	Tenké modré tepláky s modrými sieťkovanými pásmi na boku	126	0.5	f	-	0	20	2	2012-10-13 16:09:44+02
5159	Topánky zimné tmavo hnedé Dolomite	131	6	f	-	0	25	1	2012-10-13 10:37:11+02
4967	Tenké modré tepláky na uväzovanie vpredu	126	0.90000000000000002	f	-	0	14	2	2012-10-14 10:03:00+02
4952	Rifle bledomodré dolu du gumy,vpredu a vzadu hviezdičky zn.detroit	125	2.5	f	-	0	36	2	2012-10-13 16:30:23+02
5154	Čiapka modrá, vnútro bledé	131	1	f	-	0	20	1	2012-10-13 10:40:31+02
5155	Tričko biele PALOMINO	131	1	f	-	0	21	1	2012-10-13 10:40:35+02
4983	Zelený sveter hrubý pri krku na zips, na spodu nášivka 	126	2.5	f	-	0	30	2	2012-10-13 17:26:55+02
5157	Tričko Kakhi zelené TOP RACER	131	0.5	f	-	0	23	1	2012-10-13 10:40:45+02
5174	modra zimna kombineza veľ.86	132	5.5	f	-	0	14	1	2012-10-13 11:34:04+02
5166	modre rifle na traky na 24mesiacov	132	2.5	f	-	0	6	2	2012-10-13 18:15:42+02
5170	siva riflova hruba bunda s pasikatym vnutrom veľ86	132	3	f	-	0	10	1	2012-10-13 11:34:20+02
5171	hnedy sveter s mackom marks and spencer	132	1.5	f	-	0	11	1	2012-10-13 11:34:24+02
5172	tmavomodra frote bundička s kapucou veľ 68	132	2.5	f	-	0	12	1	2012-10-13 11:34:28+02
5153	Nohavice menčestrové šedé	131	1	f	-	0	19	2	2012-10-13 16:29:43+02
5163	hnedy sveter melirovany na 3 roky	132	2	f	-	0	3	1	2012-10-13 11:34:37+02
5165	rifle  modre veľ. 1,5 - 2 roky	132	2	f	-	0	5	1	2012-10-13 11:34:52+02
4971	Tmavomodré tričko s dlhým rukávom a nápisom bielym 24	126	2.1000000000000001	f	-	0	18	2	2012-10-13 18:34:08+02
5167	čierne riflove gate na traky	132	3	f	-	0	7	1	2012-10-13 11:35:01+02
5168	oranž.červena bundička veľ62	132	2	f	-	0	8	1	2012-10-13 11:35:05+02
5162	mantinel k veľkej posteli zelený s aplikaciou vlačika	132	11	f	-	0	2	1	2012-10-13 11:35:25+02
5175	vankuš na kojenie modry s bielymi bodkami	132	8	f	-	0	15	1	2012-10-13 11:36:17+02
5173	čierno biela karovana zimna bunda xoxoxo	132	4	f	-	0	13	1	2012-10-13 11:36:59+02
4987	Hnedé semišové zimné topánky s čiernou kožušinou na 3 lepky veľ. 33	126	4.2000000000000002	f	-	0	34	1	2012-10-13 12:41:24+02
4986	Hnedé semišové zimné topánky s čiernou kožušinou na 3 lepky veľ. 33	126	4.2000000000000002	f	-	0	33	1	2012-10-13 12:41:26+02
4962	Maskáčové nohavice	126	4	f	-	0	9	1	2012-10-13 12:42:39+02
4957	Modrá trigovica s kapucou /CHININO/	126	1.3	f	-	0	4	1	2012-10-13 12:44:37+02
4954	Červená trigovica s drakom 	126	1.2	f	-	0	1	1	2012-10-13 12:42:41+02
4963	Rifle modré 	126	4.5	f	-	0	10	2	2012-10-13 18:39:59+02
4980	Šedý sveter s kapucou na zips s vačkom v predu	126	3	f	-	0	27	2	2012-10-13 16:24:03+02
4964	Modré tričko s nápisom KIDS & PLAYTIME 72     	126	2.1000000000000001	f	-	0	11	2	2012-10-13 16:13:10+02
4974	Zelené tričko so štvorcom s autom s nápisom TOP RACER	126	2.1000000000000001	f	-	0	21	1	2012-10-13 12:43:12+02
4975	Zelené tričko so štvorcom s autom s nápisom TOP RACER	126	2.1000000000000001	f	-	0	22	1	2012-10-13 12:43:14+02
4968	Tmavomodré tričko s bielym nápisom 1976	126	2.5	f	-	0	15	2	2012-10-13 16:20:19+02
4970	Šedé hrubé tepláky s dvomi vačkami na predu	126	1.1000000000000001	f	-	0	17	2	2012-10-13 16:24:03+02
4966	Tmavomodré tričko s bielym nápisom 1976	126	2.5	f	-	0	13	1	2012-10-13 12:43:26+02
4972	Tmavomodré tričko s dlhým rukávom a nápisom bielym 24	126	2.1000000000000001	f	-	0	19	2	2012-10-13 16:20:19+02
4965	Žlté tričko transformers s postavičkami transformers	126	1.5	f	-	0	12	2	2012-10-13 16:24:03+02
4948	Šál modrý pásový nášivka Mickey	125	0.80000000000000004	f	-	0	32	2	2012-10-13 18:36:12+02
4955	Červená trigovica s drakom 	126	1.2	f	-	0	2	1	2012-10-13 12:43:44+02
4958	 Červená trigovica s kapucou /NO CHANCE/	126	1.5	f	-	0	5	1	2012-10-13 12:43:47+02
4988	Zelené gumáky so žltou podrážkou 	126	2.1000000000000001	f	-	0	35	1	2012-10-13 12:44:24+02
4981	Šedý sveter s kapucou na zips s vačkom v predu	126	3	f	-	0	28	1	2012-10-13 12:44:41+02
5164	modra bundička s mackom a ušami veľ.62	132	4	f	-	0	4	2	2012-10-13 16:25:44+02
4961	Hnedé menžestráky	126	2	f	-	0	8	1	2012-10-13 12:44:58+02
5158	Snehule čierne	131	3	f	-	0	24	2	2012-10-13 19:10:34+02
4976	Riflová bunda so šedou kapucou	126	5.9000000000000004	f	-	0	23	1	2012-10-13 12:45:10+02
4982	Zelený sveter hrubý pri krku na zips, na spodu nášivka 	126	2.8999999999999999	f	-	0	29	1	2012-10-13 12:45:19+02
5161	ružové snehule quachua veľ 20-21	132	6	f	-	0	1	2	2012-10-13 17:31:41+02
4985	Bielo-modrý sveter na zips s dvomi vačkami na predu	126	2.1000000000000001	f	-	0	32	1	2012-10-13 12:45:27+02
4984	Modrá trigovica s kapucou na zips, vo vnútri bledomodrá	126	1.1000000000000001	f	-	0	31	1	2012-10-13 12:45:31+02
4977	Riflová bunda so šedou kapucou	126	5.9000000000000004	f	-	0	24	1	2012-10-13 12:45:36+02
4960	Štrikovaný pulóver bielo-hnedý	126	2.2999999999999998	f	-	0	7	1	2012-10-13 12:45:45+02
4959	Štrikovaný pulóver bielo-hnedý	126	2.2999999999999998	f	-	0	6	1	2012-10-13 12:45:47+02
4947	Mikina so zateplenou  kapucňou červená vpredu č. 63 zn george veľ.3-4R	125	1.5	f	-	0	31	2	2012-10-14 10:53:50+02
4978	Modrý pletený pulover s kapucou 	126	2.8999999999999999	f	-	0	25	1	2012-10-13 12:46:08+02
4979	Modrý pletený pulover s kapucou 	126	2.8999999999999999	f	-	0	26	1	2012-10-13 12:46:11+02
5160	Topánky zimné hnedé Alpin Pro	131	6	f	-	0	26	2	2012-10-13 14:59:36+02
5042	modro-oranžov-biela šuštiaková bunda dream veľ.134	127	2	f	-	0	3	1	2012-10-13 12:06:58+02
5041	červená zimná bunda sweet, vzadu motýľ veľ.98	127	3	f	-	0	2	1	2012-10-13 12:07:03+02
5043	zelená šuštiaková bunda ottawa veľ. 114/126	127	1	f	-	0	4	1	2012-10-13 12:07:06+02
5071	čierne šuštiaky sports 134	127	1	f	-	0	32	2	2012-10-13 16:20:19+02
5045	modrá pásikavá trigovica na zips cherokee	127	2	f	-	0	6	1	2012-10-13 12:07:15+02
5046	bledomodrý sveter na zips s límcom LOTEX 6-7 rokov	127	2	f	-	0	7	1	2012-10-13 12:07:19+02
5050	hrubý rolák pásiky hnedo-bielo-ružovo-fialové  veľ.110	127	1.5	f	-	0	11	2	2012-10-13 17:24:39+02
5049	hrubý rolák pásiky oranžovo-bielo-ružovo-fialové  veľ.110	127	1.5	f	-	0	10	1	2012-10-13 12:07:30+02
5064	dievčenská trigovica hnedá s kapucou zlatý kôň	127	1.5	f	-	0	25	2	2012-10-13 18:04:43+02
5052	trigovica flísová žltá s gombíkmi adidas veľ. 140	127	1.5	f	-	0	13	1	2012-10-13 12:07:40+02
5053	trigovica flísová moro-šedá s kapucou skate fun veľ.116	127	2	f	-	0	14	1	2012-10-13 12:07:44+02
5054	trigovica oranžová s hnedým 2 kone a erb	127	1	f	-	0	15	1	2012-10-13 12:07:47+02
5055	trigovica hnedo-biela rock knights veľ. 122	127	1	f	-	0	16	1	2012-10-13 12:07:52+02
5056	vesta šedá reflective 7-8r.	127	1	f	-	0	17	1	2012-10-13 12:07:55+02
5057	riflové šaty béžové veľ. 110	127	2	f	-	0	18	1	2012-10-13 12:07:59+02
5058	riflové šaty fialové veľ. 110	127	2	f	-	0	19	1	2012-10-13 12:08:03+02
5063	dievčenský sveter dlhý na gombíky s opaskom hnedý	127	2	f	-	0	24	1	2012-10-13 12:08:29+02
5076	tričko s dlhým rukávom biele s motýľmi	127	1	f	-	0	37	2	2012-10-13 18:11:14+02
5066	dievčenské rifle modré s motýľom	127	1	f	-	0	27	1	2012-10-13 12:08:43+02
5067	menčestráky bordové hok jea	127	1	f	-	0	28	1	2012-10-13 12:08:47+02
5068	šuštiaky zateplené modré s ružovým patentom success	127	1	f	-	0	29	1	2012-10-13 12:08:50+02
5070	zelené tepláky nike	127	2	f	-	0	31	1	2012-10-13 12:09:46+02
5074	tričko s dlhým rukávom moro-čierne footbal	127	1	f	-	0	35	1	2012-10-13 12:10:13+02
5075	rolák modrý pásikavý 122/128	127	1	f	-	0	36	1	2012-10-13 12:10:18+02
5077	tričko s dlhým rukávom ružovo fialové whatś up	127	1	f	-	0	38	1	2012-10-13 12:10:27+02
5072	béžová menčestrová suknička v. 110	127	1	f	-	0	33	1	2012-10-13 12:11:03+02
5073	froté pyžamo bielo- bledomodré real fun inline skating	127	1	f	-	0	34	1	2012-10-13 12:11:14+02
5069	ružové froté tepláky s kvetinkou	127	1	f	-	0	30	1	2012-10-13 12:12:07+02
5051	svetrík s kapucou pásikavý šedo-ružovo-žlto fialový pretty for girls veľ.110	127	2	f	-	0	12	2	2012-10-13 14:46:08+02
5044	čierna prešívaná vesta dopodopo veľ.110	127	3	f	-	0	5	2	2012-10-13 14:52:41+02
5065	dievčenskénohavice bledo- fialové zateplené 	127	2	f	-	0	26	2	2012-10-13 15:31:16+02
5048	hrubý rolák pásiky modro-bielo-ružovo-fialové  veľ.110	127	1.5	f	-	0	9	2	2012-10-13 15:42:01+02
5061	 chlapčenská vesta čierna na gombíky kids by lindex v. 134	127	1	f	-	0	22	2	2012-10-13 18:20:47+02
5040	šedá zimná bunda, vzadu  smiešny modrí panáci veľ.128	127	4	f	-	0	1	2	2012-10-13 18:33:44+02
5062	nohavice klasické čierne	127	1	f	-	0	23	2	2012-10-13 18:39:59+02
5060	súprava fialový rolák+ sukňa na traky fialová kvetovaná	127	2	f	-	0	21	2	2012-10-13 19:09:27+02
5059	úpletové šaty s rolákom fialové s ružovými srdiečkami	127	2	f	-	0	20	2	2012-10-14 10:09:32+02
5078	tričko s dlhým rukávom fialové ružová gymnastka	127	1	f	-	0	39	2	2012-10-14 13:55:17+02
5047	fialová plátená bunda na gombíky s motýľom veľ.110	127	2	f	-	0	8	2	2012-10-14 13:55:18+02
5091	bielomodrý kabátik s medvedíkmi, veľ. 56:62	128	1	f	-	0	2	1	2012-10-13 09:52:31+02
5120	biele body so šedými prúžkami, veľ. 0-3 m.	128	1	f	-	0	31	2	2012-10-14 12:58:25+02
5093	biele body s prúžkami, veľ. 62	128	1	f	-	0	4	1	2012-10-13 09:52:37+02
5094	bieložlté kockované body, veľ. 62	128	1	f	-	0	5	1	2012-10-13 09:52:43+02
5095	béžové menčestráčiky, podšité, veľ. 62	128	3	f	-	0	6	1	2012-10-13 09:52:48+02
5122	biele body so žirafkou vpredu, veľ. 0-3 m.	128	1	f	-	0	33	2	2012-10-13 17:30:27+02
5097	biela mikinka so zajkom, veľ. 50	128	1.7	f	-	0	8	1	2012-10-13 09:53:09+02
5098	modrá flísová mikinka, veľ. 62	128	2.2999999999999998	f	-	0	9	1	2012-10-13 09:53:12+02
5099	tyrkysový kabátik s macíkmi, veľ. 3-6 m.	128	2	f	-	0	10	1	2012-10-13 09:53:20+02
5100	zelenobiely kabátik s medvedíkmi, veľ. 56-62	128	1	f	-	0	11	1	2012-10-13 09:53:27+02
5101	modré body, veľ. 50	128	1	f	-	0	12	1	2012-10-13 09:53:30+02
5102	bieloružové dupačky vpredu macík, veľ. 56	128	1.8	f	-	0	13	1	2012-10-13 09:53:33+02
5103	bielozelená čiapočka s medvedíkmi	128	1	f	-	0	14	1	2012-10-13 09:53:51+02
5121	biele body so šedými žirafkami, veľ. 0-3 m.	128	1	f	-	0	32	2	2012-10-13 16:02:17+02
5105	tmavomodrá čiapočka so slimákom	128	1	f	-	0	16	1	2012-10-13 09:54:01+02
5106	biely spací spak so zvieratkami, veľ. 0-6 m	128	8	f	-	0	17	1	2012-10-13 09:54:11+02
5107	modré zateplené pyžamko, veľ. 3-6 m.	128	3	f	-	0	18	1	2012-10-13 09:54:15+02
5108	bielošedá mikinka s nápisom, veľ. 56	128	2	f	-	0	19	1	2012-10-13 09:54:20+02
5109	farebné prúžkované tričko, veľ. 9-12 m.	128	1.2	f	-	0	20	1	2012-10-13 09:54:22+02
5110	biely kabátik, zelený golier, veľ. 62	128	1.8	f	-	0	21	1	2012-10-13 09:54:29+02
5142	Rolák šedý pásikavý	131	0.5	f	-	0	8	2	2012-10-13 16:17:37+02
5113	prúžkované tepláčiky, veľ. 3-6 m.	128	1.5	f	-	0	24	1	2012-10-13 09:54:38+02
5096	bielomodré tričko so šmolkom, veľ. 62	128	1.5	f	-	0	7	2	2012-10-13 17:10:51+02
5114	biele body so zelenými prúžkami, veľ. 68	128	1	f	-	0	25	1	2012-10-13 09:54:55+02
5116	bieločervené body so zajkom, veľ. 0-6 m.	128	1	f	-	0	27	1	2012-10-13 09:55:02+02
5147	Bunda prechodná modrá s patentami	131	2	f	-	0	13	1	2012-10-13 18:50:50+02
5118	béžové chlpaté rukavičky	128	1	f	-	0	29	1	2012-10-13 09:55:07+02
5119	hnedé body, zelené guličky,vpredu vtáčiky, veľ. 62	128	1	f	-	0	30	1	2012-10-13 09:55:08+02
5111	biele dupačky so sloníkom, veľ. 56	128	2	f	-	0	22	2	2012-10-13 16:02:17+02
5150	Mikina bledá bledá ADIDAS	131	2.5	f	-	0	16	2	2012-10-13 17:30:27+02
5123	čierne body s bielymi prúžkami, veľ. 56	128	1.3999999999999999	f	-	0	34	1	2012-10-13 09:55:30+02
5092	zelené body so sloníkom, veľ. 56	128	1	f	-	0	3	2	2012-10-14 12:58:25+02
5131	Svetrík zateplený na zips ružový	129	2	f	-	0	5	2	2012-10-14 10:07:54+02
5126	modrý overal s rukavičkami, veľ. 56-62	128	11	f	-	0	37	1	2012-10-13 09:55:46+02
5104	biele body s hríbikom, veľ. 62	128	1	f	-	0	15	2	2012-10-13 16:02:17+02
5136	Vesta zimná obojstranná čierno/maskáčová	131	5	f	-	0	2	1	2012-10-13 10:37:28+02
5137	Overal zimný hnedý, modrý lém	131	8	f	-	0	3	1	2012-10-13 10:37:36+02
5089	čiapka úpletová čierna so šiltom adidas	127	1	f	-	0	50	2	2012-10-13 15:34:57+02
5139	Mikina modrá bledá/hnedý lém	131	0.5	f	-	0	5	1	2012-10-13 10:37:52+02
5127	Súrodenecký kočík tandem Nurse oranžový s pláštenkou	129	30	f	-	0	1	1	2012-10-13 18:21:20+02
5138	Bunda zimná látková šedá	131	4	f	-	0	4	2	2012-10-13 15:34:26+02
5079	tričko s dlhým rukávom hnedé fialová gymnastka	127	1	f	-	0	40	2	2012-10-13 16:45:27+02
5133	Oteplováky na traky ružové 	129	2	f	-	0	7	2	2012-10-14 12:12:11+02
5144	Mikina modrá ADIDAS (patenty) 	131	1.5	f	-	0	10	1	2012-10-13 10:38:25+02
5145	Mikina svetlo modrá GAP s kapucou	131	2	f	-	0	11	1	2012-10-13 10:38:34+02
5146	Mikina Tmavo modrá 82 NEXT	131	1	f	-	0	12	1	2012-10-13 10:38:58+02
5135	Bunda zimná károvaná čierno/hnedá	131	6	f	-	0	1	2	2012-10-13 15:52:07+02
5148	Mikina tmavá modrá GAP ATHLETIC	131	1	f	-	0	14	1	2012-10-13 10:39:11+02
5149	Mikina bledo/tmavo modrá ADAMS	131	1	f	-	0	15	1	2012-10-13 10:39:18+02
5088	snehule tmavo modré s dopravnými prostriedkami a červ. Šnúrkami	127	2	f	-	0	49	2	2012-10-13 17:44:18+02
5151	Mikina červená DUDE	131	1	f	-	0	17	1	2012-10-13 10:39:29+02
5152	Nohavice menčestrové hnedé	131	1	f	-	0	18	1	2012-10-13 10:39:35+02
5087	halovky šedo-červené starheight	127	2	f	-	0	48	1	2012-10-13 12:09:32+02
5140	Pulóver hnedý NEXT	131	2	f	-	0	6	2	2012-10-13 18:01:27+02
5085	pančucháče hnedé s dinosaurami v.110-116	127	0.80000000000000004	f	-	0	46	2	2012-10-13 19:19:16+02
5115	prúžkované tričko, biele rukávy, veľ. 68	128	1.8	f	-	0	26	2	2012-10-13 17:00:09+02
5082	pančucháče biele so zelenými pásikmi v. 122-128	127	0.80000000000000004	f	-	0	43	2	2012-10-13 16:57:51+02
5080	tričko s dlhým rukávom biele s mackom a tigrom	127	1	f	-	0	41	1	2012-10-13 12:10:46+02
5081	tričko s dlhým rukávom fialové s kvietkami	127	1	f	-	0	42	1	2012-10-13 12:10:55+02
5143	Tričko modré s drakmi	131	0.5	f	-	0	9	2	2012-10-14 11:06:18+02
5083	pančucháče čierne v.110-116	127	0.80000000000000004	f	-	0	44	1	2012-10-13 12:11:46+02
5125	tmavomodrá vlnená čiapočka s brmbolcom s rukavičkami	128	2.5	f	-	0	36	2	2012-10-14 09:21:26+02
5141	Tričko červené/biely pásik	131	0.5	f	-	0	7	2	2012-10-13 15:11:23+02
5128	Prenosná taška Phils/Teds oranžová	129	8	f	-	0	2	1	2012-10-13 18:21:20+02
5129	Podložka pevná prebalovacia oranžová, žirafy	129	7	f	-	0	3	1	2012-10-13 18:21:21+02
5124	modré body so žirafkou, veľ. 56	128	1	f	-	0	35	2	2012-10-14 12:58:25+02
5084	pančucháče hnedé v.122-128	127	0.80000000000000004	f	-	0	45	2	2012-10-14 11:06:18+02
5132	Flaušová bunda s patentom béžová 	129	2	f	-	0	6	1	2012-10-13 18:21:34+02
5130	Šuštiaková bunda ružovo-modro-biela 	129	3	f	-	0	4	2	2012-10-14 12:50:36+02
5117	biele body s dinosaurom, veľ. 62	128	1	f	-	0	28	2	2012-10-13 18:40:10+02
5134	Overal na cvoky ružový 	129	2	f	-	0	8	2	2012-10-13 18:21:59+02
5182	cierno sedy rolak,ruza	133	2	f	-	0	2	1	2012-10-13 10:57:24+02
5183	seda trigovica s kapucou,gangboy	133	1	f	-	0	3	1	2012-10-13 10:57:42+02
5184	tricko s dlhym rukavom,vojenska zelena,v.98	133	0.69999999999999996	f	-	0	4	1	2012-10-13 10:57:48+02
5185	tmavo modry kabatik s oranzovymy doplnkami na zips,v.104	133	1	f	-	0	5	1	2012-10-13 10:57:51+02
5242	Hnedé menžestráky, v páse na gumu, veľ.92	134	2	f	-	0	40	2	2012-10-13 16:02:29+02
5187	sede ponco s kapucou	133	3	f	-	0	7	2	2012-10-13 15:15:37+02
5188	cierna bunda s patentom,vpredu zipsy,v.S	133	4	f	-	0	8	1	2012-10-13 10:58:15+02
5206	rolák so zajačikom oranžovo žltá veľ.80	134	1	f	-	0	4	2	2012-10-13 18:07:21+02
5233	Modré nohavice s vreckami vpredu, veľ. 12-18 mes. 	134	1	f	-	0	31	2	2012-10-14 11:04:46+02
5192	zlta ciapka,zavazovanie sportex	133	0.5	f	-	0	12	1	2012-10-13 10:59:19+02
5197	dievcenske zateplene nohavice,vojenska zelena,158	133	3	f	-	0	17	1	2012-10-13 10:59:57+02
5191	zelena ciapka,zavazovanie sportex	133	0.5	f	-	0	11	1	2012-10-13 10:59:22+02
5228	Ružové menžestráky veľ.86	134	3.5	f	-	0	26	2	2012-10-13 17:31:41+02
5196	tmavomodre dievcenske rifle,na vackoch trblietky fialove	133	3.5	f	-	0	16	1	2012-10-13 10:59:35+02
5235	Svetlohnedé menžestráky, v páse na gumu, s vyšitými kvietkami	134	1.5	f	-	0	33	2	2012-10-13 18:19:20+02
5200	chlapcenska modra prechodna bunda,s pasikavym patentom,v.152	133	5	f	-	0	20	1	2012-10-13 10:59:49+02
5198	dievcenske zateplene nohavice,vojenska zelena,158	133	3	f	-	0	18	1	2012-10-13 11:00:01+02
5201	chlapcenska bunda,tmavo modro seda,na krku zips,s kapucou	133	5	f	-	0	21	1	2012-10-13 11:00:13+02
5202	midre rifle,na pase cierny patent,v.12	133	5	f	-	0	22	1	2012-10-13 11:00:18+02
5209	Mikina flisová, svetloružová+biela, so psíkom, veľ. 74	134	1	f	-	0	7	2	2012-10-13 16:50:52+02
5225	Ružová súprava s hrochom, 2 diely, veľ. 62/68	134	1.5	f	-	0	23	1	2012-10-13 11:19:23+02
5221	Modro-ružová flísová súprava 2 diely	134	1	f	-	0	19	1	2012-10-13 11:19:32+02
5224	Súprava bielo-ružová 2 diely (body s dl.rukávom+polodupačky), veľ. 0-3 mes	134	1.5	f	-	0	22	1	2012-10-13 11:19:41+02
5223	Ružový teplý overal so zajacom, veľ.74	134	1	f	-	0	21	1	2012-10-13 11:19:49+02
5222	Modro-žltá teplá súprava 2 diely, veľ.92	134	1.5	f	-	0	20	1	2012-10-13 11:19:58+02
5220	Oranžová tepláková súprava 2 diely, zamat, (bunda+polodupačky),veľ.6/9mes.	134	2	f	-	0	18	1	2012-10-13 11:20:13+02
5212	Ružovo-biela pruhovaná flisová mikina, veľ. 86	134	1.5	f	-	0	10	1	2012-10-13 11:20:21+02
5186	ruzova trigovica s kapucou na zips,v.152	133	1.5	f	-	0	6	2	2012-10-13 15:01:38+02
5219	Fialová tepláková súprava 2 diely, zamat, veľ. 80; (bunda pruhovaná)	134	4	f	-	0	17	1	2012-10-13 11:20:49+02
5193	tmavocervene oteplovacky,LOIP,v.146	133	8	f	-	0	13	2	2012-10-13 16:57:51+02
5208	Overal so zajačikom, svetloružový, veľ.9 /12 mes.	134	1.5	f	-	0	6	1	2012-10-13 11:21:05+02
5218	Ružová tepláková súprava 2 diely, zamat, veľ. 86	134	4	f	-	0	16	1	2012-10-13 11:21:15+02
5217	Ružový overal so srdiečkami 	134	2	f	-	0	15	1	2012-10-13 11:21:21+02
5216	Ružový flísový komplet so sloníkom (mikina+tepláky) veľ.74	134	1	f	-	0	14	1	2012-10-13 11:21:28+02
5207	súprava bordová veľ.4-6 mes.	134	2	f	-	0	5	1	2012-10-13 11:21:37+02
5215	Svetlomodrý svetrík s mašličkami, veľ. 86	134	1	f	-	0	13	1	2012-10-13 11:21:44+02
5195	tmavomodre dievcenske rifle,na vackoch trblietky fialove	133	3.5	f	-	0	15	2	2012-10-13 18:13:48+02
5194	tmavocervene oteplovacky,LOIP,v.146	133	8	f	-	0	14	2	2012-10-14 10:38:24+02
5213	Ružová tepláková súprava Calvin Klein, 3 diely, veľ. 24 mes	134	3	f	-	0	11	1	2012-10-13 11:22:25+02
5239	Rifle modré, na gumu, okolo vreciek výšivka, veľ. 98	134	1	f	-	0	37	1	2012-10-13 11:22:41+02
5240	Rifle modré, na gumu, farebné "prskance" a strieb.cvoky, veľ. 4 roky	134	1.5	f	-	0	38	1	2012-10-13 11:22:45+02
5241	Rifle modré, s výšivkou	134	2	f	-	0	39	1	2012-10-13 11:22:53+02
5227	Rifle modré, na gumu, strieb. Výšivka, veľ.98	134	1	f	-	0	25	1	2012-10-13 11:23:05+02
5199	hnedo oranzove cizmy,v.37	133	3	f	-	0	19	2	2012-10-13 16:32:00+02
5177	chlapč.nohavice modro žlto kárované, podšité. Na 12 mesiacov	132	4	f	-	0	17	2	2012-10-14 11:28:57+02
5230	Ružové menžestráky na traky	134	3	f	-	0	28	2	2012-10-13 18:55:46+02
5231	Modré rifle, na gumu,	134	1	f	-	0	29	1	2012-10-13 11:23:29+02
5237	Modré rifle na traky s vyšivkou vpredu, veľ 86	134	1.5	f	-	0	35	2	2012-10-13 19:04:25+02
5234	Modré rifle na traky, vpredu s kvietkami, veľ. 12mes. 	134	1	f	-	0	32	1	2012-10-13 11:23:41+02
5229	Červené menžestráky veľ. 74/80	134	1	f	-	0	27	1	2012-10-13 11:23:46+02
5226	Zateplený sveter bordový s guličkami, veľ. 2-3 roky	134	1.5	f	-	0	24	1	2012-10-13 11:23:52+02
5210	Červeno-biely pruhovaný kabátik, veľ. 86	134	4	f	-	0	8	2	2012-10-13 14:56:30+02
5203	Otepľovačky tmavomodré, veĺ. 4 roky	134	1	f	-	0	1	2	2012-10-13 19:12:22+02
5236	hnedé menžestráky na traky, vpredu s vreckom	134	2	f	-	0	34	1	2012-10-13 11:24:16+02
5232	Zateplené hnedo-červené nohavice, v páse na gumu, veľ. 12-18 mes	134	1.5	f	-	0	30	2	2012-10-13 18:31:20+02
5189	bledo modra bunda,v.116	133	2	f	-	0	9	2	2012-10-13 17:59:36+02
5244	Ružovo-čierna bunda s odopínateľnou kapucou, veľ. 74	134	2	f	-	0	42	1	2012-10-13 11:24:37+02
5243	Ružová bunda s kapucou, veľ. 2-3 roky	134	3	f	-	0	41	1	2012-10-13 11:24:54+02
5204	Overal farebný (čierna,modrá,žltá,červená)	134	2	f	-	0	2	1	2012-10-13 11:25:42+02
5205	Tepláková súprava 3-dielna svetloružová	134	3	f	-	0	3	2	2012-10-14 10:16:33+02
5180	tehotenské rifle na traky	132	4	f	-	0	20	1	2012-10-13 11:33:52+02
5179	chlapč. nohavice hnedý menčester , podšité fleesom. 6 rokov	132	5	f	-	0	19	1	2012-10-13 11:33:58+02
5211	Bordová vesta zateplená, veľ.12-18 mes. 	134	2	f	-	0	9	2	2012-10-14 13:10:21+02
5178	chlapč. nohavice béžový menčester , podšité fleesom. 4 roky	132	4	f	-	0	18	1	2012-10-13 11:36:09+02
5238	Ružové maskáče na traky, veľ. 86	134	1.5	f	-	0	36	2	2012-10-13 14:46:08+02
5303	tmavomodré tepláky s vyšitou loptou	136	1	f	-	0	1	1	2012-10-13 09:19:07+02
5304	tmavošedé nohavice	136	1	f	-	0	2	1	2012-10-13 09:19:12+02
5305	ružové otepľovačky	136	6	f	-	0	3	1	2012-10-13 09:19:19+02
5306	šedozelené menčestráky	136	3.5	f	-	0	4	1	2012-10-13 09:19:25+02
5307	tmavomodré podšité nohavice	136	2	f	-	0	5	1	2012-10-13 09:19:36+02
5309	biela flaušová mikina so psíkmi	136	1.5	f	-	0	7	1	2012-10-13 09:19:56+02
5310	bledomodrá flaušová mikina s kapuckou na zips	136	1.5	f	-	0	8	1	2012-10-13 09:20:01+02
5272	Modrokvietkovaná mikina Next s oranžovou kapucou 80	135	5	f	-	0	20	2	2012-10-13 16:27:15+02
5312	modra bavlnená mikinka s kapuckou	136	0.5	f	-	0	10	1	2012-10-13 09:20:35+02
5294	Tmavomodré zateplené chlapčenské nohavice 2-3roky	135	5	f	-	0	42	2	2012-10-13 18:01:27+02
5252	Zimné topánky modro-biele so snehuliakom, veľ.US 6	134	2	f	-	0	50	1	2012-10-13 11:18:47+02
5250	2 čiapky, (1 krémová flísová s kvietkami vpredu, 1ružová ), veľ. Cca 12 mes	134	1	f	-	0	48	1	2012-10-13 11:18:57+02
5291	Ružové kožené GEOX topánočky veľ.19	135	7	f	-	0	39	2	2012-10-13 15:55:14+02
5311	tmavozelená mikina s kapuckou na zips vzor hrdinovia	136	2.2999999999999998	f	-	0	9	2	2012-10-13 16:24:03+02
5286	Adidas dievčenské zimné topánky veľ.20	135	20	f	-	0	34	2	2012-10-13 18:19:20+02
5247	Bordová bunda, s výšivkou - snehová vločka, veľ. 74	134	3	f	-	0	45	1	2012-10-13 11:25:26+02
5290	Hnedé kožušinkové čižmičky Next veľ.19	135	7	f	-	0	38	2	2012-10-13 19:33:27+02
5271	Hnedé zateplené menžestráky H&M veľ. 86	135	7	f	-	0	19	2	2012-10-13 14:34:31+02
5267	Ružové podšité nohavice OLD NAVY 12-18 m	135	5	f	-	0	15	2	2012-10-14 09:38:44+02
5297	Pásikový modro-biely dievčenský sveter Next  6 -9 mes.	135	10	f	-	0	45	2	2012-10-13 15:55:14+02
5274	Modré flisové nohavice veľ. 86	135	3	f	-	0	22	2	2012-10-13 16:52:37+02
5264	Tmavoružová chlpatka Next veľ. 9-12 m.	135	12	f	-	0	12	1	2012-10-13 12:02:21+02
5265	Červená chlpatka Next veľ. 12-18 m	135	8	f	-	0	13	1	2012-10-13 12:02:25+02
5258	Modrý zimný overal zn. Figi veľ. 98	135	20	f	-	0	6	1	2012-10-13 12:02:56+02
5313	body modrožltý pásik	136	0.10000000000000001	f	-	0	11	2	2012-10-13 17:24:17+02
5255	Modrý flisový kabátik s kapucou 3-6 m	135	3	f	-	0	3	1	2012-10-13 12:03:09+02
5266	Tmavoružové pletené šaty Ralph Lauren veľ. 12 m	135	20	f	-	0	14	1	2012-10-13 12:03:16+02
5256	Modré flisové nohavice 3- 6 m	135	2	f	-	0	4	1	2012-10-13 12:03:24+02
5269	Červené kvietkové tričko s červenou vestičkou zn. Next 6-9 m.	135	8	f	-	0	17	1	2012-10-13 12:03:28+02
5253	Modrá deka Benetton	135	8	f	-	0	1	1	2012-10-13 12:03:35+02
5245	Zateplený pršiplášť Disney s princeznami	134	3	f	-	0	43	2	2012-10-13 15:56:01+02
5283	Rifľová chlapčenská košeľa Next veľ.4-5 r.	135	9	f	-	0	31	1	2012-10-13 12:03:58+02
5288	Chlapčenské čierne zateplené nohavice Zara 104	135	7	f	-	0	36	1	2012-10-13 12:04:07+02
5301	Chlapčenské rifle Dodipetto veľ. L s bledými vreckami vzadu	135	4	f	-	0	49	2	2012-10-14 12:03:53+02
5295	Tmavomodrá chlapčenská mikina s MCQueenom	135	5.5	f	-	0	43	1	2012-10-13 12:04:27+02
5249	Teplý ružový župan, veľ.74	134	1.5	f	-	0	47	2	2012-10-13 15:33:00+02
5285	Pásikové dievčenské tričko Gap 6-12 mes.	135	6	f	-	0	33	1	2012-10-13 12:05:00+02
5284	Ružové menžestráky H&M veľ.50	135	4	f	-	0	32	2	2012-10-13 17:06:36+02
5273	Modrá flisová mikina na zips veľ. 86	135	4	f	-	0	21	2	2012-10-13 16:52:37+02
5302	Chlapčenské tričko s MCQueenom s tmavými rukávmi	135	3.5	f	-	0	50	1	2012-10-13 12:05:33+02
5246	Hnedý menžestrový kabátik s opaskom a kožušinovým golierom, veľ.3 roky	134	4	f	-	0	44	2	2012-10-13 18:01:27+02
5296	Šedá chlapčenská mikina Next s fialovou kapucou 104	135	10	f	-	0	44	1	2012-10-13 12:05:47+02
5275	Kožušinková vesta Next 6-9 mes.	135	3	f	-	0	23	1	2012-10-13 12:05:55+02
5289	Dievčenská kožušteková mikinka Next s mačičkou 86	135	6	f	-	0	37	2	2012-10-13 16:34:29+02
5287	Chlapčenské tmavomodré zateplené nohavice Zara 104	135	7	f	-	0	35	2	2012-10-14 10:51:29+02
5292	Hnedá pásiková mikina Next veľ.92	135	10	f	-	0	40	1	2012-10-13 12:06:13+02
5260	Dievčenská zimná jabĺčková bunda zn. Next veľ. 6-9 /74/	135	25	f	-	0	8	2	2012-10-13 16:48:23+02
5293	Ružový overal Ralph Lauren veľ. 9m	135	10	f	-	0	41	1	2012-10-13 12:06:20+02
5300	Modré chlapčenské tričko s tmavou kapucou	135	4	f	-	0	48	1	2012-10-13 12:06:28+02
5268	Rifľový dievčenský overal s opaskom zn. Next veľ. 12-18	135	15	f	-	0	16	1	2012-10-13 12:06:37+02
5248	Červený overal, aplikácia sloníka vpredu, veľ 74	134	5	f	-	0	46	2	2012-10-13 18:38:14+02
5270	Tmavomodrá prechodná bunda SISLEY veľ. 110	135	20	f	-	0	18	1	2012-10-13 12:06:53+02
5282	Bledomodré rifle na traky H&M veľ.80	135	9	f	-	0	30	1	2012-10-13 12:07:02+02
5277	Oranžové oteplené nohavice dodipetto veľ. M	135	5	f	-	0	25	1	2012-10-13 12:07:06+02
5281	Dievčenské rifle na traky so zajkovým bodynkom Next	135	11	f	-	0	29	1	2012-10-13 12:07:15+02
5278	Modro-biela čiapka s 5 brmbolcami	135	6	f	-	0	26	1	2012-10-13 12:07:45+02
5298	Modrá chlapčenská mikina Next s tmavými rukávmi veľ. 92	135	8	f	-	0	46	2	2012-10-13 15:28:42+02
5257	Chlapčenská zimná bunda Dodipetto s kožušinkou vojen.farba veľ.S	135	20	f	-	0	5	1	2012-10-13 12:08:06+02
5259	Chlapč.zimná bunda zeleno-modrá zn. Benetton veľ. 3-4 /98/	135	25	f	-	0	7	1	2012-10-13 12:08:36+02
5263	Zimný ružový overal zn. Muriquita veľ. 74	135	20	f	-	0	11	1	2012-10-13 12:09:37+02
5280	Modá čiapka s dvomi vrkočmi a zajkom	135	3	f	-	0	28	1	2012-10-13 12:09:45+02
5254	Modré flisové bolerko veľ. 3m	135	4	f	-	0	2	1	2012-10-13 12:09:49+02
5279	Tmavozelená pásikavá čiapka s brmbolcom na uväzovanie 	135	5	f	-	0	27	1	2012-10-13 12:10:05+02
5299	Béžová čiapka s bielym mackom	135	3	f	-	0	47	1	2012-10-13 12:10:11+02
5251	Zimné topánky fialové, na suchý zips, veľ 28	134	2	f	-	0	49	2	2012-10-14 13:12:37+02
5262	Dievčenský červený prechodný kabátik zn. Burberry veľ. 12 m	135	20	f	-	0	10	2	2012-10-13 18:31:53+02
5348	biela flisová šiapka,na uškách sova,RESERVED,3-6m.	137	3	f	-	0	3	1	2012-10-13 08:50:12+02
5347	biela bavlnená šiapka,na šnúrky,vpredu motýl a kvietky,PUPILL	137	2	f	-	0	2	1	2012-10-13 08:50:16+02
5346	ružová baranica,vpredu a na uškách baranička,H&M,v.74	137	3	f	-	0	1	1	2012-10-13 08:50:21+02
5355	ružové body,biele rukáviky,nápis mám 1 rôčik,BESS.sk,v.80	137	2	f	-	0	10	2	2012-10-13 17:47:00+02
5317	hnedá kárová sukňa	136	3	f	-	0	15	2	2012-10-14 13:55:18+02
5320	tmavozelené nohavice tenký pásik	136	2	f	-	0	18	2	2012-10-14 10:41:43+02
5353	červené vianočné šaty,podšité,bez rukávov,CHAROKEE,v.9-12m.	137	3	f	-	0	8	1	2012-10-13 08:50:40+02
5350	ružovo-bielo-modro-sivo pásikavý sveter,kapuca,gombíky,CHEROKEE,	137	2.5	f	-	0	5	2	2012-10-13 17:29:26+02
5368	zelená chlpatková bunda,zips,kapuca,H&M,v.86	137	7	f	-	0	23	2	2012-10-13 18:11:12+02
5354	ružové tričko,dlh.rukáv,vpredu kittynka,cez hlavu,H&M,v.74	137	2	f	-	0	9	2	2012-10-13 17:11:15+02
5333	ružové pančuchy III.	136	2	f	-	0	31	2	2012-10-13 16:57:10+02
5358	modrá flis.mikina,cez hlavičku,vpredu dole kvietky,MARKS&SPENCER	137	2	f	-	0	13	1	2012-10-13 08:51:14+02
5359	teplák.súprava,vrch belasý,nápis adidas,spodok fialový,podšitý,ADIDAS	137	11	f	-	0	14	1	2012-10-13 08:51:17+02
5360	flisová súprava,vrch oranžový,kapuca,maco pooh,spodok hnedý,C&A,80	137	6	f	-	0	15	1	2012-10-13 08:51:24+02
5361	ružová prešívaná vesta,kapuca,zips,vpredu kvetinky,C&A,v.80	137	4	f	-	0	16	1	2012-10-13 08:51:30+02
5362	zelená mikina,kapuca,zips,vpredu sova,ružové ruk.,RESERVED,v.80	137	3	f	-	0	17	1	2012-10-13 08:51:32+02
5363	červená mikina,kapuca,zips,nápis next,NEXT,v.12-18m.	137	3	f	-	0	18	1	2012-10-13 08:51:34+02
5364	žltá riflová bundička,MACKAYS,v.80	137	3	f	-	0	19	1	2012-10-13 08:51:39+02
5366	fialková prešívaná vetrovka,kapuca s kožušinkou,zips,SPROGGS,6-9m	137	4	f	-	0	21	1	2012-10-13 08:52:07+02
5329	tmavomodré lyžiarske rukavice	136	1	f	-	0	27	2	2012-10-13 15:26:40+02
5324	zimná čiapka vojenská zelená so psíkom	136	0.10000000000000001	f	-	0	22	2	2012-10-13 18:14:41+02
5369	červená nepremokavá vetrovka,kapuca,fialovo podšitá,LUPILLU,v.86/92	137	6	f	-	0	24	1	2012-10-13 08:52:17+02
5370	zelená vetrovko,oranžový zips,kapuca,vpredu 28,CHICCO,v.68	137	8	f	-	0	25	1	2012-10-13 08:52:30+02
5371	bielo-modrá kockovaná bunda,zateplená,zips,kapuca,DISNEY,2-3r.	137	2	f	-	0	26	1	2012-10-13 08:52:31+02
5373	ružové papučky,na sucháč,vpredu kvietok,v.27	137	3	f	-	0	28	1	2012-10-13 08:52:45+02
5379	červené sandálky s bielymi bodkami,na sucháče,PROTETIKA,v.23	137	5	f	-	0	34	1	2012-10-13 08:53:03+02
5377	biele kožené tenisky,ružová puma,PUMA,v.24	137	5	f	-	0	32	1	2012-10-13 08:53:08+02
5378	ružové tenisky,šnúrky,ADIDAS,v.23	137	2	f	-	0	33	1	2012-10-13 08:53:13+02
5372	bielo modré tenisky,NIKE,v.21	137	2	f	-	0	27	1	2012-10-13 08:53:17+02
5376	modré topánky,na šnúrky,semišové,WinK	137	2	f	-	0	31	1	2012-10-13 08:53:21+02
5331	ružové pančuchy I.	136	2	f	-	0	29	2	2012-10-13 16:50:52+02
5374	biele plátené tenisky,na sucháče,DUNLOP,v.24	137	4	f	-	0	29	1	2012-10-13 08:53:32+02
5314	mikinka na zips s kapuckou fialová+šedý pásik	136	3	f	-	0	12	2	2012-10-13 19:09:27+02
5341	zelené tričko so sovou	136	2.5	f	-	0	39	2	2012-10-13 19:27:00+02
5315	tehotenské rifle	136	2	f	-	0	13	1	2012-10-13 09:20:59+02
5316	béžové dievč. menčestráky	136	3	f	-	0	14	1	2012-10-13 09:21:07+02
5318	tmavošedé podšité menčestráky	136	1	f	-	0	16	1	2012-10-13 09:21:18+02
5319	prešívné nohavice vojenská zelená	136	1.7	f	-	0	17	1	2012-10-13 09:21:25+02
5383	nohavice, vnutri oteplene, cierno-biele kockovane, velkost 80	138	2.5	f	-	0	3	2	2012-10-14 11:22:38+02
5321	čierna pletená čiapka Lonsdale	136	3	f	-	0	19	1	2012-10-13 09:21:39+02
5335	tmavomodré body	136	2.5	f	-	0	33	2	2012-10-13 16:41:59+02
5323	tmavošedý flaušový šál	136	0.10000000000000001	f	-	0	21	1	2012-10-13 09:23:34+02
5380	semižové čižmy,z vnútra na zips,z vonka kvietky,SKIPPY,v.25	137	8	f	-	0	35	2	2012-10-13 18:40:08+02
5325	biela zimná pletená čiapka	136	2	f	-	0	23	1	2012-10-13 09:23:45+02
5326	biela  jesenná čiapka	136	1	f	-	0	24	1	2012-10-13 09:23:51+02
5327	tmavomodrá jesenná čiapka s pásom	136	0.5	f	-	0	25	1	2012-10-13 09:23:57+02
5342	chlapčenská vesta vojenská zelená	136	4	f	-	0	40	2	2012-10-13 16:17:37+02
5328	ružovočierne lyžiarske rukavice	136	1	f	-	0	26	2	2012-10-13 15:29:14+02
5367	fialová vesta,podšitá,kapuca,zips,prešívaná,C&A,v.92	137	4	f	-	0	22	2	2012-10-13 14:46:08+02
5343	tričko bielofialový pásik a srdiečka	136	2.5	f	-	0	41	2	2012-10-13 16:35:25+02
5357	hnedý sveter,3 gombíky,vyštrikovaný vzor,H&M,v.86	137	5	f	-	0	12	2	2012-10-13 16:54:15+02
5356	sivé podšité nohvice,vpredu a vzadu 2.vrecká,DOPODOPO,v.80	137	3	f	-	0	11	2	2012-10-13 17:06:36+02
5375	oranžové plátenky,na šnúrky,ADIDAS,v.24	137	2	f	-	0	30	2	2012-10-13 16:45:05+02
5334	hnedé body	136	2.5	f	-	0	32	2	2012-10-13 16:41:59+02
5336	pletený sveter bielohnedé pásy	136	2.5	f	-	0	34	1	2012-10-13 09:24:46+02
5351	smotanové legíny,na kolenách z vnútra prešité,F&F,v.1-1 1/2	137	2	f	-	0	6	2	2012-10-14 13:00:39+02
5339	rifľová vesta	136	1	f	-	0	37	1	2012-10-13 09:25:04+02
5340	ružové tričko 3 gombíky	136	2	f	-	0	38	1	2012-10-13 09:25:09+02
5352	sivé  tepláky,v páse ružová šnúrka,H&M,v.86	137	2	f	-	0	7	2	2012-10-14 09:38:44+02
5332	ružové pančuchy II.	136	2	f	-	0	30	2	2012-10-13 16:20:44+02
5322	súprava-modrá zimná čiapka s pásikmi a brmbolcom+nákrčník	136	3	f	-	0	20	2	2012-10-13 16:36:03+02
5344	čierne zimné topánky	136	3	f	-	0	42	1	2012-10-13 09:25:34+02
5345	biele tenisky adidas	136	2	f	-	0	43	1	2012-10-13 09:25:49+02
5338	červená mikina s kapuckou a vláčkmi	136	1.7	f	-	0	36	2	2012-10-14 12:16:42+02
5381	overal hnedo-bezovy, velkost 90-95/18mes	138	5.5	f	-	0	1	1	2012-10-13 10:35:43+02
5382	overal bledomodry Lebe, velkost 9mes	138	5.5	f	-	0	2	1	2012-10-13 10:35:54+02
5330	bieloružové lyžiarske rukavice	136	1	f	-	0	28	2	2012-10-13 14:34:31+02
5421	Overal na spanie oranžový so žirafkou	139	2.5	f	-	0	2	2	2012-10-13 16:26:26+02
5454	Chlapčenské body 6 ks	139	3	f	-	0	35	2	2012-10-13 17:01:44+02
5418	biely svetrik zn Jasper Conran 6-9mes	138	4	f	-	0	38	1	2012-10-13 10:36:09+02
5391	papucky bledomodre na snurovanie, velkost 23	138	2	f	-	0	11	1	2012-10-13 10:36:25+02
5395	papucky bledomodre s hrkalkou zn Baasley Baby, velkost 0-3m	138	1.5	f	-	0	15	1	2012-10-13 10:36:35+02
5455	Kožené topánky č. 21 Protetika	139	3	f	-	0	36	2	2012-10-14 11:16:20+02
5388	tyrkysove nohavice na traky s trickom zn.Bluezoo, velkost 3-6mes	138	3.5	f	-	0	8	1	2012-10-13 10:36:57+02
5384	bledomodry kabatik zn.TU, velkost 0-3mes, 62cm	138	4	f	-	0	4	1	2012-10-13 10:37:14+02
5424	Červená  bunda 1 a pol roka	139	2.5	f	-	0	5	2	2012-10-13 17:10:04+02
5399	rifle na traky+body zn Next, velkost 0-3mes, 6kg	138	2.5	f	-	0	19	1	2012-10-13 10:37:34+02
5396	hnede nohavice na traky s trickom zn Cheeroky, vel 56cm	138	2.2000000000000002	f	-	0	16	1	2012-10-13 10:37:41+02
5389	pasikave tricko s kapucnou, zeleno sedo cierne, zn earlydays, 3-6mes	138	2	f	-	0	9	1	2012-10-13 10:38:30+02
5411	pasikave trisko s dlhym rukavom zn Baby, vel 6-9mes	138	1.1000000000000001	f	-	0	31	2	2012-10-14 12:58:26+02
5401	topanocky 6-9mes,tyrkysove zn bz - little monsters	138	2.5	f	-	0	21	1	2012-10-13 10:38:44+02
5415	tmavozelene nohavice na traky FaF 12-18mes	138	2.5	f	-	0	35	2	2012-10-13 17:24:17+02
5423	Overal modrý na spanie s korytnačkou	139	2	f	-	0	4	2	2012-10-13 18:14:06+02
5426	Károvaná červená bunda s kapucou	139	2	f	-	0	7	2	2012-10-13 17:12:25+02
5406	nohavice na traky sede, zn okay, vel 74	138	1.2	f	-	0	26	1	2012-10-13 10:39:30+02
5405	tenky overal bledomodry, zn babyblue, velkost 3-6mes, 68cm	138	3	f	-	0	25	1	2012-10-13 10:39:43+02
5407	rifle zn Eddie Ella. Vel 6-9mes, sedomodre	138	1.5	f	-	0	27	1	2012-10-13 10:39:58+02
5428	Červená  bunda s vačkami s kožušinkou	139	2	f	-	0	9	2	2012-10-13 17:35:08+02
5404	bledomodra mikina s kapucnou, zn Miniclub, vel 74, 6-9mes	138	3	f	-	0	24	1	2012-10-13 10:40:15+02
5403	teplakova suprava sedo-modra Puma, vel 74cm	138	7	f	-	0	23	2	2012-10-13 17:12:25+02
5416	tmavomodra mikina zn Lupilu, velkost 86-92	138	2	f	-	0	36	1	2012-10-13 10:41:43+02
5414	sveter bezovy so zelenymi pasikmi, zn FaF, vel 9-12mes	138	2.5	f	-	0	34	1	2012-10-13 10:41:37+02
5413	zelene teplacky cheeroky, vel 0-3mes	138	1.5	f	-	0	33	1	2012-10-13 10:41:52+02
5408	rifle Disney s tigrikom, vel.9-12mes	138	2	f	-	0	28	1	2012-10-13 10:42:00+02
5409	tmavomodre rigle F a F, vel.9-12mes	138	2	f	-	0	29	1	2012-10-13 10:42:03+02
5410	duapcky Baby Lindex, vel.56cm, viacfarebne	138	2	f	-	0	30	1	2012-10-13 10:42:13+02
5390	papucky tmavomodre, velkost 21-22 s vysokou patou	138	2	f	-	0	10	2	2012-10-13 18:08:59+02
5417	tmavohnede nohavice zn Lupilu, vel 86-92	138	2.2000000000000002	f	-	0	37	1	2012-10-13 18:05:19+02
5436	Pletený sveter s pásikmi a kapucou na zips	139	2.5	f	-	0	17	1	2012-10-13 12:16:38+02
5394	bledomodry overal zn Next Baby, velkost 0-3mes, 3.5kg	138	8	f	-	0	14	2	2012-10-13 15:51:45+02
5441	Menžestrové nohavice s motýlikom na nohavici	139	2	f	-	0	22	2	2012-10-13 18:19:20+02
5429	Modré šaty s psíčkom	139	2	f	-	0	10	2	2012-10-13 15:45:41+02
5386	Biely overal zn ZIP ZAP, velkost 6-9mes	138	7.7000000000000002	f	-	0	6	2	2012-10-13 16:38:46+02
5387	adidas teplaky, tmavomodre, velkost 86, 12-18mes	138	4.4000000000000004	f	-	0	7	2	2012-10-14 11:08:28+02
5435	Khaki menžestráčky na traky	139	2	f	-	0	16	1	2012-10-13 12:17:15+02
5412	modre tricko s tigrikom, zn Disney at George vel 3-6mes	138	1.5	f	-	0	32	2	2012-10-13 17:10:51+02
5420	Hnedá mikina Next, 86 cm	139	2	f	-	0	1	1	2012-10-13 12:17:24+02
5430	Tmavočervená kombinéza	139	2	f	-	0	11	1	2012-10-13 12:17:29+02
5433	Tepláčky na traky tamvomodré so žirafkou	139	2	f	-	0	14	2	2012-10-13 17:59:21+02
5431	Bledomodrý overal na spinkanie s loďkou, dlhý	139	2	f	-	0	12	2	2012-10-13 15:46:59+02
5425	Fialová bunda s kapucou	139	2	f	-	0	6	2	2012-10-13 17:47:00+02
5402	topanocky sede, zn Next Baby, vel 0-3mes	138	2.5	f	-	0	22	2	2012-10-13 17:17:11+02
5427	Károvaná bunda s drevenými gombíčkami	139	2	f	-	0	8	1	2012-10-13 12:18:03+02
5448	Tmavomodré rifle s ružovými gombíkmi 	139	2	f	-	0	29	1	2012-10-13 12:18:12+02
5451	Béžové kapsáče s kvetinkou na boku	139	2	f	-	0	32	2	2012-10-14 11:53:16+02
5447	Bledomodré rifle Jeans	139	1	f	-	0	28	1	2012-10-13 12:18:24+02
5432	Pletený bledohnedý sveter na zips	139	2	f	-	0	13	1	2012-10-13 12:18:41+02
5444	Mikinka tmavošedo-oranžová	139	2	f	-	0	25	1	2012-10-13 12:19:35+02
5445	Béžové menžestáčkys kapsami vpredu	139	1	f	-	0	26	1	2012-10-13 12:19:41+02
5446	Khaki nohavice na traky	139	1.5	f	-	0	27	1	2012-10-13 12:19:47+02
5440	Fialové menžestráčky 	139	2	f	-	0	21	1	2012-10-13 12:19:53+02
5442	Flaušová mikinka s pásikmi biela, modrá a tmavomodrá	139	2	f	-	0	23	2	2012-10-13 18:28:03+02
5438	Modré vrúbkované menžestráčky so psíkom na kapse vpredu	139	2	f	-	0	19	1	2012-10-13 12:20:18+02
5437	Modré menžestráčky s károvanými kapsami	139	2	f	-	0	18	1	2012-10-13 12:20:23+02
5398	set body-nohavice bledobezovy s macikom, vel.0-3mes	138	2.5	f	-	0	18	2	2012-10-13 17:03:24+02
5449	Pletený sveter pásikavý s čiapkou	139	2	f	-	0	30	1	2012-10-13 12:21:41+02
5453	Čierne dievčenské menžestráky	139	2	f	-	0	34	1	2012-10-13 12:21:45+02
5393	detsky overal zn.Gap, tmavomodry, velkost 6-12mes	138	4	f	-	0	13	2	2012-10-14 12:03:53+02
5452	Tmavbomodré tričko s dlh rukávom Victory	139	2	f	-	0	33	1	2012-10-13 12:21:54+02
5450	Modrá mikinka Little Ski	139	1.5	f	-	0	31	1	2012-10-13 12:22:00+02
5434	Tmavomodré nohavice s gombíkmi na bokoch nohavíc	139	1.5	f	-	0	15	2	2012-10-13 19:32:16+02
5443	Tmavomodré rifle 12 až 18 mes	139	2	f	-	0	24	1	2012-10-13 12:22:32+02
5439	Hnedá bunda s mikimausom	139	2	f	-	0	20	1	2012-10-13 12:22:54+02
5422	Overal na spanie ružový so srdiečkami	139	2.5	f	-	0	3	2	2012-10-13 15:40:33+02
5479	zelenošedý zimný overal, biela podšívka,prúžkované patenty,Snow ball	140	6	f	-	0	10	2	2012-10-13 15:23:25+02
5459	Fialová čiapka so šiltom Hello Kitty	139	2	f	-	0	40	2	2012-10-13 15:31:16+02
5458	Dievčenské pančuchy tri ks, červené a ružové	139	3	f	-	0	39	2	2012-10-13 16:08:53+02
5469	Šedé tepláky hrubé s bielym pásikom na boku	139	1	f	-	0	50	2	2012-10-13 17:21:05+02
5456	Roláky - dva - šedý a pásikový - čiernobiely	139	2	f	-	0	37	2	2012-10-13 17:21:05+02
5521	šedé tepláky s modro-bielym pásom	141	0.40000000000000002	f	-	0	2	1	2012-10-13 09:30:43+02
5520	modré topánky s rybkou, suchý zips	141	2	f	-	0	1	1	2012-10-13 09:30:36+02
5522	kaki nohavice "tout simplement", 12m	141	1	f	-	0	3	1	2012-10-13 09:30:51+02
5523	pieskové manchestrové nohavice Next	141	1	f	-	0	4	1	2012-10-13 09:30:58+02
5524	pieskové manchestrové nohavice na traky, 12m	141	2	f	-	0	5	1	2012-10-13 09:31:05+02
5525	bledomodré body s medvedíkmi, dlhý rukáv	141	0.5	f	-	0	6	1	2012-10-13 09:31:12+02
5526	tmavomdré body Cheeky just like my dad, dlhý rukáv	141	0.5	f	-	0	7	1	2012-10-13 09:31:18+02
5527	oranžová mikina na zips, MINI,74-80	141	1	f	-	0	8	1	2012-10-13 09:31:26+02
5467	Tmavomodré tepláčky na šedú ozdobnú gumu a šnúrku	139	1	f	-	0	48	1	2012-10-13 12:18:49+02
5460	Ružovo-filaovo-modrá čiapka pletená	139	1	f	-	0	41	1	2012-10-13 12:19:10+02
5465	Béžové pančušky s medvedíkom	139	1	f	-	0	46	1	2012-10-13 12:19:29+02
5462	Hnedá čiapka so šnúrkami	139	1	f	-	0	43	1	2012-10-13 12:19:58+02
5463	Zelená čiapka s vláčikom a šnúrkami	139	1	f	-	0	44	1	2012-10-13 12:20:08+02
5457	Šedá mikinka s kapuckou a ružovými ozdobami	139	2	f	-	0	38	1	2012-10-13 12:22:19+02
5464	Čiapka s motorkárom 	139	1	f	-	0	45	1	2012-10-13 12:22:24+02
5470	zimné topánky chlapč., hnedé, šnurovanie, BubbleGummers, č. 22	140	4	f	-	0	1	1	2012-10-13 13:06:21+02
5472	čižmy chlapč.,čierno-šedo-červené,na zips, BobbiShoes, č.24	140	3.5	f	-	0	3	1	2012-10-13 13:06:46+02
5473	topánky chlapč., béžové s oranžovým,suchý zips, č.25	140	1.5	f	-	0	4	1	2012-10-13 13:07:01+02
5474	topánky kotníkové, modro-šedo-ružová, prešívané, šnurovanie, č.22	140	0.90000000000000002	f	-	0	5	1	2012-10-13 13:07:06+02
5475	topánky kotníkové, modro-šedomodré, šnurovanie, Protetika, č.22	140	5	f	-	0	6	1	2012-10-13 13:07:18+02
5476	bavlnený rolák stredne šedý	140	1	f	-	0	7	2	2012-10-13 17:49:24+02
5477	zimná bunda Cherokee, tm.modro-bledo modrá, kapucňa, zips	140	5	f	-	0	8	2	2012-10-13 18:01:27+02
5461	Modrošedá čiapka s brmbolcom	139	1.5	f	-	0	42	2	2012-10-13 18:53:01+02
5471	čižmy chlapč.,hnedo-oranž.-čierne,šnurovanie, DeiTex, č.25	140	5	f	-	0	2	2	2012-10-13 19:19:16+02
5466	Dvoje pančušky tmavomodré, tenšie a hrubšie	139	1.5	f	-	0	47	2	2012-10-14 11:10:35+02
5478	modré nohavice bavlnené, úpletový pás, Zara Kids, č.2-3	140	5	f	-	0	9	2	2012-10-14 11:16:20+02
5468	Modré tričko s dlh rukávom a opičkou	139	1	f	-	0	49	2	2012-10-14 11:28:41+02
5528	modrá bunda s kapucňou, TEXBASIC, 9m	141	3	f	-	0	9	1	2012-10-13 09:31:32+02
5529	kaki bunda s odopínateľnou kapocňou, H&M	141	5	f	-	0	10	1	2012-10-13 09:31:44+02
5576	Bielo-modro-cervene tenisky NATURINO	142	4	f	-	0	47	2	2012-10-13 17:07:06+02
5567	biela kosela NEXT	142	3	f	-	0	38	2	2012-10-13 14:46:08+02
2776	zltá mikina so zipsom velkost 74	71	1	f	-	0	1	1	2012-10-13 08:12:56+02
802	zelené teplé tričko, vel. 62	18	1.5	f	-	0	13	1	2012-10-13 08:13:26+02
792	tepláková súprava,bordova obojstranná, s hríbikmi, veľ. 68-74	18	2	f	-	0	3	1	2012-10-13 08:13:37+02
2797	tmavo modre teplaky s loptou	71	1.8999999999999999	f	-	0	22	1	2012-10-13 08:16:04+02
1503	krémové bodynko s oranžovými páskmi, Baby club značka, veľkosť 74	38	1.1000000000000001	f	-	0	10	1	2012-10-13 08:17:27+02
1500	hnedé teplé polodupačky otvorené s ružovým kvietkom a hnedou gombičkou na ľavej nohe, vzadu srdiečkové vrecká, veľkosť 6 - 9m, Cherokee	38	1.5	f	-	0	7	1	2012-10-13 08:17:50+02
5539	tmavomodra mikina GANT	142	5	f	-	0	10	2	2012-10-13 15:26:50+02
5544	seda mikina-SOCCER,1OOcm,modre lemy	142	5	f	-	0	15	1	2012-10-13 08:41:41+02
5543	seda mikina,modra kapuca aj rukavy,v 98	142	5	f	-	0	14	1	2012-10-13 08:41:48+02
5574	zimne GEOX oranzove lemovanie	142	5	f	-	0	45	2	2012-10-13 15:26:50+02
5541	bledozelene tricko F+F	142	2	f	-	0	12	1	2012-10-13 08:42:02+02
5557	PALOMINO modre pyzamo	142	4	f	-	0	28	2	2012-10-13 18:23:18+02
5542	flisova seda mikina MARINES	142	5	f	-	0	13	2	2012-10-13 15:26:50+02
5538	Frote-kupaci plast SPIDERMAN	142	3	f	-	0	9	1	2012-10-13 08:42:22+02
5581	Červeno-šedý zimný overal	144	15	f	-	0	3	2	2012-10-14 12:09:58+02
5537	bledomodre tricko,3 roky,-VINTAGE-beneton	142	2	f	-	0	8	2	2012-10-14 11:40:35+02
5546	tmavomodre teplaky	142	2	f	-	0	17	2	2012-10-13 15:23:25+02
5534	rifle,v98,cvocky aj gombik-N oznacenie	142	5	f	-	0	5	1	2012-10-13 08:43:01+02
5533	modre rifle-zlty lev-28	142	5	f	-	0	4	1	2012-10-13 08:43:04+02
5532	oranzovy pulover-lod vpredu-biela-SILVER	142	4	f	-	0	3	1	2012-10-13 08:43:09+02
5531	sede rifle-oranzovy opasok  98cm	142	6	f	-	0	2	1	2012-10-13 08:43:20+02
5530	svetrik paskovany modra-cervena-biela beneton	142	6	f	-	0	1	1	2012-10-13 08:43:22+02
5554	modre tricko SLONIK	142	2	f	-	0	25	2	2012-10-13 17:53:55+02
5569	tricko,biely dlhy rukav,sede pasy,v 86,vpredu napis 73	142	2	f	-	0	40	2	2012-10-13 17:53:55+02
5535	sede menz.v 98,-GRADED-oranz.stitok	142	5	f	-	0	6	2	2012-10-13 15:22:10+02
5561	nohavice sede v 80,vpravo napis -baby	142	3	f	-	0	32	1	2012-10-13 08:44:43+02
5560	Rifle v 86 vzadu napis POLICE	142	5	f	-	0	31	1	2012-10-13 08:44:46+02
5559	nohavice tm.modre v 86,na kolenach vrecka	142	3	f	-	0	30	1	2012-10-13 08:44:49+02
5558	presivana vesta-oranzova podsivka	142	6	f	-	0	29	1	2012-10-13 08:44:52+02
5577	Cerveno-cierne teniskyGEOX	142	3	f	-	0	48	2	2012-10-13 18:42:27+02
5556	tmavomodry sveter-na chrbateTIMBERLAND	142	5	f	-	0	27	1	2012-10-13 08:45:03+02
5552	zelene trickoBABY TOUR 08	142	2	f	-	0	23	2	2012-10-13 17:47:48+02
5540	tmavozelene tricko BENETON	142	2	f	-	0	11	2	2012-10-13 17:59:36+02
5553	tricko sede,dlhy rukav,vpredu cerv.aplikacia a..n	142	2	f	-	0	24	1	2012-10-13 08:45:12+02
5564	tricko-tm.modre,dlhy rukav,v 86	142	2	f	-	0	35	2	2012-10-13 17:53:55+02
807	krátke zelené body s kravičkou,pyžamko zelené s farebnými pásikmi a kravičkou, vel. 62, C&A	18	2	f	-	0	18	2	2012-10-14 11:17:02+02
5550	tricko cervene,biely rukav,obr-SPIDERMAN	142	2	f	-	0	21	1	2012-10-13 08:45:19+02
5549	bordove tricko,biele rukavy,v 98	142	2	f	-	0	20	1	2012-10-13 08:45:21+02
5548	oranz.tricko,dlhy rukav,v 98_ACES-HIGH	142	2	f	-	0	19	1	2012-10-13 08:45:23+02
5547	mikina v 98,kratky zips,napis OKI-DOKI	142	5	f	-	0	18	1	2012-10-13 08:45:28+02
5571	materske rifle v S	142	10	f	-	0	42	1	2012-10-13 08:45:37+02
5570	materske rifle v 40 ,vysoke brusko	142	10	f	-	0	41	1	2012-10-13 08:45:40+02
4110	ružový kabátik,CHEROKEE,veľ.4-5r.	105	8	f	-	0	1	2	2012-10-13 17:00:09+02
5565	pasikave tricko bl.modra-hneda	142	2	f	-	0	36	2	2012-10-13 17:53:55+02
5568	kosela+vesta+viazanka	142	6	f	-	0	39	1	2012-10-13 08:46:05+02
4156	modré zimné čižmy,PROTETIKA,zips,šnurovanie	105	9	f	-	0	47	2	2012-10-13 14:53:34+02
4126	fialovošedé pásikové tričko,PALOMINO,veľ.104	105	1	f	-	0	17	2	2012-10-13 16:20:44+02
5551	polokosela,bordova,86-98cm-SCRUABAN-	142	3	f	-	0	22	2	2012-10-14 09:48:06+02
5573	modre adidas vel 26	142	3	f	-	0	44	2	2012-10-13 17:07:06+02
5555	cervene tricko Beneton	142	2	f	-	0	26	2	2012-10-13 17:47:48+02
5575	biele adidas vel 26	142	3	f	-	0	46	1	2012-10-13 08:50:30+02
5578	Bezovo-cervene tricko MONKEY	142	1	f	-	0	49	2	2012-10-13 16:34:29+02
1254	pletený dievčenský sveter, farba biela, veľ. L/XL	29	2	f	-	0	15	1	2012-10-13 08:59:37+02
5579	Šedá chlapčenská bunda	144	3	f	-	0	1	1	2012-10-13 10:31:26+02
5588	Tmavomodrý dievčenský plášť skáro.lemom a potlačou Horal Nature	144	4	f	-	0	10	1	2012-10-13 10:31:36+02
5587	Tmavomodrá prechodná bunda veľká	144	3	f	-	0	9	1	2012-10-13 10:31:42+02
5586	Tmavomodrá prechodná bunda	144	3	f	-	0	8	1	2012-10-13 10:31:46+02
5585	Červené oteplovačky	144	2	f	-	0	7	1	2012-10-13 10:31:55+02
5584	Bielo-červeno-modrá tenká bunda	144	2	f	-	0	6	1	2012-10-13 10:32:03+02
5583	Tmavomodrá tenká bunda	144	2	f	-	0	5	1	2012-10-13 10:32:13+02
5580	Tmavomodré zimné oteplovačky -Bavlna	144	3	f	-	0	2	1	2012-10-13 10:32:26+02
3435	čierne rifle Rainbow	88	2.7999999999999998	f	-	0	2	1	2012-10-13 11:52:15+02
5562	vetrovka+flisova mikina	142	10	f	-	0	33	2	2012-10-13 15:21:06+02
5572	cervene CROCS 8-9	142	3	f	-	0	43	2	2012-10-13 16:26:43+02
5536	polokosela cerveno-biela GATE	142	5	f	-	0	7	2	2012-10-14 11:40:35+02
1541	Ružová flísová tepláková súprava, veľ. 80	40	4	f	-	0	1	1	2012-10-13 08:21:00+02
1542	Ružová bavlnená teplákova súprava, OshKoshBigosh, veľ. 104	40	8	f	-	0	2	1	2012-10-13 08:21:27+02
2592	šedé tričko so striebor. aplikáciou ( silueta dievča ), čierny lem, vel.82	67	2.5	f	-	0	18	1	2012-10-13 08:31:54+02
1046	Červená lyž. bunda s béžovými pásmi, zn.TOG24, veľ.S    NOVÁ	25	20	f	-	0	1	1	2012-10-13 08:36:53+02
1050	tmavozelená zimná bunda s výšivkou na chrbte, zn.Hoperise, veľ.:104	25	10	f	-	0	5	1	2012-10-13 08:37:34+02
313	vesta, nohavice, košela, kravata, šedé 18-24m	7	6	f	-	0	24	1	2012-10-13 08:47:34+02
538	hnede tricko	12	1.7	f	-	0	29	1	2012-10-13 08:56:00+02
4024	červené sametové nohavice s vreckami n bokoch v oblasti kolien, č. 116	103	2	f	-	0	15	1	2012-10-13 08:59:36+02
4033	pásikavá bielomodrá čiapočka, motív macko, zn. Dyem	103	2	f	-	0	24	1	2012-10-13 09:00:29+02
1892	teplaky modre, kids kode 12, Gate vel. 24 mes.	48	1	f	-	0	24	1	2012-10-13 09:06:30+02
5308	hrubý ružový sveter s gombíkmi	136	2.5	f	-	0	6	1	2012-10-13 09:19:42+02
1176	Tričko dlhý rukáv My litlle pony s kapucou veľ.68	27	2.5	f	-	0	37	1	2012-10-13 09:39:07+02
2058	svetrík prúžkový s kapucou na 3gombíčky,veľ.12-18m,cherokee	54	4	f	-	0	1	1	2012-10-13 09:50:48+02
2100	bunda bledo ružová s kapucou a vyšitou minnii,12m,disney	54	15	f	-	0	43	1	2012-10-13 09:53:43+02
2529	Čiapka - zimná -zeleno-šedo-bielo-čierna, čierny brmbolec, na ušiach strapčeky - CHEROKEE (4-8yrs) 	66	4	f	-	0	5	1	2012-10-13 09:59:26+02
2559	Mikina -flauš-modrá, vpredu vyšitá hlavička medvedíka,rukávy predelené bledým pásikom	66	1.1000000000000001	f	-	0	35	1	2012-10-13 10:00:55+02
2987	ruz.sus.overal,kapuc.s uskami, zap.zips aj lepky,vys.hlavy maciek,zn. Baby Basics,v.74	75	8	f	-	0	48	1	2012-10-13 10:04:10+02
2964	bielo-oranz. plys.dupack. overal, vpravo vysiv.Pluto,boc. zapin na pat., boc.vrecko s vys. husenicou,v. 80, zn. Disney 	75	3	f	-	0	25	1	2012-10-13 10:05:05+02
2948	bledo-zel. chlpata trigovica, vys. viacfareb. kuriatka s bielymi bambulkami,, patenty na ruk. aj vo vystrihu, zn.neud., v.74  	75	3	f	-	0	9	1	2012-10-13 10:05:55+02
3838	Riflová sukňa s ružovým pásikom Cherokee veľ. 9-12 mes.	98	3	f	-	0	32	1	2012-10-13 10:23:26+02
5589	Modre teplaky, biely modry pruh	131	0.5	f	-	0	27	1	2012-10-13 10:41:23+02
1761	Dupacky Domaja, zeleno biele v predu napis a psik s vtacikom 	45	2	f	-	0	24	1	2012-10-13 10:45:57+02
1765	Zimna bunda tmavo modra vpredu napis znacka cherokee na 9-12mes.	45	5	f	-	0	28	1	2012-10-13 10:46:38+02
5590	Tehotenske nohavice modre, vysivka	24	12	f	-	0	12	1	2012-10-13 10:57:48+02
5591	Puover bezovy tmave pasiky	24	2	f	-	0	13	1	2012-10-13 10:58:09+02
1689	rupsačik  chicco kačička žlto oranž. Červený asi 25cm	43	7	f	-	0	24	1	2012-10-13 11:07:57+02
5592	Hnede topanky suchy zips v 30	43	5	f	-	0	46	1	2012-10-13 11:13:21+02
5593	Baleriny bezove	43	5	f	-	0	47	1	2012-10-13 11:14:11+02
1225	Červený pulover,v strede a na rukáve hnedý,čierny a biely pásik	28	2.5	f	-	0	36	1	2012-10-13 11:21:33+02
1194	Čierne zimné topánky, suchý zips, na boku čierna mašlička, veľ.21	28	4	f	-	0	5	1	2012-10-13 11:25:46+02
1863	Žltomodrá mikina s kapucou na zips na spodu i rukávoch patent, veľ. 74	47	9.5	f	-	0	26	1	2012-10-13 11:43:36+02
1394	Červená zimná čiapka s modrým a bielym vzorom na uviazanie	34	1	f	-	0	4	1	2012-10-13 11:45:50+02
5086	fialové botasky na suchý zips veľ.26	127	2	f	-	0	47	1	2012-10-13 12:09:29+02
4833	tričko dlhý rukav,s mackom modré s červenými  a bielymi pásikmi	122	1	f	-	0	7	1	2012-10-13 12:14:27+02
3497	overal bodkovany 0-3mes. S volanikmi na zadočku	89	2.2000000000000002	f	-	0	45	1	2012-10-13 12:30:50+02
4652	ruzovy pulovrik s limcekom 	118	0.29999999999999999	f	-	0	26	1	2012-10-13 12:43:50+02
4637	zlta hackova ciapka 	118	3	f	-	0	11	1	2012-10-13 12:45:04+02
5337	pletený sveter bordovo farebný s pásiky a kapucňa	136	3.8999999999999999	f	-	0	35	2	2012-10-13 14:53:34+02
3462	ružový overal zimný Ladybird 6-9mes.+rukavičky+papučky	89	7	f	-	0	10	2	2012-10-13 15:33:00+02
510	zeleny kabatik next 86	12	10.5	f	-	0	1	2	2012-10-13 15:57:43+02
525	pasik. Sveter modry	12	3.6000000000000001	f	-	0	16	2	2012-10-13 16:32:00+02
1808	Ružová tepláková mikina s kapucou,pásikavé rukávy, s poníkom	46	3.2999999999999998	f	-	0	21	2	2012-10-13 16:45:27+02
2064	2ks rolák červený so srnkou,sedý s malou srnkou,veľ.86/92	54	4.5	f	-	0	7	2	2012-10-13 16:48:23+02
1571	Ružové podšité športové nohavice, Cherokee, veľ. 92	40	5	f	-	0	32	2	2012-10-13 16:50:52+02
1869	topanky bled.hnede, snurovanie, GORATEX, RICHTER, vel. 24	48	5	f	-	0	1	2	2012-10-13 16:55:58+02
556	nohavice ruzove podsite 104	12	3.8999999999999999	f	-	0	47	2	2012-10-13 17:00:09+02
3747	Next súprava čiapka + rukavice s hviezdičkami 1-2 roky	96	4	f	-	0	28	2	2012-10-13 17:18:28+02
1775	Bundicka seda vnutro ruzove, s kapucnou na vacku motyl a kvet	45	6	f	-	0	38	2	2012-10-13 17:20:39+02
3720	Zimná bunda hnedá s fialovou podšívkou s kapucňou veľ.98	96	10	f	-	0	1	2	2012-10-13 17:35:08+02
290	tmavo šedá čiapka, šál, rukavice	7	0.80000000000000004	f	-	0	1	2	2012-10-13 17:50:43+02
1899	kombineza tm.modra+čiapka biela, nasivka macko s kocikom,vel. 86	48	6	f	-	0	31	2	2012-10-13 17:54:58+02
4010	slabo plyšový modrý zimný overal, vpredu motív tigra z Macka Puh, 9-12 mes.	103	8	f	-	0	1	2	2012-10-13 18:04:39+02
2578	béžové lakované čižmičky, na boku s drobnými kvetinkami, vel. 20	67	2	f	-	0	4	2	2012-10-13 18:38:14+02
2099	bunda ružová s kvetinkami,vel.6-9m,next	54	9	f	-	0	42	2	2012-10-13 18:41:41+02
1589	Hnedá otepľovacia súprava s kapucou (rukavice, návleky na nohy), veľ. 74	40	9	f	-	0	50	2	2012-10-13 18:58:17+02
1140	Ružový zimný menčestrový overal s vyšívanými motýlikmi 0-3mes.	27	4	f	-	0	1	2	2012-10-14 10:48:25+02
1884	bunda tmav.modra šuštiakova, pleteny rukav, cherokee, vel.:18-24mes	48	4	f	-	0	16	2	2012-10-14 11:09:55+02
1167	Tričko dlhý rukáv s ružovo modro žltými pásikmi 3-6 mes. 	27	1	f	-	0	28	2	2012-10-14 13:06:53+02
2523	3ks ,trička modré,šedé,červené s dlhým rukávom vel 74-80	65	1	f	-	0	39	1	2012-10-13 08:23:03+02
854	ružove tepláky s bielými pásikmi, vel. 	19	0.29999999999999999	f	-	0	25	1	2012-10-13 08:24:29+02
2521	2ks, košielka, modrá zo psíkom, zelena s mackom vel. 56-62	65	1.6000000000000001	f	-	0	37	1	2012-10-13 08:25:14+02
2489	pyžamko baby club, pásikové oranž.-kávove s koníkom, vel. 56	65	2	f	-	0	5	1	2012-10-13 08:28:28+02
3783	manchestrove nohavice – modré, vek 5-6	97	2	f	-	0	14	1	2012-10-13 08:33:05+02
4717	svetrik s kapucnou sivy	119	2	f	-	0	41	1	2012-10-13 08:33:39+02
4698	Tricko s dlhym rukavom  bfc 80, cerveno sive	119	5	f	-	0	22	1	2012-10-13 08:35:02+02
4249	Mikina Next, bielo-modra pruzkata, 3-6 mes	108	2	f	-	0	3	1	2012-10-13 08:41:33+02
5112	modrošedé dupačky s macíkom na vreckách, veľ. 6-9 m.	128	2	f	-	0	23	2	2012-10-13 16:41:59+02
4731	biele tričko, veľ. 74	120	1	f	-	0	5	1	2012-10-13 09:46:17+02
4732	modrozelené tričko, veľ. 68	120	1.5	f	-	0	6	1	2012-10-13 09:46:20+02
3770	tričká TOY STORY /2 ks/modré+zelené/ č.104	97	1.5	f	-	0	1	2	2012-10-13 15:26:50+02
1292	modrá čapica+šál+rukavice	30	1.5	f	-	0	26	1	2012-10-13 08:47:02+02
1313	modrá čiapka s kompasom	30	1	f	-	0	47	1	2012-10-13 08:47:49+02
1251	rifľová dievčenská sukňa s ružovým lemovaním, veľ. 128	29	2	f	-	0	12	1	2012-10-13 08:53:48+02
2862	tenisky biele s modrými pásmi Adidas, veľ. 23	73	2	f	-	0	20	1	2012-10-13 08:56:00+02
431	tricko s dl. Rukavom bielo ruzove	9	1	f	-	0	42	1	2012-10-13 09:00:17+02
3283	Detský overal ružový s bledoružovou farbou po bokoch na dva zipsy, obrázok žirafa a vtáčik, veľ.68, zn. Zebra	84	8	f	-	0	3	1	2012-10-13 09:02:39+02
3310	Ružovo-fialková vestička s kožušinkovým lemovaním na kapucke, potlač kvietky, dve vrecká vpredu,zn. F&F, veľ. 6-9 mesiacov	84	6.5	f	-	0	30	1	2012-10-13 09:03:12+02
451	hnede tricko dl. Rukav	10	2	f	-	0	17	1	2012-10-13 09:04:16+02
3299	Ružové tričko s dlh.rukávom,zapínanie gombíky, vpredu anjelik s mašličkou,tmovo-hnedé guličky na rukáve, OKAY,veľ. 80	84	2.7999999999999998	f	-	0	19	1	2012-10-13 09:05:07+02
4323	Tmavomodré body s pásikovými rukávmi, veľ.cca 12-18 mesiacov	111	1.7	f	-	0	6	1	2012-10-13 09:06:13+02
472	riflove saty s fial. Pruzkom	10	4	f	-	0	38	1	2012-10-13 09:06:07+02
1325	Biela prechodná háčkovaná čiapka, veľ. 1,5 roka	31	2	f	-	0	9	1	2012-10-13 09:07:15+02
1514	trigovica tm.modrá,flaušová, zelené pásiky,s kapucou,vpredu vrecko,GEORGE,veľ.8/9r.	39	3	f	-	0	5	1	2012-10-13 09:09:37+02
4349	Ružové dupačky na cvoky s dlhým rukávom, zn. Cherokke, veľ. 3-6 m.	111	2.5	f	-	0	32	1	2012-10-13 09:09:58+02
1355	Bledomodrá mikina flaušová s kapucňou a zipsom, veľ. 110/116	31	2	f	-	0	39	1	2012-10-13 09:12:51+02
1979	bunda zimná zelená s nápisom kind sport	51	3	f	-	0	34	1	2012-10-13 09:14:11+02
2884	rolák hnedobéžový s polodlh. Rukávom, bez značky, v. 140	73	1.5	f	-	0	42	1	2012-10-13 09:14:28+02
1968	nohavice bledohnedé - cervený pasik na boku	51	1	f	-	0	23	1	2012-10-13 09:17:00+02
2404	tepláková súprava trigovica s macíkmi + tepláčky, veľ. 12 mes.	63	10.4	f	-	0	1	1	2012-10-13 09:17:34+02
2407	bodkovaný flísový kabátik Next, ružovo-hnedo-červený, veľ. do 3 mes. 	63	6.7999999999999998	f	-	0	4	1	2012-10-13 09:17:52+02
2854	hnedá bunda s béžovým odopínateľným futrom Hummelsheim, veľ. 150	73	2.5	f	-	0	12	1	2012-10-13 09:19:15+02
3065	vínové šatky spoločenské, 4-5 rokov	77	5	f	-	0	26	1	2012-10-13 09:23:39+02
2354	olivové menžestráčky, dolu s cvokmi a vačkami, veľ. 116	62	4.5999999999999996	f	-	0	1	1	2012-10-13 09:27:48+02
3077	menžestráčky smotanové s trakmi, veľ. 92	77	1.5	f	-	0	38	1	2012-10-13 09:28:37+02
3052	ružová tepláková bundička, 5-6 rokov	77	2	f	-	0	13	1	2012-10-13 09:30:14+02
2385	fialový roláčik s kvetinkou vpredu C&A, veľ. 68	62	2.5	f	-	0	32	1	2012-10-13 09:35:35+02
289	čierne tehotenské menčestráky, WINDSTAR, veľ. S	6	11	f	-	0	2	1	2012-10-13 09:39:05+02
742	Zeleno-modrý semišový gymnastický dres s kamienkami, veľ. 130-140	17	1.5	f	-	0	3	1	2012-10-13 09:42:23+02
789	Batikované šedo-zelené menčestrové šaty, nášivka psíka, Á-čkový strih	17	2	f	-	0	50	1	2012-10-13 09:42:25+02
907	Bielo-modrá pásikavá blúzka s čipkou na golieri, veľ. 110	21	1	f	-	0	1	1	2012-10-13 09:43:43+02
910	Tmavomodrý sveter na gombíky s modro-bielym vzorom, širokým patentom, H&M, veľ. 92	21	2	f	-	0	4	1	2012-10-13 09:43:43+02
4753	biele body vpredu modrý levík, veľ. 3-6 m.	120	1	f	-	0	27	1	2012-10-13 09:49:21+02
4773	modrá súprava: bielomodré prúžk. Tričko, nohavice na traky s mackom, veľ.62	120	4	f	-	0	47	1	2012-10-13 09:50:54+02
5090	tmavošedé menčestráčiky, veľ. 68	128	2.5	f	-	0	1	1	2012-10-13 09:52:16+02
4196	Tričko ružové Hot&spicy 140           	106	2.2000000000000002	f	-	0	40	1	2012-10-13 09:55:15+02
1645	suprava teplaky,tricko ,vesta, bledo seda s tmavo modrou,vpredu aplikacia orla,vel.4	42	2.1000000000000001	f	-	0	23	1	2012-10-13 09:55:40+02
4365	Bledo modré rifle s kamienkami 	112	1.8999999999999999	f	-	0	3	2	2012-10-13 15:34:57+02
3806	komplet postelné prádlo na postielku /žltozelené/ s bočnou ochranou	97	9	f	-	0	37	2	2012-10-13 16:02:17+02
1648	sametovy overal,modro oranzovy,pasiky hnede s oranzovo modrou,vpredu zajko,vel.92	42	1.8999999999999999	f	-	0	26	2	2012-10-13 16:02:17+02
3040	zimná bunda modrá, veľkosť  7-10 rokov	77	4.5	f	-	0	1	2	2012-10-13 16:02:29+02
391	snehule ADIDAS	9	8.5	f	-	0	2	2	2012-10-13 16:09:44+02
410	zateplene bledoruzove nohavice	9	3.7000000000000002	f	-	0	21	2	2012-10-13 16:34:29+02
5545	Sveter 3 zipsy 75napis	142	5	f	-	0	16	2	2012-10-13 16:39:58+02
5365	biela mikina,podšitá sivou kožušinkou,kapuca,nápis ATHL.,H&M,v.74	137	7	f	-	0	20	2	2012-10-13 17:03:24+02
2496	dupačky modre s mackom a hviezdou, vel. 56	65	2	f	-	0	12	2	2012-10-13 17:10:51+02
1314	modrá čiapka+šál+rukavice	30	1.5	f	-	0	48	2	2012-10-13 17:50:43+02
5563	Tricko-oranzove 86v-napis JUNIOR PILOT-	142	2	f	-	0	34	2	2012-10-13 17:53:55+02
5566	8ks  pancusky pozor predavat po kusoch pozor	142	8	f	-	0	37	2	2012-10-13 18:22:27+02
4375	Bunda šušťáková ružovo-modrá ADIDAS	112	2.8999999999999999	f	-	0	13	2	2012-10-13 18:28:04+02
4206	Vesta bordová 116 s hello kitty       	106	6	f	-	0	50	2	2012-10-14 12:01:37+02
1279	rifle na traky veľ.6-12mes.	30	2	f	-	0	13	2	2012-10-14 12:58:26+02
1385	chlapčenský bledomodrý pulovrík s macíkmi, 6M	32	2	f	-	0	19	1	2012-10-13 09:59:15+02
2145	čapica tmavomodrá, nápis 23	55	1.3	f	-	0	38	1	2012-10-13 10:06:06+02
3213	balerínky bielo/strieborné, veľ. 30	81	7	f	-	0	1	1	2012-10-13 10:09:00+02
3216	kabátik károvaný s kapucňou, šedo/ružový, veľ. 110	81	20	f	-	0	4	1	2012-10-13 10:09:57+02
2238	tyrkysová mikoinka s kapuckou zn.NEXT,veľ.98	58	5	f	-	0	10	1	2012-10-13 10:37:11+02
3197	Flaušový pulovrík, so sloníkom, pri krku na zips	80	1	f	-	0	35	1	2012-10-13 10:41:52+02
4218	Chlapčenská jesenná bunda, šedá s tyrkys. a červeným pasikom na rukáve, kapucňa, vel. 128 	107	7	f	-	0	12	1	2012-10-13 10:43:36+02
651	teplaky+bunda s kapucou,šedá, cactus clone,9-12m     2ks	14	3	f	-	0	42	1	2012-10-13 10:53:36+02
3424	sveter tcm 98/104 m odro červeny s aplikaciou na rukave 	87	1.5	f	-	0	41	1	2012-10-13 11:01:35+02
3396	bunda nike vel.S heigh 163 červená so šedými rukavmi s napisom na chrbte nike	87	20	f	-	0	13	1	2012-10-13 11:03:26+02
3606	ružové flísové polodupačky zn. New Born, veľ. 56	93	2	f	-	0	1	1	2012-10-13 11:32:47+02
3612	bledoružové šuštiakové nohavice na traky zn.Adam Kids, veľ. 68	93	4	f	-	0	7	1	2012-10-13 11:33:05+02
2902	modré pásikové tričko, nápis BMX,šedé rukávy, veľ.116	74	3	f	-	0	13	1	2012-10-13 11:55:49+02
242	Reserved hnedo ružové tričko, flitre, veľ 6-7 r	4	1.2	f	-	0	41	1	2012-10-13 12:01:54+02
588	oranžovo hnedá čiapka, vpredu Tweety, flaušová	13	3	f	-	0	29	1	2012-10-13 12:09:19+02
5595	Béžová bunda, podšitá umelou kožušinou, veľ. cca 164	140	8	f	-	0	11	1	2012-10-13 13:09:27+02
2237	tmavomodré rifle zn.NEXT,veľ.98	58	4	f	-	0	9	2	2012-10-13 15:28:42+02
618	košela karová,ružovo-modro-strieb.pásik, 146/152	14	5	f	-	0	9	2	2012-10-13 16:32:00+02
4951	Rifle tmavomodré zateplené dolu patent vzadu a na boku vrecká zn Lindex	125	3.5	f	-	0	35	2	2012-10-13 16:39:58+02
3407	snehule richter tmavo hnede šnurovacie vel.27	87	6.5	f	-	0	24	2	2012-10-14 11:06:18+02
2155	hnedý plet.sveter podšitý šedým flísom 2-3 r. cherokee	56	3.5	f	-	0	6	2	2012-10-14 11:09:54+02
3863	ponožkové papučky, 2 páry (sobík, sloník štrikovaný) veľ.9-18mes.	99	1	f	-	0	7	1	2012-10-13 10:07:25+02
3900	šedáTeplák.súpr.veľ.6-9mes.bunda sOranž.č.58 naPredu a č.8na nohav.	99	3	f	-	0	44	1	2012-10-13 10:09:01+02
3896	2ks bavlnené tričko s dlh.ruk.2cvoky pri krku,veľ.62-68cm(oranž.hnedé prúžky,hnedobiele s nápisom“power race“	99	0.59999999999999998	f	-	0	40	1	2012-10-13 10:09:41+02
887	Biely roláčik s modrým bolerkom, potlač kvety a motýle, zn. DopoDopoMini, vel. 86	20	3	f	-	0	24	1	2012-10-13 10:22:26+02
5400	nepremokava zateplena bunda oranzovo hneda,vel74cm, zn TU	138	3.2999999999999998	f	-	0	20	1	2012-10-13 10:39:03+02
2325	Tričko biele, s predu štrikované s čiernym a ružovým motílom, značka Alan	60	4.2000000000000002	f	-	0	27	1	2012-10-13 10:46:45+02
2460	Dupky plyš modrý s chlapčekom	64	5	f	-	0	7	1	2012-10-13 11:05:06+02
3517	bunda zimná modrá, kapuca s kožušinkou, Kenvelo, veľkosť 152	90	5.5	f	-	0	15	1	2012-10-13 11:13:54+02
3666	pyžamko bielej farby s farebnými guličkami, F§F.ve l6-9mes.	94	2.5	f	-	0	11	1	2012-10-13 11:44:47+02
4804	ZUPAN BIELY, VELKOST 98	121	2.2000000000000002	f	-	0	28	1	2012-10-13 11:46:49+02
254	Zimné topánky chlapč.,šedočierne,na suchý zips,KEY TREK,veľ.30	5	7	f	-	0	3	1	2012-10-13 11:54:07+02
4063	Bledo zel. saty s kapucnou,bielymi rukavmi,napisom,motylom  vel.80	104	2.5	f	-	0	4	1	2012-10-13 11:59:04+02
3951	rifľová bundička, s rifľovým kvietkom na ľavej str., zn. F&F, veľ. 9-12	101	2.5	f	-	0	17	1	2012-10-13 12:13:37+02
4890	bledomodrá mikina s kapucou flisová zn.TIMBUKTOO,v.152	123	1.5	f	-	0	31	1	2012-10-13 12:56:43+02
2094	nohavice na traky šuštiakové-oteplovačky červené,veľ.80	54	4.5	f	-	0	37	2	2012-10-13 14:46:08+02
1120	polokosela modro-cervena                                                                           2	26	2	f	-	0	31	2	2012-10-13 16:37:00+02
4343	Šedobiele pásikové tričko s modrými rukávmi, zn. Cherokee, veľ.4-5 r.	111	2.5	f	-	0	26	2	2012-10-13 16:45:05+02
5385	seda vesta BABY s kapucnou, velkost 12mes	138	2.2000000000000002	f	-	0	5	2	2012-10-13 17:13:47+02
5594	Bledomodra bunda na zips s bielym pasikom v.9-12m	79	2	f	-	0	42	2	2012-10-13 17:17:11+02
3895	šedomodré nohavice,možnosť skrátiť gombik.na3/4,veľ.12-18mes.bledomodrá podšívka	99	0.59999999999999998	f	-	0	39	2	2012-10-13 17:24:17+02
2296	vyteplené zelené nohavice na traky,zn.HM,vel.9-12,1 ks	59	1.5	f	-	0	48	2	2012-10-13 17:24:17+02
5214	Bielo-ružová súprava so zajačikmi (dupačky+kabátik), veľ. 68-74	134	1.5	f	-	0	12	2	2012-10-13 17:30:27+02
5349	červená čiapka,zeteplená ružovou bavlnkou,vpredu kitty,H&M,80	137	3	f	-	0	4	2	2012-10-13 18:03:40+02
3442	ružové tričko so strieborným opaskom a kapucňou, dlhý rukáv, nápis 	88	2	f	-	0	9	2	2012-10-13 18:12:35+02
4814	TRIGOVICA S KAPUCOU, S CISLOM 66, VELKOST 7 ROKOV	121	2.2000000000000002	f	-	0	38	2	2012-10-13 18:34:08+02
2183	set, kvietkova vesta a ružová flisová mikina s kapucňou veľ.98	57	4	f	-	0	1	2	2012-10-13 18:49:05+02
2215	súprava nohavice ružové,bundička s medvedíkom a čiapka ružová veľ.86	57	3	f	-	0	33	2	2012-10-14 13:10:21+02
958	čierna mikina na zips, s kapucou, ,na L.strane stiebornou nitkou vyšitý ornament, MIX, 92	22	1.8	f	-	0	24	1	2012-10-13 10:27:43+02
964	3ks pančúch dievčenských-2ks červené s motívmi hello kitty, zn.Hello kitty,1ks bledoružové s bielymi pásikmi od stehien dole,LUPILU,86	22	2.5	f	-	0	30	1	2012-10-13 10:28:55+02
5181	cierno sedy rolak,ruza	133	2	f	-	0	1	1	2012-10-13 10:57:15+02
4561	Blúza -aj tehotenská, farby čierno, zeleno fialová, zn. Stradivarius, v.L	116	6	f	-	0	25	1	2012-10-13 11:07:37+02
4547	Blúzočka na gombíky, biela s drobnými kvietkami, HM,v.74	116	2	f	-	0	11	1	2012-10-13 11:10:39+02
5169	ružova zimna bundička s 2 mackami  veľ86	132	2	f	-	0	9	1	2012-10-13 11:35:10+02
3696	smotanovy teply overalik s modrymi vzormi zajkov, Ideal, 6/9 mesiacov	95	2.3999999999999999	f	-	0	27	1	2012-10-13 11:58:08+02
5261	Dievčenská prechodná bunda s kožušinkou vo vnútri Next veľ. 6-9	135	18	f	-	0	9	1	2012-10-13 12:02:43+02
5276	Tmavomodrá prechodná bunda veľ. 1 - vpredu stromčeky a macko	135	3	f	-	0	24	1	2012-10-13 12:07:50+02
5596	Hneda bunda Cherokee	145	3	f	-	0	1	1	2012-10-13 13:19:03+02
5597	Modra zimna bunda (6-9 mesiacov)	145	2	f	-	0	2	1	2012-10-13 13:19:18+02
5598	Zelena farba baba dopracov	145	2	f	-	0	3	1	2012-10-13 13:19:39+02
5599	Overal - celovecerny zimne saty na dieta	145	5	f	-	0	6	1	2012-10-13 13:20:06+02
5600	Cierne rifle "kraus"	145	4	f	-	0	8	1	2012-10-13 13:20:33+02
5601	Modre rifle "Stone river classic"	145	4	f	-	0	9	1	2012-10-13 13:20:55+02
5602	Čierne rifle "opium"	145	4	f	-	0	10	1	2012-10-13 13:21:10+02
5603	Čierne topánky	145	5	f	-	0	11	1	2012-10-13 13:22:31+02
3577	čierne tričko dlh. Rukáv s basketbalistom	92	0.5	f	-	0	22	2	2012-10-13 15:11:23+02
4868	zateplené šedé nohavice zn.PALOMINO,v.92, NOVé	123	7	f	-	0	9	2	2012-10-13 15:28:42+02
3150	Nohavice (šušťáky)zateplené,tmavomodré veľ.128-134	79	2	f	-	0	16	2	2012-10-13 15:45:41+02
3821	ružová tepláková súprava s bielou kapucňou Baby Club veľ. 86	98	6	f	-	0	15	2	2012-10-13 16:21:45+02
3558	červená zimná bunda s nažehlovačkou hello kitty	92	1.5	f	-	0	3	2	2012-10-13 16:44:40+02
2976	modra flausova podsita ciapka s bielym siltom, vzadu vysity viacfareb. sob, zad. stah. na gumicku, v. 37-39cm, zn. neud.	75	2	f	-	0	37	2	2012-10-13 17:17:43+02
967	biela teplá pružná úpletová čiapka na zaväzovanie s ružovým pásikom, našitou kvetinkou,navrchu mašlička biela zopnutá ruž.kamienkom, vel. Cca 3-9 mesiacov	22	3	f	-	0	33	2	2012-10-13 17:30:27+02
986	ružovofialkové zimné šuštiakové palčiaky s fialovým srdiečkom navrchu, biela kožušinka na patente, Thinsulate, cca 1-roky	23	2.5	f	-	0	2	2	2012-10-13 17:36:30+02
5604	Kozuch tygrovany	90	35	f	-	0	18	1	2012-10-13 17:45:10+02
668	Červený svetrík,zn. Early days, s kapucňou na zips, v. 18-23 mes	15	3.5	f	-	0	9	2	2012-10-13 17:50:54+02
985	bledohnedé lyžiarske.nohavice na traky-odopínatelné, SAM, vel.122	23	6	f	-	0	1	2	2012-10-13 17:56:04+02
1711	prechodna ciapka bavlna,hneda, pasik hnedo bezovy,so siltom na snurky,46-48cm	44	2.6000000000000001	f	-	0	1	2	2012-10-13 18:04:39+02
1712	tepla ciapka,modro bielo s cerven.pasikom,modry brbolec,vnutri kozusina,vpredu auto+modry sal,12mes	44	5.4000000000000004	f	-	0	2	2	2012-10-13 18:22:27+02
4634	tričko modré, dlhý rukáv cherokee v. 3-4 r.	118	1	f	-	0	8	2	2012-10-13 18:33:37+02
4989	Hnedé kožené zimné topánky na 2 lepky vo vnútri s kožušinou	126	4.7999999999999998	f	-	0	36	2	2012-10-13 18:33:44+02
4100	Fialove Bama topanky-suchy zips s kamienkovym srdieckom na boku	104	7.5	f	-	0	41	2	2012-10-13 19:02:11+02
5190	cierny kozenny kabatik s kapucou na zips,v strede zavazovanie	133	3	f	-	0	10	2	2012-10-14 14:07:37+02
\.


--
-- TOC entry 1813 (class 0 OID 16442)
-- Dependencies: 142
-- Data for Name: seller_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY seller_category ("ID", "LETTER", "NAME", "FEE", "FEE_SOLD_PERC", "FEE_SOLD_ITEM", "FEE_ITEM", "FEE_ITEM_PERC") FROM stdin;
1	p	Predajca	0	10	0	0.10000000000000001	0
2	s	Dobrovolnik	0	10	0	0	0
3	d	Clen	0	0	0	0	0
\.


--
-- TOC entry 1814 (class 0 OID 16456)
-- Dependencies: 143
-- Data for Name: sellers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sellers ("SELLER_ID", "SHORT_CODE", "NAME", "COMMENT", "CHANGING", "CHANGED_BY", "SELLER_CATEGORY_ID", "MODIFIED", "STATUS") FROM stdin;
127	HA	Mgr. Soňa Berithová	0908 710 547  za MC Prijal:ctibor	f		1	2012-10-12 23:26:27+02	1
3	BE	Denisa Štefulová	421915089332.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-10 23:50:11+02	1
51	AAK	Gerhardová Marcela	0911 318 564, gerhardlubor@gmail.com za MC Prijal:ctibor	f		1	2012-10-11 20:58:13+02	1
52	MK	Ivana Dianová	0918 348 538, Iv88@azet.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 20:58:48+02	1
53	TM	Monika Hulmanová	0917 794 485 za MC prijal: !zatiaľ neprebrané!	f		1	2012-10-11 20:59:21+02	0
54	SC	Jana Jamborova	0908 171 654 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 20:59:56+02	1
4	BM	Dana Ševčikova	0903 907 148 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:16:59+02	1
5	BT	Henrieta Krajčiová	908655421.00 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova+janosik+riecicarova	f		1	2012-10-11 18:17:46+02	1
41	CS	Renáta Vraníková	090418733 za MC Prijal:ctibor	f		2	2012-10-11 20:51:25+02	1
68	KZ	Žaneta Múdra Šebíková	0915895833 za MC Prijal:ctibor	f		1	2012-10-11 21:13:10+02	1
6	DC	Eva Bachratá	0948 041 446, evka.bachrata@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:18:35+02	1
7	DZ	Adriana Gagová	0910920150        adrianaluptak@yahoo.com za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 18:19:05+02	1
8	EK	Lenka Rebrová	0908286335, llienka@centrum.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:19:26+02	1
9	EM	martin matúška	0911 116 616 za MC Prijal:ctibor	f		1	2012-10-11 18:19:50+02	1
26	SK	sona kovacova	0904487077 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		2	2012-10-11 19:30:26+02	1
11	HAS	Ivana Fraňová	0918 346 801, f.ivana@email.cz za MC Prijal:ctibor	f		1	2012-10-11 18:22:01+02	1
12	HB	patricie kepeňová	0911 116 616 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 18:22:27+02	1
37	TK	Monika Kútna	0903 503425 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		2	2012-10-11 20:43:02+02	1
14	PE	Jana Betáková	0905681843, betinka11@azet.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:25:11+02	1
15	TZ	Janka Martáková	0907365163 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:25:38+02	1
18	ZB	Tatiana korosová	0949 294 677 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:26:39+02	1
19	ZC	Ludmila Zovčáková	0904 873 803 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:27:24+02	1
20	ZS	Zuzana Bocková	0904 653 143 za MC prijal: !zatiaľ neprebrané! Prijal:ctibor	f		1	2012-10-11 18:27:51+02	1
22	KT	Mária Gašparíková	0905690593 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 18:30:51+02	1
23	KM	Miroslava Krecháčová	0907212318 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 18:32:13+02	1
24	HAA	Iveta Marčeková	0904937668 za MC prijal: !zatiaľ neprebrané! Prijal:Janosik	f		1	2012-10-11 18:33:01+02	1
25	BO	Jana Žáčiková	0903 152 521 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 18:33:11+02	1
27	EO	Eva Bohunická	 0904281801, evusig@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Miro	f		1	2012-10-11 19:31:59+02	1
28	OM	Miriam Hodálová	0915 980 645 za MC prijal: !zatiaľ neprebrané! Prijal:Janosik	f		1	2012-10-11 19:32:34+02	1
29	HV	Katarína Jedináková	0915515353 - harok poslany 2x pouzity novsi Prijal:Kristina	f		1	2012-10-11 19:33:00+02	1
30	MD	Zuzana Pavlová	0915559735 zuzka.pavlova@centrum.sk - 2x pouzity novsi Prijal:Vlasta	f		1	2012-10-11 19:34:55+02	1
31	HS	Naďa Dorňáková	0903/776457 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 19:36:19+02	1
39	AE	Gabriela Porubanová	0904/248722 za MC prijal: Prijal:ctibor	f		2	2012-10-11 20:44:55+02	1
33	VB	Tatiana Barnátková	0908714340,mail.bernatica@gmail.com za MC prijal: !zatiaľ neprebrané!	f	-	1	2012-10-11 19:37:10+02	0
34	AV	Adriana Brázdová	0903/225 604 za MC Prijal:ctibor	f		1	2012-10-11 19:38:40+02	1
36	KC	Mgr. Lenka Gajdošová	0905 628 635 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 20:42:41+02	1
38	CT	Jana Cifrová	902792122.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 20:44:20+02	1
40	DK	Lenka Petrechová	908104842.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 20:48:02+02	1
42	ABB	Betáková Petra	0902/333217 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 20:52:30+02	1
43	DB	Ivana Badejová	0915228252 za MC prijal: !zatiaľ neprebrané! Prijal:Janosik	f		1	2012-10-11 20:54:34+02	1
44	ABC	Lehocká Anna	0918894960 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 20:55:19+02	1
45	VA	Magda Gyurekova 	0907 706 796 za MC prijal: !zatiaľ neprebrané! Prijal:Janosik	f		1	2012-10-11 20:55:35+02	1
46	MA	Marcela Masaryková	911897200.00 za MC Prijal:ctibor	f		1	2012-10-11 20:56:02+02	1
47	AP	Darina Macharová	0907/356268 za MC Prijal:ctibor	f		1	2012-10-11 20:56:22+02	1
48	HO	Sedláčková Katarína	908097032.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 20:57:04+02	1
49	ABK	Petra Mešková	0903212762, p.meskova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 20:57:29+02	1
50	DT	Jana Marusincova	908760064.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 20:57:40+02	1
55	HAB	Švítelová Katarína	0908715631 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:00:17+02	1
56	BAA	Kirková Silvia	0904/686430 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:00:51+02	1
57	BZ	Katarína Macúchová	0905280960 za MC prijal: !zatiaľ neprebrané! Prijal:ctibor	f		1	2012-10-11 21:01:18+02	1
58	BAC	Martina Ondrejková	martinaondrejkova@azet.sk,0911 122 019 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:01:56+02	1
59	VK	Katarína Hečková	0915 653 394 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 21:02:58+02	1
2	JV	Júlia Jánošíková	0905850866 za MC Prijal:janosikova	f		3	2012-10-10 20:21:33+02	1
35	KB	Lenka KAMENSKÁ	0917-237 912 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		3	2012-10-11 20:41:28+02	1
17	VT	Vlasta Tvrdoňová	0904411114 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		3	2012-10-11 18:26:24+02	1
16	VZ	Vladimira Strmenska	0907767299 za MC Prijal:ctibor	f		3	2012-10-11 18:26:02+02	1
21	ZV	Pavol Tvrdoň	0904411114 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		3	2012-10-11 18:28:34+02	1
63	TA	Andrea Kohoutová	0908/6555 85 kohoutova.a@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 21:04:28+02	1
64	AC	Martina Mihulová	0944442276 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 21:04:52+02	1
65	AAE	Romana Franková	0914 298 007 za MC Prijal:ctibor	f		1	2012-10-11 21:05:16+02	1
66	TS	Martina Hujová	0907723197 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 21:07:32+02	1
69	VE	Silvia Hajdáková	0915 653 394, silvia.hajdakova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 21:19:11+02	1
70	AZ	Jana Novotná	0907203810,danko.a.janka@post.sk za MC  Prijal:ctibor	f		1	2012-10-11 21:19:49+02	1
71	ABM	Alena Matúšová	0908 195 886   alamat@centrum.sk za MC Prijal:ctibor	f		1	2012-10-11 21:20:21+02	1
73	KA	Ivana Ďurčeková	915872145.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:21:13+02	1
74	HD	Katarína Gavendová	0944202976, KatarinaG01@azet.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:22:25+02	1
75	ABT	Zuzana Martáková	0915829807 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 21:23:08+02	1
76	BBB	Lenka Víghová	0907 369 282 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:23:25+02	1
92	AM	Lenka Vraníková	Prijal:janosikova	f		2	2012-10-11 21:55:24+02	1
86	OB	Monika Samáková	0904 460 794 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		2	2012-10-11 21:28:38+02	1
80	AAM	Paulína Zemanová	0908 447 294, paula.zemanova@centrum.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:24:59+02	1
82	CAA	Janečková Lenka	0908116002, janeckova.maned@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:26:57+02	1
83	EAC	Ďurinová Jaroslava	0907 220 795 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:27:33+02	1
84	OZ	Ivana Nováková	0908713978 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:27:53+02	1
85	CAE	Simona Nagyova	0905/892382 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:28:19+02	1
87	EAR	Denisa Balažovjechová	0911787563 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:29:09+02	1
89	AK	Katarína Talčíková	0911 670 400 za MC prijal: !zatiaľ neprebrané! Prijal:ctibor	f		2	2012-10-11 21:49:32+02	1
106	EAA	ERIKA KOVACOVA	910659863.00 za MC Prijal:ctibor	f		2	2012-10-11 22:45:53+02	1
91	BBS	Iveta Megne	0915357224 za MC prijal: !zatiaľ neprebrané!	f	-	1	2012-10-11 21:54:25+02	0
93	AS	Jana Kiačiková	421905928993.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 21:55:48+02	1
94	AAB	Eva Guzoňová	915533413.00 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 22:39:17+02	1
95	ABS	Michal Vavruš	0905/245 854, nada.vavrusova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 22:39:43+02	1
96	BB	Martina Mitýľová	0903 130 359 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 22:41:09+02	1
97	BBV	Sylvia Kobidová	Mobil 0905 328 922 za MC prijal: Prijal:ctibor	f		1	2012-10-11 22:41:24+02	1
98	BC	Martina Mitýľová	0903 130 359 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 22:41:48+02	1
99	BS	Adela Krihová (0907738875)	907738875.00 za MC prijal: !zatiaľ neprebrané! Prijal:Miro	f		1	2012-10-11 22:42:15+02	1
100	BV	Miriam KRIŠTOFOVÁ	421907841187, kristofovami@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 22:42:29+02	1
101	CAR	Katarína Körmendyová	907531000.00 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		1	2012-10-11 22:42:57+02	1
122	AT	Jana Lesajová	0904 555 850 za MC Prijal:ctibor	f		3	2012-10-12 22:59:22+02	1
103	CM	Diana Vylámová	903724851.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 22:43:56+02	1
104	CV	Alica Lopatková	903628984.00 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		1	2012-10-11 22:44:12+02	1
105	DE	Sykorova Ivana	904317663.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 22:45:01+02	1
107	HAZ	Monika Varghová	0905 737 624, trencin17@azet.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 22:46:16+02	1
108	MJ	Zuzana Dinkova Gasparovicova	908742913.00 za MC prijal: !zatiaľ neprebrané! Prijal:Miro	f		1	2012-10-11 22:52:43+02	1
109	MO	Jana Višnovská	0911231936 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 22:53:10+02	1
110	OV	MONIKA GÁLOVÁ	0911-031104, monica.galova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 22:53:38+02	1
111	PA	Jana Zámečníková	0907648962 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 22:54:36+02	1
112	PC	Smolková Anna	902385417.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 22:54:54+02	1
113	SA	Zuzana Straková	0949 252 589 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 22:55:17+02	1
124	DEM	Adriana Demjanovicova	 za MC Prijal:ctibor	f		3	2012-10-12 23:07:17+02	1
115	SR	Naďa Vavrušová	0905/245 854, nada.vavrusova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 22:55:54+02	1
116	TR	Barbora Tomanová	0903266952 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 22:56:07+02	1
117	VCXX	HELENA POLIČKOVÁ	0949-556741 za MC prijal: !zatiaľ neprebrané!	f		1	2012-10-11 22:57:26+02	0
119	ZT	Lenka Montskova	0917621512 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 23:06:22+02	1
1	JJ	Júlia Jánošíková	0905850866 za MC prijal: - Prijal:janosikova	f		3	2012-10-10 20:21:27+02	1
78	LK	Lucia Stanková	0918 789 104 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		3	2012-10-11 21:24:04+02	1
118	VS	Ctibor Strmensky	0907767299 za MC Prijal:ctibor	f		3	2012-10-11 22:57:58+02	1
81	HAC	Chvílová Daniela	0918875618 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		2	2012-10-11 21:25:21+02	1
128	HAR	Baláž Jozef	0911251219 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-12 23:27:27+02	1
121	APE	LENKA BERKYOVA	0904494580 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-12 22:58:17+02	1
138	SV	Viera Turčáková	0948379980, vierka01@gmail.com za MC Prijal:ctibor	f		1	2012-10-12 23:41:55+02	1
140	HBA	Monika Jánska	0905 183 714 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		2	2012-10-12 23:46:34+02	1
120	AAR	Chlebanová Petra	0911251219 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-12 22:56:29+02	1
77	HCA	Lucia Horvátová	0903772502 lucka1812@gmail.com za MC Prijal:ctibor	f		1	2012-10-11 21:23:42+02	1
142	CAB	marta moskova	904141111.00 za MC Prijal:ctibor	f		1	2012-10-13 00:06:25+02	1
143	XX	Nový predajca	za MC prijal: !zatiaľ neprebrané!	f	-	1	2012-10-13 00:08:08+02	0
67	BA	Nikoleta Mistríková	905573350.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 21:08:35+02	1
125	DR	Iveta Žáčiková	0903 416 055, ivetzac@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-12 23:13:34+02	1
126	EB	Martina KUKUČKOVÁ 	0905 749 396, bckukuckova@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-12 23:14:43+02	1
10	ER	monika vinterová	0911 116 616 za MC Prijal:ctibor	f		1	2012-10-11 18:20:19+02	1
129	HBC	Natália Sopková	0907508326 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-12 23:28:56+02	1
130	HK	Andrea Ondrášková	0904 339 379 za MC prijal: !zatiaľ neprebrané!	f	-	1	2012-10-12 23:33:16+02	0
131	HR	Drahomíra Chrenková	0905551124, 0903806987 za MC prijal: !zatiaľ neprebrané! Prijal:Janosik	f		1	2012-10-12 23:35:14+02	1
132	HVB	Erika Melišová	0903 429 592 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-12 23:36:14+02	1
133	KE	Hostakova Tatiana	0918 909 433 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-12 23:37:01+02	1
62	TB	Peter Kohout	0905/76 37 98 kohout.mail@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-11 21:04:03+02	1
134	KR	Lenka Dvorská	0911300003 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-12 23:38:14+02	1
135	MZ	Alexandra Marková	0904498180 za MC prijal: !zatiaľ neprebrané! Prijal:Kristina	f		1	2012-10-12 23:39:04+02	1
102	CB	Katarína Novosádová	907493746.00 za MC prijal: !zatiaľ neprebrané! Prijal:Janosikova	f		1	2012-10-11 22:43:36+02	1
136	OP	Jaroslava Rendlová	0905941859 za MC prijal: !zatiaľ neprebrané! Prijal:Miro	f		1	2012-10-12 23:39:46+02	1
137	PZ	Kuželová Soňa	0903 539 998 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-12 23:40:27+02	1
60	SD	Stanislava Pizúrová	0949169048 za MC Prijal:ctibor	f		1	2012-10-11 21:03:17+02	1
141	ZM	Zuzana Macák	905657614.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-13 00:03:44+02	1
144	KAB 	Ľudmila Kacejová	915782041.00 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-13 00:14:08+02	1
90	BAB	Miroslava Piscová	0903/771723, piscova@email.cz za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 21:50:13+02	1
72	CR	Marušincová Anna	0908772546 za MC prijal: Prijal:Kristina	f		2	2012-10-11 21:20:56+02	1
61	BBA	Prokopová Jana	0907204173 za MC prijal: !zatiaľ neprebrané! Prijal:janosikova	f		1	2012-10-11 21:03:40+02	1
32	CZ	Ľudmila Hodálová	0907 507 832, lhodalova@vsm.sk za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		2	2012-10-11 19:36:42+02	1
88	AAA	Miriam Volníková	0908 506 611, mvolnikova@gmail.com za MC Prijal:ctibor	f		1	2012-10-11 21:47:44+02	1
139	ZZ	Zovčáková Andrea	0911 373 372 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		2	2012-10-12 23:42:28+02	1
123	BAT	Koprivová Gabriela	0903 843015 za MC prijal: !zatiaľ neprebrané! Prijal:janosik+katka	f		2	2012-10-12 23:00:47+02	1
79	OA	Ivana Strápková- sympatizant 	0917/483 921, yvana76@gmail.com za MC prijal: !zatiaľ neprebrané! Prijal:janosik+riecicarova	f		3	2012-10-11 21:24:29+02	1
13	MB	Mgr.Marcela Beníčková	0903 907 148 za MC prijal: !zatiaľ neprebrané! Prijal:Vlasta	f		1	2012-10-11 18:24:03+02	1
145	MC-59	Rama Raja	Nestandardny kod	f	-	1	2012-10-13 13:18:41+02	0
\.


--
-- TOC entry 1804 (class 2606 OID 16426)
-- Dependencies: 140 140
-- Name: item category id is unique; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY item_category
    ADD CONSTRAINT "item category id is unique" PRIMARY KEY ("ID");


--
-- TOC entry 1806 (class 2606 OID 16441)
-- Dependencies: 141 141
-- Name: item id is unique; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY items
    ADD CONSTRAINT "item id is unique" PRIMARY KEY ("ITEM_ID");


--
-- TOC entry 1808 (class 2606 OID 16455)
-- Dependencies: 142 142
-- Name: seller category id is unique; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY seller_category
    ADD CONSTRAINT "seller category id is unique" PRIMARY KEY ("ID");


--
-- TOC entry 1810 (class 2606 OID 16466)
-- Dependencies: 143 143
-- Name: seller id is unique; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sellers
    ADD CONSTRAINT "seller id is unique" PRIMARY KEY ("SELLER_ID");


--
-- TOC entry 1818 (class 0 OID 0)
-- Dependencies: 3
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- TOC entry 1820 (class 0 OID 0)
-- Dependencies: 140
-- Name: item_category; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE item_category FROM PUBLIC;
REVOKE ALL ON TABLE item_category FROM postgres;
GRANT ALL ON TABLE item_category TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,UPDATE ON TABLE item_category TO PUBLIC;


--
-- TOC entry 1822 (class 0 OID 0)
-- Dependencies: 141
-- Name: items; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE items FROM PUBLIC;
REVOKE ALL ON TABLE items FROM postgres;
GRANT ALL ON TABLE items TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,UPDATE ON TABLE items TO PUBLIC;


--
-- TOC entry 1829 (class 0 OID 0)
-- Dependencies: 142
-- Name: seller_category; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE seller_category FROM PUBLIC;
REVOKE ALL ON TABLE seller_category FROM postgres;
GRANT ALL ON TABLE seller_category TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,UPDATE ON TABLE seller_category TO PUBLIC;


--
-- TOC entry 1831 (class 0 OID 0)
-- Dependencies: 143
-- Name: sellers; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE sellers FROM PUBLIC;
REVOKE ALL ON TABLE sellers FROM postgres;
GRANT ALL ON TABLE sellers TO postgres;
GRANT SELECT,INSERT,REFERENCES,DELETE,UPDATE ON TABLE sellers TO PUBLIC;


-- Completed on 2012-10-14 16:57:12 CEST

--
-- PostgreSQL database dump complete
--

